package com.hb.AutoComplete.controller;


import com.hb.AutoComplete.dropdown.model.DropDownReqResTO;
import com.hb.AutoComplete.dto.AutoCompleteDropdownTO;
import com.hb.AutoComplete.service.AutoCompleteDropdownService;
import com.hb.common.ResponseDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;


@RestController
@RequestMapping("/auto-complete")
public class AutoCompleteDropdownController {

    @Autowired
    private AutoCompleteDropdownService autoCompleteDropdownService;

    @RequestMapping(value = "/dropdown", method = RequestMethod.POST, name = "AutoComplete Dropdown(Dependency)->ACDD")
    public ResponseEntity<?> searchList(@RequestBody DropDownReqResTO dropDownReqRes)
            throws Exception {
        List<AutoCompleteDropdownTO> list = this.autoCompleteDropdownService.searchList(dropDownReqRes);
        ResponseDTO response = ResponseDTO.responseBuilder(200, "COM11","/auto-complete", "list", list);
        return new ResponseEntity<ResponseDTO>(response, HttpStatus.OK);
    }

    @RequestMapping(value = "/labelById", method = RequestMethod.POST, name = "Label By Id(Dependency)->ACDD")
    public ResponseEntity<?> labelById(@RequestBody DropDownReqResTO dropDownReqRes) throws Exception {
        AutoCompleteDropdownTO labelData = this.autoCompleteDropdownService.labelById(dropDownReqRes);
        ResponseDTO response = ResponseDTO.responseBuilder(200, "COM11","/auto-complete", "list", labelData);

        return new ResponseEntity<ResponseDTO>(response, HttpStatus.OK);
    }

    @RequestMapping(value = "/labelByIdList", method = RequestMethod.POST, name = "Label By Id List(Dependency)->ACDD")
    public ResponseEntity<?> labelByIdList(@RequestBody DropDownReqResTO dropDownReqRes) throws Exception {
        List<AutoCompleteDropdownTO> list = this.autoCompleteDropdownService.labelByIdList(dropDownReqRes);
        ResponseDTO response = ResponseDTO.responseBuilder(200, "COM11","/auto-complete", "list", list);

        return new ResponseEntity<ResponseDTO>(response, HttpStatus.OK);
    }

    @RequestMapping(value = "/labelByCode", method = RequestMethod.POST, name = "Label By Code(Dependency)->ACDD")
    public ResponseEntity<?> labelByCode(@RequestBody DropDownReqResTO dropDownReqRes) throws Exception {
        AutoCompleteDropdownTO labelData = this.autoCompleteDropdownService.labelByCode(dropDownReqRes);
        ResponseDTO response = ResponseDTO.responseBuilder(200, "COM11","/auto-complete", "list", labelData);

        return new ResponseEntity<ResponseDTO>(response, HttpStatus.OK);
    }
    }

