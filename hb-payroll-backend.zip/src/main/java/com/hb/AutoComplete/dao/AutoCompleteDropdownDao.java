package com.hb.AutoComplete.dao;



import com.hb.AutoComplete.dropdown.model.*;
import com.hb.address.entity.CountriesBO;


import java.util.List;


public interface AutoCompleteDropdownDao {
	PincodeDropdownBO pincode(DropDownReqResTO dropDownReqRes);

	List<PincodeDropdownBO> getPincodeList(DropDownReqResTO dropDownReqRes);
	List<CityDropdownBO> getCitiesList(DropDownReqResTO dropDownReqRes);
	CityDropdownBO city(DropDownReqResTO dropDownReqRes);
	StateDropdownBO state(DropDownReqResTO dropDownReqRes);
	List<StateDropdownBO> getStatesList(DropDownReqResTO dropDownReqRes);
	List<ContryDropdownBO> getCountrysList(DropDownReqResTO dropDownReqRes);
	CountriesBO country(DropDownReqResTO dropDownReqRes);
	ContryDropdownBO countryById(DropDownReqResTO dropDownReqRes);
	PincodeDropdownBO pincodeById(DropDownReqResTO dropDownReqRes);
	CityDropdownBO cityById(DropDownReqResTO dropDownReqRes);
}