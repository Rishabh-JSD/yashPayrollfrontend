package com.hb.AutoComplete.dao;


import com.hb.AutoComplete.dropdown.model.*;

import com.hb.address.entity.CountriesBO;
import com.hb.common.CommonUtill;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import javax.persistence.criteria.*;

import java.util.*;

@Repository
public class AutoCompleteDropdownDaoImpl implements AutoCompleteDropdownDao {

    @PersistenceContext
    private EntityManager entityManager;


    @Override
    public List<PincodeDropdownBO> getPincodeList(DropDownReqResTO dropDownReqRes) {
        CriteriaBuilder queryBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<PincodeDropdownBO> criteriaQuery = queryBuilder.createQuery(PincodeDropdownBO.class);
        Root<PincodeDropdownBO> entityRoot = criteriaQuery.from(PincodeDropdownBO.class);
        ArrayList<Predicate> PredicateFilter = new ArrayList<>();
        if (dropDownReqRes != null && dropDownReqRes.getName() != null) {
            Predicate name = queryBuilder.like(entityRoot.get("label"), "%" + dropDownReqRes.getName().trim() + "%");
            PredicateFilter.add(queryBuilder.or(name));
        }
        criteriaQuery.where(PredicateFilter.toArray(new Predicate[0]));
        Order order = queryBuilder.asc(entityRoot.get("label"));
        criteriaQuery.orderBy(order);
        return entityManager.createQuery(criteriaQuery).setFirstResult(0).setMaxResults(20)
                .getResultList();
    }

    @Override
    public List<CityDropdownBO> getCitiesList(DropDownReqResTO dropDownReqRes) {
        CriteriaBuilder queryBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<CityDropdownBO> criteriaQuery = queryBuilder.createQuery(CityDropdownBO.class);
        Root<CityDropdownBO> entityRoot = criteriaQuery.from(CityDropdownBO.class);
        ArrayList<Predicate> PredicateFilter = new ArrayList<>();
        if (dropDownReqRes != null && dropDownReqRes.getName() != null) {
            Predicate name = queryBuilder.like(entityRoot.get("label"), "%" + dropDownReqRes.getName().trim() + "%");
            PredicateFilter.add(queryBuilder.or(name));
        }
        criteriaQuery.where(PredicateFilter.toArray(new Predicate[0]));
        Order order = queryBuilder.asc(entityRoot.get("label"));
        criteriaQuery.orderBy(order);
        return entityManager.createQuery(criteriaQuery).setFirstResult(0).setMaxResults(20)
                .getResultList();
    }

    @Override
    public CityDropdownBO city(DropDownReqResTO dropDownReqRes) {
        CriteriaBuilder queryBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<CityDropdownBO> criteriaQuery = queryBuilder.createQuery(CityDropdownBO.class);
        Root<CityDropdownBO> entityRoot = criteriaQuery.from(CityDropdownBO.class);
        criteriaQuery.where(queryBuilder.equal(entityRoot.get("label"), dropDownReqRes.getName()));
        List<CityDropdownBO> list = entityManager.createQuery(criteriaQuery).setMaxResults(1).getResultList();

        return CommonUtill.getSingleResult(list);
    }

    @Override
    public StateDropdownBO state(DropDownReqResTO dropDownReqRes) {
        CriteriaBuilder queryBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<StateDropdownBO> criteriaQuery = queryBuilder.createQuery(StateDropdownBO.class);
        Root<StateDropdownBO> entityRoot = criteriaQuery.from(StateDropdownBO.class);
        criteriaQuery.where(queryBuilder.equal(entityRoot.get("label"), dropDownReqRes.getName()));
        List<StateDropdownBO> list = entityManager.createQuery(criteriaQuery).setMaxResults(1).getResultList();
        return CommonUtill.getSingleResult(list);
    }

    @Override
    public List<StateDropdownBO> getStatesList(DropDownReqResTO dropDownReqRes) {
        CriteriaBuilder queryBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<StateDropdownBO> criteriaQuery = queryBuilder.createQuery(StateDropdownBO.class);
        Root<StateDropdownBO> entityRoot = criteriaQuery.from(StateDropdownBO.class);
        ArrayList<Predicate> PredicateFilter = new ArrayList<>();
        if (dropDownReqRes != null && dropDownReqRes.getName() != null) {
            Predicate name = queryBuilder.like(entityRoot.get("label"), "%" + dropDownReqRes.getName().trim() + "%");
            PredicateFilter.add(queryBuilder.or(name));
        }
        criteriaQuery.where(PredicateFilter.toArray(new Predicate[0]));
        Order order = queryBuilder.asc(entityRoot.get("label"));
        criteriaQuery.orderBy(order);
        return entityManager.createQuery(criteriaQuery).setFirstResult(0).setMaxResults(20)
                .getResultList();
    }

    @Override
    public List<ContryDropdownBO> getCountrysList(DropDownReqResTO dropDownReqRes) {
        CriteriaBuilder queryBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<ContryDropdownBO> criteriaQuery = queryBuilder.createQuery(ContryDropdownBO.class);
        Root<ContryDropdownBO> entityRoot = criteriaQuery.from(ContryDropdownBO.class);
        ArrayList<Predicate> PredicateFilter = new ArrayList<>();
        if (dropDownReqRes != null && dropDownReqRes.getName() != null) {
            Predicate name = queryBuilder.like(entityRoot.get("label"), "%" + dropDownReqRes.getName().trim() + "%");
            PredicateFilter.add(queryBuilder.or(name));
        }
        criteriaQuery.where(PredicateFilter.toArray(new Predicate[0]));
        Order order = queryBuilder.asc(entityRoot.get("label"));
        criteriaQuery.orderBy(order);
        return entityManager.createQuery(criteriaQuery).setFirstResult(0).setMaxResults(20)
                .getResultList();
    }

    @Override
    public CountriesBO country(DropDownReqResTO dropDownReqRes) {
        CriteriaBuilder queryBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<CountriesBO> criteriaQuery = queryBuilder.createQuery(CountriesBO.class);
        Root<CountriesBO> entityRoot = criteriaQuery.from(CountriesBO.class);
        criteriaQuery.where(queryBuilder.equal(entityRoot.get("countryName"), dropDownReqRes.getName()));
        List<CountriesBO> list = entityManager.createQuery(criteriaQuery).setMaxResults(1).getResultList();

        return CommonUtill.getSingleResult(list);
    }

    @Override
    public ContryDropdownBO countryById(DropDownReqResTO dropDownReqRes) {
        return this.entityManager.find(ContryDropdownBO.class, dropDownReqRes.getId());
    }

    @Override
    public CityDropdownBO cityById(DropDownReqResTO dropDownReqRes) {
        return this.entityManager.find(CityDropdownBO.class, dropDownReqRes.getId());
    }

    @Override
    public PincodeDropdownBO pincodeById(DropDownReqResTO dropDownReqRes) {
        return this.entityManager.find(PincodeDropdownBO.class, dropDownReqRes.getId());
    }

    @Override
    public PincodeDropdownBO pincode(DropDownReqResTO dropDownReqRes) {
        CriteriaBuilder queryBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<PincodeDropdownBO> criteriaQuery = queryBuilder.createQuery(PincodeDropdownBO.class);
        Root<PincodeDropdownBO> entityRoot = criteriaQuery.from(PincodeDropdownBO.class);
        criteriaQuery.where(queryBuilder.equal(entityRoot.get("label"), dropDownReqRes.getName()));
        List<PincodeDropdownBO> list = entityManager.createQuery(criteriaQuery).setMaxResults(1).getResultList();

        return CommonUtill.getSingleResult(list);
    }
}