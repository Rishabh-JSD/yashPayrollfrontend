package com.hb.AutoComplete.dropdown.model;


import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Setter
@Getter
@ToString
public class DropDownReqResTO {
    String name;
    String code;
    String type;
    String inventoryType;
    Integer id;
    double value;
    boolean getAll;
    String contactName;
    boolean parentMenuCheck;
    boolean childCheck;
    Integer inventoryId;
    ArrayList<Integer> idList;
    ArrayList<Integer> menuIdList;
    List<Boolean> activeList;
    ArrayList<Integer> includeIdList;
    ArrayList<Integer> excludeIdList;
    boolean manufacturedFlag;
    boolean employeeCheck;
    boolean vendorCheck;
    boolean customerCheck;
    boolean notCustomerCheck;
    boolean hoFlag;
    boolean allData;
    boolean withBom;
    boolean newBom;
    boolean forHo;
    boolean onlySingleLevel;
    Integer contactId;
    Integer parentCatOptionId;
    Integer segParentCatOptionId;
    Integer attributeId;
    Integer selectedBranchContactId;
    Integer selectedBranchId;
    Integer selectedWarehouseId;
    Integer selectedContactId;
    Integer xBranchCode;
    boolean withValuation;

    String companyGstin;
    boolean codeAsLabel;
    String nature;
    String childType;
    String wmsParentType;
    Integer wmsParentId;
    Integer baseUnitId;
    Integer wmsRootParentId;
    Integer wmsRootId;
    String storageType;
    String wmsSelectionType;
    String providerName;
    Integer wmsRootPId;
    String parentCode;
    String bomUseAt;
    Integer accountId ;
    boolean valueAsId;
    Integer parentId;
    boolean onlyBranch;
    boolean isParentProject;
    Integer  parentProjectId;
    String bomType;
    boolean taskFromProjectFlag;
    //    @Rajnish Kumar
    boolean productionInventory;
    boolean partial_complete;
    boolean jobCardFlag;
    private Integer departmentId;
    Integer projectId;
    Integer buildingBlockId;
    Integer masterId;
    Integer paymentPlanId;
    Integer paymentPlanTemplateId;
    String moduleCode;
    Integer page;
    Integer limit;
    Date date;
    String hsn;
    boolean parentProjectFlag;
    boolean projectFlag;
    boolean edit;

    String groupWise;

    //@author Rakshit
    private List<Integer>restrictBom ;
    private Boolean processCard ;
    public DropDownReqResTO() {
    }

    public Integer getxBranchCode() {
        return xBranchCode;
    }

    public void setxBranchCode(Integer xBranchCode) {
        this.xBranchCode = xBranchCode;
    }

    public DropDownReqResTO(String type, Integer id) {
        this.type = type;
        this.id = id;

    }
    
    // for logistics
    String searchType;
    String searchField;
    String selectedId;
    String selectingId;
    Integer contactRoleId;
    String pincode;
    String subAccCode;
    boolean productionEntry;
}
