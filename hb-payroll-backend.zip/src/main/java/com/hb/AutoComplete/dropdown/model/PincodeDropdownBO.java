package com.hb.AutoComplete.dropdown.model;


import com.hb.common.TABLES;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Setter
@Getter
@Table(name= TABLES.PINCODE)
public class PincodeDropdownBO {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id", updatable = false)
	private Integer id;

	@Column(name = "pincode")
	private String label;

}
