package com.hb.AutoComplete.dto;


import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class AutoCompleteDropdownTO {
    private Integer id;
    private String code;
    private String label;

    private String state;
    private String country;
    private String city;
    private String address;
    private String pinCode;
}
