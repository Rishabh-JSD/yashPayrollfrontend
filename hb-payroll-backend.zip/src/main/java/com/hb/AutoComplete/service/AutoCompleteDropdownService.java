package com.hb.AutoComplete.service;


import com.hb.AutoComplete.dropdown.model.DropDownReqResTO;
import com.hb.AutoComplete.dto.AutoCompleteDropdownTO;

import java.util.List;

public interface AutoCompleteDropdownService {
	List<AutoCompleteDropdownTO> searchList(DropDownReqResTO dropDownReqRes);

	AutoCompleteDropdownTO labelById(DropDownReqResTO dropDownReqRes);

	List<AutoCompleteDropdownTO> labelByIdList(DropDownReqResTO dropDownReqRes);

	AutoCompleteDropdownTO labelByCode(DropDownReqResTO dropDownReqRes);

	String labelByTypeId(String typeCode, Integer id, Double value);
}
