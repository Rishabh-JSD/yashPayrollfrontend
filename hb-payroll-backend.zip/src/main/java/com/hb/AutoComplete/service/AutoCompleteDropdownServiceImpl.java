package com.hb.AutoComplete.service;

import com.hb.AutoComplete.dao.AutoCompleteDropdownDao;
import com.hb.AutoComplete.dropdown.model.*;
import com.hb.AutoComplete.dto.AutoCompleteDropdownTO;
import com.hb.address.entity.CountriesBO;
import com.hb.common.AutoCompleteType;
import com.hb.common.MapperService;
import com.hb.common.CommonUtill;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;

import java.util.*;

@Service
@Transactional
public class AutoCompleteDropdownServiceImpl implements AutoCompleteDropdownService {

    @Autowired
    private MapperService modelConvertorService;

    @Autowired
    private AutoCompleteDropdownDao autoCompleteDropdownDao;
    @Override
    @Transactional(Transactional.TxType.NOT_SUPPORTED)
    public List<AutoCompleteDropdownTO> searchList(DropDownReqResTO dropDownReqRes) {
        List<AutoCompleteDropdownTO> list = new ArrayList<>();
        if (dropDownReqRes.getType() != null && !dropDownReqRes.getType().isEmpty()) {
            switch (dropDownReqRes.getType()) {

                case AutoCompleteType.PINCODE: {
                    List<PincodeDropdownBO> pincodeList = autoCompleteDropdownDao.getPincodeList(dropDownReqRes);
                    list = modelConvertorService.map(pincodeList, AutoCompleteDropdownTO.class);
                    for (int i = 0; i < pincodeList.size(); i++) {
                        list.get(i).setCode(pincodeList.get(i).getLabel());
                    }
                    break;
                }
                case AutoCompleteType.CITY: {
                    List<CityDropdownBO> citiesList = autoCompleteDropdownDao.getCitiesList(dropDownReqRes);
                    list = modelConvertorService.map(citiesList, AutoCompleteDropdownTO.class);
                    for (int i = 0; i < citiesList.size(); i++) {
                        list.get(i).setCode(citiesList.get(i).getLabel());
                    }
                    break;
                }
                case AutoCompleteType.STATE: {
                    List<StateDropdownBO> stateList = autoCompleteDropdownDao.getStatesList(dropDownReqRes);
                    list = modelConvertorService.map(stateList, AutoCompleteDropdownTO.class);
                    for (int i = 0; i < stateList.size(); i++) {
                        list.get(i).setCode(stateList.get(i).getLabel());
                    }
                    break;
                }
                case AutoCompleteType.COUNTRY: {
                    List<ContryDropdownBO> ContryList = autoCompleteDropdownDao.getCountrysList(dropDownReqRes);
                    list = modelConvertorService.map(ContryList, AutoCompleteDropdownTO.class);
                    for (int i = 0; i < ContryList.size(); i++) {
                        list.get(i).setCode(ContryList.get(i).getLabel());
                    }
                    break;
                }

            }
        }
        return list;
    }




    @Override
    @Transactional(Transactional.TxType.NOT_SUPPORTED)
    public AutoCompleteDropdownTO labelById(DropDownReqResTO dropDownReqRes) {
        AutoCompleteDropdownTO labelData = null;
        if (dropDownReqRes.getType() != null && !dropDownReqRes.getType().isEmpty()) {
            switch (dropDownReqRes.getType()) {
                case AutoCompleteType.COUNTRY: {
                    labelData = modelConvertorService.map(autoCompleteDropdownDao.countryById(dropDownReqRes), AutoCompleteDropdownTO.class);
                    break;
                }
                case AutoCompleteType.CITY: {
                    labelData = modelConvertorService.map(autoCompleteDropdownDao.cityById(dropDownReqRes), AutoCompleteDropdownTO.class);
                    break;
                }
                case AutoCompleteType.PINCODE: {
                    labelData = modelConvertorService.map(autoCompleteDropdownDao.pincodeById(dropDownReqRes), AutoCompleteDropdownTO.class);
                    break;
                }

            }
        }
        return labelData;
    }

    @Override
    public List<AutoCompleteDropdownTO> labelByIdList(DropDownReqResTO dropDownReqRes) {
        return null;
    }


    @Override
    public AutoCompleteDropdownTO labelByCode(DropDownReqResTO dropDownReqRes) {
        AutoCompleteDropdownTO labelData = null;
        if (dropDownReqRes.getType() != null && !dropDownReqRes.getType().isEmpty()
                && dropDownReqRes.getName() != null) {
            switch (dropDownReqRes.getType()) {

                case AutoCompleteType.PINCODE: {
                    labelData = modelConvertorService.map(autoCompleteDropdownDao.pincode(dropDownReqRes),
                            AutoCompleteDropdownTO.class);
                    break;
                }
                case AutoCompleteType.CITY: {
                    labelData = modelConvertorService.map(autoCompleteDropdownDao.city(dropDownReqRes),
                            AutoCompleteDropdownTO.class);
                    break;
                }
                case AutoCompleteType.STATE: {
                    labelData = modelConvertorService.map(autoCompleteDropdownDao.state(dropDownReqRes),
                            AutoCompleteDropdownTO.class);
                    break;
                }

                case AutoCompleteType.COUNTRY: {
                    CountriesBO countriesBOLocal = autoCompleteDropdownDao.country(dropDownReqRes);
                    if (CommonUtill.checkNullEmpty(countriesBOLocal)) {
                        labelData = modelConvertorService.map(countriesBOLocal, AutoCompleteDropdownTO.class);
                        labelData.setLabel(countriesBOLocal.getName());
                        break;
                    }
                }

            }
        }
        return labelData;
    }

    @Override
    public String labelByTypeId(String typeCode, Integer id, Double value) {
        return null;
    }
}






