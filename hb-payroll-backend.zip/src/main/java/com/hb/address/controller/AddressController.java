package com.hb.address.controller;

import com.hb.address.dto.*;
import com.hb.address.service.AddressService;
import com.hb.common.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/address")
public class AddressController {

  @Autowired
  private Validator addressValidator;

  @Autowired
  private AddressService addressService;

  private ResponseDTO responseDTO;

  @InitBinder
  private void initBinder(WebDataBinder binder) {
    binder.setValidator(addressValidator);
  }

  @RequestMapping(value = "/add", method = RequestMethod.POST, name = "Address Master Add->ADDCR")
  public ResponseEntity<?> addAddress(@Valid @RequestBody AddressTO addressTO, Errors errors) {
    if (errors.hasErrors()) {
      ValidationError validationError = ValidationError.fromBindingErrors(errors);
      return new ResponseEntity<>(validationError, HttpStatus.OK);
    }
    AddressTO addressTO_return = addressService.addAddress(addressTO);
    responseDTO = ResponseDTO.responseBuilder(200, "PR001", "/address", "address", addressTO_return);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/update", method = RequestMethod.POST, name = "Address Master Update->ADDCR")
  public ResponseEntity<?> updateAddress(@Valid @RequestBody AddressTO addressTO, Errors errors) {
    if (errors.hasErrors()) {
      ValidationError validationError = ValidationError.fromBindingErrors(errors);
      return new ResponseEntity<>(validationError, HttpStatus.OK);
    }
    AddressTO addressTO_return = addressService.updateAddress(addressTO);
    responseDTO = ResponseDTO.responseBuilder(200, "PR002", "/address", "address", addressTO_return);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/list", method = RequestMethod.POST, name = "Address Master List->ADDCR")
  public ResponseEntity<?> getAddressList(@RequestBody PaginationCriteria paginationCriteria) {
    SearchResponseTO searchResponseTO = addressService.getAddressList(paginationCriteria);
    if (searchResponseTO.getList() == null || searchResponseTO.getList().isEmpty()) {
      responseDTO = ResponseDTO.responseBuilder(200, "PR006", "/address", "address", searchResponseTO);
      return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }
    responseDTO = ResponseDTO.responseBuilder(200, "PR003", "/address", "address", searchResponseTO);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/{id}", method = RequestMethod.GET, name = "Address Master View->ADDCR")
  public ResponseEntity<?> getAddressById(@PathVariable Integer id) {
    AddressTO addressTO = addressService.getAddressById(id);
    if (addressTO == null) {
      responseDTO = ResponseDTO.responseBuilder(200, "PR007", "/address", "address", null);
      return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }
    responseDTO = ResponseDTO.responseBuilder(200, "PR004", "/address", "address", addressTO);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/delete", method = RequestMethod.DELETE, name = "Address Master Delete->ADDCR")
  public ResponseEntity<?> deleteAddress(@RequestParam(name = "addressId") List<Integer> addressId) {
    addressService.deleteAddress(addressId);
    responseDTO = ResponseDTO.responseBuilder(200, "PR005", "/address", "address", addressId);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

//  @RequestMapping(value = "/pincode-details/{pincode}", method = RequestMethod.GET, name = "Pincode Details(Dependency)->ADDCR")
//  public ResponseEntity<?> getPincodeDetails(@PathVariable("pincode") int pincode) {
//    responseDTO = ResponseDTO.responseBuilder(200, "PR004", "/address", "address", addressService.getPincodeRelatedData(pincode));
//    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
//  }

  @RequestMapping(value = "/city-list", method = RequestMethod.POST, name = "Address Master List->ADDCR")
  public ResponseEntity<?> getCityList(@RequestBody(required = false) String sortField) {
    List<CitiesTO> citiesTOList = addressService.getCityList(sortField);
    if (citiesTOList == null || citiesTOList.isEmpty()) {
      responseDTO = ResponseDTO.responseBuilder(200, "PR006", "/address/city-list", "city", citiesTOList);
      return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }
    responseDTO = ResponseDTO.responseBuilder(200, "PR003", "/address/city-list", "city", citiesTOList);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/city/{id}", method = RequestMethod.GET, name = "Address Master View->ADDCR")
  public ResponseEntity<?> getCityById(@PathVariable Long id) {
    CitiesTO citiesTO = addressService.getCityById(id);
    if (citiesTO == null) {
      responseDTO = ResponseDTO.responseBuilder(200, "PR007", "/address/city", "city", null);
      return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }
    responseDTO = ResponseDTO.responseBuilder(200, "PR004", "/address/city", "city", citiesTO);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/country-list", method = RequestMethod.POST, name = "Address Master List->ADDCR")
  public ResponseEntity<?> getCountryList(@RequestBody(required = false) String sortField) {
    List<CountriesTO> countriesTOList = addressService.getCountryList(sortField);
    if (countriesTOList == null || countriesTOList.isEmpty()) {
      responseDTO = ResponseDTO.responseBuilder(200, "PR006", "/address/country-list", "country", countriesTOList);
      return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }
    responseDTO = ResponseDTO.responseBuilder(200, "PR003", "/address/country-list", "country", countriesTOList);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/country/{id}", method = RequestMethod.GET, name = "Address Master View->ADDCR")
  public ResponseEntity<?> getCountryById(@PathVariable Long id) {
    CountriesTO countriesTO = addressService.getCountryById(id);
    if (countriesTO == null) {
      responseDTO = ResponseDTO.responseBuilder(200, "PR007", "/address/country", "country", null);
      return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }
    responseDTO = ResponseDTO.responseBuilder(200, "PR004", "/address/country", "country", countriesTO);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/pincode-list", method = RequestMethod.POST, name = "Address Master List->ADDCR")
  public ResponseEntity<?> getPincodeList(@RequestBody(required = false) String sortField) {
    List<PincodeTO> pincodeTOList = addressService.getPincodeList(sortField);
    if (pincodeTOList == null || pincodeTOList.isEmpty()) {
      responseDTO = ResponseDTO.responseBuilder(200, "PR006", "/address/pincode-list", "pincode", pincodeTOList);
      return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }
    responseDTO = ResponseDTO.responseBuilder(200, "PR003", "/address/pincode-list", "pincode", pincodeTOList);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/pincode/{id}", method = RequestMethod.GET, name = "Address Master View->ADDCR")
  public ResponseEntity<?> getPincodeById(@PathVariable Long id) {
    PincodeTO pincodeTO = addressService.getPincodeById(id);
    if (pincodeTO == null) {
      responseDTO = ResponseDTO.responseBuilder(200, "PR007", "/address/pincode", "pincode", null);
      return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }
    responseDTO = ResponseDTO.responseBuilder(200, "PR004", "/address/pincode", "pincode", pincodeTO);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/state-list", method = RequestMethod.GET, name = "Address Master List->ADDCR")
  public ResponseEntity<?> getStateList() {
    List<StatesTO> statesTOList = addressService.getStateList();
    if (statesTOList == null || statesTOList.isEmpty()) {
      responseDTO = ResponseDTO.responseBuilder(200, "PR006", "/address/state-list", "state", statesTOList);
      return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }
    responseDTO = ResponseDTO.responseBuilder(200, "PR003", "/address/state-list", "state", statesTOList);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/state/{id}", method = RequestMethod.GET, name = "Address Master View->ADDCR")
  public ResponseEntity<?> getStateById(@PathVariable Long id) {
    StatesTO statesTO = addressService.getStateById(id);
    if (statesTO == null) {
      responseDTO = ResponseDTO.responseBuilder(200, "PR007", "/address/state", "state", null);
      return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }
    responseDTO = ResponseDTO.responseBuilder(200, "PR004", "/address/state", "state", statesTO);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }
}
