package com.hb.address.dao;

import com.hb.address.entity.*;
import com.hb.common.PaginationCriteria;
import com.hb.master.dto.CommonListTO;

import java.util.List;

public interface AddressDao {

  AddressBO addAddress(AddressBO addressTO);

  AddressBO updateAddress(AddressBO addressTO);

  CommonListTO<AddressBO> getAddressList(PaginationCriteria paginationCriteria);

  AddressBO getAddressById(Integer id);

  void deleteAddress(List<Integer> id);

  List<CitiesBO> getCityList(String sortField);

  CitiesBO getCityById(Long id);

  List<CountriesBO> getCountryList(String sortField);

  CountriesBO getCountryById(Long id);

  List<PincodeBO> getPincodeList(String sortField);

  PincodeBO getPincodeById(Long id);

  List<StatesBO> getStateList();

  StatesBO getStateById(Long id);
}
