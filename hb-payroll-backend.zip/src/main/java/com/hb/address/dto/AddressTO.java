package com.hb.address.dto;

import com.hb.common.AuditTO;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AddressTO extends AuditTO {

  private Long id;
  private String addressOne;
  private String addressTwo;
  private Long cityId;
  private String cityName;
  private Long pincodeId;
  private String pincode;
  private Long stateId;
  private String stateName;
  private Long countryId;
  private String countryName;
  private boolean deleteFlag;

}
