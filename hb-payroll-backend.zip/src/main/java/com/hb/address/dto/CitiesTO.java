package com.hb.address.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CitiesTO {

  private Long id;
  private Long stateId;
  private String name;
  private String countryCode;
}
