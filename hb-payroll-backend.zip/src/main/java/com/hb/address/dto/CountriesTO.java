package com.hb.address.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CountriesTO {

  private Long id;
  private String shortName;
  private String name;
  private int phoneCode;
}
