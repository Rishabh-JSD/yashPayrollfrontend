package com.hb.address.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PincodeTO {

  private Long id;
  private String pincode;
  private Long cityId;
}
