package com.hb.address.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class StatesTO {

  private Long id;
  private Long countryId;
  private String countryCode;
  private String name;
  private String stateAbbrevCode;
  private String gstinPrefix;
  private int stateCode;
}
