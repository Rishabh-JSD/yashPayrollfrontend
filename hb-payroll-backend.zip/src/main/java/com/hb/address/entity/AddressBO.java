package com.hb.address.entity;

import com.hb.common.Audit;
import com.hb.common.TABLES;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = TABLES.ADDRESS)
public class AddressBO extends Audit {

  private static final long serialVersionUID = 3935672606438086598L;

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "id", updatable = false)
  private Long id;

  @Column(name = "address_one")
  private String addressOne;

  @Column(name = "address_two")
  private String addressTwo;

  @Column(name = "city_id")
  private Long cityId;

  @Column(name = "pincode_id")
  private Long pincodeId;

  @Column(name = "state_id")
  private Long stateId;

  @Column(name = "country_id")
  private Long countryId;

  @Column(name = "delete_flag")
  private boolean deleteFlag;

}
