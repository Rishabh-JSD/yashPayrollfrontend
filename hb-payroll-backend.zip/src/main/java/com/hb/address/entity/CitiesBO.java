package com.hb.address.entity;

import com.hb.common.TABLES;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;

@Getter
@Setter
@Entity
@Table(name = TABLES.CITIES)
public class CitiesBO implements Serializable {

  private static final long serialVersionUID = -6384072555216311690L;

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "id", updatable = false)
  private Long id;

  @Column(name = "state_id")
  private Long stateId;

  @Column(name = "name")
  private String name;

  @Column(name = "country_code")
  private String countryCode;
}
