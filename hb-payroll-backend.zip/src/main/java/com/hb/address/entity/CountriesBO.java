package com.hb.address.entity;

import com.hb.common.TABLES;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;

@Getter
@Setter
@Entity
@Table(name = TABLES.COUNTRIES)
public class CountriesBO implements Serializable {

  private static final long serialVersionUID = -6099715771312350615L;

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "id", updatable = false)
  private Long id;

  @Column(name = "short_name")
  private String shortName;

  @Column(name = "name")
  private String name;

  @Column(name = "phone_code")
  private int phoneCode;
}
