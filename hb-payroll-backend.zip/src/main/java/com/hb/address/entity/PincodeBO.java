package com.hb.address.entity;

import com.hb.common.TABLES;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;

@Getter
@Setter
@Entity
@Table(name = TABLES.PINCODE)
public class PincodeBO implements Serializable {

  private static final long serialVersionUID = 3092237520452423249L;

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "id", updatable = false)
  private Long id;

  @Column(name = "pincode")
  private String pincode;

  @Column(name = "city_id")
  private Long cityId;
}
