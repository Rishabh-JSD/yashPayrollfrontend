package com.hb.address.entity;

import com.hb.common.TABLES;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;

@Getter
@Setter
@Entity
@Table(name = TABLES.STATES)
public class StatesBO implements Serializable {

  private static final long serialVersionUID = -7191989511770737307L;

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "id", updatable = false)
  private Long id;

  @Column(name = "country_id")
  private Long countryId;

  @Column(name = "country_code")
  private String countryCode;

  @Column(name = "name")
  private String name;

  @Column(name = "state_abbrev_code")
  private String stateAbbrevCode;

  @Column(name = "gstin_prefix")
  private String gstinPrefix;

  @Column(name = "state_code")
  private int stateCode;
}
