package com.hb.address.service;

import com.hb.address.dto.*;
import com.hb.common.PaginationCriteria;
import com.hb.common.SearchResponseTO;

import java.util.List;

public interface AddressService {

  AddressTO addAddress(AddressTO addressTO);

  AddressTO updateAddress(AddressTO addressTO);

  SearchResponseTO getAddressList(PaginationCriteria paginationCriteria);

  AddressTO getAddressById(Integer id);

  void deleteAddress(List<Integer> addressId);

  List<CitiesTO> getCityList(String sortField);

  CitiesTO getCityById(Long id);

  List<CountriesTO> getCountryList(String sortField);

  CountriesTO getCountryById(Long id);

  List<PincodeTO> getPincodeList(String sortField);

  PincodeTO getPincodeById(Long id);

  List<StatesTO> getStateList();

  StatesTO getStateById(Long id);
}
