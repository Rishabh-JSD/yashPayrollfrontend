package com.hb.address.service;

import com.hb.address.dao.AddressDao;
import com.hb.address.dto.*;
import com.hb.address.entity.AddressBO;
import com.hb.common.MapperService;
import com.hb.common.PaginationCriteria;
import com.hb.common.SearchResponseTO;
import com.hb.master.dto.CommonListTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;

@Service
@Transactional
public class AddressServiceImpl implements AddressService {

  @Autowired
  private AddressDao addressDao;

  @Autowired
  private MapperService mapperService;

  @Override
  public AddressTO addAddress(AddressTO addressTO) {
    AddressBO addressBO = mapperService.map(addressTO, AddressBO.class);
    return mapperService.map(addressDao.addAddress(addressBO), AddressTO.class);
  }

  @Override
  public AddressTO updateAddress(AddressTO addressTO) {
    AddressBO addressBO = mapperService.map(addressTO, AddressBO.class);
    return mapperService.map(addressDao.updateAddress(addressBO), AddressTO.class);
  }

  @Override
  @Transactional(Transactional.TxType.NOT_SUPPORTED)
  public SearchResponseTO getAddressList(PaginationCriteria paginationCriteria) {
    SearchResponseTO searchResponseTO = new SearchResponseTO();
    CommonListTO<AddressBO> commonListTO = addressDao.getAddressList(paginationCriteria);

    List<AddressTO> addressTOS = mapperService.map(commonListTO.getDataList(), AddressTO.class);
    searchResponseTO.setList(addressTOS);
    searchResponseTO.setPageCount(commonListTO.getPageCount());
    searchResponseTO.setTotalRowCount(commonListTO.getTotalRow().intValue());
    return searchResponseTO;
  }

  @Override
  @Transactional(Transactional.TxType.NOT_SUPPORTED)
  public AddressTO getAddressById(Integer id) {
    return mapperService.map(addressDao.getAddressById(id), AddressTO.class);
  }

  @Override
  public void deleteAddress(List<Integer> id) {
    addressDao.deleteAddress(id);
  }

  @Override
  public List<CitiesTO> getCityList(String sortField) {
    return mapperService.map(addressDao.getCityList(sortField), CitiesTO.class);
  }

  @Override
  public CitiesTO getCityById(Long id) {
    return mapperService.map(addressDao.getCityById(id), CitiesTO.class);
  }

  @Override
  public List<CountriesTO> getCountryList(String sortField) {
    return mapperService.map(addressDao.getCountryList(sortField), CountriesTO.class);
  }

  @Override
  public CountriesTO getCountryById(Long id) {
    return mapperService.map(addressDao.getCountryById(id), CountriesTO.class);
  }

  @Override
  public List<PincodeTO> getPincodeList(String sortField) {
    return mapperService.map(addressDao.getPincodeList(sortField), PincodeTO.class);
  }

  @Override
  public PincodeTO getPincodeById(Long id) {
    return mapperService.map(addressDao.getPincodeById(id), PincodeTO.class);
  }

  @Override
  public List<StatesTO> getStateList() {
    return mapperService.map(addressDao.getStateList(), StatesTO.class);
  }

  @Override
  public StatesTO getStateById(Long id) {
    return mapperService.map(addressDao.getStateById(id), StatesTO.class);
  }
}
