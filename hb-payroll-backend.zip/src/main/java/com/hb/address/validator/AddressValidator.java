package com.hb.address.validator;

import com.hb.address.controller.AddressController;
import com.hb.address.dto.AddressTO;
import com.hb.common.PaginationCriteria;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.ControllerAdvice;

@ControllerAdvice(assignableTypes = AddressController.class)
public class AddressValidator implements Validator {

  @Override
  public boolean supports(Class<?> aClass) {
    boolean support = AddressTO.class.equals(aClass);
    if (!support) {
      support = PaginationCriteria.class.equals(aClass);
    }
    if (!support) {
      support = String.class.equals(aClass);
    }
    return support;
  }

  @Override
  public void validate(Object o, Errors errors) {
    AddressTO addressTO = (AddressTO) o;

//    ValidationUtils.rejectIfEmptyOrWhitespace(errors, "name", "PMS001E", APP_MSG.MESSAGE.get("PR001E"));

  }
}
