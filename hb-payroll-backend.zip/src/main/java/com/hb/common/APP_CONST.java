package com.hb.common;

public class APP_CONST {

	public static final class HEADER {

		public static final String PRESERVE_KEY_HEADER = "x-preserveKey";

		public static final String INVITE_ACCOUNT_HEADER = "x-account_id";

		public static final String AUTH_TOKEN = "x-auth-token";

		public static final String TENANT_HEADER = "x-business-uuid";

		public static final String CAT_HEADER = "x-category";

		public static final String CAT_CHILD_HEADER = "x-category-child";

		public static final String HTTP_ALLOWED_METHODS = "GET,POST,PUT,DELETE,OPTIONS";

		public static final String ACCESS_CONTROL_ALLOW_ORIGIN = "Access-Control-Allow-Origin";

		public static final String HTTP_ALLOWED_HEADERS = "Content-Type, X-Requested-With, accept,Origin, Access-Control-Request-Method, "
				+ "Access-Control-Request-Headers," + AUTH_TOKEN + "," + TENANT_HEADER + "," + CAT_HEADER + ","
				+ CAT_CHILD_HEADER + "," + INVITE_ACCOUNT_HEADER + "," + PRESERVE_KEY_HEADER + "," + ACCESS_CONTROL_ALLOW_ORIGIN;

		public static final String CORS_CONFIG_ORIGIN = "*";

		public static final String CORS_CONFIG_PATH = "/**";

	}

	public static final String DEFAULT_LOGIN_DB = "hb-payroll-master";

	public final static String DEFAULT_TENANT = "LOGIN";

	public static final String TOKEN_KEY = "TokenValid";

	public static final String TOKEN_KEY_FLAG = "F";

	public static final String PRESERVE_KEY = "KeyValid";

	public static final String PRESERVE_KEY_FLAG = "F";

	public static final String KEY = "12";
}
