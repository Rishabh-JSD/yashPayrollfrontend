package com.hb.common;

import java.util.HashMap;
import java.util.Map;

public class APP_MSG {

	public static final Map<String, String> VALIDATION = new HashMap<>();

	public static final Map<String, String> RESPONSE = new HashMap<>();

	public static final String HELP = "support@hostbooks.com";

	static {
		VALIDATION.put("GL001", "UNAUTHORIZED Request");
		RESPONSE.put("U001", "User List get Successfully");
		
		RESPONSE.put("PR001", "Created successfully!");
		RESPONSE.put("PR002", "Updated successfully!");
		RESPONSE.put("PR003", "Fetched List!");
		RESPONSE.put("PR004", "Selected section!");
		RESPONSE.put("PR005", "Deleted successfully!");
		RESPONSE.put("PR006", "Empty List!");
		RESPONSE.put("PR007", "Not Found!");
		RESPONSE.put("PR008", "Fetched Result!");
		RESPONSE.put("PR001E", "Required Field!");
		RESPONSE.put("PR002E", "Must be unique!");
	}

}
