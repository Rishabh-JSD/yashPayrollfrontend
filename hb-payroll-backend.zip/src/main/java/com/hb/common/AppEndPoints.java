package com.hb.common;

public class AppEndPoints {

	public static final class USER {
		public static final String BODY_KEY = "user";
		public static final String DEFAULT = "/user";
		public static final String USER_LIST = "/list";
		public static final String USER_BY_ID = "/{id}";

	}
}
