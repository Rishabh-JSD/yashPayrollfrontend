package com.hb.common;

import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;

import com.hb.config.UserSessionContext;

public class AuditListenerHandler {

	@PrePersist
	public void onPrePersist(Audit audit) {
		if (audit != null) {
			audit.setCreatedBy(UserSessionContext.getCurrentTenant().getUserId());
			audit.setUpdatedBy(UserSessionContext.getCurrentTenant().getUserId());
		}
	}

	@PreUpdate
	public void onPreUpdate(Audit audit) {
		if (audit != null) {
			audit.setUpdatedBy(UserSessionContext.getCurrentTenant().getUserId());
		}
	}
}
