package com.hb.common;

import lombok.Getter;
import lombok.Setter;

import java.util.Date;

@Getter
@Setter
public class AuditLoginTO {

  private Date createdAt;

  private Long createdBy;

  private Date updatedAt;

  private Long updatedBy;

}
