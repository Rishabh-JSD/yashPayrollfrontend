package com.hb.common;

public class AutoCompleteType {

    public static final String CITY = "CITY";
    public static final String STATE = "STATE";
    public static final String COUNTRY = "COUNTRY";
    public static final String PINCODE = "PINCODE";

}
