package com.hb.common;

import java.util.List;

public class CommonUtill {

	public static boolean isValid(String value) {
		return value != null && !value.isEmpty();
	}

	public static <T> boolean isValid(List<T> list) {
		return list != null && !list.isEmpty();
	}

	public static boolean checkNullEmpty(Object obj) {
		return (obj != null && !obj.toString().isEmpty());
	}

	public static <T> T getSingleResult(List<T> resultList) {
		if (checkNullEmpty(resultList)) {
			return resultList.get(0);
		}
		return null;
	}
}
