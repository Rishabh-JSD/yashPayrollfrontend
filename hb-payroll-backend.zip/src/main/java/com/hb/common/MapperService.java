package com.hb.common;

import java.util.Collection;
import java.util.List;

public interface MapperService {

	<D, T> D map(T entity, Class<D> outClass);

	<D, T> List<D> map(Collection<T> entityList, Class<D> outCLass);

}
