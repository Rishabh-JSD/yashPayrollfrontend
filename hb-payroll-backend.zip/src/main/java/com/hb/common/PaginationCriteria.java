package com.hb.common;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;

@Setter
@Getter
@ToString
public class PaginationCriteria implements Serializable {

  private static final long serialVersionUID = 4739016371276922686L;

  private int page;

  private int limit;

  private int firstLimit;

  private int endLimit;

  private int sortType;

  private String sortField;

  private String searchFor;

  private Long id;

  private Long departmentId;
}
