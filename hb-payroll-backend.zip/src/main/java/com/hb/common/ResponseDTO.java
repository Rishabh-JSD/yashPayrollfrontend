package com.hb.common;

import java.util.HashMap;
import java.util.Map;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class ResponseDTO {

	private int status;

	private String message;

	private String path;

	private String code;

	private Map<String, Object> data = new HashMap<>();

	public void putData(String key, Object Value) {
		data.put(key, Value);
	}

	public ResponseDTO() {
		super();
	}

	public ResponseDTO(int status, String code, String message) {
		super();
		this.status = status;
		this.code = code;
		this.message = message;
	}

	public static ResponseDTO responseBuilder(int status, String code, String path, String key, Object data) {
		ResponseDTO response = new ResponseDTO();
		response.setStatus(status);
		response.setPath(path);
		response.setMessage(APP_MSG.RESPONSE.get(code));
		response.setCode(code);
		response.putData(key, data);
		return response;
	}
}
