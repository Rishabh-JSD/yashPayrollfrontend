package com.hb.common;

public class TABLES {

	public static final String USERS = "users";
	public static final String ROLES = "roles";
	public static final String USER_ROLES = "user_roles";
	public static final String COMPANY = "company";
	public static final String USER_COMPANY = "user_company";
	public static final String MASTER_BUSINESS_DATASOURCE = "master_business_datasource";
	public static final String FIXED_MASTERS = "fixed_masters";
	public static final String ALLOWANCE_MASTER = "allowance_master";
	public static final String DEDUCTION_MASTER = "deduction_master";
	public static final String DESIGNATION_MASTER = "designation_master";
	public static final String DOCUMENT_CATEGORY_MASTER = "document_category_master";
	public static final String DOCUMENT_TYPE_MASTER = "document_type_master";
	public static final String EMPLOYEE_LEVEL_MASTER = "employee_level_master";
	public static final String EMPLOYMENT_STATUS_MASTER = "employment_status_master";
	public static final String PAY_FREQUENCY_MASTER = "pay_frequency_master";
	public static final String REIMBURSEMENT_MASTER = "reimbursement_master";
	public static final String SHIFT_TIMING_MASTER = "shift_timing_master";
	public static final String SHIFT_TYPE_MASTER = "shift_type_master";
	public static final String ADDRESS = "address";
	public static final String CITIES = "cities";
	public static final String COUNTRIES = "countries";
	public static final String PINCODE = "pincodes";
	public static final String STATES = "states";
	public static final String INDUSTRY = "industries";
	public static final String EMPLOYEE = "employee";
	public static final String EMPLOYEE_ACCOUNT = "employee_account";
	public static final String EMPLOYEE_COMPANY_DETAILS = "employee_company_detail";
	public static final String EMPLOYEE_EXPERIENCE = "employee_experience";
	public static final String EMPLOYEE_EXPERIENCE_ATTACHMENT = "employee_experience_attachment";
	public static final String EMPLOYEE_KYC = "employee_kyc";
	public static final String EMPLOYEE_QUALIFICATION = "employee_qualification";
	public static final String EMPLOYEE_REFERENCE = "employee_reference";
	public static final String EMPLOYEE_SALARY_DETAIL = "employee_salary_detail";
	public static final String EMPLOYEE_DEDUCTION = "employee_deduction";
	public static final String EMPLOYEE_REIMBURSEMENT = "employee_reimbursement";
	public static final String EMPLOYEE_ALLOWANCE = "employee_allowance";
	public static final String EMPLOYEE_CATEGORY = "employee_category";
	public static final String COMPANY_DYNAMIC_INFO = "company_dynamic_info";
	public static final String COMPANY_DYNAMIC_INFO_OPTION = "company_dynamic_info_option";
	public static final String BRANCH = "branch";
	public static final String COST_CENTER = "cost_center";
	public static final String PROFIT_CENTER = "profit_center";
	public static final String DEPARTMENT = "department";
	public static final String LOCATION = "location";
	public static final String LEAVE_TYPE = "leave_type";
	public static final String LEAVE_RULES = "leave_rules";
	public static final String LEAVERULES_DETAILS="leave_rules_details";
	public static final String PAYROLL_MASTER = "payroll_masters";
	public static final String PAYROLL_MASTER_OPTION = "payroll_masters_options";

}
