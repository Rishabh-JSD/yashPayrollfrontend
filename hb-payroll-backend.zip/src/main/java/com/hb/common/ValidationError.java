package com.hb.common;

import java.util.ArrayList;
import java.util.List;

import org.springframework.validation.Errors;
import org.springframework.validation.FieldError;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ValidationError {
	private int status;
	private String code;
	private String message;
	private Integer totalErrorCount;
	private List<FieldValidError> fieldErrors = new ArrayList<>();

	public static ValidationError fromBindingErrors(Errors errors) {

		ValidationError error = new ValidationError();
		Integer failObj = 0;
		error.setStatus(400);
		error.setCode("CM001E");
		error.setMessage(APP_MSG.RESPONSE.get("CM001E"));

		for (FieldError fieldError : errors.getFieldErrors()) {
			failObj++;
			FieldValidError fieldValidError = new FieldValidError();
			fieldValidError.setFieldName(fieldError.getField());
			fieldValidError.setMessage(fieldError.getDefaultMessage());
			error.getFieldErrors().add(fieldValidError);
		}
		error.setTotalErrorCount(failObj);
		return error;
	}

	public ValidationError(int status, String code, String message) {
		this.status = status;
		this.code = code;
		this.message = message;
	}
}
