package com.hb.common.controller;

import com.hb.common.ResponseDTO;
import com.hb.common.ValidationError;
import com.hb.common.dto.IndustryTO;
import com.hb.common.service.IndustryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/industry")
public class IndustryController {

  @Autowired
  private Validator industryValidator;

  @Autowired
  private IndustryService industryService;

  private ResponseDTO responseDTO;

  @InitBinder
  private void initBinder(WebDataBinder binder) {
    binder.setValidator(industryValidator);
  }

  @RequestMapping(value = "/add", method = RequestMethod.POST, name = "Industry Master Add->INDCR")
  public ResponseEntity<?> addIndustry(@Valid @RequestBody IndustryTO industryTO, Errors errors) {
    if (errors.hasErrors()) {
      ValidationError validationError = ValidationError.fromBindingErrors(errors);
      return new ResponseEntity<>(validationError, HttpStatus.OK);
    }
    IndustryTO industryTO_return = industryService.addIndustry(industryTO);
    responseDTO = ResponseDTO.responseBuilder(200, "PR001", "/industry", "industry", industryTO_return);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/update", method = RequestMethod.POST, name = "Industry Master Update->INDCR")
  public ResponseEntity<?> updateIndustry(@Valid @RequestBody IndustryTO industryTO, Errors errors) {
    if (errors.hasErrors()) {
      ValidationError validationError = ValidationError.fromBindingErrors(errors);
      return new ResponseEntity<>(validationError, HttpStatus.OK);
    }
    IndustryTO industryTO_return = industryService.updateIndustry(industryTO);
    responseDTO = ResponseDTO.responseBuilder(200, "PR002", "/industry", "industry", industryTO_return);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/list", method = RequestMethod.GET, name = "Industry Master List->INDCR")
  public ResponseEntity<?> getIndustryList() {
    List<IndustryTO> industryList = industryService.getIndustryList();
    if (industryList == null || industryList.isEmpty()) {
      responseDTO = ResponseDTO.responseBuilder(200, "PR006", "/industry-list", "industry", industryList);
      return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }
    responseDTO = ResponseDTO.responseBuilder(200, "PR003", "/industry-list", "industry", industryList);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/{id}", method = RequestMethod.GET, name = "Industry Master View->INDCR")
  public ResponseEntity<?> getIndustryById(@PathVariable Long id) {
    IndustryTO industryTO = industryService.getIndustryById(id);
    if (industryTO == null) {
      responseDTO = ResponseDTO.responseBuilder(200, "PR007", "/industry", "industry", null);
      return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }
    responseDTO = ResponseDTO.responseBuilder(200, "PR004", "/industry", "industry", industryTO);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/delete", method = RequestMethod.DELETE, name = "Industry Master Delete->INDCR")
  public ResponseEntity<?> deleteIndustry(@RequestParam(name = "industryId") List<Long> industryId) {
    industryService.deleteIndustry(industryId);
    responseDTO = ResponseDTO.responseBuilder(200, "PR005", "/industry", "industry", industryId);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }
}
