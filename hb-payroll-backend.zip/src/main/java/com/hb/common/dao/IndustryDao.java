package com.hb.common.dao;

import com.hb.common.entity.IndustryBO;

import java.util.List;

public interface IndustryDao {

  IndustryBO addIndustry(IndustryBO industryTO);

  IndustryBO updateIndustry(IndustryBO industryTO);

  List<IndustryBO> getIndustryList();

  IndustryBO getIndustryById(Long id);

  void deleteIndustry(List<Long> id);
}
