package com.hb.common.dao;

import com.hb.common.entity.IndustryBO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.*;
import java.util.List;

@Repository
public class IndustryDaoImpl implements IndustryDao {

  @PersistenceContext
  private EntityManager entityManager;

  private static final Logger logger = LoggerFactory.getLogger(IndustryDaoImpl.class);

  @Override
  public IndustryBO addIndustry(IndustryBO industryBO) {
    entityManager.persist(industryBO);
    logger.info("Industry has added successfully, Industry details=" + industryBO);
    return industryBO;
  }

  @Override
  public IndustryBO updateIndustry(IndustryBO industryBO) {
    entityManager.merge(industryBO);
    logger.info("Industry has updated successfully, Industry details=" + industryBO);
    return industryBO;
  }

  @Override
  public List<IndustryBO> getIndustryList() {
    CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
    CriteriaQuery<IndustryBO> criteriaQuery = criteriaBuilder.createQuery(IndustryBO.class);
    criteriaQuery.from(IndustryBO.class);
    return entityManager.createQuery(criteriaQuery).getResultList();
  }
  
  @Override
  public IndustryBO getIndustryById(Long id) {
    CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
    CriteriaQuery<IndustryBO> criteriaQuery = criteriaBuilder.createQuery(IndustryBO.class);

    Root<IndustryBO> root = criteriaQuery.from(IndustryBO.class);
    criteriaQuery.where(criteriaBuilder.equal(root.get("industryId"), id));
    return entityManager.createQuery(criteriaQuery).getSingleResult();
  }

  @Override
  public void deleteIndustry(List<Long> id) {
    CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
    CriteriaUpdate<IndustryBO> criteriaUpdate = criteriaBuilder.createCriteriaUpdate(IndustryBO.class);
    Root<IndustryBO> root = criteriaUpdate.from(IndustryBO.class);
    criteriaUpdate.set("deleteFlag", true);
    criteriaUpdate.where(root.get("industryId").in(id));
    entityManager.createQuery(criteriaUpdate).executeUpdate();
  }
}
