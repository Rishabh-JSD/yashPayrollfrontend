package com.hb.common.dto;

import com.hb.common.AuditLoginTO;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class IndustryTO extends AuditLoginTO {

  private Long industryId;
  private String code;
  private String name;
  private String description;
}
