package com.hb.common.entity;

import com.hb.common.AuditLogin;
import com.hb.common.TABLES;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.math.BigDecimal;

@Getter
@Setter
@Entity
@Table(name = TABLES.INDUSTRY)
public class IndustryBO extends AuditLogin {

  private static final long serialVersionUID = -2520281682613072155L;

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "industry_id", updatable = false)
  private Long industryId;

  @Column(name = "code")
  private String code;

  @Column(name = "name")
  private String name;

  @Column(name = "description")
  private String description;
}
