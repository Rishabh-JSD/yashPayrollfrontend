package com.hb.common.service;

import com.hb.common.dto.IndustryTO;

import java.util.List;

public interface IndustryService {

  IndustryTO addIndustry(IndustryTO industryTO);

  IndustryTO updateIndustry(IndustryTO industryTO);

  List<IndustryTO> getIndustryList();

  IndustryTO getIndustryById(Long id);

  void deleteIndustry(List<Long> industryId);
}
