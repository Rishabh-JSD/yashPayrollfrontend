package com.hb.common.service;

import com.hb.common.MapperService;
import com.hb.common.dao.IndustryDao;
import com.hb.common.dto.IndustryTO;
import com.hb.common.entity.IndustryBO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;

@Service
@Transactional
public class IndustryServiceImpl implements IndustryService {

  @Autowired
  private IndustryDao employeeDao;

  @Autowired
  private MapperService mapperService;

  @Override
  public IndustryTO addIndustry(IndustryTO employeeTO) {
    IndustryBO employeeBO = mapperService.map(employeeTO, IndustryBO.class);
    return mapperService.map(employeeDao.addIndustry(employeeBO), IndustryTO.class);
  }

  @Override
  public IndustryTO updateIndustry(IndustryTO employeeTO) {
    IndustryBO employeeBO = mapperService.map(employeeTO, IndustryBO.class);
    return mapperService.map(employeeDao.updateIndustry(employeeBO), IndustryTO.class);
  }

  @Override
  public List<IndustryTO> getIndustryList() {
    return mapperService.map(employeeDao.getIndustryList(), IndustryTO.class);
  }

  @Override
  @Transactional(Transactional.TxType.NOT_SUPPORTED)
  public IndustryTO getIndustryById(Long id) {
    return mapperService.map(employeeDao.getIndustryById(id), IndustryTO.class);
  }

  @Override
  public void deleteIndustry(List<Long> id) {
    employeeDao.deleteIndustry(id);
  }
}
