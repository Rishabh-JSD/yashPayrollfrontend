package com.hb.company.branch.controller;

import com.hb.common.PaginationCriteria;
import com.hb.common.ResponseDTO;
import com.hb.common.SearchResponseTO;
import com.hb.common.ValidationError;
import com.hb.company.branch.dto.BranchTO;
import com.hb.company.branch.dto.BranchLabelTO;
import com.hb.company.branch.service.BranchService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/branch")
public class BranchController {

  @Autowired
  private Validator branchValidator;

  @Autowired
  private BranchService branchService;

  private ResponseDTO responseDTO;

  @InitBinder
  private void initBinder(WebDataBinder binder) {
    binder.setValidator(branchValidator);
  }

  @RequestMapping(value = "/add", method = RequestMethod.POST, name = "Branch Master Add->BRCR")
  public ResponseEntity<?> addBranch(@Valid @RequestBody BranchTO branchTO, Errors errors) {
    if (errors.hasErrors()) {
      ValidationError validationError = ValidationError.fromBindingErrors(errors);
      return new ResponseEntity<>(validationError, HttpStatus.OK);
    }
    BranchTO branchTO_return = branchService.addBranch(branchTO);
    responseDTO = ResponseDTO.responseBuilder(200, "PR001", "/branch", "branch", branchTO_return);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/update", method = RequestMethod.POST, name = "Branch Master Update->BRCR")
  public ResponseEntity<?> updateBranch(@Valid @RequestBody BranchTO branchTO, Errors errors) {
    if (errors.hasErrors()) {
      ValidationError validationError = ValidationError.fromBindingErrors(errors);
      return new ResponseEntity<>(validationError, HttpStatus.OK);
    }
    BranchTO branchTO_return = branchService.updateBranch(branchTO);
    responseDTO = ResponseDTO.responseBuilder(200, "PR002", "/branch", "branch", branchTO_return);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/list", method = RequestMethod.POST, name = "Branch Master List->BRCR")
  public ResponseEntity<?> getBranchList(@RequestBody PaginationCriteria paginationCriteria) {
    SearchResponseTO searchResponseTO = branchService.getBranchList(paginationCriteria);
    if (searchResponseTO.getList() == null || searchResponseTO.getList().isEmpty()) {
      responseDTO = ResponseDTO.responseBuilder(200, "PR006", "/branch", "branch", searchResponseTO);
      return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }
    responseDTO = ResponseDTO.responseBuilder(200, "PR003", "/branch", "branch", searchResponseTO);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/{id}", method = RequestMethod.GET, name = "Branch Master View->BRCR")
  public ResponseEntity<?> getBranchById(@PathVariable Long id) {
    BranchTO branchTO = branchService.getBranchById(id);
    if (branchTO == null) {
      responseDTO = ResponseDTO.responseBuilder(200, "PR007", "/branch", "branch", null);
      return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }
    responseDTO = ResponseDTO.responseBuilder(200, "PR004", "/branch", "branch", branchTO);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/branchName/{id}", method = RequestMethod.GET, name = "Branch Master View->BRCR")
  public ResponseEntity<?> getBranchNameById(@PathVariable Long id) {
    BranchLabelTO branchLabelTO = branchService.getBranchNameById(id);
    if (branchLabelTO == null) {
      responseDTO = ResponseDTO.responseBuilder(200, "PR007", "/branch", "branch", null);
      return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }
    responseDTO = ResponseDTO.responseBuilder(200, "PR004", "/branch", "branch", branchLabelTO);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/delete", method = RequestMethod.DELETE, name = "Branch Master Delete->BRCR")
  public ResponseEntity<?> deleteBranch(@RequestParam(name = "branchId") List<Long> branchId) {
    branchService.deleteBranch(branchId);
    responseDTO = ResponseDTO.responseBuilder(200, "PR005", "/branch", "branch", branchId);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }
}
