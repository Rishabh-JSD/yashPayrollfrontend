package com.hb.company.branch.dao;

import com.hb.common.PaginationCriteria;
import com.hb.company.branch.entity.BranchBO;
import com.hb.company.branch.entity.BranchNameBO;
import com.hb.master.dto.CommonListTO;

import java.util.List;

public interface BranchDao {

  BranchBO addBranch(BranchBO branchTO);

  BranchBO updateBranch(BranchBO branchTO);

  CommonListTO<BranchBO> getBranchList(PaginationCriteria paginationCriteria);

  BranchBO getBranchById(Long id);

  BranchNameBO getBranchNameById(Long id);

  void deleteBranch(List<Long> id);

}
