package com.hb.company.branch.dao;

import com.hb.common.PaginationCriteria;
import com.hb.company.branch.entity.BranchBO;
import com.hb.company.branch.entity.BranchNameBO;
import com.hb.master.dto.CommonListTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.*;
import java.util.List;

@Repository
public class BranchDaoImpl implements BranchDao {

  @PersistenceContext
  private EntityManager entityManager;

  private static final Logger logger = LoggerFactory.getLogger(BranchDaoImpl.class);

  @Override
  public BranchBO addBranch(BranchBO branchBO) {
    entityManager.persist(branchBO);
    logger.info("Branch has added successfully, Branch details=" + branchBO);
    return branchBO;
  }

  @Override
  public BranchBO updateBranch(BranchBO branchBO) {
    entityManager.merge(branchBO);
    logger.info("Branch has updated successfully, Branch details=" + branchBO);
    return branchBO;
  }

  @Override
  public CommonListTO<BranchBO> getBranchList(PaginationCriteria paginationCriteria) {
    CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
    CriteriaQuery<BranchBO> criteriaQuery = criteriaBuilder.createQuery(BranchBO.class);
    Root<BranchBO> root = criteriaQuery.from(BranchBO.class);
    criteriaQuery.where(criteriaBuilder.equal(root.get("deleteFlag"), false));

    //condition for search
    if (paginationCriteria.getSearchFor() != null) {
      Path<String> pathName = root.get("name");
      Predicate predicateForName = criteriaBuilder.like(pathName, "%" + paginationCriteria.getSearchFor() + "%");
      // Assuming "deleteFlag" is the field representing the deletion status
      Path<Boolean> pathDeleteFlag = root.get("deleteFlag");
      Predicate predicateNotDeleted = criteriaBuilder.isFalse(pathDeleteFlag);
      criteriaQuery.where(criteriaBuilder.and(predicateForName, predicateNotDeleted));
    }

    // Condition for sorting.
    if (paginationCriteria.getSortField() != null && !paginationCriteria.getSortField().isEmpty()) {
      Order order;
      if (paginationCriteria.getSortType() == 2) {
        order = criteriaBuilder.desc(root.get(paginationCriteria.getSortField()));
      } else {
        order = criteriaBuilder.asc(root.get(paginationCriteria.getSortField()));
      }
      criteriaQuery.orderBy(order);
    } else {
      Order order = criteriaBuilder.desc(root.get("id"));
      criteriaQuery.orderBy(order);
    }

    // Adding Pagination total Count
    CommonListTO<BranchBO> commonListTO = new CommonListTO<>();
    CriteriaQuery<Long> criteriaQuery2 = criteriaBuilder.createQuery(Long.class);
    Root<BranchBO> root2 = criteriaQuery2.from(BranchBO.class);
    criteriaQuery2.where(criteriaBuilder.equal(root2.get("deleteFlag"), false));
    CriteriaQuery<Long> select = criteriaQuery2.select(criteriaBuilder.count(root2));
    Long count = entityManager.createQuery(select).getSingleResult();
    commonListTO.setTotalRow(count);
    int size = count.intValue();
    int limit = paginationCriteria.getLimit();
    if (limit != 0) {
      commonListTO.setPageCount((size + limit - 1) / limit);
    } else {
      commonListTO.setPageCount(1);
    }

    TypedQuery<BranchBO> typedQuery = entityManager.createQuery(criteriaQuery);
    // Condition for paging.
    if (paginationCriteria.getPage() != 0 && paginationCriteria.getLimit() > 0) {
      typedQuery.setFirstResult((paginationCriteria.getPage() - 1) * paginationCriteria.getLimit());
      typedQuery.setMaxResults(paginationCriteria.getLimit());
    }
    commonListTO.setDataList(typedQuery.getResultList());
    return commonListTO;
  }

  @Override
  public BranchBO getBranchById(Long id) {
    CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
    CriteriaQuery<BranchBO> criteriaQuery = criteriaBuilder.createQuery(BranchBO.class);

    Root<BranchBO> root = criteriaQuery.from(BranchBO.class);
    Predicate predicateForId = criteriaBuilder.equal(root.get("id"), id);
    Predicate predicateForDeleteFlag = criteriaBuilder.equal(root.get("deleteFlag"), false);
    Predicate predicate = criteriaBuilder.and(predicateForId, predicateForDeleteFlag);
    criteriaQuery.where(predicate);
    return entityManager.createQuery(criteriaQuery).getSingleResult();
  }

  @Override
  public BranchNameBO getBranchNameById(Long id) {
    CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
    CriteriaQuery<BranchNameBO> criteriaQuery = criteriaBuilder.createQuery(BranchNameBO.class);

    Root<BranchNameBO> root = criteriaQuery.from(BranchNameBO.class);
    Predicate predicateForId = criteriaBuilder.equal(root.get("id"), id);
    Predicate predicateForDeleteFlag = criteriaBuilder.equal(root.get("deleteFlag"), false);
    Predicate predicate = criteriaBuilder.and(predicateForId, predicateForDeleteFlag);
    criteriaQuery.where(predicate);
    return entityManager.createQuery(criteriaQuery).getSingleResult();
  }



  @Override
  public void deleteBranch(List<Long> id) {
    CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
    CriteriaUpdate<BranchBO> criteriaUpdate = criteriaBuilder.createCriteriaUpdate(BranchBO.class);
    Root<BranchBO> root = criteriaUpdate.from(BranchBO.class);
    criteriaUpdate.set("deleteFlag", true);
    criteriaUpdate.where(root.get("id").in(id));
    entityManager.createQuery(criteriaUpdate).executeUpdate();
  }
}
