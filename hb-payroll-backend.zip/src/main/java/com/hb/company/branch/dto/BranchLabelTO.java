package com.hb.company.branch.dto;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BranchLabelTO {
    private Long id;
    private String name;
    private boolean deleteFlag;
}
