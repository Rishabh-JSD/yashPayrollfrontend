package com.hb.company.branch.dto;

import com.hb.address.dto.AddressTO;
import com.hb.address.entity.AddressBO;
import com.hb.common.AuditTO;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
public class BranchTO extends AuditTO {

  private Long id;
  private String name;
  private String code;
  private String gstin;
  private Long addressId;
  private Long headId;
  private String headName;
  private Long phoneNo;
  private String email;
  private Long shiftTypeId;
  private Long shiftTimingId;
  private BigDecimal workingHours;
  private boolean deleteFlag;
  private AddressTO address;
  private Long totalEmployees;
}
