package com.hb.company.branch.entity;

import com.hb.address.entity.AddressBO;
import com.hb.common.Audit;
import com.hb.common.TABLES;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.math.BigDecimal;

@Getter
@Setter
@Entity
@Table(name = TABLES.BRANCH)
public class BranchBO extends Audit {

  private static final long serialVersionUID = -8594968278434644290L;

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "id", updatable = false)
  private Long id;

  @Column(name = "name")
  private String name;

  @Column(name = "code")
  private String code;

  @Column(name = "gstin")
  private String gstin;

  @Column(name = "address_id", insertable = false, updatable = false)
  private Long addressId;

  @Column(name = "head_id")
  private Long headId;

  @Column(name = "phone_no")
  private Long phoneNo;

  @Column(name = "email")
  private String email;

  @Column(name = "shift_type_id")
  private Long shiftTypeId;

  @Column(name = "shift_timing_id")
  private Long shiftTimingId;

  @Column(name = "working_hours")
  private BigDecimal workingHours;

  @Column(name = "delete_flag")
  private boolean deleteFlag;

  @OneToOne(cascade = CascadeType.ALL, orphanRemoval = true)
  @JoinColumn(name = "address_id")
  private AddressBO address;
}
