package com.hb.company.branch.entity;

import com.hb.common.TABLES;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = TABLES.BRANCH)
public class BranchNameBO {
    private static final long serialVersionUID = -8594968278434644290L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", updatable = false)
    private Long id;

    @Column(name = "name")
    private String name;

    @Column(name = "delete_flag")
    private boolean deleteFlag;

}
