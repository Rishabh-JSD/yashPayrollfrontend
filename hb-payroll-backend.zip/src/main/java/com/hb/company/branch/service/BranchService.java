package com.hb.company.branch.service;

import com.hb.common.PaginationCriteria;
import com.hb.common.SearchResponseTO;
import com.hb.company.branch.dto.BranchTO;
import com.hb.company.branch.dto.BranchLabelTO;


import java.util.List;

public interface BranchService {

  BranchTO addBranch(BranchTO branchTO);

  BranchTO updateBranch(BranchTO branchTO);

  SearchResponseTO getBranchList(PaginationCriteria paginationCriteria);

  BranchTO getBranchById(Long id);

  BranchLabelTO getBranchNameById(Long id);

  void deleteBranch(List<Long> branchId);
}
