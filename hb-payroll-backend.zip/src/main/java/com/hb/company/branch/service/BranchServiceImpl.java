package com.hb.company.branch.service;

import com.hb.address.service.AddressService;
import com.hb.common.MapperService;
import com.hb.common.PaginationCriteria;
import com.hb.common.SearchResponseTO;
import com.hb.company.branch.dao.BranchDao;
import com.hb.company.branch.dto.BranchTO;
import com.hb.company.branch.dto.BranchLabelTO;
import com.hb.company.branch.entity.BranchBO;
import com.hb.employee.dao.EmployeeDao;
import com.hb.employee.service.EmployeeService;
import com.hb.master.dto.CommonListTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;

@Service
@Transactional
public class BranchServiceImpl implements BranchService {

  @Autowired
  private BranchDao branchDao;

  @Autowired
  private EmployeeService employeeService;

  @Autowired
  private EmployeeDao employeeDao;

  @Autowired
  private AddressService addressService;

  @Autowired
  private MapperService mapperService;

  @Override
  public BranchTO addBranch(BranchTO branchTO) {
    BranchBO branchBO = mapperService.map(branchTO, BranchBO.class);
    return mapperService.map(branchDao.addBranch(branchBO), BranchTO.class);
  }

  @Override
  public BranchTO updateBranch(BranchTO branchTO) {
    BranchBO branchBO = mapperService.map(branchTO, BranchBO.class);
    return mapperService.map(branchDao.updateBranch(branchBO), BranchTO.class);
  }

  @Override
  @Transactional(Transactional.TxType.NOT_SUPPORTED)
  public SearchResponseTO getBranchList(PaginationCriteria paginationCriteria) {
    SearchResponseTO searchResponseTO = new SearchResponseTO();
    CommonListTO<BranchBO> commonListTO = branchDao.getBranchList(paginationCriteria);

    List<BranchTO> branchTOS = null;
    if (commonListTO.getDataList() != null && !commonListTO.getDataList().isEmpty()) {
      branchTOS = new ArrayList<>();
      for (BranchBO branchBO : commonListTO.getDataList()) {
        BranchTO branchTO = mapperService.map(branchBO, BranchTO.class);
        if (branchTO.getHeadId() != null) {
          branchTO.setHeadName(employeeService.getEmployeeById(branchTO.getHeadId()).getName());
        }
        if (branchTO.getAddress() != null) {
          if (branchTO.getAddress().getCityId() != null) {
            branchTO.getAddress().setCityName(addressService.getCityById(branchTO.getAddress().getCityId()).getName());
          }
          if (branchTO.getAddress().getStateId() != null) {
            branchTO.getAddress().setStateName(addressService.getStateById(branchTO.getAddress().getStateId()).getName());
          }
          if (branchTO.getAddress().getPincodeId() != null) {
            branchTO.getAddress().setPincode(addressService.getPincodeById(branchTO.getAddress().getPincodeId()).getPincode());
          }
          if (branchTO.getAddress().getCountryId() != null) {
            branchTO.getAddress().setCountryName(addressService.getCountryById(branchTO.getAddress().getCountryId()).getName());
          }
        }
        branchTO.setTotalEmployees(employeeDao.employeeCount(branchTO.getId(), "branch"));
        branchTOS.add(branchTO);
      }
    }
    searchResponseTO.setList(branchTOS);
    searchResponseTO.setPageCount(commonListTO.getPageCount());
    searchResponseTO.setTotalRowCount(commonListTO.getTotalRow().intValue());
    return searchResponseTO;
  }

  @Override
  @Transactional(Transactional.TxType.NOT_SUPPORTED)
  public BranchTO getBranchById(Long id) {
    BranchTO branchTO = mapperService.map(branchDao.getBranchById(id), BranchTO.class);
    if (branchTO.getHeadId() != null) {
      branchTO.setHeadName(employeeService.getEmployeeById(branchTO.getHeadId()).getName());
    }
    if (branchTO.getAddress() != null) {
      if (branchTO.getAddress().getCityId() != null) {
        branchTO.getAddress().setCityName(addressService.getCityById(branchTO.getAddress().getCityId()).getName());
      }
      if (branchTO.getAddress().getStateId() != null) {
        branchTO.getAddress().setStateName(addressService.getStateById(branchTO.getAddress().getStateId()).getName());
      }
      if (branchTO.getAddress().getPincodeId() != null) {
        branchTO.getAddress().setPincode(addressService.getPincodeById(branchTO.getAddress().getPincodeId()).getPincode());
      }
      if (branchTO.getAddress().getCountryId() != null) {
        branchTO.getAddress().setCountryName(addressService.getCountryById(branchTO.getAddress().getCountryId()).getName());
      }
    }
    return branchTO;
  }

  @Override
  @Transactional(Transactional.TxType.NOT_SUPPORTED)
  public BranchLabelTO getBranchNameById(Long id) {
    BranchLabelTO branchLabelTO = mapperService.map(branchDao.getBranchNameById(id), BranchLabelTO.class);
  return branchLabelTO;
  }


  @Override
  public void deleteBranch(List<Long> id) {
    branchDao.deleteBranch(id);
  }

}
