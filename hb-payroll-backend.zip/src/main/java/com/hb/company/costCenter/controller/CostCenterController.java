package com.hb.company.costCenter.controller;

import com.hb.common.PaginationCriteria;
import com.hb.common.ResponseDTO;
import com.hb.common.SearchResponseTO;
import com.hb.common.ValidationError;
import com.hb.company.costCenter.dto.CostCenterTO;
import com.hb.company.costCenter.service.CostCenterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/cost-center")
public class CostCenterController {

  @Autowired
  private Validator costCenterValidator;

  @Autowired
  private CostCenterService costCenterService;

  private ResponseDTO responseDTO;

  @InitBinder
  private void initBinder(WebDataBinder binder) {
    binder.setValidator(costCenterValidator);
  }

  @RequestMapping(value = "/add", method = RequestMethod.POST, name = "Cost Center Master Add->CCRCR")
  public ResponseEntity<?> addCostCenter(@Valid @RequestBody CostCenterTO costCenterTO, Errors errors) {
    if (errors.hasErrors()) {
      ValidationError validationError = ValidationError.fromBindingErrors(errors);
      return new ResponseEntity<>(validationError, HttpStatus.OK);
    }
    CostCenterTO costCenterTO_return = costCenterService.addCostCenter(costCenterTO);
    responseDTO = ResponseDTO.responseBuilder(200, "PR001", "/cost-center", "costCenter", costCenterTO_return);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/update", method = RequestMethod.POST, name = "Cost Center Master Update->CCRCR")
  public ResponseEntity<?> updateCostCenter(@Valid @RequestBody CostCenterTO costCenterTO, Errors errors) {
    if (errors.hasErrors()) {
      ValidationError validationError = ValidationError.fromBindingErrors(errors);
      return new ResponseEntity<>(validationError, HttpStatus.OK);
    }
    CostCenterTO costCenterTO_return = costCenterService.updateCostCenter(costCenterTO);
    responseDTO = ResponseDTO.responseBuilder(200, "PR002", "/cost-center", "costCenter", costCenterTO_return);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/list", method = RequestMethod.POST, name = "Cost Center Master List->CCRCR")
  public ResponseEntity<?> getCostCenterList(@RequestBody PaginationCriteria paginationCriteria) {
    SearchResponseTO searchResponseTO = costCenterService.getCostCenterList(paginationCriteria);
    if (searchResponseTO.getList() == null || searchResponseTO.getList().isEmpty()) {
      responseDTO = ResponseDTO.responseBuilder(200, "PR006", "/cost-center", "costCenter", searchResponseTO);
      return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }
    responseDTO = ResponseDTO.responseBuilder(200, "PR003", "/cost-center", "costCenter", searchResponseTO);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/{id}", method = RequestMethod.GET, name = "Cost Center Master View->CCRCR")
  public ResponseEntity<?> getCostCenterById(@PathVariable Long id) {
    CostCenterTO costCenterTO = costCenterService.getCostCenterById(id);
    if (costCenterTO == null) {
      responseDTO = ResponseDTO.responseBuilder(200, "PR007", "/cost-center", "costCenter", null);
      return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }
    responseDTO = ResponseDTO.responseBuilder(200, "PR004", "/cost-center", "costCenter", costCenterTO);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/delete", method = RequestMethod.DELETE, name = "Cost Center Master Delete->CCRCR")
  public ResponseEntity<?> deleteCostCenter(@RequestParam(name = "costCenterId") List<Long> costCenterId) {
    costCenterService.deleteCostCenter(costCenterId);
    responseDTO = ResponseDTO.responseBuilder(200, "PR005", "/cost-center", "costCenter", costCenterId);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }
}
