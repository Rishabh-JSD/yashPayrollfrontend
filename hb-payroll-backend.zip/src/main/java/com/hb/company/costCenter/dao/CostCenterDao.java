package com.hb.company.costCenter.dao;

import com.hb.common.PaginationCriteria;
import com.hb.company.costCenter.entity.CostCenterBO;
import com.hb.master.dto.CommonListTO;

import java.util.List;

public interface CostCenterDao {

  CostCenterBO addCostCenter(CostCenterBO costCenterTO);

  CostCenterBO updateCostCenter(CostCenterBO costCenterTO);

  CommonListTO<CostCenterBO> getCostCenterList(PaginationCriteria paginationCriteria);

  CostCenterBO getCostCenterById(Long id);

  void deleteCostCenter(List<Long> id);

}
