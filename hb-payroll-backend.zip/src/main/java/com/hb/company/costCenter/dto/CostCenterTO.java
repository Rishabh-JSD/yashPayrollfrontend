package com.hb.company.costCenter.dto;

import com.hb.address.dto.AddressTO;
import com.hb.address.entity.AddressBO;
import com.hb.common.AuditTO;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
public class CostCenterTO extends AuditTO {

  private Long id;
  private String name;
  private Long branchId;
  private String branchName;
  private boolean sameAsBranchFlag;
  private Long addressId;
  private Long headId;
  private String headName;
  private Long phoneNo;
  private String email;
  private Long shiftTypeId;
  private Long shiftTimingId;
  private BigDecimal workingHours;
  private boolean deleteFlag;
  private AddressTO address;
  private Long totalEmployees;
}
