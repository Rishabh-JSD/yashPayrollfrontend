package com.hb.company.costCenter.service;

import com.hb.common.PaginationCriteria;
import com.hb.common.SearchResponseTO;
import com.hb.company.costCenter.dto.CostCenterTO;

import java.util.List;

public interface CostCenterService {

  CostCenterTO addCostCenter(CostCenterTO costCenterTO);

  CostCenterTO updateCostCenter(CostCenterTO costCenterTO);

  SearchResponseTO getCostCenterList(PaginationCriteria paginationCriteria);

  CostCenterTO getCostCenterById(Long id);

  void deleteCostCenter(List<Long> costCenterId);
}
