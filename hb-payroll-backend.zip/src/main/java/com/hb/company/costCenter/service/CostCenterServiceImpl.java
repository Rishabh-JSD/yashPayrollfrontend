package com.hb.company.costCenter.service;

import com.hb.address.service.AddressService;
import com.hb.common.MapperService;
import com.hb.common.PaginationCriteria;
import com.hb.common.SearchResponseTO;
import com.hb.company.branch.service.BranchService;
import com.hb.company.costCenter.dao.CostCenterDao;
import com.hb.company.costCenter.dto.CostCenterTO;
import com.hb.company.costCenter.entity.CostCenterBO;
import com.hb.employee.dao.EmployeeDao;
import com.hb.employee.service.EmployeeService;
import com.hb.master.dto.CommonListTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;

@Service
@Transactional
public class CostCenterServiceImpl implements CostCenterService {

  @Autowired
  private CostCenterDao costCenterDao;

  @Autowired
  private EmployeeService employeeService;
  
  @Autowired
  private EmployeeDao employeeDao;

  @Autowired
  private BranchService branchService;

  @Autowired
  private AddressService addressService;

  @Autowired
  private MapperService mapperService;

  @Override
  public CostCenterTO addCostCenter(CostCenterTO costCenterTO) {
    CostCenterBO costCenterBO = mapperService.map(costCenterTO, CostCenterBO.class);
    return mapperService.map(costCenterDao.addCostCenter(costCenterBO), CostCenterTO.class);
  }

  @Override
  public CostCenterTO updateCostCenter(CostCenterTO costCenterTO) {
    CostCenterBO costCenterBO = mapperService.map(costCenterTO, CostCenterBO.class);
    return mapperService.map(costCenterDao.updateCostCenter(costCenterBO), CostCenterTO.class);
  }

  @Override
  @Transactional(Transactional.TxType.NOT_SUPPORTED)
  public SearchResponseTO getCostCenterList(PaginationCriteria paginationCriteria) {
    SearchResponseTO searchResponseTO = new SearchResponseTO();
    CommonListTO<CostCenterBO> commonListTO = costCenterDao.getCostCenterList(paginationCriteria);

    List<CostCenterTO> costCenterTOS = null;
    if (commonListTO.getDataList() != null && !commonListTO.getDataList().isEmpty()) {
      costCenterTOS = new ArrayList<>();
      for (CostCenterBO costCenterBO : commonListTO.getDataList()) {
        CostCenterTO costCenterTO = mapperService.map(costCenterBO, CostCenterTO.class);
        if (costCenterTO.getBranchId() != null) {
          costCenterTO.setBranchName(branchService.getBranchNameById(costCenterTO.getBranchId()).getName());
        }
        if (costCenterTO.getHeadId() != null) {
          costCenterTO.setHeadName(employeeService.getEmployeeNameById(costCenterTO.getHeadId()).getName());
        }
        if (costCenterTO.getAddress() != null) {
          if (costCenterTO.getAddress().getCityId() != null) {
            costCenterTO.getAddress().setCityName(addressService.getCityById(costCenterTO.getAddress().getCityId()).getName());
          }
          if (costCenterTO.getAddress().getStateId() != null) {
            costCenterTO.getAddress().setStateName(addressService.getStateById(costCenterTO.getAddress().getStateId()).getName());
          }
          if (costCenterTO.getAddress().getPincodeId() != null) {
            costCenterTO.getAddress().setPincode(addressService.getPincodeById(costCenterTO.getAddress().getPincodeId()).getPincode());
          }
          if (costCenterTO.getAddress().getCountryId() != null) {
            costCenterTO.getAddress().setCountryName(addressService.getCountryById(costCenterTO.getAddress().getCountryId()).getName());
          }
        }
        costCenterTO.setTotalEmployees(employeeDao.employeeCount(costCenterTO.getId(), "costCenter"));
        costCenterTOS.add(costCenterTO);
      }
    }
    searchResponseTO.setList(costCenterTOS);
    searchResponseTO.setPageCount(commonListTO.getPageCount());
    searchResponseTO.setTotalRowCount(commonListTO.getTotalRow().intValue());
    return searchResponseTO;
  }

  @Override
  @Transactional(Transactional.TxType.NOT_SUPPORTED)
  public CostCenterTO getCostCenterById(Long id) {
    CostCenterTO costCenterTO = mapperService.map(costCenterDao.getCostCenterById(id), CostCenterTO.class);
    if (costCenterTO.getBranchId() != null) {
      costCenterTO.setBranchName(branchService.getBranchById(costCenterTO.getBranchId()).getName());
    }
    if (costCenterTO.getHeadId() != null) {
      costCenterTO.setHeadName(employeeService.getEmployeeById(costCenterTO.getHeadId()).getName());
    }
    if (costCenterTO.getAddress() != null) {
      if (costCenterTO.getAddress().getCityId() != null) {
        costCenterTO.getAddress().setCityName(addressService.getCityById(costCenterTO.getAddress().getCityId()).getName());
      }
      if (costCenterTO.getAddress().getStateId() != null) {
        costCenterTO.getAddress().setStateName(addressService.getStateById(costCenterTO.getAddress().getStateId()).getName());
      }
      if (costCenterTO.getAddress().getPincodeId() != null) {
        costCenterTO.getAddress().setPincode(addressService.getPincodeById(costCenterTO.getAddress().getPincodeId()).getPincode());
      }
      if (costCenterTO.getAddress().getCountryId() != null) {
        costCenterTO.getAddress().setCountryName(addressService.getCountryById(costCenterTO.getAddress().getCountryId()).getName());
      }
    }
    return costCenterTO;
  }

  @Override
  public void deleteCostCenter(List<Long> id) {
    costCenterDao.deleteCostCenter(id);
  }

}
