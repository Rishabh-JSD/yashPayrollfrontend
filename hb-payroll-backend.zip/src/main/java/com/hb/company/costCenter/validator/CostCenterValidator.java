package com.hb.company.costCenter.validator;

import com.hb.common.PaginationCriteria;
import com.hb.company.costCenter.controller.CostCenterController;
import com.hb.company.costCenter.dto.CostCenterTO;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.ControllerAdvice;

@ControllerAdvice(assignableTypes = CostCenterController.class)
public class CostCenterValidator implements Validator {

  @Override
  public boolean supports(Class<?> aClass) {
    boolean support = CostCenterTO.class.equals(aClass);
    if (!support) {
      support = PaginationCriteria.class.equals(aClass);
    }
    return support;
  }

  @Override
  public void validate(Object o, Errors errors) {
    CostCenterTO costCenterTO = (CostCenterTO) o;

//    ValidationUtils.rejectIfEmptyOrWhitespace(errors, "name", "PMS001E", APP_MSG.MESSAGE.get("PR001E"));

  }
}
