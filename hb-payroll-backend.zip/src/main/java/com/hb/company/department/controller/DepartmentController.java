package com.hb.company.department.controller;

import com.hb.common.PaginationCriteria;
import com.hb.common.ResponseDTO;
import com.hb.common.SearchResponseTO;
import com.hb.common.ValidationError;
import com.hb.company.department.dto.DepartmentTO;
import com.hb.company.department.service.DepartmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/department")
public class DepartmentController {

  @Autowired
  private Validator departmentValidator;

  @Autowired
  private DepartmentService departmentService;

  private ResponseDTO responseDTO;

  @InitBinder
  private void initBinder(WebDataBinder binder) {
    binder.setValidator(departmentValidator);
  }

  @RequestMapping(value = "/add", method = RequestMethod.POST, name = "Department Master Add->DPMCR")
  public ResponseEntity<?> addDepartment(@Valid @RequestBody DepartmentTO departmentTO, Errors errors) {
    if (errors.hasErrors()) {
      ValidationError validationError = ValidationError.fromBindingErrors(errors);
      return new ResponseEntity<>(validationError, HttpStatus.OK);
    }
    DepartmentTO departmentTO_return = departmentService.addDepartment(departmentTO);
    responseDTO = ResponseDTO.responseBuilder(200, "PR001", "/department", "department", departmentTO_return);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/update", method = RequestMethod.POST, name = "Department Master Update->DPMCR")
  public ResponseEntity<?> updateDepartment(@Valid @RequestBody DepartmentTO departmentTO, Errors errors) {
    if (errors.hasErrors()) {
      ValidationError validationError = ValidationError.fromBindingErrors(errors);
      return new ResponseEntity<>(validationError, HttpStatus.OK);
    }
    DepartmentTO departmentTO_return = departmentService.updateDepartment(departmentTO);
    responseDTO = ResponseDTO.responseBuilder(200, "PR002", "/department", "department", departmentTO_return);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/list", method = RequestMethod.POST, name = "Department Master List->DPMCR")
  public ResponseEntity<?> getDepartmentList(@RequestBody PaginationCriteria paginationCriteria) {
    SearchResponseTO searchResponseTO = departmentService.getDepartmentList(paginationCriteria);
    if (searchResponseTO.getList() == null || searchResponseTO.getList().isEmpty()) {
      responseDTO = ResponseDTO.responseBuilder(200, "PR006", "/department", "department", searchResponseTO);
      return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }
    responseDTO = ResponseDTO.responseBuilder(200, "PR003", "/department", "department", searchResponseTO);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/{id}", method = RequestMethod.GET, name = "Department Master View->DPMCR")
  public ResponseEntity<?> getDepartmentById(@PathVariable Long id) {
    DepartmentTO departmentTO = departmentService.getDepartmentById(id);
    if (departmentTO == null) {
      responseDTO = ResponseDTO.responseBuilder(200, "PR007", "/department", "department", null);
      return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }
    responseDTO = ResponseDTO.responseBuilder(200, "PR004", "/department", "department", departmentTO);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/delete", method = RequestMethod.DELETE, name = "Department Master Delete->DPMCR")
  public ResponseEntity<?> deleteDepartment(@RequestParam(name = "departmentId") List<Long> departmentId) {
    departmentService.deleteDepartment(departmentId);
    responseDTO = ResponseDTO.responseBuilder(200, "PR005", "/department", "department", departmentId);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }
}
