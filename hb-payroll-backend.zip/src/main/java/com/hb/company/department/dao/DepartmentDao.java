package com.hb.company.department.dao;

import com.hb.common.PaginationCriteria;
import com.hb.company.department.entity.DepartmentBO;
import com.hb.master.dto.CommonListTO;

import java.util.List;

public interface DepartmentDao {

  DepartmentBO addDepartment(DepartmentBO departmentTO);

  DepartmentBO updateDepartment(DepartmentBO departmentTO);

  CommonListTO<DepartmentBO> getDepartmentList(PaginationCriteria paginationCriteria);

  DepartmentBO getDepartmentById(Long id);

  void deleteDepartment(List<Long> id);

}
