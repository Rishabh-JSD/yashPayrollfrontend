package com.hb.company.department.dto;

import com.hb.common.AuditTO;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
public class DepartmentTO extends AuditTO {

  private Long id;
  private boolean departmentFlag;
  private boolean subDepartmentFlag;
  private Long departmentId;
  private Long typeId;
  private String name;
  private Long branchId;
  private String branchName;
  private Long costCenterId;
  private String costCenterName;
  private Long headId;
  private String headName;
  private Long phoneNo;
  private String email;
  private Long shiftTypeId;
  private Long shiftTimingId;
  private BigDecimal workingHours;
  private String description;
  private boolean deleteFlag;
  private Long totalEmployees;
}
