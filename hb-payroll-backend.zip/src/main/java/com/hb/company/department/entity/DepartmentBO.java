package com.hb.company.department.entity;

import com.hb.address.entity.AddressBO;
import com.hb.common.Audit;
import com.hb.common.TABLES;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.math.BigDecimal;

@Getter
@Setter
@Entity
@Table(name = TABLES.DEPARTMENT)
public class DepartmentBO extends Audit {

  private static final long serialVersionUID = -3015801901350337816L;

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "id", updatable = false)
  private Long id;

  @Column(name = "department_flag")
  private boolean departmentFlag;

  @Column(name = "sub_department_flag")
  private boolean subDepartmentFlag;

  @Column(name = "department_id")
  private Long departmentId;

  @Column(name = "type_id")
  private Long typeId;

  @Column(name = "name")
  private String name;

  @Column(name = "branch_id")
  private Long branchId;

  @Column(name = "cost_center_id")
  private Long costCenterId;

  @Column(name = "head_id")
  private Long headId;

  @Column(name = "phone_no")
  private Long phoneNo;

  @Column(name = "email")
  private String email;

  @Column(name = "shift_type_id")
  private Long shiftTypeId;

  @Column(name = "shift_timing_id")
  private Long shiftTimingId;

  @Column(name = "working_hours")
  private BigDecimal workingHours;

  @Column(name = "description")
  private String description;

  @Column(name = "delete_flag")
  private boolean deleteFlag;
}
