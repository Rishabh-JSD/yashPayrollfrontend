package com.hb.company.department.service;

import com.hb.common.PaginationCriteria;
import com.hb.common.SearchResponseTO;
import com.hb.company.department.dto.DepartmentTO;

import java.util.List;

public interface DepartmentService {

  DepartmentTO addDepartment(DepartmentTO departmentTO);

  DepartmentTO updateDepartment(DepartmentTO departmentTO);

  SearchResponseTO getDepartmentList(PaginationCriteria paginationCriteria);

  DepartmentTO getDepartmentById(Long id);

  void deleteDepartment(List<Long> departmentId);
}
