package com.hb.company.department.service;

import com.hb.common.MapperService;
import com.hb.common.PaginationCriteria;
import com.hb.common.SearchResponseTO;
import com.hb.company.branch.dto.BranchTO;
import com.hb.company.branch.entity.BranchBO;
import com.hb.company.branch.service.BranchService;
import com.hb.company.costCenter.service.CostCenterService;
import com.hb.company.department.dao.DepartmentDao;
import com.hb.company.department.dto.DepartmentTO;
import com.hb.company.department.entity.DepartmentBO;
import com.hb.employee.dao.EmployeeDao;
import com.hb.employee.service.EmployeeService;
import com.hb.master.dto.CommonListTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;

@Service
@Transactional
public class DepartmentServiceImpl implements DepartmentService {

  @Autowired
  private DepartmentDao departmentDao;

  @Autowired
  private EmployeeService employeeService;

  @Autowired
  private BranchService branchService;

  @Autowired
  private CostCenterService costCenterService;

  @Autowired
  private EmployeeDao employeeDao;

  @Autowired
  private MapperService mapperService;

  @Override
  public DepartmentTO addDepartment(DepartmentTO departmentTO) {
    DepartmentBO departmentBO = mapperService.map(departmentTO, DepartmentBO.class);
    return mapperService.map(departmentDao.addDepartment(departmentBO), DepartmentTO.class);
  }

  @Override
  public DepartmentTO updateDepartment(DepartmentTO departmentTO) {
    DepartmentBO departmentBO = mapperService.map(departmentTO, DepartmentBO.class);
    return mapperService.map(departmentDao.updateDepartment(departmentBO), DepartmentTO.class);
  }

  @Override
  @Transactional(Transactional.TxType.NOT_SUPPORTED)
  public SearchResponseTO getDepartmentList(PaginationCriteria paginationCriteria) {
    SearchResponseTO searchResponseTO = new SearchResponseTO();
    CommonListTO<DepartmentBO> commonListTO = departmentDao.getDepartmentList(paginationCriteria);

    List<DepartmentTO> departmentTOS = null;
    if (commonListTO.getDataList() != null && !commonListTO.getDataList().isEmpty()) {
      departmentTOS = new ArrayList<>();
      for (DepartmentBO departmentBO : commonListTO.getDataList()) {
        DepartmentTO departmentTO = mapperService.map(departmentBO, DepartmentTO.class);
        if (departmentTO.getBranchId() != null) {
          departmentTO.setBranchName(branchService.getBranchById(departmentTO.getBranchId()).getName());
        }
        if (departmentTO.getCostCenterId() != null) {
          departmentTO.setCostCenterName(costCenterService.getCostCenterById(departmentTO.getCostCenterId()).getName());
        }
        if (departmentTO.getHeadId() != null) {
          departmentTO.setHeadName(employeeService.getEmployeeById(departmentTO.getHeadId()).getName());
        }
        departmentTO.setTotalEmployees(employeeDao.employeeCount(departmentTO.getId(), "department"));
        departmentTOS.add(departmentTO);
      }
    }
    searchResponseTO.setList(departmentTOS);
    searchResponseTO.setPageCount(commonListTO.getPageCount());
    searchResponseTO.setTotalRowCount(commonListTO.getTotalRow().intValue());
    return searchResponseTO;
  }

  @Override
  @Transactional(Transactional.TxType.NOT_SUPPORTED)
  public DepartmentTO getDepartmentById(Long id) {
    DepartmentTO departmentTO = mapperService.map(departmentDao.getDepartmentById(id), DepartmentTO.class);
    if (departmentTO.getHeadId() != null) {
      departmentTO.setHeadName(employeeService.getEmployeeById(departmentTO.getHeadId()).getName());
    }
    return departmentTO;
  }

  @Override
  public void deleteDepartment(List<Long> id) {
    departmentDao.deleteDepartment(id);
  }

}
