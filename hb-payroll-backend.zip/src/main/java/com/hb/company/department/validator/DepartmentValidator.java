package com.hb.company.department.validator;

import com.hb.common.PaginationCriteria;
import com.hb.company.department.controller.DepartmentController;
import com.hb.company.department.dto.DepartmentTO;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.ControllerAdvice;

@ControllerAdvice(assignableTypes = DepartmentController.class)
public class DepartmentValidator implements Validator {

  @Override
  public boolean supports(Class<?> aClass) {
    boolean support = DepartmentTO.class.equals(aClass);
    if (!support) {
      support = PaginationCriteria.class.equals(aClass);
    }
    return support;
  }

  @Override
  public void validate(Object o, Errors errors) {
    DepartmentTO departmentTO = (DepartmentTO) o;

//    ValidationUtils.rejectIfEmptyOrWhitespace(errors, "name", "PMS001E", APP_MSG.MESSAGE.get("PR001E"));

  }
}
