package com.hb.company.detail.controller;

import com.hb.common.PaginationCriteria;
import com.hb.common.ResponseDTO;
import com.hb.common.SearchResponseTO;
import com.hb.common.ValidationError;
import com.hb.company.detail.dto.CompanyDetailTO;
import com.hb.company.detail.service.CompanyDetailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/company-detail")
public class CompanyDetailController {

  @Autowired
  private Validator companyDetailValidator;

  @Autowired
  private CompanyDetailService companyDetailService;

  private ResponseDTO responseDTO;

  @InitBinder
  private void initBinder(WebDataBinder binder) {
    binder.setValidator(companyDetailValidator);
  }

  @RequestMapping(value = "/add", method = RequestMethod.POST, name = "Company Detail Master Add->CPDCR")
  public ResponseEntity<?> addCompanyDetail(@Valid @RequestBody CompanyDetailTO companyDetailTO, Errors errors) {
    if (errors.hasErrors()) {
      ValidationError validationError = ValidationError.fromBindingErrors(errors);
      return new ResponseEntity<>(validationError, HttpStatus.OK);
    }
    CompanyDetailTO companyDetailTO_return = companyDetailService.addCompanyDetail(companyDetailTO);
    responseDTO = ResponseDTO.responseBuilder(200, "PR001", "/company-detail", "companyDetail", companyDetailTO_return);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/update", method = RequestMethod.POST, name = "Company Detail Master Update->CPDCR")
  public ResponseEntity<?> updateCompanyDetail(@Valid @RequestBody CompanyDetailTO companyDetailTO, Errors errors) {
    if (errors.hasErrors()) {
      ValidationError validationError = ValidationError.fromBindingErrors(errors);
      return new ResponseEntity<>(validationError, HttpStatus.OK);
    }
    CompanyDetailTO companyDetailTO_return = companyDetailService.updateCompanyDetail(companyDetailTO);
    responseDTO = ResponseDTO.responseBuilder(200, "PR002", "/company-detail", "companyDetail", companyDetailTO_return);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/list", method = RequestMethod.POST, name = "Company Detail Master List->CPDCR")
  public ResponseEntity<?> getCompanyDetailList(@RequestBody PaginationCriteria paginationCriteria) {
    SearchResponseTO searchResponseTO = companyDetailService.getCompanyDetailList(paginationCriteria);
    if (searchResponseTO.getList() == null || searchResponseTO.getList().isEmpty()) {
      responseDTO = ResponseDTO.responseBuilder(200, "PR006", "/company-detail", "companyDetail", searchResponseTO);
      return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }
    responseDTO = ResponseDTO.responseBuilder(200, "PR003", "/company-detail", "companyDetail", searchResponseTO);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/{id}", method = RequestMethod.GET, name = "Company Detail Master View->CPDCR")
  public ResponseEntity<?> getCompanyDetailById(@PathVariable Long id) {
    CompanyDetailTO companyDetailTO = companyDetailService.getCompanyDetailById(id);
    if (companyDetailTO == null) {
      responseDTO = ResponseDTO.responseBuilder(200, "PR007", "/company-detail", "companyDetail", null);
      return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }
    responseDTO = ResponseDTO.responseBuilder(200, "PR004", "/company-detail", "companyDetail", companyDetailTO);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/delete", method = RequestMethod.DELETE, name = "Company Detail Master Delete->CPDCR")
  public ResponseEntity<?> deleteCompanyDetail(@RequestParam(name = "companyDetailId") List<Long> companyDetailId) {
    companyDetailService.deleteCompanyDetail(companyDetailId);
    responseDTO = ResponseDTO.responseBuilder(200, "PR005", "/company-detail", "companyDetail", companyDetailId);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }
}
