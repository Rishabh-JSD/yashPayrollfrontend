package com.hb.company.detail.dao;

import com.hb.common.PaginationCriteria;
import com.hb.company.detail.entity.CompanyDetailBO;
import com.hb.master.dto.CommonListTO;

import java.util.List;

public interface CompanyDetailDao {

  CompanyDetailBO addCompanyDetail(CompanyDetailBO companyDetailTO);

  CompanyDetailBO updateCompanyDetail(CompanyDetailBO companyDetailTO);

  CommonListTO<CompanyDetailBO> getCompanyDetailList(PaginationCriteria paginationCriteria);

  CompanyDetailBO getCompanyDetailById(Long id);

  void deleteCompanyDetail(List<Long> id);

}
