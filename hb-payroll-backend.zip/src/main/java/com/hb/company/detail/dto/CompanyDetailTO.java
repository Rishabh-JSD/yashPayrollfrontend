package com.hb.company.detail.dto;

import com.hb.address.entity.AddressBO;
import com.hb.common.AuditTO;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

@Getter
@Setter
public class CompanyDetailTO extends AuditTO {

  private Long id;
  private Long documentId;
  private String name;
  private String pan;
  private String tan;
  private String gstin;
  private Long phoneNo;
  private String email;
  private Long addressRegisteredId;
  private boolean sameAsRegistered;
  private Long addressOperationalId;
  private String workingDays;
  private Date startTime;
  private Date endTime;
  private boolean deleteFlag;
  private AddressBO addressRegistered;
  private AddressBO addressOperational;
}
