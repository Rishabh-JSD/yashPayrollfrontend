package com.hb.company.detail.entity;

import com.hb.address.entity.AddressBO;
import com.hb.common.Audit;
import com.hb.common.TABLES;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.util.Date;

@Getter
@Setter
@Entity
@Table(name = TABLES.COMPANY)
public class CompanyDetailBO extends Audit {

  private static final long serialVersionUID = 1926884009942924291L;

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "id", updatable = false)
  private Long id;

  @Column(name = "document_id")
  private Long documentId;

  @Column(name = "name")
  private String name;

  @Column(name = "pan")
  private String pan;

  @Column(name = "tan")
  private String tan;

  @Column(name = "gstin")
  private String gstin;

  @Column(name = "phone_no")
  private Long phoneNo;

  @Column(name = "email")
  private String email;

  @Column(name = "address_registered_id", insertable = false, updatable = false)
  private Long addressRegisteredId;

  @Column(name = "same_as_registered")
  private boolean sameAsRegistered;

  @Column(name = "address_operational_id", insertable = false, updatable = false)
  private Long addressOperationalId;

  @Column(name = "working_days")
  private String workingDays;

  @Column(name = "start_time")
  private Date startTime;

  @Column(name = "end_time")
  private Date endTime;

  @Column(name = "delete_flag")
  private boolean deleteFlag;

  @OneToOne(cascade = CascadeType.ALL, orphanRemoval = true)
  @JoinColumn(name = "address_registered_id")
  private AddressBO addressRegistered;

  @OneToOne(cascade = CascadeType.ALL, orphanRemoval = true)
  @JoinColumn(name = "address_operational_id")
  private AddressBO addressOperational;
}
