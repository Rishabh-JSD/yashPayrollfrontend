package com.hb.company.detail.service;

import com.hb.common.PaginationCriteria;
import com.hb.common.SearchResponseTO;
import com.hb.company.detail.dto.CompanyDetailTO;

import java.util.List;

public interface CompanyDetailService {

  CompanyDetailTO addCompanyDetail(CompanyDetailTO companyDetailTO);

  CompanyDetailTO updateCompanyDetail(CompanyDetailTO companyDetailTO);

  SearchResponseTO getCompanyDetailList(PaginationCriteria paginationCriteria);

  CompanyDetailTO getCompanyDetailById(Long id);

  void deleteCompanyDetail(List<Long> companyDetailId);
}
