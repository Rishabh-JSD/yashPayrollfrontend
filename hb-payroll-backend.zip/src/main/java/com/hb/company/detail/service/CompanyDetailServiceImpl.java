package com.hb.company.detail.service;

import com.hb.common.MapperService;
import com.hb.common.PaginationCriteria;
import com.hb.common.SearchResponseTO;
import com.hb.company.detail.dao.CompanyDetailDao;
import com.hb.company.detail.dto.CompanyDetailTO;
import com.hb.company.detail.entity.CompanyDetailBO;
import com.hb.master.dto.CommonListTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;

@Service
@Transactional
public class CompanyDetailServiceImpl implements CompanyDetailService {

  @Autowired
  private CompanyDetailDao companyDetailDao;

  @Autowired
  private MapperService mapperService;

  @Override
  public CompanyDetailTO addCompanyDetail(CompanyDetailTO companyDetailTO) {
    CompanyDetailBO companyDetailBO = mapperService.map(companyDetailTO, CompanyDetailBO.class);
    return mapperService.map(companyDetailDao.addCompanyDetail(companyDetailBO), CompanyDetailTO.class);
  }

  @Override
  public CompanyDetailTO updateCompanyDetail(CompanyDetailTO companyDetailTO) {
    CompanyDetailBO companyDetailBO = mapperService.map(companyDetailTO, CompanyDetailBO.class);
    return mapperService.map(companyDetailDao.updateCompanyDetail(companyDetailBO), CompanyDetailTO.class);
  }

  @Override
  @Transactional(Transactional.TxType.NOT_SUPPORTED)
  public SearchResponseTO getCompanyDetailList(PaginationCriteria paginationCriteria) {
    SearchResponseTO searchResponseTO = new SearchResponseTO();
    CommonListTO<CompanyDetailBO> commonListTO = companyDetailDao.getCompanyDetailList(paginationCriteria);

    List<CompanyDetailTO> companyDetailTOS = mapperService.map(commonListTO.getDataList(), CompanyDetailTO.class);
    searchResponseTO.setList(companyDetailTOS);
    searchResponseTO.setPageCount(commonListTO.getPageCount());
    searchResponseTO.setTotalRowCount(commonListTO.getTotalRow().intValue());
    return searchResponseTO;
  }

  @Override
  @Transactional(Transactional.TxType.NOT_SUPPORTED)
  public CompanyDetailTO getCompanyDetailById(Long id) {
    return mapperService.map(companyDetailDao.getCompanyDetailById(id), CompanyDetailTO.class);
  }

  @Override
  public void deleteCompanyDetail(List<Long> id) {
    companyDetailDao.deleteCompanyDetail(id);
  }

}
