package com.hb.company.detail.validator;

import com.hb.common.PaginationCriteria;
import com.hb.company.detail.controller.CompanyDetailController;
import com.hb.company.detail.dto.CompanyDetailTO;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.ControllerAdvice;

@ControllerAdvice(assignableTypes = CompanyDetailController.class)
public class CompanyDetailValidator implements Validator {

  @Override
  public boolean supports(Class<?> aClass) {
    boolean support = CompanyDetailTO.class.equals(aClass);
    if (!support) {
      support = PaginationCriteria.class.equals(aClass);
    }
    return support;
  }

  @Override
  public void validate(Object o, Errors errors) {
    CompanyDetailTO companyDetailTO = (CompanyDetailTO) o;

//    ValidationUtils.rejectIfEmptyOrWhitespace(errors, "name", "PMS001E", APP_MSG.MESSAGE.get("PR001E"));

  }
}
