package com.hb.company.dynamicInfo.controller;

import com.hb.common.PaginationCriteria;
import com.hb.common.ResponseDTO;
import com.hb.common.SearchResponseTO;
import com.hb.common.ValidationError;
import com.hb.company.dynamicInfo.dto.CompanyDynamicInfoTO;
import com.hb.company.dynamicInfo.service.CompanyDynamicInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/company-info")
public class CompanyDynamicInfoController {

  @Autowired
  private Validator companyDynamicInfoValidator;

  @Autowired
  private CompanyDynamicInfoService companyDynamicInfoService;

  private ResponseDTO responseDTO;

  @InitBinder
  private void initBinder(WebDataBinder binder) {
    binder.setValidator(companyDynamicInfoValidator);
  }

  @RequestMapping(value = "/add", method = RequestMethod.POST, name = "Company Info Master Add->CDICR")
  public ResponseEntity<?> addCompanyInfo(@Valid @RequestBody CompanyDynamicInfoTO companyDynamicInfoTO, Errors errors) {
    if (errors.hasErrors()) {
      ValidationError validationError = ValidationError.fromBindingErrors(errors);
      return new ResponseEntity<>(validationError, HttpStatus.OK);
    }
    CompanyDynamicInfoTO companyDynamicInfoTO_return = companyDynamicInfoService.addCompanyInfo(companyDynamicInfoTO);
    responseDTO = ResponseDTO.responseBuilder(200, "PR001", "/company-info", "companyInfo", companyDynamicInfoTO_return);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/update", method = RequestMethod.POST, name = "Company Info Master Update->CDICR")
  public ResponseEntity<?> updateCompanyInfo(@Valid @RequestBody CompanyDynamicInfoTO companyDynamicInfoTO, Errors errors) {
    if (errors.hasErrors()) {
      ValidationError validationError = ValidationError.fromBindingErrors(errors);
      return new ResponseEntity<>(validationError, HttpStatus.OK);
    }
    CompanyDynamicInfoTO companyDynamicInfoTO_return = companyDynamicInfoService.updateCompanyInfo(companyDynamicInfoTO);
    responseDTO = ResponseDTO.responseBuilder(200, "PR002", "/company-info", "companyInfo", companyDynamicInfoTO_return);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/list", method = RequestMethod.POST, name = "Company Info Master List->CDICR")
  public ResponseEntity<?> getCompanyInfoList(@RequestBody PaginationCriteria paginationCriteria) {
    SearchResponseTO searchResponseTO = companyDynamicInfoService.getCompanyInfoList(paginationCriteria);
    if (searchResponseTO.getList() == null || searchResponseTO.getList().isEmpty()) {
      responseDTO = ResponseDTO.responseBuilder(200, "PR006", "/company-info", "companyInfo", searchResponseTO);
      return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }
    responseDTO = ResponseDTO.responseBuilder(200, "PR003", "/company-info", "companyInfo", searchResponseTO);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/{id}", method = RequestMethod.GET, name = "Company Info Master View->CDICR")
  public ResponseEntity<?> getCompanyInfoById(@PathVariable Long id) {
    CompanyDynamicInfoTO companyDynamicInfoTO = companyDynamicInfoService.getCompanyInfoById(id);
    if (companyDynamicInfoTO == null) {
      responseDTO = ResponseDTO.responseBuilder(200, "PR007", "/company-info", "companyInfo", null);
      return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }
    responseDTO = ResponseDTO.responseBuilder(200, "PR004", "/company-info", "companyInfo", companyDynamicInfoTO);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/delete", method = RequestMethod.DELETE, name = "Company Info Master Delete->CDICR")
  public ResponseEntity<?> deleteCompanyInfo(@RequestParam(name = "companyInfoId") List<Long> companyInfoId) {
    companyDynamicInfoService.deleteCompanyInfo(companyInfoId);
    responseDTO = ResponseDTO.responseBuilder(200, "PR005", "/company-info", "companyInfo", companyInfoId);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }
}
