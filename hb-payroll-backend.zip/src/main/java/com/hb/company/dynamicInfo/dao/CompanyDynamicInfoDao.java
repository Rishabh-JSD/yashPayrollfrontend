package com.hb.company.dynamicInfo.dao;

import com.hb.common.PaginationCriteria;
import com.hb.company.dynamicInfo.entity.CompanyDynamicInfoBO;
import com.hb.master.dto.CommonListTO;

import java.util.List;

public interface CompanyDynamicInfoDao {

  CompanyDynamicInfoBO addCompanyInfo(CompanyDynamicInfoBO companyInfoTO);

  CompanyDynamicInfoBO updateCompanyInfo(CompanyDynamicInfoBO companyInfoTO);

  CommonListTO<CompanyDynamicInfoBO> getCompanyInfoList(PaginationCriteria paginationCriteria);

  CompanyDynamicInfoBO getCompanyInfoById(Long id);

  void deleteCompanyInfo(List<Long> id);

}
