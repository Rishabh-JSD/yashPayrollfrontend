package com.hb.company.dynamicInfo.dao;

import com.hb.common.PaginationCriteria;
import com.hb.company.dynamicInfo.entity.CompanyDynamicInfoBO;
import com.hb.master.dto.CommonListTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.*;
import java.util.List;

@Repository
public class CompanyDynamicInfoDaoImpl implements CompanyDynamicInfoDao {

  @PersistenceContext
  private EntityManager entityManager;

  private static final Logger logger = LoggerFactory.getLogger(CompanyDynamicInfoDaoImpl.class);

  @Override
  public CompanyDynamicInfoBO addCompanyInfo(CompanyDynamicInfoBO companyDynamicInfoBO) {
    entityManager.persist(companyDynamicInfoBO);
    logger.info("Company Info has added successfully, Company Info details=" + companyDynamicInfoBO);
    return companyDynamicInfoBO;
  }

  @Override
  public CompanyDynamicInfoBO updateCompanyInfo(CompanyDynamicInfoBO companyDynamicInfoBO) {
    entityManager.merge(companyDynamicInfoBO);
    logger.info("Company Info has updated successfully, Company Info details=" + companyDynamicInfoBO);
    return companyDynamicInfoBO;
  }

  @Override
  public CommonListTO<CompanyDynamicInfoBO> getCompanyInfoList(PaginationCriteria paginationCriteria) {
    CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
    CriteriaQuery<CompanyDynamicInfoBO> criteriaQuery = criteriaBuilder.createQuery(CompanyDynamicInfoBO.class);
    Root<CompanyDynamicInfoBO> root = criteriaQuery.from(CompanyDynamicInfoBO.class);
    criteriaQuery.where(criteriaBuilder.equal(root.get("deleteFlag"), false));

    //condition for search
    if (paginationCriteria.getSearchFor() != null) {
      Path<String> pathName = root.get("name");
      Predicate predicateForName = criteriaBuilder.like(pathName, "%" + paginationCriteria.getSearchFor() + "%");
      criteriaQuery.where(predicateForName);
    }

    // Condition for sorting.
    if (paginationCriteria.getSortField() != null && !paginationCriteria.getSortField().isEmpty()) {
      Order order;
      if (paginationCriteria.getSortType() == 2) {
        order = criteriaBuilder.desc(root.get(paginationCriteria.getSortField()));
      } else {
        order = criteriaBuilder.asc(root.get(paginationCriteria.getSortField()));
      }
      criteriaQuery.orderBy(order);
    } else {
      Order order = criteriaBuilder.desc(root.get("id"));
      criteriaQuery.orderBy(order);
    }

    // Adding Pagination total Count
    CommonListTO<CompanyDynamicInfoBO> commonListTO = new CommonListTO<>();
    CriteriaQuery<Long> criteriaQuery2 = criteriaBuilder.createQuery(Long.class);
    Root<CompanyDynamicInfoBO> root2 = criteriaQuery2.from(CompanyDynamicInfoBO.class);
    criteriaQuery2.where(criteriaBuilder.equal(root2.get("deleteFlag"), false));
    CriteriaQuery<Long> select = criteriaQuery2.select(criteriaBuilder.count(root2));
    Long count = entityManager.createQuery(select).getSingleResult();
    commonListTO.setTotalRow(count);
    int size = count.intValue();
    int limit = paginationCriteria.getLimit();
    if (limit != 0) {
      commonListTO.setPageCount((size + limit - 1) / limit);
    } else {
      commonListTO.setPageCount(1);
    }

    TypedQuery<CompanyDynamicInfoBO> typedQuery = entityManager.createQuery(criteriaQuery);
    // Condition for paging.
    if (paginationCriteria.getPage() != 0 && paginationCriteria.getLimit() > 0) {
      typedQuery.setFirstResult((paginationCriteria.getPage() - 1) * paginationCriteria.getLimit());
      typedQuery.setMaxResults(paginationCriteria.getLimit());
    }
    commonListTO.setDataList(typedQuery.getResultList());
    return commonListTO;
  }

  @Override
  public CompanyDynamicInfoBO getCompanyInfoById(Long id) {
    CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
    CriteriaQuery<CompanyDynamicInfoBO> criteriaQuery = criteriaBuilder.createQuery(CompanyDynamicInfoBO.class);

    Root<CompanyDynamicInfoBO> root = criteriaQuery.from(CompanyDynamicInfoBO.class);
    Predicate predicateForId = criteriaBuilder.equal(root.get("id"), id);
    Predicate predicateForDeleteFlag = criteriaBuilder.equal(root.get("deleteFlag"), false);
    Predicate predicate = criteriaBuilder.and(predicateForId, predicateForDeleteFlag);
    criteriaQuery.where(predicate);
    return entityManager.createQuery(criteriaQuery).getSingleResult();
  }

  @Override
  public void deleteCompanyInfo(List<Long> id) {
    CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
    CriteriaUpdate<CompanyDynamicInfoBO> criteriaUpdate = criteriaBuilder.createCriteriaUpdate(CompanyDynamicInfoBO.class);
    Root<CompanyDynamicInfoBO> root = criteriaUpdate.from(CompanyDynamicInfoBO.class);
    criteriaUpdate.set("deleteFlag", true);
    criteriaUpdate.where(root.get("id").in(id));
    entityManager.createQuery(criteriaUpdate).executeUpdate();
  }
}
