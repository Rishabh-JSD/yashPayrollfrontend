package com.hb.company.dynamicInfo.dto;

import com.hb.common.AuditTO;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CompanyDynamicInfoOptionTO extends AuditTO {

  private Long id;
  private Long companyDynamicInfoId;
  private boolean departmentFlag;
  private boolean subDepartmentFlag;
  private String name;
  private String code;
  private String gstin;
  private Long branchId;
  private Long costCenterId;
  private Long departmentId;
  private boolean sameBranchFlag;
  private Long addressId;
  private Long headId;
  private Long shiftTypeId;
  private String description;
  private boolean deleteFlag;
}
