package com.hb.company.dynamicInfo.dto;

import com.hb.common.AuditTO;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class CompanyDynamicInfoTO extends AuditTO {

  private Long id;
  private String name;
  private boolean deleteFlag;
  private List<CompanyDynamicInfoOptionTO> companyDynamicInfoOption;
}
