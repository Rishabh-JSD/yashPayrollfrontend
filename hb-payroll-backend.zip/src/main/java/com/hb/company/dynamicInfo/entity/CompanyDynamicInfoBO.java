package com.hb.company.dynamicInfo.entity;

import com.hb.common.Audit;
import com.hb.common.TABLES;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.util.List;

@Getter
@Setter
@Entity
@Table(name = TABLES.COMPANY_DYNAMIC_INFO)
public class CompanyDynamicInfoBO extends Audit {

  private static final long serialVersionUID = -111769189987043721L;

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "id", updatable = false)
  private Long id;

  @Column(name = "name")
  private String name;

  @Column(name = "delete_flag")
  private boolean deleteFlag;

  @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
  @JoinColumn(name = "company_dynamic_info_id", referencedColumnName = "id")
  private List<CompanyDynamicInfoOptionBO> companyDynamicInfoOption;
}
