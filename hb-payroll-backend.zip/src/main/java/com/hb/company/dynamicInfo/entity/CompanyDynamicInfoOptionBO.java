package com.hb.company.dynamicInfo.entity;

import com.hb.common.Audit;
import com.hb.common.TABLES;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = TABLES.COMPANY_DYNAMIC_INFO_OPTION)
public class CompanyDynamicInfoOptionBO extends Audit {

  private static final long serialVersionUID = -5768454890733694682L;

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "id", updatable = false)
  private Long id;

  @Column(name = "company_dynamic_info_id")
  private Long companyDynamicInfoId;

  @Column(name = "department_flag")
  private boolean departmentFlag;

  @Column(name = "sub_department_flag")
  private boolean subDepartmentFlag;

  @Column(name = "name")
  private String name;

  @Column(name = "code")
  private String code;

  @Column(name = "gstin")
  private String gstin;

  @Column(name = "branch_id")
  private Long branchId;

  @Column(name = "cost_center_id")
  private Long costCenterId;

  @Column(name = "department_id")
  private Long departmentId;

  @Column(name = "same_branch_flag")
  private boolean sameBranchFlag;

  @Column(name = "address_id")
  private Long addressId;

  @Column(name = "head_id")
  private Long headId;

  @Column(name = "shift_type_id")
  private Long shiftTypeId;

  @Column(name = "description")
  private String description;

  @Column(name = "delete_flag")
  private boolean deleteFlag;

}
