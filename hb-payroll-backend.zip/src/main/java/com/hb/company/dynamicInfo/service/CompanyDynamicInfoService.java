package com.hb.company.dynamicInfo.service;

import com.hb.common.PaginationCriteria;
import com.hb.common.SearchResponseTO;
import com.hb.company.dynamicInfo.dto.CompanyDynamicInfoTO;

import java.util.List;

public interface CompanyDynamicInfoService {

  CompanyDynamicInfoTO addCompanyInfo(CompanyDynamicInfoTO companyDynamicInfoTO);

  CompanyDynamicInfoTO updateCompanyInfo(CompanyDynamicInfoTO companyDynamicInfoTO);

  SearchResponseTO getCompanyInfoList(PaginationCriteria paginationCriteria);

  CompanyDynamicInfoTO getCompanyInfoById(Long id);

  void deleteCompanyInfo(List<Long> companyInfoId);
}
