package com.hb.company.dynamicInfo.service;

import com.hb.common.MapperService;
import com.hb.common.PaginationCriteria;
import com.hb.common.SearchResponseTO;
import com.hb.company.dynamicInfo.dao.CompanyDynamicInfoDao;
import com.hb.company.dynamicInfo.dto.CompanyDynamicInfoTO;
import com.hb.company.dynamicInfo.entity.CompanyDynamicInfoBO;
import com.hb.master.dto.CommonListTO;
import com.hb.master.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;

@Service
@Transactional
public class CompanyDynamicInfoServiceImpl implements CompanyDynamicInfoService {

  @Autowired
  private CompanyDynamicInfoDao companyDynamicInfoDao;

  @Autowired
  private MapperService mapperService;

  @Autowired
  private UserService userService;

  @Override
  public CompanyDynamicInfoTO addCompanyInfo(CompanyDynamicInfoTO companyDynamicInfoTO) {
    CompanyDynamicInfoBO companyDynamicInfoBO = mapperService.map(companyDynamicInfoTO, CompanyDynamicInfoBO.class);
    return mapperService.map(companyDynamicInfoDao.addCompanyInfo(companyDynamicInfoBO), CompanyDynamicInfoTO.class);
  }

  @Override
  public CompanyDynamicInfoTO updateCompanyInfo(CompanyDynamicInfoTO companyDynamicInfoTO) {
    CompanyDynamicInfoBO companyDynamicInfoBO = mapperService.map(companyDynamicInfoTO, CompanyDynamicInfoBO.class);
    return mapperService.map(companyDynamicInfoDao.updateCompanyInfo(companyDynamicInfoBO), CompanyDynamicInfoTO.class);
  }

  @Override
  @Transactional(Transactional.TxType.NOT_SUPPORTED)
  public SearchResponseTO getCompanyInfoList(PaginationCriteria paginationCriteria) {
    SearchResponseTO searchResponseTO = new SearchResponseTO();
    CommonListTO<CompanyDynamicInfoBO> commonListTO = companyDynamicInfoDao.getCompanyInfoList(paginationCriteria);

    List<CompanyDynamicInfoTO> companyDynamicInfoTOS = mapperService.map(commonListTO.getDataList(), CompanyDynamicInfoTO.class);
    searchResponseTO.setList(companyDynamicInfoTOS);
    searchResponseTO.setPageCount(commonListTO.getPageCount());
    searchResponseTO.setTotalRowCount(commonListTO.getTotalRow().intValue());
    return searchResponseTO;
  }

  @Override
  @Transactional(Transactional.TxType.NOT_SUPPORTED)
  public CompanyDynamicInfoTO getCompanyInfoById(Long id) {
    return mapperService.map(companyDynamicInfoDao.getCompanyInfoById(id), CompanyDynamicInfoTO.class);
  }

  @Override
  public void deleteCompanyInfo(List<Long> id) {
    companyDynamicInfoDao.deleteCompanyInfo(id);
  }
}
