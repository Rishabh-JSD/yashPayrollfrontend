package com.hb.company.dynamicInfo.validator;

import com.hb.common.PaginationCriteria;
import com.hb.company.dynamicInfo.controller.CompanyDynamicInfoController;
import com.hb.company.dynamicInfo.dto.CompanyDynamicInfoTO;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.ControllerAdvice;

@ControllerAdvice(assignableTypes = CompanyDynamicInfoController.class)
public class CompanyDynamicInfoValidator implements Validator {

  @Override
  public boolean supports(Class<?> aClass) {
    boolean support = CompanyDynamicInfoTO.class.equals(aClass);
    if (!support) {
      support = PaginationCriteria.class.equals(aClass);
    }
    return support;
  }

  @Override
  public void validate(Object o, Errors errors) {
    CompanyDynamicInfoTO companyDynamicInfoTO = (CompanyDynamicInfoTO) o;

//    ValidationUtils.rejectIfEmptyOrWhitespace(errors, "name", "PMS001E", APP_MSG.MESSAGE.get("PR001E"));

  }
}
