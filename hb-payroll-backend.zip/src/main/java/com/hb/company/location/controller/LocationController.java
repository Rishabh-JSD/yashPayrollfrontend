package com.hb.company.location.controller;

import com.hb.common.PaginationCriteria;
import com.hb.common.ResponseDTO;
import com.hb.common.SearchResponseTO;
import com.hb.common.ValidationError;
import com.hb.company.location.dto.LocationTO;
import com.hb.company.location.service.LocationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/location")
public class LocationController {

  @Autowired
  private Validator locationValidator;

  @Autowired
  private LocationService locationService;

  private ResponseDTO responseDTO;

  @InitBinder
  private void initBinder(WebDataBinder binder) {
    binder.setValidator(locationValidator);
  }

  @RequestMapping(value = "/add", method = RequestMethod.POST, name = "Location Master Add->LCTCR")
  public ResponseEntity<?> addLocation(@Valid @RequestBody LocationTO locationTO, Errors errors) {
    if (errors.hasErrors()) {
      ValidationError validationError = ValidationError.fromBindingErrors(errors);
      return new ResponseEntity<>(validationError, HttpStatus.OK);
    }
    LocationTO locationTO_return = locationService.addLocation(locationTO);
    responseDTO = ResponseDTO.responseBuilder(200, "PR001", "/location", "location", locationTO_return);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/update", method = RequestMethod.POST, name = "Location Master Update->LCTCR")
  public ResponseEntity<?> updateLocation(@Valid @RequestBody LocationTO locationTO, Errors errors) {
    if (errors.hasErrors()) {
      ValidationError validationError = ValidationError.fromBindingErrors(errors);
      return new ResponseEntity<>(validationError, HttpStatus.OK);
    }
    LocationTO locationTO_return = locationService.updateLocation(locationTO);
    responseDTO = ResponseDTO.responseBuilder(200, "PR002", "/location", "location", locationTO_return);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/list", method = RequestMethod.POST, name = "Location Master List->LCTCR")
  public ResponseEntity<?> getLocationList(@RequestBody PaginationCriteria paginationCriteria) {
    SearchResponseTO searchResponseTO = locationService.getLocationList(paginationCriteria);
    if (searchResponseTO.getList() == null || searchResponseTO.getList().isEmpty()) {
      responseDTO = ResponseDTO.responseBuilder(200, "PR006", "/location", "location", searchResponseTO);
      return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }
    responseDTO = ResponseDTO.responseBuilder(200, "PR003", "/location", "location", searchResponseTO);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/{id}", method = RequestMethod.GET, name = "Location Master View->LCTCR")
  public ResponseEntity<?> getLocationById(@PathVariable Long id) {
    LocationTO locationTO = locationService.getLocationById(id);
    if (locationTO == null) {
      responseDTO = ResponseDTO.responseBuilder(200, "PR007", "/location", "location", null);
      return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }
    responseDTO = ResponseDTO.responseBuilder(200, "PR004", "/location", "location", locationTO);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/delete", method = RequestMethod.DELETE, name = "Location Master Delete->LCTCR")
  public ResponseEntity<?> deleteLocation(@RequestParam(name = "locationId") List<Long> locationId) {
    locationService.deleteLocation(locationId);
    responseDTO = ResponseDTO.responseBuilder(200, "PR005", "/location", "location", locationId);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }
}
