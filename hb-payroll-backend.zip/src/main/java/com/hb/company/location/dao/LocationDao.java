package com.hb.company.location.dao;

import com.hb.common.PaginationCriteria;
import com.hb.company.location.entity.LocationBO;
import com.hb.master.dto.CommonListTO;

import java.util.List;

public interface LocationDao {

  LocationBO addLocation(LocationBO locationTO);

  LocationBO updateLocation(LocationBO locationTO);

  CommonListTO<LocationBO> getLocationList(PaginationCriteria paginationCriteria);

  LocationBO getLocationById(Long id);

  void deleteLocation(List<Long> id);

}
