package com.hb.company.location.dto;

import com.hb.address.dto.AddressTO;
import com.hb.common.AuditTO;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LocationTO extends AuditTO {

  private Long id;
  private String name;
  private String gstin;
  private Long costCenterId;
  private Long addressId;
  private Long headId;
  private Long phoneNo;
  private String email;
  private Long shiftTypeId;
  private Long shiftTimingId;
  private boolean deleteFlag;
  private AddressTO address;
}
