package com.hb.company.location.service;

import com.hb.common.PaginationCriteria;
import com.hb.common.SearchResponseTO;
import com.hb.company.location.dto.LocationTO;

import java.util.List;

public interface LocationService {

  LocationTO addLocation(LocationTO locationTO);

  LocationTO updateLocation(LocationTO locationTO);

  SearchResponseTO getLocationList(PaginationCriteria paginationCriteria);

  LocationTO getLocationById(Long id);

  void deleteLocation(List<Long> locationId);
}
