package com.hb.company.location.service;

import com.hb.common.MapperService;
import com.hb.common.PaginationCriteria;
import com.hb.common.SearchResponseTO;
import com.hb.company.location.dao.LocationDao;
import com.hb.company.location.dto.LocationTO;
import com.hb.company.location.entity.LocationBO;
import com.hb.master.dto.CommonListTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;

@Service
@Transactional
public class LocationServiceImpl implements LocationService {

  @Autowired
  private LocationDao locationDao;

  @Autowired
  private MapperService mapperService;

  @Override
  public LocationTO addLocation(LocationTO locationTO) {
    LocationBO locationBO = mapperService.map(locationTO, LocationBO.class);
    return mapperService.map(locationDao.addLocation(locationBO), LocationTO.class);
  }

  @Override
  public LocationTO updateLocation(LocationTO locationTO) {
    LocationBO locationBO = mapperService.map(locationTO, LocationBO.class);
    LocationBO locationBO_return = locationDao.updateLocation(locationBO);
    return mapperService.map(locationBO_return, LocationTO.class);
  }

  @Override
  @Transactional(Transactional.TxType.NOT_SUPPORTED)
  public SearchResponseTO getLocationList(PaginationCriteria paginationCriteria) {
    SearchResponseTO searchResponseTO = new SearchResponseTO();
    CommonListTO<LocationBO> commonListTO = locationDao.getLocationList(paginationCriteria);

    List<LocationTO> locationTOS = mapperService.map(commonListTO.getDataList(), LocationTO.class);
    searchResponseTO.setList(locationTOS);
    searchResponseTO.setPageCount(commonListTO.getPageCount());
    searchResponseTO.setTotalRowCount(commonListTO.getTotalRow().intValue());
    return searchResponseTO;
  }

  @Override
  @Transactional(Transactional.TxType.NOT_SUPPORTED)
  public LocationTO getLocationById(Long id) {
    return mapperService.map(locationDao.getLocationById(id), LocationTO.class);
  }

  @Override
  public void deleteLocation(List<Long> id) {
    locationDao.deleteLocation(id);
  }

}
