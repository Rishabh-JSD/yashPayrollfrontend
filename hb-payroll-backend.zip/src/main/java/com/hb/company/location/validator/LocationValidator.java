package com.hb.company.location.validator;

import com.hb.common.PaginationCriteria;
import com.hb.company.location.controller.LocationController;
import com.hb.company.location.dto.LocationTO;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.ControllerAdvice;

@ControllerAdvice(assignableTypes = LocationController.class)
public class LocationValidator implements Validator {

  @Override
  public boolean supports(Class<?> aClass) {
    boolean support = LocationTO.class.equals(aClass);
    if (!support) {
      support = PaginationCriteria.class.equals(aClass);
    }
    return support;
  }

  @Override
  public void validate(Object o, Errors errors) {
    LocationTO locationTO = (LocationTO) o;

//    ValidationUtils.rejectIfEmptyOrWhitespace(errors, "name", "PMS001E", APP_MSG.MESSAGE.get("PR001E"));

  }
}
 