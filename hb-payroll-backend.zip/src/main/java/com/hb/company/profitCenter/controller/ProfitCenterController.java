package com.hb.company.profitCenter.controller;

import com.hb.common.PaginationCriteria;
import com.hb.common.ResponseDTO;
import com.hb.common.SearchResponseTO;
import com.hb.common.ValidationError;
import com.hb.company.profitCenter.dto.ProfitCenterTO;
import com.hb.company.profitCenter.service.ProfitCenterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/profit-center")
public class ProfitCenterController {

  @Autowired
  private Validator profitCenterValidator;

  @Autowired
  private ProfitCenterService profitCenterService;

  private ResponseDTO responseDTO;

  @InitBinder
  private void initBinder(WebDataBinder binder) {
    binder.setValidator(profitCenterValidator);
  }

  @RequestMapping(value = "/add", method = RequestMethod.POST, name = "Profit Center Master Add->PCMCR")
  public ResponseEntity<?> addProfitCenter(@Valid @RequestBody ProfitCenterTO profitCenterTO, Errors errors) {
    if (errors.hasErrors()) {
      ValidationError validationError = ValidationError.fromBindingErrors(errors);
      return new ResponseEntity<>(validationError, HttpStatus.OK);
    }
    ProfitCenterTO profitCenterTO_return = profitCenterService.addProfitCenter(profitCenterTO);
    responseDTO = ResponseDTO.responseBuilder(200, "PR001", "/profit-center", "profitCenter", profitCenterTO_return);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/update", method = RequestMethod.POST, name = "Profit Center Master Update->PCMCR")
  public ResponseEntity<?> updateProfitCenter(@Valid @RequestBody ProfitCenterTO profitCenterTO, Errors errors) {
    if (errors.hasErrors()) {
      ValidationError validationError = ValidationError.fromBindingErrors(errors);
      return new ResponseEntity<>(validationError, HttpStatus.OK);
    }
    ProfitCenterTO profitCenterTO_return = profitCenterService.updateProfitCenter(profitCenterTO);
    responseDTO = ResponseDTO.responseBuilder(200, "PR002", "/profit-center", "profitCenter", profitCenterTO_return);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/list", method = RequestMethod.POST, name = "Profit Center Master List->PCMCR")
  public ResponseEntity<?> getProfitCenterList(@RequestBody PaginationCriteria paginationCriteria) {
    SearchResponseTO searchResponseTO = profitCenterService.getProfitCenterList(paginationCriteria);
    if (searchResponseTO.getList() == null || searchResponseTO.getList().isEmpty()) {
      responseDTO = ResponseDTO.responseBuilder(200, "PR006", "/profit-center", "profitCenter", searchResponseTO);
      return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }
    responseDTO = ResponseDTO.responseBuilder(200, "PR003", "/profit-center", "profitCenter", searchResponseTO);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/{id}", method = RequestMethod.GET, name = "Profit Center Master View->PCMCR")
  public ResponseEntity<?> getProfitCenterById(@PathVariable Long id) {
    ProfitCenterTO profitCenterTO = profitCenterService.getProfitCenterById(id);
    if (profitCenterTO == null) {
      responseDTO = ResponseDTO.responseBuilder(200, "PR007", "/profit-center", "profitCenter", null);
      return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }
    responseDTO = ResponseDTO.responseBuilder(200, "PR004", "/profit-center", "profitCenter", profitCenterTO);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/delete", method = RequestMethod.DELETE, name = "Profit Center Master Delete->PCMCR")
  public ResponseEntity<?> deleteProfitCenter(@RequestParam(name = "profitCenterId") List<Long> profitCenterId) {
    profitCenterService.deleteProfitCenter(profitCenterId);
    responseDTO = ResponseDTO.responseBuilder(200, "PR005", "/profit-center", "profitCenter", profitCenterId);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }
}
