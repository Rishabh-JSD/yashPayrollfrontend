package com.hb.company.profitCenter.dao;

import com.hb.common.PaginationCriteria;
import com.hb.company.profitCenter.entity.ProfitCenterBO;
import com.hb.master.dto.CommonListTO;

import java.util.List;

public interface ProfitCenterDao {

  ProfitCenterBO addProfitCenter(ProfitCenterBO profitCenterTO);

  ProfitCenterBO updateProfitCenter(ProfitCenterBO profitCenterTO);

  CommonListTO<ProfitCenterBO> getProfitCenterList(PaginationCriteria paginationCriteria);

  ProfitCenterBO getProfitCenterById(Long id);

  void deleteProfitCenter(List<Long> id);

}
