package com.hb.company.profitCenter.dao;

import com.hb.common.PaginationCriteria;
import com.hb.company.profitCenter.entity.ProfitCenterBO;
import com.hb.master.dto.CommonListTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.*;
import java.util.List;

@Repository
public class ProfitCenterDaoImpl implements ProfitCenterDao {

  @PersistenceContext
  private EntityManager entityManager;

  private static final Logger logger = LoggerFactory.getLogger(ProfitCenterDaoImpl.class);

  @Override
  public ProfitCenterBO addProfitCenter(ProfitCenterBO branchBO) {
    entityManager.persist(branchBO);
    logger.info("Profit Center has added successfully, Profit Center details=" + branchBO);
    return branchBO;
  }

  @Override
  public ProfitCenterBO updateProfitCenter(ProfitCenterBO branchBO) {
    entityManager.merge(branchBO);
    logger.info("Profit Center has updated successfully, Profit Center details=" + branchBO);
    return branchBO;
  }

  @Override
  public CommonListTO<ProfitCenterBO> getProfitCenterList(PaginationCriteria paginationCriteria) {
    CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
    CriteriaQuery<ProfitCenterBO> criteriaQuery = criteriaBuilder.createQuery(ProfitCenterBO.class);
    Root<ProfitCenterBO> root = criteriaQuery.from(ProfitCenterBO.class);
    criteriaQuery.where(criteriaBuilder.equal(root.get("deleteFlag"), false));

    //condition for search
    if (paginationCriteria.getSearchFor() != null) {
      Path<String> pathName = root.get("name");
      Predicate predicateForName = criteriaBuilder.like(pathName, "%" + paginationCriteria.getSearchFor() + "%");
      criteriaQuery.where(predicateForName);
    }

    // Condition for sorting.
    if (paginationCriteria.getSortField() != null && !paginationCriteria.getSortField().isEmpty()) {
      Order order;
      if (paginationCriteria.getSortType() == 2) {
        order = criteriaBuilder.desc(root.get(paginationCriteria.getSortField()));
      } else {
        order = criteriaBuilder.asc(root.get(paginationCriteria.getSortField()));
      }
      criteriaQuery.orderBy(order);
    } else {
      Order order = criteriaBuilder.desc(root.get("id"));
      criteriaQuery.orderBy(order);
    }

    // Adding Pagination total Count
    CommonListTO<ProfitCenterBO> commonListTO = new CommonListTO<>();
    CriteriaQuery<Long> criteriaQuery2 = criteriaBuilder.createQuery(Long.class);
    Root<ProfitCenterBO> root2 = criteriaQuery2.from(ProfitCenterBO.class);
    criteriaQuery2.where(criteriaBuilder.equal(root2.get("deleteFlag"), false));
    CriteriaQuery<Long> select = criteriaQuery2.select(criteriaBuilder.count(root2));
    Long count = entityManager.createQuery(select).getSingleResult();
    commonListTO.setTotalRow(count);
    int size = count.intValue();
    int limit = paginationCriteria.getLimit();
    if (limit != 0) {
      commonListTO.setPageCount((size + limit - 1) / limit);
    } else {
      commonListTO.setPageCount(1);
    }

    TypedQuery<ProfitCenterBO> typedQuery = entityManager.createQuery(criteriaQuery);
    // Condition for paging.
    if (paginationCriteria.getPage() != 0 && paginationCriteria.getLimit() > 0) {
      typedQuery.setFirstResult((paginationCriteria.getPage() - 1) * paginationCriteria.getLimit());
      typedQuery.setMaxResults(paginationCriteria.getLimit());
    }
    commonListTO.setDataList(typedQuery.getResultList());
    return commonListTO;
  }

  @Override
  public ProfitCenterBO getProfitCenterById(Long id) {
    CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
    CriteriaQuery<ProfitCenterBO> criteriaQuery = criteriaBuilder.createQuery(ProfitCenterBO.class);

    Root<ProfitCenterBO> root = criteriaQuery.from(ProfitCenterBO.class);
    Predicate predicateForId = criteriaBuilder.equal(root.get("id"), id);
    Predicate predicateForDeleteFlag = criteriaBuilder.equal(root.get("deleteFlag"), false);
    Predicate predicate = criteriaBuilder.and(predicateForId, predicateForDeleteFlag);
    criteriaQuery.where(predicate);
    return entityManager.createQuery(criteriaQuery).getSingleResult();
  }

  @Override
  public void deleteProfitCenter(List<Long> id) {
    CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
    CriteriaUpdate<ProfitCenterBO> criteriaUpdate = criteriaBuilder.createCriteriaUpdate(ProfitCenterBO.class);
    Root<ProfitCenterBO> root = criteriaUpdate.from(ProfitCenterBO.class);
    criteriaUpdate.set("deleteFlag", true);
    criteriaUpdate.where(root.get("id").in(id));
    entityManager.createQuery(criteriaUpdate).executeUpdate();
  }
}
