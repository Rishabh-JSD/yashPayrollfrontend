package com.hb.company.profitCenter.dto;

import com.hb.address.entity.AddressBO;
import com.hb.common.AuditTO;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProfitCenterTO extends AuditTO {

  private Long id;
  private String name;
  private Long branchId;
  private boolean sameAsBranch;
  private Long addressId;
  private Long headId;
  private Long phoneNo;
  private String email;
  private Long shiftTypeId;
  private Long shiftTimingId;
  private boolean deleteFlag;
  private AddressBO address;
}
