package com.hb.company.profitCenter.entity;

import com.hb.address.entity.AddressBO;
import com.hb.common.Audit;
import com.hb.common.TABLES;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = TABLES.PROFIT_CENTER)
public class ProfitCenterBO extends Audit {

  private static final long serialVersionUID = 5783575715004639338L;

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "id", updatable = false)
  private Long id;

  @Column(name = "name")
  private String name;

  @Column(name = "branch_id")
  private Long branchId;

  @Column(name = "same_as_branch")
  private boolean sameAsBranch;

  @Column(name = "address_id", insertable = false, updatable = false)
  private Long addressId;

  @Column(name = "head_id")
  private Long headId;

  @Column(name = "phone_no")
  private Long phoneNo;

  @Column(name = "email")
  private String email;

  @Column(name = "shift_type_id")
  private Long shiftTypeId;

  @Column(name = "shift_timing_id")
  private Long shiftTimingId;

  @Column(name = "delete_flag")
  private boolean deleteFlag;

  @OneToOne(cascade = CascadeType.ALL, orphanRemoval = true)
  @JoinColumn(name = "address_id")
  private AddressBO address;
}
