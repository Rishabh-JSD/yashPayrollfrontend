package com.hb.company.profitCenter.service;

import com.hb.common.PaginationCriteria;
import com.hb.common.SearchResponseTO;
import com.hb.company.profitCenter.dto.ProfitCenterTO;

import java.util.List;

public interface ProfitCenterService {

  ProfitCenterTO addProfitCenter(ProfitCenterTO profitCenterTO);

  ProfitCenterTO updateProfitCenter(ProfitCenterTO profitCenterTO);

  SearchResponseTO getProfitCenterList(PaginationCriteria paginationCriteria);

  ProfitCenterTO getProfitCenterById(Long id);

  void deleteProfitCenter(List<Long> profitCenterId);
}
