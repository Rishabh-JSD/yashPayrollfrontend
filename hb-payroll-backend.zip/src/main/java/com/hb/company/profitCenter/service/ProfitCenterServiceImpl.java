package com.hb.company.profitCenter.service;

import com.hb.common.MapperService;
import com.hb.common.PaginationCriteria;
import com.hb.common.SearchResponseTO;
import com.hb.company.profitCenter.dao.ProfitCenterDao;
import com.hb.company.profitCenter.dto.ProfitCenterTO;
import com.hb.company.profitCenter.entity.ProfitCenterBO;
import com.hb.master.dto.CommonListTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;

@Service
@Transactional
public class ProfitCenterServiceImpl implements ProfitCenterService {

  @Autowired
  private ProfitCenterDao profitCenterDao;

  @Autowired
  private MapperService mapperService;

  @Override
  public ProfitCenterTO addProfitCenter(ProfitCenterTO profitCenterTO) {
    ProfitCenterBO profitCenterBO = mapperService.map(profitCenterTO, ProfitCenterBO.class);
    return mapperService.map(profitCenterDao.addProfitCenter(profitCenterBO), ProfitCenterTO.class);
  }

  @Override
  public ProfitCenterTO updateProfitCenter(ProfitCenterTO profitCenterTO) {
    ProfitCenterBO profitCenterBO = mapperService.map(profitCenterTO, ProfitCenterBO.class);
    return mapperService.map(profitCenterDao.updateProfitCenter(profitCenterBO), ProfitCenterTO.class);
  }

  @Override
  @Transactional(Transactional.TxType.NOT_SUPPORTED)
  public SearchResponseTO getProfitCenterList(PaginationCriteria paginationCriteria) {
    SearchResponseTO searchResponseTO = new SearchResponseTO();
    CommonListTO<ProfitCenterBO> commonListTO = profitCenterDao.getProfitCenterList(paginationCriteria);

    List<ProfitCenterTO> profitCenterTOS = mapperService.map(commonListTO.getDataList(), ProfitCenterTO.class);
    searchResponseTO.setList(profitCenterTOS);
    searchResponseTO.setPageCount(commonListTO.getPageCount());
    searchResponseTO.setTotalRowCount(commonListTO.getTotalRow().intValue());
    return searchResponseTO;
  }

  @Override
  @Transactional(Transactional.TxType.NOT_SUPPORTED)
  public ProfitCenterTO getProfitCenterById(Long id) {
    return mapperService.map(profitCenterDao.getProfitCenterById(id), ProfitCenterTO.class);
  }

  @Override
  public void deleteProfitCenter(List<Long> id) {
    profitCenterDao.deleteProfitCenter(id);
  }

}
