package com.hb.company.profitCenter.validator;

import com.hb.common.PaginationCriteria;
import com.hb.company.profitCenter.controller.ProfitCenterController;
import com.hb.company.profitCenter.dto.ProfitCenterTO;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.ControllerAdvice;

@ControllerAdvice(assignableTypes = ProfitCenterController.class)
public class ProfitCenterValidator implements Validator {

  @Override
  public boolean supports(Class<?> aClass) {
    boolean support = ProfitCenterTO.class.equals(aClass);
    if (!support) {
      support = PaginationCriteria.class.equals(aClass);
    }
    return support;
  }

  @Override
  public void validate(Object o, Errors errors) {
    ProfitCenterTO profitCenterTO = (ProfitCenterTO) o;

//    ValidationUtils.rejectIfEmptyOrWhitespace(errors, "name", "PMS001E", APP_MSG.MESSAGE.get("PR001E"));

  }
}
