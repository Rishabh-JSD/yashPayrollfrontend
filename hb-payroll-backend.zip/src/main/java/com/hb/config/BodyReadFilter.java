package com.hb.config;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

public class BodyReadFilter implements Filter {

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {

	}

	@Override
	public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain)
			throws IOException, ServletException {

		MultiReadHttpServletRequest wrappedRequest = new MultiReadHttpServletRequest(
				(HttpServletRequest) servletRequest);

		filterChain.doFilter(wrappedRequest, servletResponse);
	}

	@Override
	public void destroy() {

	}
}