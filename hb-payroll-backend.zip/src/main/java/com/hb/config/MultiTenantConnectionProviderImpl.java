package com.hb.config;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import org.hibernate.engine.jdbc.connections.spi.AbstractDataSourceBasedMultiTenantConnectionProviderImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import com.hb.common.APP_CONST;

@Component
public class MultiTenantConnectionProviderImpl extends AbstractDataSourceBasedMultiTenantConnectionProviderImpl {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private static final Logger logger = LoggerFactory.getLogger(MultiTenantConnectionProviderImpl.class);

	@Autowired
	private DataSource dataSource;

	@Autowired
	private ApplicationContext context;

	private Map<String, DataSource> map = new HashMap<>();

	boolean init = false;

	@PostConstruct
	public void load() {
		map.put(APP_CONST.DEFAULT_TENANT, dataSource);
	}

	public void setManualDatasource(String tenantId, DataSource dataSource) {
		map.put(tenantId, dataSource);
	}

	@Override
	protected DataSource selectAnyDataSource() {
		logger.info("*************************" + APP_CONST.DEFAULT_TENANT + "*********************");
		logger.info("**********Fetching default connection***********");
		return map.get(APP_CONST.DEFAULT_TENANT);
	}

	@Override
	protected DataSource selectDataSource(String tenantIdentifier) {
		if (!init) {
			init = true;
			TenantDataSource tenantDataSource = context.getBean(TenantDataSource.class);
			map.putAll(tenantDataSource.getAll());
		}

		if (map.get(tenantIdentifier) != null) {
			logger.info("*************************" + tenantIdentifier + "*********************");
			System.out.println("**********Fetching Client DB connection***********");
			return map.get(tenantIdentifier);
		} else {
			logger.info("*************************" + APP_CONST.DEFAULT_TENANT + "*********************");
			logger.info("**********Fetching default connection***********");
			return map.get(APP_CONST.DEFAULT_TENANT);
		}
	}

}
