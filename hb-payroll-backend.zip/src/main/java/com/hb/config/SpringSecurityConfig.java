package com.hb.config;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.session.SessionRegistry;
import org.springframework.security.core.session.SessionRegistryImpl;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import com.hb.common.APP_CONST;
import com.hb.master.service.UserService;

@Configuration
@EnableWebSecurity
@EnableScheduling
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class SpringSecurityConfig extends WebSecurityConfigurerAdapter {

	@Autowired
	private UserService userService;

	@Override
	public void configure(HttpSecurity http) throws Exception {
		final TokenAuthenticationFilter tokenAuthenticationFilter = new TokenAuthenticationFilter(userService);
		http.addFilterBefore(tokenAuthenticationFilter, BasicAuthenticationFilter.class);
		final BasicAuthenticationFilter customBasicAuthFilter = new BasicAuthenticationFilter(
				this.authenticationManager());
		http.addFilter(customBasicAuthFilter);
		http.cors().and().authorizeRequests().antMatchers("/").permitAll();
		http.cors().and().authorizeRequests().anyRequest().authenticated().and().csrf().disable().httpBasic().and()
				.exceptionHandling().authenticationEntryPoint(authenticationEntryPoint());

	}

	@Bean
	CorsConfigurationSource corsConfigurationSource() {
		CorsConfiguration configuration = new CorsConfiguration();
		configuration.setAllowedOrigins(Arrays.asList(APP_CONST.HEADER.CORS_CONFIG_ORIGIN));
		configuration.setAllowedMethods(Arrays.asList(APP_CONST.HEADER.HTTP_ALLOWED_METHODS.split("\\s*,\\s*")));
		configuration.setAllowedHeaders(Arrays.asList(APP_CONST.HEADER.HTTP_ALLOWED_HEADERS.split("\\s*,\\s*")));
		configuration.addExposedHeader(APP_CONST.HEADER.ACCESS_CONTROL_ALLOW_ORIGIN);
		UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
		source.registerCorsConfiguration(APP_CONST.HEADER.CORS_CONFIG_PATH, configuration);
		return source;
	}

	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		super.configure(auth);
	}

	@Override
	public void configure(WebSecurity web) throws Exception {
//		web.ignoring().antMatchers("/user/*");
	}

	@Bean
	public SessionRegistry sessionRegistry() {
		return new SessionRegistryImpl();
	}

	@Bean
	public AuthenticationEntryPoint authenticationEntryPoint() {
		return new CustomAuthenticationEntryPoint();
	}

	@Bean
	public PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}
}
