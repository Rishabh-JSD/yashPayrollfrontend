package com.hb.config;

public class TenantContext {

	private static ThreadLocal<String> currentTenant = new InheritableThreadLocal<>();

	private static ThreadLocal<String> currentTenantCat = new InheritableThreadLocal<>();

	private static ThreadLocal<String> currentTenantCatChild = new InheritableThreadLocal<>();

	public static String getCurrentTenant() {
		return currentTenant.get();
	}

	public static void setCurrentTenant(String tenant) {
		currentTenant.set(tenant);
	}

	public static void clearCurrentTenant() {
		currentTenant.set(null);
	}

	public static String getCurrentTenantCat() {
		return currentTenantCat.get();
	}

	public static void setCurrentTenantCat(String tenant) {
		currentTenantCat.set(tenant);
	}

	public static void clearCurrentTenantCat() {
		currentTenantCat.set(null);
	}

	public static String getCurrentTenantCatChild() {
		return currentTenantCatChild.get();
	}

	public static void setCurrentTenantCatChild(String tenant) {
		currentTenantCatChild.set(tenant);
	}

	public static void clearCurrentTenantCatChild() {
		currentTenantCatChild.set(null);
	}
}
