package com.hb.config;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.stereotype.Component;

import com.hb.master.dao.MasterBusinessDataSourceDao;
import com.hb.master.entity.MasterBusinessDataSource;

@Component
public class TenantDataSource implements Serializable {

	private static final long serialVersionUID = 1L;

	private HashMap<String, DataSource> dataSources = new HashMap<>();

	@Autowired
	private MasterBusinessDataSourceDao configRepo;

	public DataSource getDataSource(String name) {
		if (dataSources.get(name) != null) {
			return dataSources.get(name);
		}
		DataSource dataSource = createDataSource(name);
		if (dataSource != null) {
			dataSources.put(name, dataSource);
		}
		return dataSource;
	}

	@PostConstruct
	public Map<String, DataSource> getAll() {
		List<MasterBusinessDataSource> configList = configRepo.getDatasourceConfigList();
		Map<String, DataSource> result = new HashMap<>();
		for (MasterBusinessDataSource config : configList) {
			result.put(config.getTenantId(), this.getDataSource(config));
		}
		return result;
	}

	private DataSource createDataSource(String tenantId) {
		MasterBusinessDataSource config = configRepo.getDatasourceConfigByTenantId(tenantId);
		return this.getDataSource(config);
	}

	private DataSource getDataSource(MasterBusinessDataSource config) {
		if (config != null) {
			DataSourceBuilder<?> factory = DataSourceBuilder.create().driverClassName(config.getDriver())
					.username(config.getUsername()).password(config.getPassword()).url(config.getDatasource());
			DataSource ds = factory.build();
			return ds;
		}
		return null;
	}
}
