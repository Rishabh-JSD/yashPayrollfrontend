package com.hb.config;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import com.hb.common.APP_CONST;
import com.hb.common.CommonUtill;
import com.hb.exception.UserTokenKeyNotValidException;

@Component
public class TenantInterceptor implements HandlerInterceptor {

	@Value("${spring.profiles.active}")
	private String activeProfile;

	private static final Logger logger = LoggerFactory.getLogger(TenantInterceptor.class);

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {

		logger.debug("*********0000API0000 Request URI 000000API000000*********" + request.getRequestURI());

		if (CommonUtill.isValid(activeProfile) && !activeProfile.equals("local") && !activeProfile.equals("dev")) {
			if (APP_CONST.PRESERVE_KEY_FLAG.equals(request.getAttribute(APP_CONST.PRESERVE_KEY) + "")
					|| APP_CONST.TOKEN_KEY_FLAG.equals(request.getAttribute(APP_CONST.TOKEN_KEY) + "")) {
				throw new UserTokenKeyNotValidException();
			}
		}
		return HandlerInterceptor.super.preHandle(request, response, handler);
	}

	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		HandlerInterceptor.super.postHandle(request, response, handler, modelAndView);
	}

}
