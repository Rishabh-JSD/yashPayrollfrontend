package com.hb.config;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.filter.GenericFilterBean;

import com.hb.common.APP_CONST;
import com.hb.master.dto.UserTO;
import com.hb.master.service.UserService;

public class TokenAuthenticationFilter extends GenericFilterBean {

	UserService userService;

	public TokenAuthenticationFilter(UserService userDetailsService) {
		super();
		this.userService = userDetailsService;
	}

	@Override
	public void doFilter(final ServletRequest request, final ServletResponse response, final FilterChain chain)
			throws IOException, ServletException {
		final HttpServletRequest httpRequest = (HttpServletRequest) request;
		final String accessToken = httpRequest.getHeader(APP_CONST.HEADER.AUTH_TOKEN);
		final String preserveKey = httpRequest.getHeader(APP_CONST.HEADER.PRESERVE_KEY_HEADER);
		if (accessToken != null) {
			// Get user from database
			UserTO userdata = userService.loadUserByToken(accessToken);
			if (userdata != null) {
				// Setting business tenant and shared category schema
				TenantContext.setCurrentTenant(httpRequest.getHeader(APP_CONST.HEADER.TENANT_HEADER));
				TenantContext.setCurrentTenantCat(httpRequest.getHeader(APP_CONST.HEADER.CAT_HEADER));
				TenantContext.setCurrentTenantCatChild(httpRequest.getHeader(APP_CONST.HEADER.CAT_CHILD_HEADER));
				// Setting User Into UserSessionContext
				UserSessionContext.setCurrentTenant(userdata);
				SecurityContextHolder.getContext().setAuthentication(
						new UsernamePasswordAuthenticationToken(userdata, null, userdata.getAuthorities()));
			} else {
				request.setAttribute(APP_CONST.TOKEN_KEY, APP_CONST.TOKEN_KEY_FLAG);
			}

			if (preserveKey != null) {
				if (!(accessToken).equals(preserveKey + APP_CONST.KEY) || userService.getToken(preserveKey).isEmpty()) {
					request.setAttribute(APP_CONST.PRESERVE_KEY, APP_CONST.PRESERVE_KEY_FLAG);
				}
			}
		}
		chain.doFilter(request, response);
	}
}