package com.hb.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hb.master.dto.RoleTO;
import com.hb.master.dto.UserTO;

public class UserSessionContext {

	private static final Logger logger = LoggerFactory.getLogger(UserSessionContext.class.getName());

	private static final ThreadLocal<UserTO> currentTenant = new ThreadLocal<>();

	public static void setCurrentTenant(UserTO userTO) {
		logger.debug("Setting User session Context ************************************ ===> " + userTO);
		currentTenant.set(userTO);
	}

	public static UserTO getCurrentTenant() {
		return currentTenant.get();
	}
	
	public static RoleTO getUserRole() {
		UserTO userData = UserSessionContext.getCurrentTenant();
		if(userData != null && userData.getRoles() != null && userData.getRoles().size() > 0) {
			return userData.getRoles().get(0);
		}
		return null;
	}

	public static void clear() {
		currentTenant.set(null);
	}

}
