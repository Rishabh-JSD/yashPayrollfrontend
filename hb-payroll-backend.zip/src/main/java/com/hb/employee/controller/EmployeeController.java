package com.hb.employee.controller;

import com.hb.common.PaginationCriteria;
import com.hb.common.ResponseDTO;
import com.hb.common.SearchResponseTO;
import com.hb.common.ValidationError;
import com.hb.employee.dto.EmployeeLabelTO;
import com.hb.employee.dto.EmployeeTO;
import com.hb.employee.entity.EmployeeProxyBO;
import com.hb.employee.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/employee")
public class EmployeeController {

  @Autowired
  private Validator employeeValidator;

  @Autowired
  private EmployeeService employeeService;

  private ResponseDTO responseDTO;

  @InitBinder
  private void initBinder(WebDataBinder binder) {
    binder.setValidator(employeeValidator);
  }

  @RequestMapping(value = "/add", method = RequestMethod.POST, name = "Employee Master Add->EMPCR")
  public ResponseEntity<?> addEmployee(@Valid @RequestBody EmployeeTO employeeTO, Errors errors) {
    if (errors.hasErrors()) {
      ValidationError validationError = ValidationError.fromBindingErrors(errors);
      return new ResponseEntity<>(validationError, HttpStatus.OK);
    }
    EmployeeTO employeeTO_return = employeeService.addEmployee(employeeTO);
    responseDTO = ResponseDTO.responseBuilder(200, "PR001", "/employee", "employee", employeeTO_return);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/update", method = RequestMethod.POST, name = "Employee Master Update->EMPCR")
  public ResponseEntity<?> updateEmployee(@Valid @RequestBody EmployeeTO employeeTO, Errors errors) {
    if (errors.hasErrors()) {
      ValidationError validationError = ValidationError.fromBindingErrors(errors);
      return new ResponseEntity<>(validationError, HttpStatus.OK);
    }
    EmployeeTO employeeTO_return = employeeService.updateEmployee(employeeTO);
    responseDTO = ResponseDTO.responseBuilder(200, "PR002", "/employee", "employee", employeeTO_return);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/list", method = RequestMethod.POST, name = "Employee Master List->EMPCR")
  public ResponseEntity<?> getEmployeeList(@RequestBody PaginationCriteria paginationCriteria) {
    SearchResponseTO searchResponseTO = employeeService.getEmployeeList(paginationCriteria);
    if (searchResponseTO.getList() == null || searchResponseTO.getList().isEmpty()) {
      responseDTO = ResponseDTO.responseBuilder(200, "PR006", "/employee", "employee", searchResponseTO);
      return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }
    responseDTO = ResponseDTO.responseBuilder(200, "PR003", "/employee", "employee", searchResponseTO);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/{id}", method = RequestMethod.GET, name = "Employee Master View->EMPCR")
  public ResponseEntity<?> getEmployeeById(@PathVariable Long id) {
    EmployeeTO employeeTO = employeeService.getEmployeeById(id);
    if (employeeTO == null) {
      responseDTO = ResponseDTO.responseBuilder(200, "PR007", "/employee", "employee", null);
      return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }
    responseDTO = ResponseDTO.responseBuilder(200, "PR004", "/employee", "employee", employeeTO);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }
  @RequestMapping(value = "/employeeName/{id}", method = RequestMethod.GET, name = "Employee Master View->EMPCR")
  public ResponseEntity<?> getEmployeeNameById(@PathVariable Long id) {
    EmployeeLabelTO employeeLabelTO = employeeService.getEmployeeNameById(id);
    if (employeeLabelTO == null) {
      responseDTO = ResponseDTO.responseBuilder(200, "PR007", "/employee", "employee", null);
      return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }
    responseDTO = ResponseDTO.responseBuilder(200, "PR004", "/employee", "employee", employeeLabelTO);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }


  @RequestMapping(value = "/proxy/{id}", method = RequestMethod.GET, name = "Employee Label View->EMPCR")
  public ResponseEntity<?> getEmployeeProxyById(@PathVariable Long id) {
    EmployeeProxyBO employeeProxyBO = employeeService.getEmployeeProxyById(id);
    if (employeeProxyBO == null) {
      responseDTO = ResponseDTO.responseBuilder(200, "PMS007", "/employee", "employee", null);
      return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }
    responseDTO = ResponseDTO.responseBuilder(200, "PMS004", "/employee", "employee", employeeProxyBO);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/delete", method = RequestMethod.DELETE, name = "Employee Master Delete->EMPCR")
  public ResponseEntity<?> deleteEmployee(@RequestParam(name = "employeeId") List<Long> employeeId) {
    employeeService.deleteEmployee(employeeId);
    responseDTO = ResponseDTO.responseBuilder(200, "PR005", "/employee", "employee", employeeId);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }
}
