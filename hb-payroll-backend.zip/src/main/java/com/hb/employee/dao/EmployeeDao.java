package com.hb.employee.dao;

import com.hb.common.PaginationCriteria;
import com.hb.employee.entity.EmployeeBO;
import com.hb.employee.entity.EmployeeNameBO;
import com.hb.employee.entity.EmployeeProxyBO;
import com.hb.master.dto.CommonListTO;

import java.util.List;

public interface EmployeeDao {

  EmployeeBO addEmployee(EmployeeBO employeeTO);

  EmployeeBO updateEmployee(EmployeeBO employeeTO);

  CommonListTO<EmployeeBO> getEmployeeList(PaginationCriteria paginationCriteria);

  EmployeeBO getEmployeeById(Long id);

  EmployeeNameBO getEmployeeNameById(Long id);

  EmployeeProxyBO getEmployeeProxyById(Long employeeId);

  void deleteEmployee(List<Long> id);

  Long employeeCount(Long id, String type);
}
