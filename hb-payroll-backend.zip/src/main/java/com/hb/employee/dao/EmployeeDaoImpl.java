package com.hb.employee.dao;

import com.hb.common.PaginationCriteria;
import com.hb.employee.entity.EmployeeBO;
import com.hb.employee.entity.EmployeeCompanyDetailsBO;
import com.hb.employee.entity.EmployeeNameBO;
import com.hb.employee.entity.EmployeeProxyBO;
import com.hb.master.dto.CommonListTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.*;
import java.util.ArrayList;
import java.util.List;

@Repository
public class EmployeeDaoImpl implements EmployeeDao {

  @PersistenceContext
  private EntityManager entityManager;

  private static final Logger logger = LoggerFactory.getLogger(EmployeeDaoImpl.class);

  @Override
  public EmployeeBO addEmployee(EmployeeBO employeeBO) {
    entityManager.persist(employeeBO);
    logger.info("Employee has added successfully, Employee details=" + employeeBO);
    return employeeBO;
  }

  @Override
  public EmployeeBO updateEmployee(EmployeeBO employeeBO) {
    entityManager.merge(employeeBO);
    logger.info("Employee has updated successfully, Employee details=" + employeeBO);
    return employeeBO;
  }

  @Override
  public CommonListTO<EmployeeBO> getEmployeeList(PaginationCriteria paginationCriteria) {
    CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
    CriteriaQuery<EmployeeBO> criteriaQuery = criteriaBuilder.createQuery(EmployeeBO.class);
    Root<EmployeeBO> root = criteriaQuery.from(EmployeeBO.class);
    List<Predicate> predicates=new ArrayList<>();
    predicates.add(criteriaBuilder.equal(root.get("deleteFlag"), false));
//    if (paginationCriteria.getDepartmentId() != null) {
//      Join<EmployeeBO, EmployeeCompanyDetailsBO> lineJoin = root.join("employeeCompanyDetails");
//      Predicate predicateBranch = criteriaBuilder.equal(lineJoin.get("departmentId"), paginationCriteria.getDepartmentId());
//      predicate = criteriaBuilder.and(predicate, predicateBranch);
//    }
//    criteriaQuery.where(predicate);
    if (paginationCriteria.getDepartmentId() != null) {
      Join<EmployeeBO, EmployeeCompanyDetailsBO> lineJoin = root.join("employeeCompanyDetails");
      predicates.add(criteriaBuilder.equal(lineJoin.get("departmentId"), paginationCriteria.getDepartmentId()));
    }


    //condition for search
//    if (paginationCriteria.getSearchFor() != null && !paginationCriteria.getSearchFor().isEmpty()) {
//      Path<String> pathName = root.get("name");
//      Predicate predicateForName = criteriaBuilder.like(pathName, "%" + paginationCriteria.getSearchFor() + "%");
//      // Assuming "deleteFlag" is the field representing the deletion status
//      Path<Boolean> pathDeleteFlag = root.get("deleteFlag");
//      Predicate predicateNotDeleted = criteriaBuilder.isFalse(pathDeleteFlag);
//      criteriaQuery.where(criteriaBuilder.and(predicateForName, predicateNotDeleted));
//    }
    if (paginationCriteria.getSearchFor() != null && !paginationCriteria.getSearchFor().isEmpty()) {
      Path<String> pathName = root.get("name");
      Predicate predicateForName = criteriaBuilder.like(pathName, "%" + paginationCriteria.getSearchFor() + "%");
      // Assuming "deleteFlag" is the field representing the deletion status
      Path<Boolean> pathDeleteFlag = root.get("deleteFlag");
      Predicate predicateNotDeleted = criteriaBuilder.isFalse(pathDeleteFlag);
      predicates.add(criteriaBuilder.and(predicateForName, predicateNotDeleted));
    }
    // Combine all predicates using AND
    Predicate finalPredicate = criteriaBuilder.and(predicates.toArray(new Predicate[0]));
    criteriaQuery.where(finalPredicate);

    // Condition for sorting.
    if (paginationCriteria.getSortField() != null && !paginationCriteria.getSortField().isEmpty()) {
      Order order;
      if (paginationCriteria.getSortType() == 2) {
        order = criteriaBuilder.desc(root.get(paginationCriteria.getSortField()));
      } else {
        order = criteriaBuilder.asc(root.get(paginationCriteria.getSortField()));
      }
      criteriaQuery.orderBy(order);
    } else {
      Order order = criteriaBuilder.desc(root.get("id"));
      criteriaQuery.orderBy(order);
    }

    // Adding Pagination total Count
    CommonListTO<EmployeeBO> commonListTO = new CommonListTO<>();
    CriteriaQuery<Long> criteriaQuery2 = criteriaBuilder.createQuery(Long.class);
    Root<EmployeeBO> root2 = criteriaQuery2.from(EmployeeBO.class);
    criteriaQuery2.where(criteriaBuilder.equal(root2.get("deleteFlag"), false));
    CriteriaQuery<Long> select = criteriaQuery2.select(criteriaBuilder.count(root2));
    Long count = entityManager.createQuery(select).getSingleResult();
    commonListTO.setTotalRow(count);
    int size = count.intValue();
    int limit = paginationCriteria.getLimit();
    if (limit != 0) {
      commonListTO.setPageCount((size + limit - 1) / limit);
    } else {
      commonListTO.setPageCount(1);
    }

    TypedQuery<EmployeeBO> typedQuery = entityManager.createQuery(criteriaQuery);
    // Condition for paging.
    if (paginationCriteria.getPage() != 0 && paginationCriteria.getLimit() > 0) {
      typedQuery.setFirstResult((paginationCriteria.getPage() - 1) * paginationCriteria.getLimit());
      typedQuery.setMaxResults(paginationCriteria.getLimit());
    }
    commonListTO.setDataList(typedQuery.getResultList());
    return commonListTO;
  }

  @Override
  public EmployeeBO getEmployeeById(Long id) {
    CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
    CriteriaQuery<EmployeeBO> criteriaQuery = criteriaBuilder.createQuery(EmployeeBO.class);

    Root<EmployeeBO> root = criteriaQuery.from(EmployeeBO.class);
    Predicate predicateForId = criteriaBuilder.equal(root.get("id"), id);
    Predicate predicateForDeleteFlag = criteriaBuilder.equal(root.get("deleteFlag"), false);
    Predicate predicate = criteriaBuilder.and(predicateForId, predicateForDeleteFlag);
    criteriaQuery.where(predicate);
    return entityManager.createQuery(criteriaQuery).getSingleResult();
  }

  @Override
  public EmployeeNameBO getEmployeeNameById(Long id) {
    CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
    CriteriaQuery<EmployeeNameBO> criteriaQuery = criteriaBuilder.createQuery(EmployeeNameBO.class);

    Root<EmployeeNameBO> root = criteriaQuery.from(EmployeeNameBO.class);
    Predicate predicateForId = criteriaBuilder.equal(root.get("id"), id);
    Predicate predicateForDeleteFlag = criteriaBuilder.equal(root.get("deleteFlag"), false);
    Predicate predicate = criteriaBuilder.and(predicateForId, predicateForDeleteFlag);
    criteriaQuery.where(predicate);
    return entityManager.createQuery(criteriaQuery).getSingleResult();
  }

  @Override
  public EmployeeProxyBO getEmployeeProxyById(Long employeeId) {
    EmployeeProxyBO employeeProxyBO = entityManager.find(EmployeeProxyBO.class, employeeId);
    logger.info("Employee loaded successfully, Employee details" + employeeProxyBO);
    return employeeProxyBO;
  }

  @Override
  public void deleteEmployee(List<Long> id) {
    CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
    CriteriaUpdate<EmployeeBO> criteriaUpdate = criteriaBuilder.createCriteriaUpdate(EmployeeBO.class);
    Root<EmployeeBO> root = criteriaUpdate.from(EmployeeBO.class);
    criteriaUpdate.set("deleteFlag", true);
    criteriaUpdate.where(root.get("id").in(id));
    entityManager.createQuery(criteriaUpdate).executeUpdate();
  }

  @Override
  public Long employeeCount(Long id, String type) {
    CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
    CriteriaQuery<Long> criteriaQuery = criteriaBuilder.createQuery(Long.class);
    Root<EmployeeBO> root = criteriaQuery.from(EmployeeBO.class);

    Join<EmployeeBO, EmployeeCompanyDetailsBO> lineJoin = root.join("employeeCompanyDetails");
    Predicate predicate = criteriaBuilder.equal(root.get("deleteFlag"), false);
    Predicate predicateBranch = null;
    switch (type) {
      case "branch":
        predicateBranch = criteriaBuilder.equal(lineJoin.get("branchId"), id);
        break;
      case "costCenter":
        predicateBranch = criteriaBuilder.equal(lineJoin.get("costCenterId"), id);
        break;
      case "department":
        predicateBranch = criteriaBuilder.equal(lineJoin.get("departmentId"), id);
        break;
    }
    criteriaQuery.where(criteriaBuilder.and(predicate, predicateBranch));
    CriteriaQuery<Long> select = criteriaQuery.select(criteriaBuilder.count(root));
    Long count = 0L;
    try {
      count = entityManager.createQuery(select).getSingleResult();
    } catch (Exception e) {
      e.printStackTrace();
    }
    return count;
  }
}
