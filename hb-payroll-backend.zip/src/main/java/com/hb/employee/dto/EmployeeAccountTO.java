package com.hb.employee.dto;

import com.hb.common.AuditTO;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EmployeeAccountTO extends AuditTO {

  private Long id;
  private Long employeeId;
  private String fullName;
  private String bankName;
  private String accountNumber;
  private String branchName;
  private String ifsc;
  private boolean deleteFlag;
}
