package com.hb.employee.dto;

import com.hb.common.AuditTO;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
public class EmployeeAllowanceTO extends AuditTO {

  private Long id;
  private Long employeeSalaryDetailId;
  private Long allowanceMasterId;
  private String allowanceMasterName;
  private BigDecimal amount;
  private boolean deleteFlag;

}
