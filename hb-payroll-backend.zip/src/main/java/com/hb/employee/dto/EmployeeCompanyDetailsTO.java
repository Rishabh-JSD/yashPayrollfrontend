package com.hb.employee.dto;

import com.hb.common.AuditTO;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

@Getter
@Setter
public class EmployeeCompanyDetailsTO extends AuditTO {

  private Long id;
  private String employeeNumber;
  private Date joiningDate;
  private Long employeeCategoryId;
  private String employeeCategoryName;
  private String attendanceTypeCode;
  private Date contractFrom;
  private Date contractTo;
  private Long shiftTypeId;
  private String shiftTypeName;
  private Long shiftTimingId;
  private Date shiftTimingStartTime;
  private Date shiftTimingEndTime;
  private Long designationId;
  private String designationName;
  private Long branchId;
  private String branchName;
  private Long costCenterId;
  private String costCenterName;
  private Long departmentId;
  private String departmentName;
  private Long employeeLevelId;
  private String employeeLevelName;
  private Long reportToId;
  private String reportToName;
  private Long functionalAppraiserId;
  private String functionalAppraiserName;
  private Long adminAppraiserId;
  private String adminAppraiserName;
  private Long payFrequencyId;
  private String payFrequencyName;
  private Date separationDate;
  private boolean overtimeFlag;
  private String jobDescription;
  private boolean deleteFlag;
}
