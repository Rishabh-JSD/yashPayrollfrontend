package com.hb.employee.dto;

import com.hb.common.AuditTO;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EmployeeExperienceAttachmentTO extends AuditTO {

  private Long id;
  private Long employeeExperienceId;
  private Long documentTypeId;
  private String documentTypeName;
  private String remark;
  private Long documentId;
  private boolean deleteFlag;
}
