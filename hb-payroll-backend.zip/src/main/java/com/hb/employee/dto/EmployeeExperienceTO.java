package com.hb.employee.dto;

import com.hb.common.AuditTO;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;
import java.util.List;

@Getter
@Setter
public class EmployeeExperienceTO extends AuditTO {

  private Long id;
  private Long employeeId;
  private String title;
  private String employmentTypeCode;
  private String companyName;
  private Long countryId;
  private String countryName;
  private Long stateId;
  private String stateName;
  private Date startDate;
  private Date endDate;
  private String jobTitle;
  private Long industryId;
  private String industryName;
  private String jobDescription;
  private Long documentId;
  private boolean deleteFlag;
  private List<EmployeeExperienceAttachmentTO> employeeExperienceAttachments;

}
