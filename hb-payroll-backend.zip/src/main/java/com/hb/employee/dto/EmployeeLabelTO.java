package com.hb.employee.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EmployeeLabelTO {
    private Long id;
    private String name;
    private boolean deleteFlag;
}
