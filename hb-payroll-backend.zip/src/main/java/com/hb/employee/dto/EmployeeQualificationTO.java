package com.hb.employee.dto;

import com.hb.common.AuditTO;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EmployeeQualificationTO extends AuditTO {

  private Long id;
  private Long employeeId;
  private Long documentTypeId;
  private String documentTypeName;
  private String remark;
  private String institutionDescription;
  private Long countryId;
  private String countryName;
  private Long stateId;
  private String stateName;
  private Long documentId;
  private boolean deleteFlag;

}
