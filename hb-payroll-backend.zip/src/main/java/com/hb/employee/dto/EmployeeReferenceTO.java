package com.hb.employee.dto;

import com.hb.common.AuditTO;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EmployeeReferenceTO extends AuditTO {

  private Long id;
  private String name;
  private Long employeeId;
  private Long mobile;
  private boolean deleteFlag;

}
