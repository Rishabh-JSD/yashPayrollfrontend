package com.hb.employee.dto;

import com.hb.common.AuditTO;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.List;

@Getter
@Setter
public class EmployeeSalaryDetailsTO extends AuditTO {

  private Long id;
  private BigDecimal basicSalary;
  private BigDecimal ctc;
  private BigDecimal netPayBeforeTds;
  private String taxSummary;
  private boolean deleteFlag;
  private List<EmployeeReimbursementTO> employeeReimbursement;
  private List<EmployeeAllowanceTO> employeeAllowance;
  private List<EmployeeDeductionTO> employeeDeduction;
}
