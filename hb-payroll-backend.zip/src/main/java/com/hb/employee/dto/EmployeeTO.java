package com.hb.employee.dto;

import com.hb.address.dto.AddressTO;
import com.hb.common.AuditTO;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

@Getter
@Setter
public class EmployeeTO extends AuditTO {

  private Long id;
  private BigDecimal profileCompletion;
  private Long employmentStatusId;
  private String employmentStatusName;
  private String name;
  private String fathersName;
  private Date dob;
  private String gender;
  private String personalEmail;
  private String officialEmail;
  private Long phoneNo;
  private Long nationalityId;
  private String nationName;
  private String maritalStatus;
  private String pan;
  private String verificationAddress;
  private Long companyDetailId;
  private Long salaryDetailId;
  private Long addressCorrespondenceId;
  private boolean sameAsCorrespondence;
  private Long addressPermanentId;
  private boolean deleteFlag;
  private List<EmployeeAccountTO> employeeAccount;
  private List<EmployeeExperienceTO> employeeExperience;
  private List<EmployeeKycTO> employeeKyc;
  private List<EmployeeQualificationTO> employeeQualification;
  private List<EmployeeReferenceTO> employeeReference;
  private EmployeeCompanyDetailsTO employeeCompanyDetails;
  private EmployeeSalaryDetailsTO employeeSalaryDetails;
  private AddressTO addressCorrespondence;
  private AddressTO addressPermanent;
  private Long termCompleted;
}
