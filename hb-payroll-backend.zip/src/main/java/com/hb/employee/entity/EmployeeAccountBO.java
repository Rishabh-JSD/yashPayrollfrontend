package com.hb.employee.entity;

import com.hb.common.Audit;
import com.hb.common.TABLES;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = TABLES.EMPLOYEE_ACCOUNT)
public class EmployeeAccountBO extends Audit {

  private static final long serialVersionUID = 3109011182819185419L;

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "id", updatable = false)
  private Long id;

  @Column(name = "employee_id")
  private Long employeeId;

  @Column(name = "full_name")
  private String fullName;

  @Column(name = "bank_name")
  private String bankName;

  @Column(name = "account_number")
  private String accountNumber;

  @Column(name = "branch_name")
  private String branchName;

  @Column(name = "ifsc")
  private String ifsc;

  @Column(name = "delete_flag")
  private boolean deleteFlag;
}
