package com.hb.employee.entity;

import com.hb.address.entity.AddressBO;
import com.hb.common.Audit;
import com.hb.common.TABLES;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

@Getter
@Setter
@Entity
@Table(name = TABLES.EMPLOYEE)
public class EmployeeBO extends Audit {

  private static final long serialVersionUID = 3201179579546975295L;

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "id", updatable = false)
  private Long id;

  @Column(name = "profile_completion")
  private BigDecimal profileCompletion;

  @Column(name = "employment_status_id")
  private Long employmentStatusId;

  @Column(name = "name")
  private String name;

  @Column(name = "fathers_name")
  private String fathersName;

  @Column(name = "dob")
  private Date dob;

  @Column(name = "gender")
  private String gender;

  @Column(name = "personal_email")
  private String personalEmail;

  @Column(name = "official_email")
  private String officialEmail;

  @Column(name = "phone_no")
  private Long phoneNo;

  @Column(name = "nationality_id")
  private Long nationalityId;

  @Column(name = "marital_status")
  private String maritalStatus;

  @Column(name = "pan")
  private String pan;

  @Column(name = "verification_address")
  private String verificationAddress;

  @Column(name = "company_detail_id", insertable = false, updatable = false)
  private Long companyDetailId;

  @Column(name = "salary_detail_id", insertable = false, updatable = false)
  private Long salaryDetailId;

  @Column(name = "address_correspondence_id", insertable = false, updatable = false)
  private Long addressCorrespondenceId;

  @Column(name = "same_as_correspondence")
  private boolean sameAsCorrespondence;

  @Column(name = "address_permanent_id", insertable = false, updatable = false)
  private Long addressPermanentId;

  @Column(name = "delete_flag")
  private boolean deleteFlag;

  @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
  @JoinColumn(name = "employee_id", referencedColumnName = "id")
  private List<EmployeeAccountBO> employeeAccount;

  @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
  @JoinColumn(name = "employee_id", referencedColumnName = "id")
  private List<EmployeeExperienceBO> employeeExperience;

  @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
  @JoinColumn(name = "employee_id", referencedColumnName = "id")
  private List<EmployeeKycBO> employeeKyc;

  @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
  @JoinColumn(name = "employee_id", referencedColumnName = "id")
  private List<EmployeeQualificationBO> employeeQualification;

  @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
  @JoinColumn(name = "employee_id", referencedColumnName = "id")
  private List<EmployeeReferenceBO> employeeReference;

  @OneToOne(cascade = CascadeType.ALL, orphanRemoval = true)
  @JoinColumn(name = "company_detail_id")
  private EmployeeCompanyDetailsBO employeeCompanyDetails;

  @OneToOne(cascade = CascadeType.ALL, orphanRemoval = true)
  @JoinColumn(name = "salary_detail_id")
  private EmployeeSalaryDetailsBO employeeSalaryDetails;

  @OneToOne(cascade = CascadeType.ALL, orphanRemoval = true)
  @JoinColumn(name = "address_correspondence_id")
  private AddressBO addressCorrespondence;

  @OneToOne(cascade = CascadeType.ALL, orphanRemoval = true)
  @JoinColumn(name = "address_permanent_id")
  private AddressBO addressPermanent;
}
