package com.hb.employee.entity;

import com.hb.common.Audit;
import com.hb.common.TABLES;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.util.Date;

@Getter
@Setter
@Entity
@Table(name = TABLES.EMPLOYEE_COMPANY_DETAILS)
public class EmployeeCompanyDetailsBO extends Audit {

  private static final long serialVersionUID = -6850364773775879679L;

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "id", updatable = false)
  private Long id;

  @Column(name = "employee_number")
  private String employeeNumber;

  @Column(name = "joining_date")
  private Date joiningDate;

  @Column(name = "employee_category_id")
  private Long employeeCategoryId;

  @Column(name = "attendance_type_code")
  private String attendanceTypeCode;

  @Column(name = "contract_from")
  private Date contractFrom;

  @Column(name = "contract_to")
  private Date contractTo;

  @Column(name = "shift_type_id")
  private Long shiftTypeId;

  @Column(name = "shift_timing_id")
  private Long shiftTimingId;

  @Column(name = "designation_id")
  private Long designationId;

  @Column(name = "branch_id")
  private Long branchId;

  @Column(name = "cost_center_id")
  private Long costCenterId;

  @Column(name = "department_id")
  private Long departmentId;

  @Column(name = "employee_level_id")
  private Long employeeLevelId;

  @Column(name = "report_to_id")
  private Long reportToId;

  @Column(name = "functional_appraiser_id")
  private Long functionalAppraiserId;

  @Column(name = "admin_appraiser_id")
  private Long adminAppraiserId;

  @Column(name = "pay_frequency_id")
  private Long payFrequencyId;

  @Column(name = "separation_date")
  private Date separationDate;

  @Column(name = "overtime_flag")
  private boolean overtimeFlag;

  @Column(name = "job_description")
  private String jobDescription;

  @Column(name = "delete_flag")
  private boolean deleteFlag;
}
