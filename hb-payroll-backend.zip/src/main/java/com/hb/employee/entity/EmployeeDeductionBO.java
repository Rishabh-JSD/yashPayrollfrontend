package com.hb.employee.entity;

import com.hb.common.Audit;
import com.hb.common.TABLES;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.math.BigDecimal;

@Getter
@Setter
@Entity
@Table(name = TABLES.EMPLOYEE_DEDUCTION)
public class EmployeeDeductionBO extends Audit {

  private static final long serialVersionUID = 8351134027752767144L;

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "id", updatable = false)
  private Long id;

  @Column(name = "employee_salary_detail_id")
  private Long employeeSalaryDetailId;

  @Column(name = "deduction_master_id")
  private Long deductionMasterId;

  @Column(name = "amount")
  private BigDecimal amount;

  @Column(name = "delete_flag")
  private boolean deleteFlag;

}
