package com.hb.employee.entity;

import com.hb.common.Audit;
import com.hb.common.TABLES;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = TABLES.EMPLOYEE_EXPERIENCE_ATTACHMENT)
public class EmployeeExperienceAttachmentBO extends Audit {

  private static final long serialVersionUID = -5315473268202663146L;

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "id", updatable = false)
  private Long id;

  @Column(name = "employee_experience_id")
  private Long employeeExperienceId;

  @Column(name = "document_type_id")
  private Long documentTypeId;

  @Column(name = "remark")
  private String remark;

  @Column(name = "document_id")
  private Long documentId;

  @Column(name = "delete_flag")
  private boolean deleteFlag;
}
