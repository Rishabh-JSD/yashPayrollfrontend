package com.hb.employee.entity;

import com.hb.common.Audit;
import com.hb.common.TABLES;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.util.Date;
import java.util.List;

@Getter
@Setter
@Entity
@Table(name = TABLES.EMPLOYEE_EXPERIENCE)
public class EmployeeExperienceBO extends Audit {

  private static final long serialVersionUID = 7528634853104503388L;

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "id", updatable = false)
  private Long id;

  @Column(name = "employee_id")
  private Long employeeId;

  @Column(name = "title")
  private String title;

  @Column(name = "employment_type_code")
  private String employmentTypeCode;

  @Column(name = "company_name")
  private String companyName;

  @Column(name = "country_id")
  private Long countryId;

  @Column(name = "state_id")
  private Long stateId;

  @Column(name = "start_date")
  private Date startDate;

  @Column(name = "end_date")
  private Date endDate;

  @Column(name = "job_title")
  private String jobTitle;

  @Column(name = "industry_id")
  private Long industryId;

  @Column(name = "job_description")
  private String jobDescription;

  @Column(name = "delete_flag")
  private boolean deleteFlag;

  @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
  @JoinColumn(name = "employee_experience_id", referencedColumnName = "id")
  private List<EmployeeExperienceAttachmentBO> employeeExperienceAttachments;
}
