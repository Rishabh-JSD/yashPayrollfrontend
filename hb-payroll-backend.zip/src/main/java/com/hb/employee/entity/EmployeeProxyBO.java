package com.hb.employee.entity;

import com.hb.common.TABLES;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Getter
@Setter
@Entity
@Table(name = TABLES.EMPLOYEE)
public class EmployeeProxyBO implements Serializable {

  private static final long serialVersionUID = -8480798400315942324L;

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "id", updatable = false)
  private Long id;

  @Column(name = "name")
  private String name;

  @Column(name = "fathers_name")
  private String fathersName;

  @Column(name = "dob")
  private Date dob;

  @Column(name = "gender")
  private String gender;

  @Column(name = "personal_email")
  private String personalEmail;

  @Column(name = "official_email")
  private String officialEmail;

  @Column(name = "phone_no")
  private Long phoneNo;

  @Column(name = "marital_status")
  private String maritalStatus;

  @Column(name = "pan")
  private String pan;

}
