package com.hb.employee.entity;

import com.hb.common.Audit;
import com.hb.common.TABLES;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = TABLES.EMPLOYEE_QUALIFICATION)
public class EmployeeQualificationBO extends Audit {

  private static final long serialVersionUID = -4843983390685831557L;

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "id", updatable = false)
  private Long id;

  @Column(name = "employee_id")
  private Long employeeId;

  @Column(name = "document_type_id")
  private Long documentTypeId;

  @Column(name = "remark")
  private String remark;

  @Column(name = "institution_description")
  private String institutionDescription;

  @Column(name = "country_id")
  private Long countryId;

  @Column(name = "state_id")
  private Long stateId;

  @Column(name = "document_id")
  private Long documentId;

  @Column(name = "delete_flag")
  private boolean deleteFlag;

}
