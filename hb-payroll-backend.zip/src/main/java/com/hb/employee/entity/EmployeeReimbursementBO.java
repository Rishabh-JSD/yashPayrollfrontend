package com.hb.employee.entity;

import com.hb.common.Audit;
import com.hb.common.TABLES;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.math.BigDecimal;

@Getter
@Setter
@Entity
@Table(name = TABLES.EMPLOYEE_REIMBURSEMENT)
public class EmployeeReimbursementBO extends Audit {

  private static final long serialVersionUID = -4680150453268086929L;

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "id", updatable = false)
  private Long id;

  @Column(name = "employee_salary_detail_id")
  private Long employeeSalaryDetailId;

  @Column(name = "reimbursement_master_id")
  private Long reimbursementMasterId;

  @Column(name = "amount")
  private BigDecimal amount;

  @Column(name = "delete_flag")
  private boolean deleteFlag;

}
