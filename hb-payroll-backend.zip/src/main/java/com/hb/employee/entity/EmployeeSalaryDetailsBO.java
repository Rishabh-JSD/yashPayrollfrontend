package com.hb.employee.entity;

import com.hb.common.Audit;
import com.hb.common.TABLES;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.List;

@Getter
@Setter
@Entity
@Table(name = TABLES.EMPLOYEE_SALARY_DETAIL)
public class EmployeeSalaryDetailsBO extends Audit {

  private static final long serialVersionUID = -4149509659703014575L;

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "id", updatable = false)
  private Long id;

  @Column(name = "basic_salary")
  private BigDecimal basicSalary;

  @Column(name = "ctc")
  private BigDecimal ctc;

  @Column(name = "net_pay_before_tds")
  private BigDecimal netPayBeforeTds;

  @Column(name = "tax_summary")
  private String taxSummary;

  @Column(name = "delete_flag")
  private boolean deleteFlag;

  @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
  @JoinColumn(name = "employee_salary_detail_id", referencedColumnName = "id")
  private List<EmployeeReimbursementBO> employeeReimbursement;

  @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
  @JoinColumn(name = "employee_salary_detail_id", referencedColumnName = "id")
  private List<EmployeeAllowanceBO> employeeAllowance;

  @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
  @JoinColumn(name = "employee_salary_detail_id", referencedColumnName = "id")
  private List<EmployeeDeductionBO> employeeDeduction;

}
