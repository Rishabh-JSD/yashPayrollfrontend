package com.hb.employee.service;

import com.hb.common.PaginationCriteria;
import com.hb.common.SearchResponseTO;
import com.hb.employee.dto.EmployeeLabelTO;
import com.hb.employee.dto.EmployeeTO;
import com.hb.employee.entity.EmployeeProxyBO;

import java.util.List;

public interface EmployeeService {

  EmployeeTO addEmployee(EmployeeTO employeeTO);

  EmployeeTO updateEmployee(EmployeeTO employeeTO);

  SearchResponseTO getEmployeeList(PaginationCriteria paginationCriteria);

  EmployeeTO getEmployeeById(Long id);

EmployeeLabelTO getEmployeeNameById(Long id);

  EmployeeProxyBO getEmployeeProxyById(Long employeeId);

  void deleteEmployee(List<Long> employeeId);

}
