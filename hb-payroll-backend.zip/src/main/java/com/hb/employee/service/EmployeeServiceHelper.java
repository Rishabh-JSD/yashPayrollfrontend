package com.hb.employee.service;

import com.hb.address.dto.AddressTO;
import com.hb.employee.dto.*;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;

@Service
public class EmployeeServiceHelper {
  double profileCompletion;
  double total;

  public BigDecimal calculateProfileCompletion(EmployeeTO employeeTO) {
    profileCompletion = 0;
    total = 0;
    if (employeeTO.getEmploymentStatusId() != null) {
      profileCompletion++;
    }
    total++;
    if (employeeTO.getName() != null) {
      profileCompletion++;
    }
    total++;
    if (employeeTO.getFathersName() != null) {
      profileCompletion++;
    }
    total++;
    if (employeeTO.getDob() != null) {
      profileCompletion++;
    }
    total++;
    if (employeeTO.getGender() != null) {
      profileCompletion++;
    }
    total++;
    if (employeeTO.getPersonalEmail() != null) {
      profileCompletion++;
    }
    total++;
    if (employeeTO.getOfficialEmail() != null) {
      profileCompletion++;
    }
    total++;
    if (employeeTO.getPhoneNo() != null) {
      profileCompletion++;
    }
    total++;
    if (employeeTO.getNationalityId() != null) {
      profileCompletion++;
    }
    total++;
    if (employeeTO.getMaritalStatus() != null) {
      profileCompletion++;
    }
    total++;
    if (employeeTO.getPan() != null) {
      profileCompletion++;
    }
    total++;
    if (employeeTO.getVerificationAddress() != null) {
      profileCompletion++;
    }
    total++;
    if (employeeTO.getEmployeeAccount() != null && !employeeTO.getEmployeeAccount().isEmpty()) {
      employeeAccountFields(employeeTO.getEmployeeAccount());
    }
    if (employeeTO.getEmployeeExperience() != null && !employeeTO.getEmployeeExperience().isEmpty()) {
      employeeExperienceFields(employeeTO.getEmployeeExperience());
    }
    if (employeeTO.getEmployeeKyc() != null && !employeeTO.getEmployeeKyc().isEmpty()) {
      employeeKycFields(employeeTO.getEmployeeKyc());
    }
    if (employeeTO.getEmployeeQualification() != null && !employeeTO.getEmployeeQualification().isEmpty()) {
      employeeQualificationFields(employeeTO.getEmployeeQualification());
    }
    if (employeeTO.getEmployeeReference() != null && !employeeTO.getEmployeeReference().isEmpty()) {
      employeeReferenceFields(employeeTO.getEmployeeReference());
    }
    if (employeeTO.getEmployeeCompanyDetails() != null) {
      employeeCompanyDetailsFields(employeeTO.getEmployeeCompanyDetails());
    }
    if (employeeTO.getEmployeeSalaryDetails() != null) {
      employeeSalaryDetailsFields(employeeTO.getEmployeeSalaryDetails());
    }
    if (employeeTO.getAddressCorrespondence() != null) {
      employeeAddressFields(employeeTO.getAddressCorrespondence());
    }
    if (employeeTO.getAddressPermanent() != null) {
      employeeAddressFields(employeeTO.getAddressPermanent());
    }
    return roundedValue((profileCompletion / total) * 100);
  }

  private void employeeAccountFields(List<EmployeeAccountTO> employeeAccountTOList) {
    for (EmployeeAccountTO employeeAccountTO : employeeAccountTOList) {
      if (employeeAccountTO.getFullName() != null) {
        profileCompletion++;
      }
      total++;
      if (employeeAccountTO.getBankName() != null) {
        profileCompletion++;
      }
      total++;
      if (employeeAccountTO.getAccountNumber() != null) {
        profileCompletion++;
      }
      total++;
      if (employeeAccountTO.getBranchName() != null) {
        profileCompletion++;
      }
      total++;
      if (employeeAccountTO.getIfsc() != null) {
        profileCompletion++;
      }
      total++;
    }
  }

  private void employeeExperienceFields(List<EmployeeExperienceTO> employeeExperienceTOList) {
    for (EmployeeExperienceTO employeeExperienceTO : employeeExperienceTOList) {
      if (employeeExperienceTO.getTitle() != null) {
        profileCompletion++;
      }
      total++;
      if (employeeExperienceTO.getEmploymentTypeCode() != null) {
        profileCompletion++;
      }
      total++;
      if (employeeExperienceTO.getCompanyName() != null) {
        profileCompletion++;
      }
      total++;
      if (employeeExperienceTO.getCountryId() != null) {
        profileCompletion++;
      }
      total++;
      if (employeeExperienceTO.getStateId() != null) {
        profileCompletion++;
      }
      total++;
      if (employeeExperienceTO.getStartDate() != null) {
        profileCompletion++;
      }
      total++;
      if (employeeExperienceTO.getEndDate() != null) {
        profileCompletion++;
      }
      total++;
      if (employeeExperienceTO.getJobTitle() != null) {
        profileCompletion++;
      }
      total++;
      if (employeeExperienceTO.getIndustryId() != null) {
        profileCompletion++;
      }
      total++;
      if (employeeExperienceTO.getJobDescription() != null) {
        profileCompletion++;
      }
      total++;
      if (employeeExperienceTO.getEmployeeExperienceAttachments() != null && !employeeExperienceTO.getEmployeeExperienceAttachments().isEmpty()) {
        for (EmployeeExperienceAttachmentTO employeeExperienceAttachment : employeeExperienceTO.getEmployeeExperienceAttachments()) {
          if (employeeExperienceAttachment.getDocumentTypeId() != null) {
            profileCompletion++;
          }
          total++;
          if (employeeExperienceAttachment.getRemark() != null) {
            profileCompletion++;
          }
          total++;
          if (employeeExperienceAttachment.getDocumentId() != null) {
            profileCompletion++;
          }
          total++;
        }
      }
    }
  }

  private void employeeKycFields(List<EmployeeKycTO> employeeKycTOList) {
    for (EmployeeKycTO employeeKycTO : employeeKycTOList) {
      if (employeeKycTO.getDocumentTypeId() != null) {
        profileCompletion++;
      }
      total++;
      if (employeeKycTO.getRemark() != null) {
        profileCompletion++;
      }
      total++;
      if (employeeKycTO.getDocumentId() != null) {
        profileCompletion++;
      }
      total++;
    }
  }

  private void employeeQualificationFields(List<EmployeeQualificationTO> employeeQualificationTOList) {
    for (EmployeeQualificationTO employeeQualificationTO : employeeQualificationTOList) {
      if (employeeQualificationTO.getDocumentTypeId() != null) {
        profileCompletion++;
      }
      total++;
      if (employeeQualificationTO.getRemark() != null) {
        profileCompletion++;
      }
      total++;
      if (employeeQualificationTO.getInstitutionDescription() != null) {
        profileCompletion++;
      }
      total++;
      if (employeeQualificationTO.getCountryId() != null) {
        profileCompletion++;
      }
      total++;
      if (employeeQualificationTO.getStateId() != null) {
        profileCompletion++;
      }
      total++;
      if (employeeQualificationTO.getDocumentId() != null) {
        profileCompletion++;
      }
      total++;
    }
  }

  private void employeeReferenceFields(List<EmployeeReferenceTO> employeeReferenceTOList) {
    for (EmployeeReferenceTO employeeReferenceTO : employeeReferenceTOList) {
      if (employeeReferenceTO.getName() != null) {
        profileCompletion++;
      }
      total++;
      if (employeeReferenceTO.getMobile() != null) {
        profileCompletion++;
      }
      total++;
    }
  }

  private void employeeCompanyDetailsFields(EmployeeCompanyDetailsTO employeeCompanyDetailsTO) {
    if (employeeCompanyDetailsTO.getEmployeeNumber() != null) {
      profileCompletion++;
    }
    total++;
    if (employeeCompanyDetailsTO.getJoiningDate() != null) {
      profileCompletion++;
    }
    total++;
    if (employeeCompanyDetailsTO.getEmployeeCategoryId() != null) {
      profileCompletion++;
    }
    total++;
    if (employeeCompanyDetailsTO.getEmployeeNumber() != null) {
      profileCompletion++;
    }
    total++;
    if (employeeCompanyDetailsTO.getAttendanceTypeCode() != null) {
      profileCompletion++;
    }
    total++;
    if (employeeCompanyDetailsTO.getContractFrom() != null) {
      profileCompletion++;
    }
    total++;
    if (employeeCompanyDetailsTO.getContractTo() != null) {
      profileCompletion++;
    }
    total++;
    if (employeeCompanyDetailsTO.getShiftTypeId() != null) {
      profileCompletion++;
    }
    total++;
    if (employeeCompanyDetailsTO.getShiftTimingId() != null) {
      profileCompletion++;
    }
    total++;
    if (employeeCompanyDetailsTO.getDesignationId() != null) {
      profileCompletion++;
    }
    total++;
    if (employeeCompanyDetailsTO.getEmployeeLevelId() != null) {
      profileCompletion++;
    }
    total++;
    if (employeeCompanyDetailsTO.getPayFrequencyId() != null) {
      profileCompletion++;
    }
    total++;
    if (employeeCompanyDetailsTO.getSeparationDate() != null) {
      profileCompletion++;
    }
    total++;
    if (employeeCompanyDetailsTO.getJobDescription() != null) {
      profileCompletion++;
    }
    total++;
  }

  private void employeeSalaryDetailsFields(EmployeeSalaryDetailsTO employeeSalaryDetailsTO) {
    if (employeeSalaryDetailsTO.getBasicSalary() != null) {
      profileCompletion++;
    }
    total++;
    if (employeeSalaryDetailsTO.getCtc() != null) {
      profileCompletion++;
    }
    total++;
    if (employeeSalaryDetailsTO.getNetPayBeforeTds() != null) {
      profileCompletion++;
    }
    total++;
    if (employeeSalaryDetailsTO.getTaxSummary() != null) {
      profileCompletion++;
    }
    total++;
    if (employeeSalaryDetailsTO.getEmployeeReimbursement() != null &&
            !employeeSalaryDetailsTO.getEmployeeReimbursement().isEmpty()) {
      for (EmployeeReimbursementTO employeeReimbursementTO : employeeSalaryDetailsTO.getEmployeeReimbursement()) {
        if (employeeReimbursementTO.getReimbursementMasterId() != null) {
          profileCompletion++;
        }
        total++;
        if (employeeReimbursementTO.getAmount() != null) {
          profileCompletion++;
        }
        total++;
      }
    }
    if (employeeSalaryDetailsTO.getEmployeeAllowance() != null &&
            !employeeSalaryDetailsTO.getEmployeeAllowance().isEmpty()) {
      for (EmployeeAllowanceTO employeeAllowanceTO : employeeSalaryDetailsTO.getEmployeeAllowance()) {
        if (employeeAllowanceTO.getAllowanceMasterId() != null) {
          profileCompletion++;
        }
        total++;
        if (employeeAllowanceTO.getAmount() != null) {
          profileCompletion++;
        }
        total++;
      }
    }
    if (employeeSalaryDetailsTO.getEmployeeDeduction() != null &&
            !employeeSalaryDetailsTO.getEmployeeDeduction().isEmpty()) {
      for (EmployeeDeductionTO employeeDeductionTO : employeeSalaryDetailsTO.getEmployeeDeduction()) {
        if (employeeDeductionTO.getDeductionMasterId() != null) {
          profileCompletion++;
        }
        total++;
        if (employeeDeductionTO.getAmount() != null) {
          profileCompletion++;
        }
        total++;
      }
    }
  }

  private void employeeAddressFields(AddressTO addressTO) {
    if (addressTO.getAddressOne() != null) {
      profileCompletion++;
    }
    total++;
    if (addressTO.getCityId() != null) {
      profileCompletion++;
    }
    total++;
    if (addressTO.getPincodeId() != null) {
      profileCompletion++;
    }
    total++;
    if (addressTO.getStateId() != null) {
      profileCompletion++;
    }
    total++;
    if (addressTO.getCountryId() != null) {
      profileCompletion++;
    }
    total++;
  }

  private BigDecimal roundedValue(double value) {
    return BigDecimal.valueOf(value).setScale(2, RoundingMode.HALF_EVEN);
  }
}
