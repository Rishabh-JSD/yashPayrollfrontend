package com.hb.employee.service;

import com.hb.address.service.AddressService;
import com.hb.common.MapperService;
import com.hb.common.PaginationCriteria;
import com.hb.common.SearchResponseTO;
import com.hb.common.service.IndustryService;
import com.hb.company.branch.service.BranchService;
import com.hb.company.costCenter.service.CostCenterService;
import com.hb.company.department.service.DepartmentService;
import com.hb.employee.dao.EmployeeDao;
import com.hb.employee.dto.*;
import com.hb.employee.entity.EmployeeBO;
import com.hb.employee.entity.EmployeeProxyBO;
import com.hb.master.dto.CommonListTO;
import com.hb.payrollMasters.allowance.service.AllowanceService;
import com.hb.payrollMasters.deduction.service.DeductionService;
import com.hb.payrollMasters.designation.service.DesignationService;
import com.hb.payrollMasters.document.type.service.DocumentTypeService;
import com.hb.payrollMasters.employeeCategory.service.EmployeeCategoryService;
import com.hb.payrollMasters.employeeLevel.service.EmployeeLevelService;
import com.hb.payrollMasters.employmentStatus.service.EmploymentStatusService;
import com.hb.payrollMasters.payFrequency.service.PayFrequencyService;
import com.hb.payrollMasters.reimbursement.service.ReimbursementService;
import com.hb.payrollMasters.shift.timing.dto.ShiftTimingTO;
import com.hb.payrollMasters.shift.timing.service.ShiftTimingService;
import com.hb.payrollMasters.shift.type.service.ShiftTypeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;

@Service
@Transactional
public class EmployeeServiceImpl implements EmployeeService {

  @Autowired
  private EmployeeDao employeeDao;

  @Autowired
  private EmploymentStatusService employmentStatusService;

  @Autowired
  private DesignationService designationService;

  @Autowired
  private DepartmentService departmentService;

  @Autowired
  private AddressService addressService;

  @Autowired
  private EmployeeCategoryService employeeCategoryService;

  @Autowired
  private ShiftTypeService shiftTypeService;

  @Autowired
  private ShiftTimingService shiftTimingService;

  @Autowired
  private BranchService branchService;

  @Autowired
  private CostCenterService costCenterService;

  @Autowired
  private EmployeeLevelService employeeLevelService;

  @Autowired
  private PayFrequencyService payFrequencyService;

  @Autowired
  private ReimbursementService reimbursementService;

  @Autowired
  private AllowanceService allowanceService;

  @Autowired
  private DeductionService deductionService;

  @Autowired
  private DocumentTypeService documentTypeService;

  @Autowired
  private IndustryService industryService;

  @Autowired
  private EmployeeServiceHelper employeeServiceHelper;

  @Autowired
  private MapperService mapperService;

  @Override
  public EmployeeTO addEmployee(EmployeeTO employeeTO) {
    employeeTO.setProfileCompletion(employeeServiceHelper.calculateProfileCompletion(employeeTO));
    EmployeeBO employeeBO = mapperService.map(employeeTO, EmployeeBO.class);
    return mapperService.map(employeeDao.addEmployee(employeeBO), EmployeeTO.class);
  }

  @Override
  public EmployeeTO updateEmployee(EmployeeTO employeeTO) {
    employeeTO.setProfileCompletion(employeeServiceHelper.calculateProfileCompletion(employeeTO));
    EmployeeBO employeeBO = mapperService.map(employeeTO, EmployeeBO.class);
    return mapperService.map(employeeDao.updateEmployee(employeeBO), EmployeeTO.class);
  }

  @Override
  @Transactional(Transactional.TxType.NOT_SUPPORTED)
  public SearchResponseTO getEmployeeList(PaginationCriteria paginationCriteria) {
    SearchResponseTO searchResponseTO = new SearchResponseTO();
    CommonListTO<EmployeeBO> commonListTO = employeeDao.getEmployeeList(paginationCriteria);

    List<EmployeeTO> employeeTOS = null;
    if (commonListTO.getDataList() != null && !commonListTO.getDataList().isEmpty()) {
      employeeTOS = new ArrayList<>();
      for (EmployeeBO employeeBO : commonListTO.getDataList()) {
        EmployeeTO employeeTO = mapperService.map(employeeBO, EmployeeTO.class);
        if (employeeTO.getEmploymentStatusId() != null) {
          employeeTO.setEmploymentStatusName(employmentStatusService
                  .getEmploymentStatusById(employeeTO.getEmploymentStatusId()).getName());
        }
        if (employeeTO.getNationalityId() != null) {
          employeeTO.setNationName(addressService.getCountryById(employeeTO.getNationalityId()).getName());
        }
        if (employeeTO.getEmployeeCompanyDetails().getDesignationId() != null) {
          employeeTO.getEmployeeCompanyDetails().setDesignationName(designationService
                  .getDesignationById(employeeTO.getEmployeeCompanyDetails().getDesignationId()).getName());
        }
        if (employeeTO.getEmployeeCompanyDetails().getDepartmentId() != null) {
          employeeTO.getEmployeeCompanyDetails().setDepartmentName(departmentService
                  .getDepartmentById(employeeTO.getEmployeeCompanyDetails().getDepartmentId()).getName());
        }
        employeeTOS.add(employeeTO);
      }
    }
    searchResponseTO.setList(employeeTOS);
    searchResponseTO.setPageCount(commonListTO.getPageCount());
    searchResponseTO.setTotalRowCount(commonListTO.getTotalRow().intValue());
    return searchResponseTO;
  }

  @Override
  @Transactional(Transactional.TxType.NOT_SUPPORTED)
  public EmployeeTO getEmployeeById(Long id) {
    EmployeeTO employeeTO = mapperService.map(employeeDao.getEmployeeById(id), EmployeeTO.class);
    if (employeeTO.getEmploymentStatusId() != null) {
      employeeTO.setEmploymentStatusName(employmentStatusService
              .getEmploymentStatusById(employeeTO.getEmploymentStatusId()).getName());
    }
    if (employeeTO.getNationalityId() != null) {
      employeeTO.setNationName(addressService.getCountryById(employeeTO.getNationalityId()).getName());
    }
    if (employeeTO.getEmployeeCompanyDetails() != null) {
      if (employeeTO.getEmployeeCompanyDetails().getEmployeeCategoryId() != null) {
        employeeTO.getEmployeeCompanyDetails().setEmployeeCategoryName(employeeCategoryService
                .getEmployeeCategoryById(employeeTO.getEmployeeCompanyDetails().getEmployeeCategoryId()).getName());
      }
      if (employeeTO.getEmployeeCompanyDetails().getShiftTypeId() != null) {
        employeeTO.getEmployeeCompanyDetails().setShiftTypeName(shiftTypeService
                .getShiftTypeById(employeeTO.getEmployeeCompanyDetails().getShiftTypeId()).getName());
      }
      if (employeeTO.getEmployeeCompanyDetails().getShiftTimingId() != null) {
        ShiftTimingTO shiftTiming = shiftTimingService.getShiftTimingById(employeeTO.getEmployeeCompanyDetails().getShiftTimingId());
        employeeTO.getEmployeeCompanyDetails().setShiftTimingStartTime(shiftTiming.getStartTime());
        employeeTO.getEmployeeCompanyDetails().setShiftTimingEndTime(shiftTiming.getEndTime());
      }
      if (employeeTO.getEmployeeCompanyDetails().getDesignationId() != null) {
        employeeTO.getEmployeeCompanyDetails().setDesignationName(designationService
                .getDesignationById(employeeTO.getEmployeeCompanyDetails().getDesignationId()).getName());
      }
      if (employeeTO.getEmployeeCompanyDetails().getBranchId() != null) {
        employeeTO.getEmployeeCompanyDetails().setBranchName(branchService
                .getBranchById(employeeTO.getEmployeeCompanyDetails().getBranchId()).getName());
      }
      if (employeeTO.getEmployeeCompanyDetails().getCostCenterId() != null) {
        employeeTO.getEmployeeCompanyDetails().setCostCenterName(costCenterService
                .getCostCenterById(employeeTO.getEmployeeCompanyDetails().getCostCenterId()).getName());
      }
      if (employeeTO.getEmployeeCompanyDetails().getDepartmentId() != null) {
        employeeTO.getEmployeeCompanyDetails().setDepartmentName(departmentService
                .getDepartmentById(employeeTO.getEmployeeCompanyDetails().getDepartmentId()).getName());
      }
      if (employeeTO.getEmployeeCompanyDetails().getEmployeeLevelId() != null) {
        employeeTO.getEmployeeCompanyDetails().setEmployeeLevelName(employeeLevelService
                .getEmployeeLevelById(employeeTO.getEmployeeCompanyDetails().getEmployeeLevelId()).getName());
      }
      if (employeeTO.getEmployeeCompanyDetails().getReportToId() != null) {
        employeeTO.getEmployeeCompanyDetails().setReportToName(
                getEmployeeProxyById(employeeTO.getEmployeeCompanyDetails().getReportToId()).getName());
      }
      if (employeeTO.getEmployeeCompanyDetails().getFunctionalAppraiserId() != null) {
        employeeTO.getEmployeeCompanyDetails().setFunctionalAppraiserName(
                getEmployeeProxyById(employeeTO.getEmployeeCompanyDetails().getFunctionalAppraiserId()).getName());
      }
      if (employeeTO.getEmployeeCompanyDetails().getAdminAppraiserId() != null) {
        employeeTO.getEmployeeCompanyDetails().setAdminAppraiserName(
                getEmployeeProxyById(employeeTO.getEmployeeCompanyDetails().getAdminAppraiserId()).getName());
      }
      if (employeeTO.getEmployeeCompanyDetails().getPayFrequencyId() != null) {
        employeeTO.getEmployeeCompanyDetails().setPayFrequencyName(payFrequencyService
                .getPayFrequencyById(employeeTO.getEmployeeCompanyDetails().getPayFrequencyId()).getName());
      }
    }
    if (employeeTO.getEmployeeSalaryDetails() != null) {
      if (employeeTO.getEmployeeSalaryDetails().getEmployeeReimbursement() != null &&
              !employeeTO.getEmployeeSalaryDetails().getEmployeeReimbursement().isEmpty()) {
        for (EmployeeReimbursementTO employeeReimbursementTO : employeeTO.getEmployeeSalaryDetails().getEmployeeReimbursement()) {
          employeeReimbursementTO.setReimbursementMasterName(reimbursementService
                  .getReimbursementById(employeeReimbursementTO.getReimbursementMasterId()).getName());
        }
      }
      if (employeeTO.getEmployeeSalaryDetails().getEmployeeAllowance() != null &&
              !employeeTO.getEmployeeSalaryDetails().getEmployeeAllowance().isEmpty()) {
        for (EmployeeAllowanceTO employeeAllowanceTO : employeeTO.getEmployeeSalaryDetails().getEmployeeAllowance()) {
          employeeAllowanceTO.setAllowanceMasterName(reimbursementService
                  .getReimbursementById(employeeAllowanceTO.getAllowanceMasterId()).getName());
        }
      }
      if (employeeTO.getEmployeeSalaryDetails().getEmployeeDeduction() != null &&
              !employeeTO.getEmployeeSalaryDetails().getEmployeeDeduction().isEmpty()) {
        for (EmployeeDeductionTO employeeDeductionTO : employeeTO.getEmployeeSalaryDetails().getEmployeeDeduction()) {
          employeeDeductionTO.setDeductionMasterName(reimbursementService
                  .getReimbursementById(employeeDeductionTO.getDeductionMasterId()).getName());
        }
      }
    }
    if (employeeTO.getEmployeeKyc() != null && !employeeTO.getEmployeeKyc().isEmpty()) {
      for (EmployeeKycTO employeeKycTO : employeeTO.getEmployeeKyc()) {
        employeeKycTO.setDocumentTypeName(documentTypeService.getDocumentTypeById(employeeKycTO.getDocumentTypeId()).getName());
      }
    }
    if (employeeTO.getEmployeeQualification() != null && !employeeTO.getEmployeeQualification().isEmpty()) {
      for (EmployeeQualificationTO employeeQualificationTO : employeeTO.getEmployeeQualification()) {
        employeeQualificationTO.setDocumentTypeName(documentTypeService.getDocumentTypeById(employeeQualificationTO.getDocumentTypeId()).getName());
        employeeQualificationTO.setCountryName(addressService.getCountryById(employeeQualificationTO.getCountryId()).getName());
        employeeQualificationTO.setStateName(addressService.getStateById(employeeQualificationTO.getStateId()).getName());
      }
    }
    if (employeeTO.getEmployeeExperience() != null && !employeeTO.getEmployeeExperience().isEmpty()) {
      for (EmployeeExperienceTO employeeExperienceTO : employeeTO.getEmployeeExperience()) {
        employeeExperienceTO.setCountryName(addressService.getCountryById(employeeExperienceTO.getCountryId()).getName());
        employeeExperienceTO.setStateName(addressService.getStateById(employeeExperienceTO.getStateId()).getName());
        if (employeeExperienceTO.getEmployeeExperienceAttachments() != null &&
                !employeeExperienceTO.getEmployeeExperienceAttachments().isEmpty()) {
          for (EmployeeExperienceAttachmentTO employeeExperienceAttachment : employeeExperienceTO.getEmployeeExperienceAttachments()) {
            employeeExperienceAttachment.setDocumentTypeName(documentTypeService
                    .getDocumentTypeById(employeeExperienceAttachment.getDocumentTypeId()).getName());
          }
        }
      }
    }
    if (employeeTO.getAddressCorrespondence() != null) {
      if (employeeTO.getAddressCorrespondence().getCityId() != null) {
        employeeTO.getAddressCorrespondence().setCityName(addressService
                .getCityById(employeeTO.getAddressCorrespondence().getCityId()).getName());
      }
      if (employeeTO.getAddressCorrespondence().getStateId() != null) {
        employeeTO.getAddressCorrespondence().setStateName(addressService
                .getStateById(employeeTO.getAddressCorrespondence().getStateId()).getName());
      }
      if (employeeTO.getAddressCorrespondence().getPincodeId() != null) {
        employeeTO.getAddressCorrespondence().setPincode(addressService
                .getPincodeById(employeeTO.getAddressCorrespondence().getPincodeId()).getPincode());
      }
      if (employeeTO.getAddressCorrespondence().getCountryId() != null) {
        employeeTO.getAddressCorrespondence().setCountryName(addressService
                .getCountryById(employeeTO.getAddressCorrespondence().getCountryId()).getName());
      }
    }
    if (employeeTO.getAddressPermanent() != null) {
      if (employeeTO.getAddressPermanent().getCityId() != null) {
        employeeTO.getAddressPermanent().setCityName(addressService
                .getCityById(employeeTO.getAddressPermanent().getCityId()).getName());
      }
      if (employeeTO.getAddressPermanent().getStateId() != null) {
        employeeTO.getAddressPermanent().setStateName(addressService
                .getStateById(employeeTO.getAddressPermanent().getStateId()).getName());
      }
      if (employeeTO.getAddressPermanent().getPincodeId() != null) {
        employeeTO.getAddressPermanent().setPincode(addressService
                .getPincodeById(employeeTO.getAddressPermanent().getPincodeId()).getPincode());
      }
      if (employeeTO.getAddressPermanent().getCountryId() != null) {
        employeeTO.getAddressPermanent().setCountryName(addressService
                .getCountryById(employeeTO.getAddressPermanent().getCountryId()).getName());
      }
    }
    return employeeTO;
  }

  @Override
  @Transactional(Transactional.TxType.NOT_SUPPORTED)
  public EmployeeLabelTO getEmployeeNameById(Long id) {
    EmployeeLabelTO employeeLabelTO = mapperService.map(employeeDao.getEmployeeNameById(id), EmployeeLabelTO.class);
  return employeeLabelTO;
  }

  @Override
  @Transactional(Transactional.TxType.NOT_SUPPORTED)
  public EmployeeProxyBO getEmployeeProxyById(Long employeeId) {
    return employeeDao.getEmployeeProxyById(employeeId);
  }

  @Override
  public void deleteEmployee(List<Long> id) {
    employeeDao.deleteEmployee(id);
  }
}
