package com.hb.employee.validator;

import com.hb.common.PaginationCriteria;
import com.hb.employee.controller.EmployeeController;
import com.hb.employee.dto.EmployeeTO;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.ControllerAdvice;

@ControllerAdvice(assignableTypes = EmployeeController.class)
public class EmployeeValidator implements Validator {

  @Override
  public boolean supports(Class<?> aClass) {
    boolean support = EmployeeTO.class.equals(aClass);
    if (!support) {
      support = PaginationCriteria.class.equals(aClass);
    }
    return support;
  }

  @Override
  public void validate(Object o, Errors errors) {
    EmployeeTO employeeTO = (EmployeeTO) o;

//    ValidationUtils.rejectIfEmptyOrWhitespace(errors, "name", "PMS001E", APP_MSG.MESSAGE.get("PR001E"));

  }
}
