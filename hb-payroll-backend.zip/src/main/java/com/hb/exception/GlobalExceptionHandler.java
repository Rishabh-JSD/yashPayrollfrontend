package com.hb.exception;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.hb.common.APP_MSG;
import com.hb.common.ValidationError;

@ControllerAdvice
public class GlobalExceptionHandler {

	@ExceptionHandler(UserTokenKeyNotValidException.class)
	public ResponseEntity<ValidationError> handleUserPreserveKeyNotValidException(HttpServletRequest request,
			Exception ex) {
		ValidationError message = new ValidationError(HttpStatus.UNAUTHORIZED.value(), "GL001",
				APP_MSG.VALIDATION.get("GL001"));
		return new ResponseEntity<>(message, HttpStatus.OK);
	}

}
