package com.hb.exception;

import java.io.Serializable;

public class UserTokenKeyNotValidException extends Exception implements Serializable {

	public static final long serialVersionUID = 1L;

	public UserTokenKeyNotValidException() {
		super("User Auth Token Or Preserve Key not valid");

	}

}
