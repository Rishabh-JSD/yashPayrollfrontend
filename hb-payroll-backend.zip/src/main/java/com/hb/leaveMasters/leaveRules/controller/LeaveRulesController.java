package com.hb.leaveMasters.leaveRules.controller;

import com.hb.common.PaginationCriteria;
import com.hb.common.ResponseDTO;
import com.hb.common.SearchResponseTO;
import com.hb.common.ValidationError;
import com.hb.leaveMasters.leaveRules.dto.LeaveRulesTO;
import com.hb.leaveMasters.leaveRules.service.LeaveRulesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/leaveRules")
public class LeaveRulesController {
    @Autowired
    private Validator leaveRulesValidator;

    @Autowired
    private LeaveRulesService leaveRulesService;

    private ResponseDTO responseDTO;

    @InitBinder
    private void initBinder(WebDataBinder binder) {
        binder.setValidator(leaveRulesValidator);
    }

    @RequestMapping(value = "/add", method = RequestMethod.POST, name = "LeaveRules Master Add->AMCR")
    public ResponseEntity<?> addLeaveRules(@Valid @RequestBody LeaveRulesTO leaveRulesTO, Errors errors) {
            if (errors.hasErrors()) {
                ValidationError validationError = ValidationError.fromBindingErrors(errors);
                return new ResponseEntity<>(validationError, HttpStatus.OK);
            }
               LeaveRulesTO leaveRulesTO_return = leaveRulesService.addLeaveRules(leaveRulesTO);
               responseDTO = ResponseDTO.responseBuilder(200, "PR001", "/leaveRules", "leaveRules", leaveRulesTO_return);
            return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }

    @RequestMapping(value = "/update", method = RequestMethod.POST, name = "LeaveRules Master Update->AMCR")
    public ResponseEntity<?> updateLeaveRules(@Valid @RequestBody LeaveRulesTO leaveRulesTO, Errors errors) {
        if (errors.hasErrors()) {
            ValidationError validationError = ValidationError.fromBindingErrors(errors);
            return new ResponseEntity<>(validationError, HttpStatus.OK);
        }
        LeaveRulesTO leaveRulesTO_return = leaveRulesService.updateLeaveRules(leaveRulesTO);
        responseDTO = ResponseDTO.responseBuilder(200, "PR002", "/leaveRules", "leaveRules", leaveRulesTO_return);
        return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }

    @RequestMapping(value = "/list", method = RequestMethod.POST, name = "LeaveRules Master List->AMCR")
    public ResponseEntity<?> getLeaveRulesList(@RequestBody PaginationCriteria paginationCriteria) {
        SearchResponseTO searchResponseTO = leaveRulesService.getLeaveRulesList(paginationCriteria);
        if (searchResponseTO.getList() == null || searchResponseTO.getList().isEmpty()) {
            responseDTO = ResponseDTO.responseBuilder(200, "PR006", "/leaveRules", "leaveRules", searchResponseTO);
            return new ResponseEntity<>(responseDTO, HttpStatus.OK);
        }
        responseDTO = ResponseDTO.responseBuilder(200, "PR003", "/leaveRules", "leaveRules", searchResponseTO);
        return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }

    @RequestMapping(value = "/{id}", method = RequestMethod.GET, name = "LeaveRules Master View->AMCR")
    public ResponseEntity<?> getLeaveRulesById(@PathVariable Long id) {
        LeaveRulesTO leaveRulesTO = leaveRulesService.getLeaveRulesById(id);
        if (leaveRulesTO == null) {
            responseDTO = ResponseDTO.responseBuilder(200, "PR007", "/leaveRules", "leaveRules", null);
            return new ResponseEntity<>(responseDTO, HttpStatus.OK);
        }
        responseDTO = ResponseDTO.responseBuilder(200, "PR004", "/leaveRules", "leaveRules", leaveRulesTO);
        return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }

    @RequestMapping(value = "/delete", method = RequestMethod.DELETE, name = "LeaveRules Master Delete->AMCR")
    public ResponseEntity<?> deleteLeaveRules(@RequestParam(name = "leaveRulesId") List<Long> leaveRulesId) {
        leaveRulesService.deleteLeaveRules(leaveRulesId);
        responseDTO = ResponseDTO.responseBuilder(200, "PR005", "/leaveRules", "leaveRules", leaveRulesId);
        return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }
}
