package com.hb.leaveMasters.leaveRules.dao;

import com.hb.common.PaginationCriteria;
import com.hb.leaveMasters.leaveRules.entity.LeaveRulesBO;
import com.hb.master.dto.CommonListTO;

import java.util.List;

public interface LeaveRulesDao {

    LeaveRulesBO addLeaveRules(LeaveRulesBO leaveRulesTO);

    LeaveRulesBO updateLeaveRules(LeaveRulesBO leaveRulesBO);

    CommonListTO<LeaveRulesBO> getLeaveRulesList(PaginationCriteria paginationCriteria);

    LeaveRulesBO getLeaveRulesById(Long id);

    void deleteLeaveRules(List<Long> id);

}
