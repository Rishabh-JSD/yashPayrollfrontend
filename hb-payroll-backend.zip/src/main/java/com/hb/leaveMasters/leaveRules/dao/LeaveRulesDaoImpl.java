package com.hb.leaveMasters.leaveRules.dao;

import com.hb.common.PaginationCriteria;
import com.hb.leaveMasters.leaveRules.entity.LeaveRulesBO;
import com.hb.leaveMasters.leaveRules.entity.LeaveRulesDetailsBO;
import com.hb.master.dto.CommonListTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.*;
import java.util.List;

@Repository
public class LeaveRulesDaoImpl implements LeaveRulesDao {

    @PersistenceContext
    private EntityManager entityManager;

    private static final Logger logger = LoggerFactory.getLogger(LeaveRulesDaoImpl.class);

    @Override
    public LeaveRulesBO addLeaveRules(LeaveRulesBO leaveRulesBO) {
        entityManager.persist(leaveRulesBO);
        logger.info("LeaveRule has added successfully, LeaveRules details=" + leaveRulesBO);
        return leaveRulesBO;
    }

    @Override
    public LeaveRulesBO updateLeaveRules(LeaveRulesBO leaveRulesBO) {
        LeaveRulesBO existingLeaveRules = entityManager.find(LeaveRulesBO.class, leaveRulesBO.getId());

        if (existingLeaveRules != null) {
            existingLeaveRules.setName(leaveRulesBO.getName());
            existingLeaveRules.setDeleteFlag(leaveRulesBO.isDeleteFlag());
            // Update LeaveRulesDetailsBO individually
            List<LeaveRulesDetailsBO> existingDetails = existingLeaveRules.getLeaveRulesDetails();
            List<LeaveRulesDetailsBO> newDetails = leaveRulesBO.getLeaveRulesDetails();

            for (int i = 0; i < Math.min(existingDetails.size(), newDetails.size()); i++) {
                LeaveRulesDetailsBO existingDetail = existingDetails.get(i);
                LeaveRulesDetailsBO newDetail = newDetails.get(i);

                existingDetail.setLeaveType(newDetail.getLeaveType());
                existingDetail.setMinimumNumber(newDetail.getMinimumNumber());
                existingDetail.setMaximumNumber(newDetail.getMaximumNumber());
                existingDetail.setMaxPeriod(newDetail.getMaxPeriod());
                existingDetail.setDeleteFlag(newDetail.isDeleteFlag());
                existingDetail.setLeavesCredit(newDetail.getLeavesCredit());
                existingDetail.setCarryForward(newDetail.getCarryForward());
            }
            entityManager.merge(existingLeaveRules);
            logger.info("LeaveRules has been updated successfully, LeaveRules details=" + existingLeaveRules);
            return existingLeaveRules;
        } else {
            return null;
        }

    }

    @Override
    public CommonListTO<LeaveRulesBO> getLeaveRulesList(PaginationCriteria paginationCriteria) {
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<LeaveRulesBO> criteriaQuery = criteriaBuilder.createQuery(LeaveRulesBO.class);
        Root<LeaveRulesBO> root = criteriaQuery.from(LeaveRulesBO.class);
        criteriaQuery.where(criteriaBuilder.equal(root.get("deleteFlag"), false));

        //condition for search
        if (paginationCriteria.getSearchFor() != null && !paginationCriteria.getSearchFor().isEmpty()) {
            Path<String> pathName = root.get("name");
            Predicate predicateForName = criteriaBuilder.like(pathName, "%" + paginationCriteria.getSearchFor() + "%");
            // Assuming "deleteFlag" is the field representing the deletion status
            Path<Boolean> pathDeleteFlag = root.get("deleteFlag");
            Predicate predicateNotDeleted = criteriaBuilder.isFalse(pathDeleteFlag);
            criteriaQuery.where(criteriaBuilder.and(predicateForName, predicateNotDeleted));
        }

        // Condition for sorting.
        if (paginationCriteria.getSortField() != null && !paginationCriteria.getSortField().isEmpty()) {
            Order order;
            if (paginationCriteria.getSortType() == 2) {
                order = criteriaBuilder.desc(root.get(paginationCriteria.getSortField()));
            } else {
                order = criteriaBuilder.asc(root.get(paginationCriteria.getSortField()));
            }
            criteriaQuery.orderBy(order);
        } else {
            Order order = criteriaBuilder.desc(root.get("id"));
            criteriaQuery.orderBy(order);
        }

        // Adding Pagination total Count
        CommonListTO<LeaveRulesBO> commonListTO = new CommonListTO<>();
        CriteriaQuery<Long> criteriaQuery2 = criteriaBuilder.createQuery(Long.class);
        Root<LeaveRulesBO> root2 = criteriaQuery2.from(LeaveRulesBO.class);
        criteriaQuery2.where(criteriaBuilder.equal(root2.get("deleteFlag"), false));
        CriteriaQuery<Long> select = criteriaQuery2.select(criteriaBuilder.count(root2));
        Long count = entityManager.createQuery(select).getSingleResult();
        commonListTO.setTotalRow(count);
        int size = count.intValue();
        int limit = paginationCriteria.getLimit();
        if (limit != 0) {
            commonListTO.setPageCount((size + limit - 1) / limit);
        } else {
            commonListTO.setPageCount(1);
        }

        TypedQuery<LeaveRulesBO> typedQuery = entityManager.createQuery(criteriaQuery);
        // Condition for paging.
        if (paginationCriteria.getPage() != 0 && paginationCriteria.getLimit() > 0) {
            typedQuery.setFirstResult((paginationCriteria.getPage() - 1) * paginationCriteria.getLimit());
            typedQuery.setMaxResults(paginationCriteria.getLimit());
        }
        commonListTO.setDataList(typedQuery.getResultList());
        return commonListTO;
    }

    @Override
    public LeaveRulesBO getLeaveRulesById(Long id) {
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<LeaveRulesBO> criteriaQuery = criteriaBuilder.createQuery(LeaveRulesBO.class);

        Root<LeaveRulesBO> root = criteriaQuery.from(LeaveRulesBO.class);
        Predicate predicateForId = criteriaBuilder.equal(root.get("id"), id);
        Predicate predicateForDeleteFlag = criteriaBuilder.equal(root.get("deleteFlag"), false);
        Predicate predicate = criteriaBuilder.and(predicateForId, predicateForDeleteFlag);
        criteriaQuery.where(predicate);
        return entityManager.createQuery(criteriaQuery).getSingleResult();
    }

    @Override
    public void deleteLeaveRules(List<Long> id) {
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaUpdate<LeaveRulesBO> criteriaUpdate = criteriaBuilder.createCriteriaUpdate(LeaveRulesBO.class);
        Root<LeaveRulesBO> root = criteriaUpdate.from(LeaveRulesBO.class);
        criteriaUpdate.set("deleteFlag", true);
        criteriaUpdate.where(root.get("id").in(id));
        entityManager.createQuery(criteriaUpdate).executeUpdate();
    }


}
