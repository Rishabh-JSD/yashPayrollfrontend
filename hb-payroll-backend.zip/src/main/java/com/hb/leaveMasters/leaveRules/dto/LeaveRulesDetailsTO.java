package com.hb.leaveMasters.leaveRules.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LeaveRulesDetailsTO {

    private Long id;

    private String leaveType;

    private double minimumNumber;

    private double maximumNumber;

    private double maxPeriod;

    private boolean deleteFlag;

    private double leavesCredit;

    private double carryForward;

    private LeaveRulesTO leaveRule;
}
