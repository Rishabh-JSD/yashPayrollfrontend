package com.hb.leaveMasters.leaveRules.entity;

import com.hb.common.Audit;
import com.hb.common.TABLES;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.util.*;


@Getter
@Setter
@Entity
@Table(name = TABLES.LEAVE_RULES)
public class LeaveRulesBO extends Audit {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "name")
    private String name;

    @Column(name = "delete_flag")
    private boolean deleteFlag;

    @OneToMany(cascade = CascadeType.ALL)
    @JoinColumn(name = "leave_rule_id", referencedColumnName = "id")
    private List<LeaveRulesDetailsBO> leaveRulesDetails;

}

