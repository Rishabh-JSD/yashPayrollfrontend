package com.hb.leaveMasters.leaveRules.entity;

import com.hb.common.Audit;
import com.hb.common.TABLES;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = TABLES.LEAVERULES_DETAILS)
public class LeaveRulesDetailsBO extends Audit {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "leave_type")
    private String leaveType;

    @Column(name = "minimum_number")
    private double minimumNumber;

    @Column(name = "maximum_number")
    private double maximumNumber;

    @Column(name = "max_period")
    private double maxPeriod;

    @Column(name = "delete_flag")
    private boolean deleteFlag;

    @Column(name = "leaves_credit")
    private double leavesCredit;

    @Column(name = "carry_forward")
    private double carryForward;


}
