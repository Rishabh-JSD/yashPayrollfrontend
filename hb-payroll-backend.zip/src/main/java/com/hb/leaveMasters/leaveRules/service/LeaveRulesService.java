package com.hb.leaveMasters.leaveRules.service;

import com.hb.common.PaginationCriteria;
import com.hb.common.SearchResponseTO;
import com.hb.leaveMasters.leaveRules.dto.LeaveRulesTO;

import java.util.List;

public interface LeaveRulesService {

    LeaveRulesTO addLeaveRules(LeaveRulesTO leaveRulesTO);

    LeaveRulesTO updateLeaveRules(LeaveRulesTO leaveRulesTO);

    SearchResponseTO getLeaveRulesList(PaginationCriteria paginationCriteria);

    LeaveRulesTO getLeaveRulesById(Long id);

    void deleteLeaveRules(List<Long> LeaveRulesId);
}
