package com.hb.leaveMasters.leaveRules.service;

import com.hb.common.MapperService;
import com.hb.common.PaginationCriteria;
import com.hb.common.SearchResponseTO;
import com.hb.leaveMasters.leaveRules.dao.LeaveRulesDao;
import com.hb.leaveMasters.leaveRules.dto.LeaveRulesTO;
import com.hb.leaveMasters.leaveRules.entity.LeaveRulesBO;
import com.hb.master.dto.CommonListTO;
import com.hb.master.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;

@Service
@Transactional
public class LeaveRulesServiceImpl implements LeaveRulesService{
    @Autowired
    private LeaveRulesDao leaveRulesDao;

    @Autowired
    private MapperService mapperService;

    @Autowired
    private UserService userService;

    @Override
    public LeaveRulesTO addLeaveRules(LeaveRulesTO leaveRulesTO) {
        LeaveRulesBO leaveRulesBO = mapperService.map(leaveRulesTO, LeaveRulesBO.class);
        return mapperService.map(leaveRulesDao.addLeaveRules(leaveRulesBO), LeaveRulesTO.class);
    }

    @Override
    public LeaveRulesTO updateLeaveRules(LeaveRulesTO leaveRulesTO) {
        LeaveRulesBO leaveRulesBO = mapperService.map(leaveRulesTO, LeaveRulesBO.class);
        return mapperService.map(leaveRulesDao.updateLeaveRules(leaveRulesBO), LeaveRulesTO.class);
    }

    @Override
    @Transactional(Transactional.TxType.NOT_SUPPORTED)
    public SearchResponseTO getLeaveRulesList(PaginationCriteria paginationCriteria) {
        SearchResponseTO searchResponseTO = new SearchResponseTO();
        CommonListTO<LeaveRulesBO> commonListTO = leaveRulesDao.getLeaveRulesList(paginationCriteria);

        List<LeaveRulesTO> leaveRulesTOS = null;
        if (commonListTO.getDataList() != null && !commonListTO.getDataList().isEmpty()) {
            leaveRulesTOS = new ArrayList<>();
            for (LeaveRulesBO leaveRulesBO : commonListTO.getDataList()) {
                LeaveRulesTO leaveRulesTO = mapperService.map(leaveRulesBO, LeaveRulesTO.class);
                if (leaveRulesTO.getCreatedBy() != null) {
                    leaveRulesTO.setCreatedByName(userService.getUserById(leaveRulesTO.getCreatedBy()).getName());
                }
                if (leaveRulesTO.getUpdatedBy() != null) {
                    leaveRulesTO.setUpdatedByName(userService.getUserById(leaveRulesTO.getUpdatedBy()).getName());
                }
                leaveRulesTOS.add(leaveRulesTO);
            }
        }
        searchResponseTO.setList(leaveRulesTOS);
        searchResponseTO.setPageCount(commonListTO.getPageCount());
        searchResponseTO.setTotalRowCount(commonListTO.getTotalRow().intValue());
        return searchResponseTO;
    }

    @Override
    @Transactional(Transactional.TxType.NOT_SUPPORTED)
    public LeaveRulesTO getLeaveRulesById(Long id) {
        return mapperService.map(leaveRulesDao.getLeaveRulesById(id), LeaveRulesTO.class);
    }

    @Override
    public void deleteLeaveRules(List<Long> id) {
        leaveRulesDao.deleteLeaveRules(id);
    }
}
