package com.hb.leaveMasters.leaveRules.validator;

import com.hb.common.PaginationCriteria;
import com.hb.leaveMasters.leaveRules.controller.LeaveRulesController;
import com.hb.leaveMasters.leaveRules.dto.LeaveRulesTO;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.ControllerAdvice;

@ControllerAdvice(assignableTypes = LeaveRulesController.class)
public class LeaveRulesValidator implements Validator {

    @Override
    public boolean supports(Class<?> aClass) {
        boolean support = LeaveRulesTO.class.equals(aClass);
        if (!support) {
            support = PaginationCriteria.class.equals(aClass);
        }
        return support;
    }

    @Override
    public void validate(Object o, Errors errors) {
        LeaveRulesTO leaveRulesTO = (LeaveRulesTO) o;

//    ValidationUtils.rejectIfEmptyOrWhitespace(errors, "name", "PMS001E", APP_MSG.MESSAGE.get("PR001E"));

    }
}
