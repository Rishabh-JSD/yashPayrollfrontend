package com.hb.leaveMasters.leaveType.controller;

import com.hb.common.PaginationCriteria;
import com.hb.common.ResponseDTO;
import com.hb.common.SearchResponseTO;
import com.hb.common.ValidationError;
import com.hb.leaveMasters.leaveType.dto.LeaveTypeTO;
import com.hb.leaveMasters.leaveType.service.LeaveTypeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/leaveType")
public class LeaveTypeController {

    @Autowired
    private Validator leaveTypeValidator;

    @Autowired
    private LeaveTypeService leaveTypeService;

    private ResponseDTO responseDTO;

    @InitBinder
    private void initBinder(WebDataBinder binder) {
        binder.setValidator(leaveTypeValidator);
    }

    @RequestMapping(value = "/add", method = RequestMethod.POST, name = "LeaveType Master Add->AMCR")
    public ResponseEntity<?> addLeaveType(@Valid @RequestBody LeaveTypeTO leaveTypeTO, Errors errors) {
        if (errors.hasErrors()) {
            ValidationError validationError = ValidationError.fromBindingErrors(errors);
            return new ResponseEntity<>(validationError, HttpStatus.OK);
        }
        LeaveTypeTO leaveTypeTO_return = leaveTypeService.addLeaveType(leaveTypeTO);
        responseDTO = ResponseDTO.responseBuilder(200, "PR001", "/leaveType", "leaveType", leaveTypeTO_return);
        return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }

    @RequestMapping(value = "/update", method = RequestMethod.POST, name = "LeaveType Master Update->AMCR")
    public ResponseEntity<?> updateLeaveType(@Valid @RequestBody LeaveTypeTO leaveTypeTO, Errors errors) {
        if (errors.hasErrors()) {
            ValidationError validationError = ValidationError.fromBindingErrors(errors);
            return new ResponseEntity<>(validationError, HttpStatus.OK);
        }
        LeaveTypeTO leaveTypeTO_return = leaveTypeService.updateLeaveType(leaveTypeTO);
        responseDTO = ResponseDTO.responseBuilder(200, "PR002", "/leaveType", "leaveType", leaveTypeTO_return);
        return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }

    @RequestMapping(value = "/list", method = RequestMethod.POST, name = "LeaveType Master List->AMCR")
    public ResponseEntity<?> getLeaveTypeList(@RequestBody PaginationCriteria paginationCriteria) {
        SearchResponseTO searchResponseTO = leaveTypeService.getLeaveTypeList(paginationCriteria);
        if (searchResponseTO.getList() == null || searchResponseTO.getList().isEmpty()) {
            responseDTO = ResponseDTO.responseBuilder(200, "PR006", "/leaveType", "leaveType", searchResponseTO);
            return new ResponseEntity<>(responseDTO, HttpStatus.OK);
        }
        responseDTO = ResponseDTO.responseBuilder(200, "PR003", "/leaveType", "leaveType", searchResponseTO);
        return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }

    @RequestMapping(value = "/{id}", method = RequestMethod.GET, name = "LeaveType Master View->AMCR")
    public ResponseEntity<?> getLeaveTypeById(@PathVariable Long id) {
        LeaveTypeTO leaveTypeTO = leaveTypeService.getLeaveTypeById(id);
        if (leaveTypeTO == null) {
            responseDTO = ResponseDTO.responseBuilder(200, "PR007", "/leaveType", "leaveType", null);
            return new ResponseEntity<>(responseDTO, HttpStatus.OK);
        }
        responseDTO = ResponseDTO.responseBuilder(200, "PR004", "/leaveType", "leaveType", leaveTypeTO);
        return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }

    @RequestMapping(value = "/delete", method = RequestMethod.DELETE, name = "LeaveType Master Delete->AMCR")
    public ResponseEntity<?> deleteLeaveType(@RequestParam(name = "leaveTypeId") List<Long> leaveTypeId) {
        leaveTypeService.deleteLeaveType(leaveTypeId);
        responseDTO = ResponseDTO.responseBuilder(200, "PR005", "/leaveType", "leaveType", leaveTypeId);
        return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }
}
