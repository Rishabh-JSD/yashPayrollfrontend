package com.hb.leaveMasters.leaveType.dao;

import com.hb.common.PaginationCriteria;
import com.hb.leaveMasters.leaveType.entity.LeaveTypeBO;
import com.hb.master.dto.CommonListTO;

import java.util.List;

public interface LeaveTypeDao {
    LeaveTypeBO addLeaveType(LeaveTypeBO leaveTypeBO);

    LeaveTypeBO updateLeaveType(LeaveTypeBO leaveTypeBO);

    CommonListTO<LeaveTypeBO> getLeaveTypeList(PaginationCriteria paginationCriteria);

    LeaveTypeBO getLeaveTypeById(Long id);

    void deleteLeaveType(List<Long> id);
}
