package com.hb.leaveMasters.leaveType.dto;

import com.hb.common.AuditTO;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LeaveTypeTO extends AuditTO {

    private Long id;
    private String name;
    private boolean deleteFlag;
}
