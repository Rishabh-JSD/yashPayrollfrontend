package com.hb.leaveMasters.leaveType.service;

import com.hb.common.PaginationCriteria;
import com.hb.common.SearchResponseTO;
import com.hb.leaveMasters.leaveType.dto.LeaveTypeTO;

import java.util.List;

public interface LeaveTypeService {

    LeaveTypeTO addLeaveType(LeaveTypeTO leaveTypeTO);

    LeaveTypeTO updateLeaveType(LeaveTypeTO leaveTypeTO);

    SearchResponseTO getLeaveTypeList(PaginationCriteria paginationCriteria);

    LeaveTypeTO getLeaveTypeById(Long id);

    void deleteLeaveType(List<Long> LeaveTypeId);
}
