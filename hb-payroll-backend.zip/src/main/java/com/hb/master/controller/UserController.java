package com.hb.master.controller;

import com.hb.common.AppEndPoints;
import com.hb.common.ResponseDTO;
import com.hb.master.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(AppEndPoints.USER.DEFAULT)
public class UserController {

  @Autowired
  private UserService userService;

  @RequestMapping(value = AppEndPoints.USER.USER_LIST, method = RequestMethod.GET)
  public ResponseEntity<?> getUserList() {
    ResponseDTO response = ResponseDTO.responseBuilder(HttpStatus.OK.value(), "U001",
            AppEndPoints.USER.DEFAULT + AppEndPoints.USER.USER_LIST, AppEndPoints.USER.BODY_KEY,
            userService.getUserList());
    return new ResponseEntity<>(response, HttpStatus.OK);
  }

  @RequestMapping(value = AppEndPoints.USER.USER_BY_ID, method = RequestMethod.GET)
  public ResponseEntity<?> getUserById(@PathVariable Long id) {
    ResponseDTO response = ResponseDTO.responseBuilder(HttpStatus.OK.value(), "U001",
            AppEndPoints.USER.DEFAULT + AppEndPoints.USER.USER_BY_ID, AppEndPoints.USER.BODY_KEY,
            userService.getUserById(id));
    return new ResponseEntity<>(response, HttpStatus.OK);
  }
}
