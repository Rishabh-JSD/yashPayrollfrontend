package com.hb.master.dao;

import java.util.List;

import com.hb.master.entity.MasterBusinessDataSource;

public interface MasterBusinessDataSourceDao {

	List<MasterBusinessDataSource> getDatasourceConfigList();

	MasterBusinessDataSource getDatasourceConfigByTenantId(String tenantId);

	MasterBusinessDataSource addMasterDatasourceConfig(MasterBusinessDataSource masterDataSourceConfig);

}
