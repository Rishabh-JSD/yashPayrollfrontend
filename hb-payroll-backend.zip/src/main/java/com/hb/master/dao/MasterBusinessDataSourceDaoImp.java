package com.hb.master.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.hb.master.entity.MasterBusinessDataSource;

@Repository
public class MasterBusinessDataSourceDaoImp implements MasterBusinessDataSourceDao {

	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public List<MasterBusinessDataSource> getDatasourceConfigList() {
		CriteriaBuilder queryBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<MasterBusinessDataSource> criteriaQuery = queryBuilder.createQuery(MasterBusinessDataSource.class);
		Root<MasterBusinessDataSource> entityRoot = criteriaQuery.from(MasterBusinessDataSource.class);
		Predicate condition = queryBuilder.and(queryBuilder.equal(entityRoot.get("status"), true));
		criteriaQuery.where(condition);
		return entityManager.createQuery(criteriaQuery).getResultList();
	}

	@Override
	public MasterBusinessDataSource getDatasourceConfigByTenantId(String tenantId) {
		CriteriaBuilder queryBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<MasterBusinessDataSource> criteriaQuery = queryBuilder.createQuery(MasterBusinessDataSource.class);
		Root<MasterBusinessDataSource> entityRoot = criteriaQuery.from(MasterBusinessDataSource.class);
		Predicate condition = queryBuilder.and(queryBuilder.equal(entityRoot.get("tenantId"), tenantId),
				queryBuilder.equal(entityRoot.get("status"), true));
		criteriaQuery.where(condition);
		List<MasterBusinessDataSource> list = entityManager.createQuery(criteriaQuery).getResultList();
		if (list != null && !list.isEmpty() && list.get(0) != null) {
			return list.get(0);
		}
		return null;
	}

	@Override
	public MasterBusinessDataSource addMasterDatasourceConfig(MasterBusinessDataSource masterDataSourceConfig) {
		entityManager.persist(masterDataSourceConfig);
		entityManager.flush();
		entityManager.clear();
		return masterDataSourceConfig;
	}

}
