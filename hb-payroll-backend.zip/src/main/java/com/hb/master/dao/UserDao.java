package com.hb.master.dao;

import java.util.List;

import com.hb.master.entity.UserBO;

public interface UserDao {

	UserBO getUserByToken(String accessToken);

	List<UserBO> getUserList();

	UserBO getUserById(Long id);
}
