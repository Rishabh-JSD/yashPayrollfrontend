package com.hb.master.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import com.hb.payrollMasters.allowance.entity.AllowanceBO;
import org.springframework.stereotype.Repository;

import com.hb.common.CommonUtill;
import com.hb.master.entity.UserBO;

@Repository
public class UserDaoImpl implements UserDao {

	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public UserBO getUserByToken(String accessToken) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<UserBO> query = criteriaBuilder.createQuery(UserBO.class);
		Root<UserBO> root = query.from(UserBO.class);
		query.where(criteriaBuilder.and(criteriaBuilder.equal(root.get("authTokenKey"), accessToken),
				criteriaBuilder.equal(root.get("active"), true)));
		List<UserBO> listUser = entityManager.createQuery(query).getResultList();
		if (CommonUtill.isValid(listUser)) {
			return listUser.get(0);
		}
		return null;
	}

	@Override
	public List<UserBO> getUserList() {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<UserBO> query = criteriaBuilder.createQuery(UserBO.class);
		Root<UserBO> root = query.from(UserBO.class);
		query.where(criteriaBuilder.and(criteriaBuilder.equal(root.get("active"), true)));
		return entityManager.createQuery(query).getResultList();
	}

	@Override
	public UserBO getUserById(Long id) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<UserBO> criteriaQuery = criteriaBuilder.createQuery(UserBO.class);

		Root<UserBO> root = criteriaQuery.from(UserBO.class);
		Predicate predicateForId = criteriaBuilder.equal(root.get("userId"), id);
		Predicate predicateForDeleteFlag = criteriaBuilder.equal(root.get("active"), true);
		Predicate predicate = criteriaBuilder.and(predicateForId, predicateForDeleteFlag);
		criteriaQuery.where(predicate);
		return entityManager.createQuery(criteriaQuery).getSingleResult();
	}

}
