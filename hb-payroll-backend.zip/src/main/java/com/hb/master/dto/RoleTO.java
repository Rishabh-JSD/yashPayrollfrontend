package com.hb.master.dto;

import com.hb.common.AuditTO;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class RoleTO extends AuditTO {

	private Integer roleId;

	private String roleName;

}
