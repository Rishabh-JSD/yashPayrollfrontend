package com.hb.master.entity;

import com.hb.common.AuditLogin;
import com.hb.common.TABLES;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = TABLES.MASTER_BUSINESS_DATASOURCE)
public class MasterBusinessDataSource extends AuditLogin {

  private static final long serialVersionUID = 1L;

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @Column(name = "business_uuid")
  private String tenantId;

  private String driver;

  private String datasource;

  private String username;

  private String password;

  private boolean status;

}
