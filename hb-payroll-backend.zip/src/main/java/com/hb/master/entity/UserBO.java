package com.hb.master.entity;

import com.hb.common.AuditLogin;
import com.hb.common.TABLES;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = TABLES.USERS)
public class UserBO extends AuditLogin {

  /**
   *
   */
  private static final long serialVersionUID = 1L;

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "user_id")
  private Long userId;

  private String name;

  private String username;

  private String password;

  private String email;

  @Column(name = "portal_user_id")
  private Integer portalUserId;

  @Column(name = "portal_account_number")
  private String portalAccountNumber;

  private String mobile;

  @Column(name = "auth_token_key")
  private String authTokenKey;

  @Column(name = "preserve_key")
  private String preserveKey;

  private boolean active;

}
