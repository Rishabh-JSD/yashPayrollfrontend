package com.hb.master.service;

import java.util.List;

import com.hb.master.dto.UserTO;

public interface UserService {

	UserTO loadUserByToken(String accessToken);

	String getToken(String preserveKey);

	List<UserTO> getUserList();

	UserTO getUserById(Long id);
}
