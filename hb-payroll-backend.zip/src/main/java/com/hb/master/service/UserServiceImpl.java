package com.hb.master.service;

import java.util.List;

import javax.transaction.Transactional;

import com.hb.payrollMasters.allowance.dto.AllowanceTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hb.common.MapperService;
import com.hb.master.dao.UserDao;
import com.hb.master.dto.UserTO;
import com.hb.master.entity.UserBO;

@Transactional
@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private MapperService mapperService;

	@Autowired
	private UserDao userDetDAO;

	@Override
	public UserTO loadUserByToken(String accessToken) {
		UserBO userByToken = userDetDAO.getUserByToken(accessToken);
		if (userByToken != null) {
			return mapperService.map(userByToken, UserTO.class);
		}
		return null;
	}

	@Override
	public String getToken(String preserveKey) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<UserTO> getUserList() {
		List<UserBO> userList = userDetDAO.getUserList();
		return mapperService.map(userList, UserTO.class);
	}

	@Override
	public UserTO getUserById(Long id) {
		return mapperService.map(userDetDAO.getUserById(id), UserTO.class);
	}

}
