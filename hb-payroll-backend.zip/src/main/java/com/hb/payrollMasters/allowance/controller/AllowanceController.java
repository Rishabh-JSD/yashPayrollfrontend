package com.hb.payrollMasters.allowance.controller;

import com.hb.common.ResponseDTO;
import com.hb.common.PaginationCriteria;
import com.hb.common.SearchResponseTO;
import com.hb.common.ValidationError;
import com.hb.payrollMasters.allowance.dto.AllowanceTO;
import com.hb.payrollMasters.allowance.service.AllowanceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/allowance")
public class AllowanceController {

  @Autowired
  private Validator allowanceValidator;

  @Autowired
  private AllowanceService allowanceService;

  private ResponseDTO responseDTO;

  @InitBinder
  private void initBinder(WebDataBinder binder) {
    binder.setValidator(allowanceValidator);
  }

  @RequestMapping(value = "/add", method = RequestMethod.POST, name = "Allowance Master Add->AMCR")
  public ResponseEntity<?> addAllowance(@Valid @RequestBody AllowanceTO allowanceTO, Errors errors) {
    if (errors.hasErrors()) {
      ValidationError validationError = ValidationError.fromBindingErrors(errors);
      return new ResponseEntity<>(validationError, HttpStatus.OK);
    }
    AllowanceTO allowanceTO_return = allowanceService.addAllowance(allowanceTO);
    responseDTO = ResponseDTO.responseBuilder(200, "PR001", "/allowance", "allowance", allowanceTO_return);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/update", method = RequestMethod.POST, name = "Allowance Master Update->AMCR")
  public ResponseEntity<?> updateAllowance(@Valid @RequestBody AllowanceTO allowanceTO, Errors errors) {
    if (errors.hasErrors()) {
      ValidationError validationError = ValidationError.fromBindingErrors(errors);
      return new ResponseEntity<>(validationError, HttpStatus.OK);
    }
    AllowanceTO allowanceTO_return = allowanceService.updateAllowance(allowanceTO);
    responseDTO = ResponseDTO.responseBuilder(200, "PR002", "/allowance", "allowance", allowanceTO_return);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/list", method = RequestMethod.POST, name = "Allowance Master List->AMCR")
  public ResponseEntity<?> getAllowanceList(@RequestBody PaginationCriteria paginationCriteria) {
    SearchResponseTO searchResponseTO = allowanceService.getAllowanceList(paginationCriteria);
    if (searchResponseTO.getList() == null || searchResponseTO.getList().isEmpty()) {
      responseDTO = ResponseDTO.responseBuilder(200, "PR006", "/allowance", "allowance", searchResponseTO);
      return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }
    responseDTO = ResponseDTO.responseBuilder(200, "PR003", "/allowance", "allowance", searchResponseTO);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/{id}", method = RequestMethod.GET, name = "Allowance Master View->AMCR")
  public ResponseEntity<?> getAllowanceById(@PathVariable Long id) {
    AllowanceTO allowanceTO = allowanceService.getAllowanceById(id);
    if (allowanceTO == null) {
      responseDTO = ResponseDTO.responseBuilder(200, "PR007", "/allowance", "allowance", null);
      return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }
    responseDTO = ResponseDTO.responseBuilder(200, "PR004", "/allowance", "allowance", allowanceTO);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/delete", method = RequestMethod.DELETE, name = "Allowance Master Delete->AMCR")
  public ResponseEntity<?> deleteAllowance(@RequestParam(name = "allowanceId") List<Long> allowanceId) {
    allowanceService.deleteAllowance(allowanceId);
    responseDTO = ResponseDTO.responseBuilder(200, "PR005", "/allowance", "allowance", allowanceId);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }
}
