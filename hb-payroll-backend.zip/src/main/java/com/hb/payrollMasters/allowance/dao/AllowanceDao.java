package com.hb.payrollMasters.allowance.dao;

import com.hb.common.PaginationCriteria;
import com.hb.master.dto.CommonListTO;
import com.hb.payrollMasters.allowance.entity.AllowanceBO;

import java.util.List;

public interface AllowanceDao {

  AllowanceBO addAllowance(AllowanceBO allowanceTO);

  AllowanceBO updateAllowance(AllowanceBO allowanceTO);

  CommonListTO<AllowanceBO> getAllowanceList(PaginationCriteria paginationCriteria);

  AllowanceBO getAllowanceById(Long id);

  void deleteAllowance(List<Long> id);

}
