package com.hb.payrollMasters.allowance.dao;

import com.hb.common.PaginationCriteria;
import com.hb.master.dto.CommonListTO;
import com.hb.payrollMasters.allowance.entity.AllowanceBO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.*;
import java.util.List;

@Repository
public class AllowanceDaoImpl implements AllowanceDao {

  @PersistenceContext
  private EntityManager entityManager;

  private static final Logger logger = LoggerFactory.getLogger(AllowanceDaoImpl.class);

  @Override
  public AllowanceBO addAllowance(AllowanceBO allowanceBO) {
    entityManager.persist(allowanceBO);
    logger.info("Allowance has added successfully, Allowance details=" + allowanceBO);
    return allowanceBO;
  }

  @Override
  public AllowanceBO updateAllowance(AllowanceBO allowanceBO) {
    entityManager.merge(allowanceBO);
    logger.info("Allowance has updated successfully, Allowance details=" + allowanceBO);
    return allowanceBO;
  }

  @Override
  public CommonListTO<AllowanceBO> getAllowanceList(PaginationCriteria paginationCriteria) {
    CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
    CriteriaQuery<AllowanceBO> criteriaQuery = criteriaBuilder.createQuery(AllowanceBO.class);
    Root<AllowanceBO> root = criteriaQuery.from(AllowanceBO.class);
    criteriaQuery.where(criteriaBuilder.equal(root.get("deleteFlag"), false));

    //condition for search
    if (paginationCriteria.getSearchFor() != null && !paginationCriteria.getSearchFor().isEmpty() ) {
      Path<String> pathName = root.get("name");
      Predicate predicateForName = criteriaBuilder.like(pathName, "%" + paginationCriteria.getSearchFor() + "%");
      // Assuming "deleteFlag" is the field representing the deletion status
      Path<Boolean> pathDeleteFlag = root.get("deleteFlag");
      Predicate predicateNotDeleted = criteriaBuilder.isFalse(pathDeleteFlag);
      criteriaQuery.where(criteriaBuilder.and(predicateForName, predicateNotDeleted));
    }

    // Condition for sorting.
    if (paginationCriteria.getSortField() != null && !paginationCriteria.getSortField().isEmpty()) {
      Order order;
      if (paginationCriteria.getSortType() == 2) {
        order = criteriaBuilder.desc(root.get(paginationCriteria.getSortField()));
      } else {
        order = criteriaBuilder.asc(root.get(paginationCriteria.getSortField()));
      }
      criteriaQuery.orderBy(order);
    } else {
      Order order = criteriaBuilder.desc(root.get("id"));
      criteriaQuery.orderBy(order);
    }

    // Adding Pagination total Count
    CommonListTO<AllowanceBO> commonListTO = new CommonListTO<>();
    CriteriaQuery<Long> criteriaQuery2 = criteriaBuilder.createQuery(Long.class);
    Root<AllowanceBO> root2 = criteriaQuery2.from(AllowanceBO.class);
    criteriaQuery2.where(criteriaBuilder.equal(root2.get("deleteFlag"), false));
    CriteriaQuery<Long> select = criteriaQuery2.select(criteriaBuilder.count(root2));
    Long count = entityManager.createQuery(select).getSingleResult();
    commonListTO.setTotalRow(count);
    int size = count.intValue();
    int limit = paginationCriteria.getLimit();
    if (limit != 0) {
      commonListTO.setPageCount((size + limit - 1) / limit);
    } else {
      commonListTO.setPageCount(1);
    }

    TypedQuery<AllowanceBO> typedQuery = entityManager.createQuery(criteriaQuery);
    // Condition for paging.
    if (paginationCriteria.getPage() != 0 && paginationCriteria.getLimit() > 0) {
      typedQuery.setFirstResult((paginationCriteria.getPage() - 1) * paginationCriteria.getLimit());
      typedQuery.setMaxResults(paginationCriteria.getLimit());
    }
    commonListTO.setDataList(typedQuery.getResultList());
    return commonListTO;
  }

  @Override
  public AllowanceBO getAllowanceById(Long id) {
    CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
    CriteriaQuery<AllowanceBO> criteriaQuery = criteriaBuilder.createQuery(AllowanceBO.class);

    Root<AllowanceBO> root = criteriaQuery.from(AllowanceBO.class);
    Predicate predicateForId = criteriaBuilder.equal(root.get("id"), id);
    Predicate predicateForDeleteFlag = criteriaBuilder.equal(root.get("deleteFlag"), false);
    Predicate predicate = criteriaBuilder.and(predicateForId, predicateForDeleteFlag);
    criteriaQuery.where(predicate);
    return entityManager.createQuery(criteriaQuery).getSingleResult();
  }

  @Override
  public void deleteAllowance(List<Long> id) {
    CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
    CriteriaUpdate<AllowanceBO> criteriaUpdate = criteriaBuilder.createCriteriaUpdate(AllowanceBO.class);
    Root<AllowanceBO> root = criteriaUpdate.from(AllowanceBO.class);
    criteriaUpdate.set("deleteFlag", true);
    criteriaUpdate.where(root.get("id").in(id));
    entityManager.createQuery(criteriaUpdate).executeUpdate();
  }
}
