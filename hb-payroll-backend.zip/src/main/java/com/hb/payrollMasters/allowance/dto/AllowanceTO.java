package com.hb.payrollMasters.allowance.dto;

import com.hb.common.AuditTO;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AllowanceTO extends AuditTO {

  private Long id;
  private String name;
  private boolean deleteFlag;

}
