package com.hb.payrollMasters.allowance.entity;

import com.hb.common.Audit;
import com.hb.common.TABLES;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = TABLES.ALLOWANCE_MASTER)
public class AllowanceBO extends Audit {

  private static final long serialVersionUID = 5329310638765483677L;

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "id", updatable = false)
  private Long id;

  @Column(name = "name")
  private String name;

  @Column(name = "delete_flag")
  private boolean deleteFlag;

}
