package com.hb.payrollMasters.allowance.service;

import com.hb.common.PaginationCriteria;
import com.hb.common.SearchResponseTO;
import com.hb.payrollMasters.allowance.dto.AllowanceTO;

import java.util.List;

public interface AllowanceService {

  AllowanceTO addAllowance(AllowanceTO allowanceTO);

  AllowanceTO updateAllowance(AllowanceTO allowanceTO);

  SearchResponseTO getAllowanceList(PaginationCriteria paginationCriteria);

  AllowanceTO getAllowanceById(Long id);

  void deleteAllowance(List<Long> allowanceId);
}
