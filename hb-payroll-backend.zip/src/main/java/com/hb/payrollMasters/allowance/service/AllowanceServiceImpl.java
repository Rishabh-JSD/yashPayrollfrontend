package com.hb.payrollMasters.allowance.service;

import com.hb.common.MapperService;
import com.hb.common.PaginationCriteria;
import com.hb.common.SearchResponseTO;
import com.hb.master.dto.CommonListTO;
import com.hb.master.service.UserService;
import com.hb.payrollMasters.allowance.dao.AllowanceDao;
import com.hb.payrollMasters.allowance.dto.AllowanceTO;
import com.hb.payrollMasters.allowance.entity.AllowanceBO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;

@Service
@Transactional
public class AllowanceServiceImpl implements AllowanceService {

  @Autowired
  private AllowanceDao allowanceDao;

  @Autowired
  private MapperService mapperService;

  @Autowired
  private UserService userService;

  @Override
  public AllowanceTO addAllowance(AllowanceTO allowanceTO) {
    AllowanceBO allowanceBO = mapperService.map(allowanceTO, AllowanceBO.class);
    return mapperService.map(allowanceDao.addAllowance(allowanceBO), AllowanceTO.class);
  }

  @Override
  public AllowanceTO updateAllowance(AllowanceTO allowanceTO) {
    AllowanceBO allowanceBO = mapperService.map(allowanceTO, AllowanceBO.class);
    return mapperService.map(allowanceDao.updateAllowance(allowanceBO), AllowanceTO.class);
  }

  @Override
  @Transactional(Transactional.TxType.NOT_SUPPORTED)
  public SearchResponseTO getAllowanceList(PaginationCriteria paginationCriteria) {
    SearchResponseTO searchResponseTO = new SearchResponseTO();
    CommonListTO<AllowanceBO> commonListTO = allowanceDao.getAllowanceList(paginationCriteria);

    List<AllowanceTO> allowanceTOS = null;
    if (commonListTO.getDataList() != null && !commonListTO.getDataList().isEmpty()) {
      allowanceTOS = new ArrayList<>();
      for (AllowanceBO allowanceBO : commonListTO.getDataList()) {
        AllowanceTO allowanceTO = mapperService.map(allowanceBO, AllowanceTO.class);
        if (allowanceTO.getCreatedBy() != null) {
          allowanceTO.setCreatedByName(userService.getUserById(allowanceTO.getCreatedBy()).getName());
        }
        if (allowanceTO.getUpdatedBy() != null) {
          allowanceTO.setUpdatedByName(userService.getUserById(allowanceTO.getUpdatedBy()).getName());
        }
        allowanceTOS.add(allowanceTO);
      }
    }
    searchResponseTO.setList(allowanceTOS);
    searchResponseTO.setPageCount(commonListTO.getPageCount());
    searchResponseTO.setTotalRowCount(commonListTO.getTotalRow().intValue());
    return searchResponseTO;
  }

  @Override
  @Transactional(Transactional.TxType.NOT_SUPPORTED)
  public AllowanceTO getAllowanceById(Long id) {
    return mapperService.map(allowanceDao.getAllowanceById(id), AllowanceTO.class);
  }

  @Override
  public void deleteAllowance(List<Long> id) {
    allowanceDao.deleteAllowance(id);
  }
}
