package com.hb.payrollMasters.deduction.controller;

import com.hb.common.ResponseDTO;
import com.hb.common.PaginationCriteria;
import com.hb.common.SearchResponseTO;
import com.hb.common.ValidationError;
import com.hb.payrollMasters.deduction.dto.DeductionTO;
import com.hb.payrollMasters.deduction.service.DeductionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/deduction")
public class DeductionController {

  @Autowired
  private Validator deductionValidator;

  @Autowired
  private DeductionService deductionService;

  private ResponseDTO responseDTO;

  @InitBinder
  private void initBinder(WebDataBinder binder) {
    binder.setValidator(deductionValidator);
  }

  @RequestMapping(value = "/add", method = RequestMethod.POST, name = "Deduction Master Add->DDMCR")
  public ResponseEntity<?> addDeduction(@Valid @RequestBody DeductionTO deductionTO, Errors errors) {
    if (errors.hasErrors()) {
      ValidationError validationError = ValidationError.fromBindingErrors(errors);
      return new ResponseEntity<>(validationError, HttpStatus.OK);
    }
    DeductionTO deductionTO_return = deductionService.addDeduction(deductionTO);
    responseDTO = ResponseDTO.responseBuilder(200, "PR001", "/deduction", "deduction", deductionTO_return);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/update", method = RequestMethod.POST, name = "Deduction Master Update->DDMCR")
  public ResponseEntity<?> updateDeduction(@Valid @RequestBody DeductionTO deductionTO, Errors errors) {
    if (errors.hasErrors()) {
      ValidationError validationError = ValidationError.fromBindingErrors(errors);
      return new ResponseEntity<>(validationError, HttpStatus.OK);
    }
    DeductionTO deductionTO_return = deductionService.updateDeduction(deductionTO);
    responseDTO = ResponseDTO.responseBuilder(200, "PR002", "/deduction", "deduction", deductionTO_return);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/list", method = RequestMethod.POST, name = "Deduction Master List->DDMCR")
  public ResponseEntity<?> getDeductionList(@RequestBody PaginationCriteria paginationCriteria) {
    SearchResponseTO searchResponseTO = deductionService.getDeductionList(paginationCriteria);
    if (searchResponseTO.getList() == null || searchResponseTO.getList().isEmpty()) {
      responseDTO = ResponseDTO.responseBuilder(200, "PR006", "/deduction", "deduction", searchResponseTO);
      return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }
    responseDTO = ResponseDTO.responseBuilder(200, "PR003", "/deduction", "deduction", searchResponseTO);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/{id}", method = RequestMethod.GET, name = "Deduction Master View->DDMCR")
  public ResponseEntity<?> getDeductionById(@PathVariable Long id) {
    DeductionTO deductionTO = deductionService.getDeductionById(id);
    if (deductionTO == null) {
      responseDTO = ResponseDTO.responseBuilder(200, "PR007", "/deduction", "deduction", null);
      return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }
    responseDTO = ResponseDTO.responseBuilder(200, "PR004", "/deduction", "deduction", deductionTO);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/delete", method = RequestMethod.DELETE, name = "Deduction Master Delete->DDMCR")
  public ResponseEntity<?> deleteDeduction(@RequestParam(name = "deductionId") List<Integer> deductionId) {
    deductionService.deleteDeduction(deductionId);
    responseDTO = ResponseDTO.responseBuilder(200, "PR005", "/deduction", "deduction", deductionId);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }
}
