package com.hb.payrollMasters.deduction.dao;

import com.hb.common.PaginationCriteria;
import com.hb.master.dto.CommonListTO;
import com.hb.payrollMasters.deduction.entity.DeductionBO;

import java.util.List;

public interface DeductionDao {

  DeductionBO addDeduction(DeductionBO deductionBO);

  DeductionBO updateDeduction(DeductionBO deductionBO);

  CommonListTO<DeductionBO> getDeductionList(PaginationCriteria paginationCriteria);

  DeductionBO getDeductionById(Long id);

  void deleteDeduction(List<Integer> id);

}
