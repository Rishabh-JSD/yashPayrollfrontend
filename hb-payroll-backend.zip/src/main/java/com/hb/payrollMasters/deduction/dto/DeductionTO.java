package com.hb.payrollMasters.deduction.dto;

import com.hb.common.AuditTO;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DeductionTO extends AuditTO {

  private Long id;
  private String name;
  private boolean deleteFlag;

}
