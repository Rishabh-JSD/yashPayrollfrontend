package com.hb.payrollMasters.deduction.entity;

import com.hb.common.Audit;
import com.hb.common.TABLES;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = TABLES.DEDUCTION_MASTER)
public class DeductionBO extends Audit {

  private static final long serialVersionUID = -2465226737654855110L;

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "id", updatable = false)
  private Long id;

  @Column(name = "name")
  private String name;

  @Column(name = "delete_flag")
  private boolean deleteFlag;

}
