package com.hb.payrollMasters.deduction.service;

import com.hb.common.PaginationCriteria;
import com.hb.common.SearchResponseTO;
import com.hb.payrollMasters.deduction.dto.DeductionTO;

import java.util.List;

public interface DeductionService {

  DeductionTO addDeduction(DeductionTO deductionTO);

  DeductionTO updateDeduction(DeductionTO deductionTO);

  SearchResponseTO getDeductionList(PaginationCriteria paginationCriteria);

  DeductionTO getDeductionById(Long id);

  void deleteDeduction(List<Integer> deductionId);

}
