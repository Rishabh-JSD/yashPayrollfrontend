package com.hb.payrollMasters.deduction.service;

import com.hb.common.MapperService;
import com.hb.common.PaginationCriteria;
import com.hb.common.SearchResponseTO;
import com.hb.master.dto.CommonListTO;
import com.hb.master.service.UserService;
import com.hb.payrollMasters.deduction.dao.DeductionDao;
import com.hb.payrollMasters.deduction.dto.DeductionTO;
import com.hb.payrollMasters.deduction.entity.DeductionBO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;

@Service
@Transactional
public class DeductionServiceImpl implements DeductionService {

  @Autowired
  private DeductionDao deductionDao;

  @Autowired
  private MapperService mapperService;

  @Autowired
  private UserService userService;

  @Override
  public DeductionTO addDeduction(DeductionTO deductionTO) {
    DeductionBO deductionBO = mapperService.map(deductionTO, DeductionBO.class);
    return mapperService.map(deductionDao.addDeduction(deductionBO), DeductionTO.class);
  }

  @Override
  public DeductionTO updateDeduction(DeductionTO deductionTO) {
    DeductionBO deductionBO = mapperService.map(deductionTO, DeductionBO.class);
    return mapperService.map(deductionDao.updateDeduction(deductionBO), DeductionTO.class);
  }

  @Override
  @Transactional(Transactional.TxType.NOT_SUPPORTED)
  public SearchResponseTO getDeductionList(PaginationCriteria paginationCriteria) {
    SearchResponseTO searchResponseTO = new SearchResponseTO();
    CommonListTO<DeductionBO> commonListTO = deductionDao.getDeductionList(paginationCriteria);

    List<DeductionTO> deductionTOS = null;
    if (commonListTO.getDataList() != null && !commonListTO.getDataList().isEmpty()) {
      deductionTOS = new ArrayList<>();
      for (DeductionBO deductionBO : commonListTO.getDataList()) {
        DeductionTO deductionTO = mapperService.map(deductionBO, DeductionTO.class);
        if (deductionTO.getCreatedBy() != null) {
          deductionTO.setCreatedByName(userService.getUserById(deductionTO.getCreatedBy()).getName());
        }
        if (deductionTO.getUpdatedBy() != null) {
          deductionTO.setUpdatedByName(userService.getUserById(deductionTO.getUpdatedBy()).getName());
        }
        deductionTOS.add(deductionTO);
      }
    }
    searchResponseTO.setList(deductionTOS);
    searchResponseTO.setPageCount(commonListTO.getPageCount());
    searchResponseTO.setTotalRowCount(commonListTO.getTotalRow().intValue());
    return searchResponseTO;
  }

  @Override
  @Transactional(Transactional.TxType.NOT_SUPPORTED)
  public DeductionTO getDeductionById(Long id) {
    return mapperService.map(deductionDao.getDeductionById(id), DeductionTO.class);
  }

  @Override
  public void deleteDeduction(List<Integer> id) {
    deductionDao.deleteDeduction(id);
  }
}
