package com.hb.payrollMasters.deduction.validator;

import com.hb.common.PaginationCriteria;
import com.hb.payrollMasters.deduction.controller.DeductionController;
import com.hb.payrollMasters.deduction.dto.DeductionTO;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.ControllerAdvice;

@ControllerAdvice(assignableTypes = DeductionController.class)
public class DeductionValidator implements Validator {
  
  @Override
  public boolean supports(Class<?> aClass) {
    boolean support = DeductionTO.class.equals(aClass);
    if (!support) {
      support = PaginationCriteria.class.equals(aClass);
    }
    return support;
  }

  @Override
  public void validate(Object o, Errors errors) {
    DeductionTO deductionTO = (DeductionTO) o;

//    ValidationUtils.rejectIfEmptyOrWhitespace(errors, "name", "PMS001E", APP_MSG.MESSAGE.get("PR001E"));

  }
}
