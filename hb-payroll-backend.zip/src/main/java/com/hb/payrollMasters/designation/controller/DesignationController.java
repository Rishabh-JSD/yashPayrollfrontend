package com.hb.payrollMasters.designation.controller;

import com.hb.common.ResponseDTO;
import com.hb.common.PaginationCriteria;
import com.hb.common.SearchResponseTO;
import com.hb.common.ValidationError;
import com.hb.payrollMasters.designation.dto.DesignationTO;
import com.hb.payrollMasters.designation.service.DesignationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/designation")
public class DesignationController {

  @Autowired
  private Validator designationValidator;

  @Autowired
  private DesignationService designationService;

  private ResponseDTO responseDTO;

  @InitBinder
  private void initBinder(WebDataBinder binder) {
    binder.setValidator(designationValidator);
  }

  @RequestMapping(value = "/add", method = RequestMethod.POST, name = "Designation Master Add->DNMCR")
  public ResponseEntity<?> addDesignation(@Valid @RequestBody DesignationTO designationTO, Errors errors) {
    if (errors.hasErrors()) {
      ValidationError validationError = ValidationError.fromBindingErrors(errors);
      return new ResponseEntity<>(validationError, HttpStatus.OK);
    }
    DesignationTO designationTO_return = designationService.addDesignation(designationTO);
    responseDTO = ResponseDTO.responseBuilder(200, "PR001", "/designation", "designation", designationTO_return);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/update", method = RequestMethod.POST, name = "Designation Master Update->DNMCR")
  public ResponseEntity<?> updateDesignation(@Valid @RequestBody DesignationTO designationTO, Errors errors) {
    if (errors.hasErrors()) {
      ValidationError validationError = ValidationError.fromBindingErrors(errors);
      return new ResponseEntity<>(validationError, HttpStatus.OK);
    }
    DesignationTO designationTO_return = designationService.updateDesignation(designationTO);
    responseDTO = ResponseDTO.responseBuilder(200, "PR002", "/designation", "designation", designationTO_return);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/list", method = RequestMethod.POST, name = "Designation Master List->DNMCR")
  public ResponseEntity<?> getDesignationList(@RequestBody PaginationCriteria paginationCriteria) {
    SearchResponseTO searchResponseTO = designationService.getDesignationList(paginationCriteria);
    if (searchResponseTO.getList() == null || searchResponseTO.getList().isEmpty()) {
      responseDTO = ResponseDTO.responseBuilder(200, "PR006", "/designation", "designation", searchResponseTO);
      return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }
    responseDTO = ResponseDTO.responseBuilder(200, "PR003", "/designation", "designation", searchResponseTO);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/{id}", method = RequestMethod.GET, name = "Designation Master View->DNMCR")
  public ResponseEntity<?> getDesignationById(@PathVariable Long id) {
    DesignationTO designationTO = designationService.getDesignationById(id);
    if (designationTO == null) {
      responseDTO = ResponseDTO.responseBuilder(200, "PR007", "/designation", "designation", null);
      return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }
    responseDTO = ResponseDTO.responseBuilder(200, "PR004", "/designation", "designation", designationTO);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/delete", method = RequestMethod.DELETE, name = "Designation Master Delete->DNMCR")
  public ResponseEntity<?> deleteDesignation(@RequestParam(name = "designationId") List<Long> designationId) {
    designationService.deleteDesignation(designationId);
    responseDTO = ResponseDTO.responseBuilder(200, "PR005", "/designation", "designation", designationId);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }
}
