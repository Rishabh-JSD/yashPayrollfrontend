package com.hb.payrollMasters.designation.dao;

import com.hb.common.PaginationCriteria;
import com.hb.master.dto.CommonListTO;
import com.hb.payrollMasters.designation.entity.DesignationBO;

import java.util.List;

public interface DesignationDao {

  DesignationBO addDesignation(DesignationBO designationBO);

  DesignationBO updateDesignation(DesignationBO designationBO);

  CommonListTO<DesignationBO> getDesignationList(PaginationCriteria paginationCriteria);

  DesignationBO getDesignationById(Long id);

  void deleteDesignation(List<Long> designationId);

}
