package com.hb.payrollMasters.designation.dto;

import com.hb.common.AuditTO;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DesignationTO extends AuditTO {

  private Long id;
  private String name;
  private String code;
  private Long levelId;
  private Long reportingToId;
  private String reportingToName;
  private String description;
  private boolean deleteFlag;

}
