package com.hb.payrollMasters.designation.entity;

import com.hb.common.Audit;
import com.hb.common.TABLES;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = TABLES.DESIGNATION_MASTER)
public class DesignationBO extends Audit {

  private static final long serialVersionUID = -3923624226733930372L;

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "id", updatable = false)
  private Long id;

  @Column(name = "name")
  private String name;

  @Column(name = "code")
  private String code;

  @Column(name = "level_id")
  private Long levelId;

  @Column(name = "reporting_to_id")
  private Long reportingToId;

  @Column(name = "description")
  private String description;

  @Column(name = "delete_flag")
  private boolean deleteFlag;

}
