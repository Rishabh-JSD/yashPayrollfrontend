package com.hb.payrollMasters.designation.service;

import com.hb.common.PaginationCriteria;
import com.hb.common.SearchResponseTO;
import com.hb.payrollMasters.designation.dto.DesignationTO;

import java.util.List;

public interface DesignationService {

  DesignationTO addDesignation(DesignationTO designationTO);

  DesignationTO updateDesignation(DesignationTO designationTO);

  SearchResponseTO getDesignationList(PaginationCriteria paginationCriteria);

  DesignationTO getDesignationById(Long id);

  void deleteDesignation(List<Long> designationId);

}
