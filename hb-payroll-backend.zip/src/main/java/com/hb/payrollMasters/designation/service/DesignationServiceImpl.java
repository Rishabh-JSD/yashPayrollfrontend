package com.hb.payrollMasters.designation.service;

import com.hb.common.MapperService;
import com.hb.common.PaginationCriteria;
import com.hb.common.SearchResponseTO;
import com.hb.employee.service.EmployeeService;
import com.hb.master.dto.CommonListTO;

import com.hb.master.service.UserService;
import com.hb.payrollMasters.designation.dao.DesignationDao;
import com.hb.payrollMasters.designation.dto.DesignationTO;
import com.hb.payrollMasters.designation.entity.DesignationBO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;

@Service
@Transactional
public class DesignationServiceImpl implements DesignationService {

  @Autowired
  private DesignationDao designationDao;

  @Autowired
  private EmployeeService EmpService;

  @Autowired
  private UserService userService;

  @Autowired
  private MapperService mapperService;

  @Override
  public DesignationTO addDesignation(DesignationTO designationTO) {
    DesignationBO designationBO = mapperService.map(designationTO, DesignationBO.class);
    return mapperService.map(designationDao.addDesignation(designationBO), DesignationTO.class);
  }

  @Override
  public DesignationTO updateDesignation(DesignationTO designationTO) {
    DesignationBO designationBO = mapperService.map(designationTO, DesignationBO.class);
    return mapperService.map(designationDao.updateDesignation(designationBO), DesignationTO.class);
  }

  @Override
  @Transactional(Transactional.TxType.NOT_SUPPORTED)
  public SearchResponseTO getDesignationList(PaginationCriteria paginationCriteria) {
    SearchResponseTO searchResponseTO = new SearchResponseTO();
    CommonListTO<DesignationBO> commonListTO = designationDao.getDesignationList(paginationCriteria);

    List<DesignationTO> designationTOS = null;
    if (commonListTO.getDataList() != null && !commonListTO.getDataList().isEmpty()) {
      designationTOS = new ArrayList<>();
      for (DesignationBO designationBO : commonListTO.getDataList()) {
        DesignationTO designationTO = mapperService.map(designationBO, DesignationTO.class);
        if (designationTO.getReportingToId() != null) {
          designationTO.setReportingToName(EmpService.getEmployeeById(designationTO.getReportingToId()).getName());
        }
        if (designationTO.getCreatedBy() != null) {
          designationTO.setCreatedByName(userService.getUserById(designationTO.getCreatedBy()).getName());
        }
        if (designationTO.getUpdatedBy() != null) {
          designationTO.setUpdatedByName(userService.getUserById(designationTO.getUpdatedBy()).getName());
        }
        designationTOS.add(designationTO);
      }
    }
    searchResponseTO.setList(designationTOS);
    searchResponseTO.setPageCount(commonListTO.getPageCount());
    searchResponseTO.setTotalRowCount(commonListTO.getTotalRow().intValue());
    return searchResponseTO;
  }

  @Override
  @Transactional(Transactional.TxType.NOT_SUPPORTED)
  public DesignationTO getDesignationById(Long id) {
    return mapperService.map(designationDao.getDesignationById(id), DesignationTO.class);
  }

  @Override
  public void deleteDesignation(List<Long> designationId) {
    designationDao.deleteDesignation(designationId);
  }

}
