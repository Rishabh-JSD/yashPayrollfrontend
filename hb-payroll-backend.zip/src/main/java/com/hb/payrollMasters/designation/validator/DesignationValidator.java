package com.hb.payrollMasters.designation.validator;

import com.hb.common.PaginationCriteria;
import com.hb.payrollMasters.designation.controller.DesignationController;
import com.hb.payrollMasters.designation.dto.DesignationTO;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.ControllerAdvice;

@ControllerAdvice(assignableTypes = DesignationController.class)
public class DesignationValidator implements Validator {
  
  @Override
  public boolean supports(Class<?> aClass) {
    boolean support = DesignationTO.class.equals(aClass);
    if (!support) {
      support = PaginationCriteria.class.equals(aClass);
    }
    return support;
  }

  @Override
  public void validate(Object o, Errors errors) {
    DesignationTO designationTO = (DesignationTO) o;

//    ValidationUtils.rejectIfEmptyOrWhitespace(errors, "name", "PMS001E", APP_MSG.MESSAGE.get("PR001E"));

  }
}
