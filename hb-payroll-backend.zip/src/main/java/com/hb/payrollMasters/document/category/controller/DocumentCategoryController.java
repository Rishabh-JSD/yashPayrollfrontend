package com.hb.payrollMasters.document.category.controller;

import com.hb.common.ResponseDTO;
import com.hb.common.PaginationCriteria;
import com.hb.common.SearchResponseTO;
import com.hb.common.ValidationError;
import com.hb.payrollMasters.document.category.dto.DocumentCategoryTO;
import com.hb.payrollMasters.document.category.service.DocumentCategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/document-category")
public class DocumentCategoryController {

  @Autowired
  private Validator documentCategoryValidator;

  @Autowired
  private DocumentCategoryService documentCategoryService;

  private ResponseDTO responseDTO;

  @InitBinder
  private void initBinder(WebDataBinder binder) {
    binder.setValidator(documentCategoryValidator);
  }

  @RequestMapping(value = "/add", method = RequestMethod.POST, name = "Document Category Master Add->DCMCR")
  public ResponseEntity<?> addDocumentCategory(@Valid @RequestBody DocumentCategoryTO documentCategoryTO, Errors errors) {
    if (errors.hasErrors()) {
      ValidationError validationError = ValidationError.fromBindingErrors(errors);
      return new ResponseEntity<>(validationError, HttpStatus.OK);
    }
    DocumentCategoryTO documentCategoryTO_return = documentCategoryService.addDocumentCategory(documentCategoryTO);
    responseDTO = ResponseDTO.responseBuilder(200, "PR001", "/document-category", "documentCategory", documentCategoryTO_return);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/update", method = RequestMethod.POST, name = "Document Category Master Update->DCMCR")
  public ResponseEntity<?> updateDocumentCategory(@Valid @RequestBody DocumentCategoryTO documentCategoryTO, Errors errors) {
    if (errors.hasErrors()) {
      ValidationError validationError = ValidationError.fromBindingErrors(errors);
      return new ResponseEntity<>(validationError, HttpStatus.OK);
    }
    DocumentCategoryTO documentCategoryTO_return = documentCategoryService.updateDocumentCategory(documentCategoryTO);
    responseDTO = ResponseDTO.responseBuilder(200, "PR002", "/document-category", "documentCategory", documentCategoryTO_return);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/list", method = RequestMethod.POST, name = "Document Category Master List->DCMCR")
  public ResponseEntity<?> getDocumentCategoryList(@RequestBody PaginationCriteria paginationCriteria) {
    SearchResponseTO searchResponseTO = documentCategoryService.getDocumentCategoryList(paginationCriteria);
    if (searchResponseTO.getList() == null || searchResponseTO.getList().isEmpty()) {
      responseDTO = ResponseDTO.responseBuilder(200, "PR006", "/document-category", "documentCategory", searchResponseTO);
      return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }
    responseDTO = ResponseDTO.responseBuilder(200, "PR003", "/document-category", "documentCategory", searchResponseTO);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/{id}", method = RequestMethod.GET, name = "Document Category Master View->DCMCR")
  public ResponseEntity<?> getDocumentCategoryById(@PathVariable Long id) {
    DocumentCategoryTO documentCategoryTO = documentCategoryService.getDocumentCategoryById(id);
    if (documentCategoryTO == null) {
      responseDTO = ResponseDTO.responseBuilder(200, "PR007", "/document-category", "documentCategory", null);
      return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }
    responseDTO = ResponseDTO.responseBuilder(200, "PR004", "/document-category", "documentCategory", documentCategoryTO);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/delete", method = RequestMethod.DELETE, name = "Document Category Master Delete->DCMCR")
  public ResponseEntity<?> deleteDocumentCategory(@RequestParam(name = "documentCategoryId") List<Long> documentCategoryId) {
    documentCategoryService.deleteDocumentCategory(documentCategoryId);
    responseDTO = ResponseDTO.responseBuilder(200, "PR005", "/document-category", "documentCategory", documentCategoryId);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }
}
