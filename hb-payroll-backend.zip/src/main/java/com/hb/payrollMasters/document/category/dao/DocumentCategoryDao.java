package com.hb.payrollMasters.document.category.dao;

import com.hb.common.PaginationCriteria;
import com.hb.master.dto.CommonListTO;
import com.hb.payrollMasters.document.category.entity.DocumentCategoryBO;

import java.util.List;

public interface DocumentCategoryDao {

  DocumentCategoryBO addDocumentCategory(DocumentCategoryBO documentCategoryTO);

  DocumentCategoryBO updateDocumentCategory(DocumentCategoryBO documentCategoryTO);

  CommonListTO<DocumentCategoryBO> getDocumentCategoryList(PaginationCriteria paginationCriteria);

  DocumentCategoryBO getDocumentCategoryById(Long id);

  DocumentCategoryBO getDocumentCategoryByCode(String code);

  void deleteDocumentCategory(List<Long> id);
}
