package com.hb.payrollMasters.document.category.dto;

import com.hb.common.AuditTO;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DocumentCategoryTO extends AuditTO {

  private Long id;
  private String name;
  private String code;
  private boolean deleteFlag;

}
