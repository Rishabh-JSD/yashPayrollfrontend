package com.hb.payrollMasters.document.category.entity;

import com.hb.common.Audit;
import com.hb.common.TABLES;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = TABLES.DOCUMENT_CATEGORY_MASTER)
public class DocumentCategoryBO extends Audit {

  private static final long serialVersionUID = -7409716245511002445L;

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "id", updatable = false)
  private Long id;

  @Column(name = "name")
  private String name;

  @Column(name = "code")
  private String code;

  @Column(name = "delete_flag")
  private boolean deleteFlag;

}
