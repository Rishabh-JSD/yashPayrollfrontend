package com.hb.payrollMasters.document.category.service;

import com.hb.common.PaginationCriteria;
import com.hb.common.SearchResponseTO;
import com.hb.payrollMasters.document.category.dto.DocumentCategoryTO;

import java.util.List;

public interface DocumentCategoryService {

  DocumentCategoryTO addDocumentCategory(DocumentCategoryTO documentCategoryTO);

  DocumentCategoryTO updateDocumentCategory(DocumentCategoryTO documentCategoryTO);

  SearchResponseTO getDocumentCategoryList(PaginationCriteria paginationCriteria);

  DocumentCategoryTO getDocumentCategoryById(Long id);

  DocumentCategoryTO getDocumentCategoryByCode(String code);

  void deleteDocumentCategory(List<Long> documentCategoryId);

}
