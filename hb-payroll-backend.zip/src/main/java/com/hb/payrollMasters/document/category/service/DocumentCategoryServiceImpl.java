package com.hb.payrollMasters.document.category.service;

import com.hb.common.MapperService;
import com.hb.common.PaginationCriteria;
import com.hb.common.SearchResponseTO;
import com.hb.master.dto.CommonListTO;
import com.hb.master.service.UserService;
import com.hb.payrollMasters.document.category.dao.DocumentCategoryDao;
import com.hb.payrollMasters.document.category.dto.DocumentCategoryTO;
import com.hb.payrollMasters.document.category.entity.DocumentCategoryBO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;

@Service
@Transactional
public class DocumentCategoryServiceImpl implements DocumentCategoryService{

  @Autowired
  private DocumentCategoryDao documentCategoryDao;

  @Autowired
  private MapperService mapperService;

  @Autowired
  private UserService userService;

  @Override
  public DocumentCategoryTO addDocumentCategory(DocumentCategoryTO documentCategoryTO) {
    documentCategoryTO.setCode(documentCategoryTO.getName().toLowerCase().replace(" ", "_"));
    DocumentCategoryBO documentCategoryBO = mapperService.map(documentCategoryTO, DocumentCategoryBO.class);
    return mapperService.map(documentCategoryDao.addDocumentCategory(documentCategoryBO), DocumentCategoryTO.class);
  }

  @Override
  public DocumentCategoryTO updateDocumentCategory(DocumentCategoryTO documentCategoryTO) {
    documentCategoryTO.setCode(documentCategoryTO.getName().toLowerCase().replace(" ", "_"));
    DocumentCategoryBO documentCategoryBO = mapperService.map(documentCategoryTO, DocumentCategoryBO.class);
    return mapperService.map(documentCategoryDao.updateDocumentCategory(documentCategoryBO), DocumentCategoryTO.class);
  }

  @Override
  @Transactional(Transactional.TxType.NOT_SUPPORTED)
  public SearchResponseTO getDocumentCategoryList(PaginationCriteria paginationCriteria) {
    SearchResponseTO searchResponseTO = new SearchResponseTO();
    CommonListTO<DocumentCategoryBO> commonListTO = documentCategoryDao.getDocumentCategoryList(paginationCriteria);

    List<DocumentCategoryTO> documentCategoryTOS = null;
    if (commonListTO.getDataList() != null && !commonListTO.getDataList().isEmpty()) {
      documentCategoryTOS = new ArrayList<>();
      for (DocumentCategoryBO documentCategoryBO : commonListTO.getDataList()) {
        DocumentCategoryTO documentCategoryTO = mapperService.map(documentCategoryBO, DocumentCategoryTO.class);
        if (documentCategoryTO.getCreatedBy() != null) {
          documentCategoryTO.setCreatedByName(userService.getUserById(documentCategoryTO.getCreatedBy()).getName());
        }
        if (documentCategoryTO.getUpdatedBy() != null) {
          documentCategoryTO.setUpdatedByName(userService.getUserById(documentCategoryTO.getUpdatedBy()).getName());
        }
        documentCategoryTOS.add(documentCategoryTO);
      }
    }
    searchResponseTO.setList(documentCategoryTOS);
    searchResponseTO.setPageCount(commonListTO.getPageCount());
    searchResponseTO.setTotalRowCount(commonListTO.getTotalRow().intValue());
    return searchResponseTO;
  }

  @Override
  @Transactional(Transactional.TxType.NOT_SUPPORTED)
  public DocumentCategoryTO getDocumentCategoryById(Long id) {
    return mapperService.map(documentCategoryDao.getDocumentCategoryById(id), DocumentCategoryTO.class);
  }

  @Override
  @Transactional(Transactional.TxType.NOT_SUPPORTED)
  public DocumentCategoryTO getDocumentCategoryByCode(String code) {
    return mapperService.map(documentCategoryDao.getDocumentCategoryByCode(code), DocumentCategoryTO.class);
  }

  @Override
  public void deleteDocumentCategory(List<Long> documentCategoryId) {
    documentCategoryDao.deleteDocumentCategory(documentCategoryId);
  }
}
