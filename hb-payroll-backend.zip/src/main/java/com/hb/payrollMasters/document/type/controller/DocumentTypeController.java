package com.hb.payrollMasters.document.type.controller;

import com.hb.common.PaginationCriteria;
import com.hb.common.ResponseDTO;
import com.hb.common.SearchResponseTO;
import com.hb.common.ValidationError;
import com.hb.payrollMasters.document.type.dto.DocumentTypeTO;
import com.hb.payrollMasters.document.type.service.DocumentTypeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/document-type")
public class DocumentTypeController {

  @Autowired
  private Validator documentTypeValidator;

  @Autowired
  private DocumentTypeService documentTypeService;

  private ResponseDTO responseDTO;

  @InitBinder
  private void initBinder(WebDataBinder binder) {
    binder.setValidator(documentTypeValidator);
  }

  @RequestMapping(value = "/add", method = RequestMethod.POST, name = "Document Type Master Add->DTMCR")
  public ResponseEntity<?> addDocumentType(@Valid @RequestBody DocumentTypeTO documentTypeTO, Errors errors) {
    if (errors.hasErrors()) {
      ValidationError validationError = ValidationError.fromBindingErrors(errors);
      return new ResponseEntity<>(validationError, HttpStatus.OK);
    }
    DocumentTypeTO documentTypeTO_return = documentTypeService.addDocumentType(documentTypeTO);
    responseDTO = ResponseDTO.responseBuilder(200, "PR001", "/document-type", "documentType", documentTypeTO_return);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/update", method = RequestMethod.POST, name = "Document Type Master Update->DTMCR")
  public ResponseEntity<?> updateDocumentType(@Valid @RequestBody DocumentTypeTO documentTypeTO, Errors errors) {
    if (errors.hasErrors()) {
      ValidationError validationError = ValidationError.fromBindingErrors(errors);
      return new ResponseEntity<>(validationError, HttpStatus.OK);
    }
    DocumentTypeTO documentTypeTO_return = documentTypeService.updateDocumentType(documentTypeTO);
    responseDTO = ResponseDTO.responseBuilder(200, "PR002", "/document-type", "documentType", documentTypeTO_return);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/list", method = RequestMethod.POST, name = "Document Type Master List->DTMCR")
  public ResponseEntity<?> getDocumentTypeList(@RequestBody PaginationCriteria paginationCriteria) {
    SearchResponseTO searchResponseTO = documentTypeService.getDocumentTypeList(paginationCriteria);
    if (searchResponseTO.getList() == null || searchResponseTO.getList().isEmpty()) {
      responseDTO = ResponseDTO.responseBuilder(200, "PR006", "/document-type", "documentType", searchResponseTO);
      return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }
    responseDTO = ResponseDTO.responseBuilder(200, "PR003", "/document-type", "documentType", searchResponseTO);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/{id}", method = RequestMethod.GET, name = "Document Type Master View->DTMCR")
  public ResponseEntity<?> getDocumentTypeById(@PathVariable Long id) {
    DocumentTypeTO documentTypeTO = documentTypeService.getDocumentTypeById(id);
    if (documentTypeTO == null) {
      responseDTO = ResponseDTO.responseBuilder(200, "PR007", "/document-type", "documentType", null);
      return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }
    responseDTO = ResponseDTO.responseBuilder(200, "PR004", "/document-type", "documentType", documentTypeTO);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/category/{code}", method = RequestMethod.GET, name = "Document Type Master View->DTMCR")
  public ResponseEntity<?> getDocumentTypeByDocumentCategoryCode(@PathVariable String code) {
    List<DocumentTypeTO> documentTypeTOS = documentTypeService.getDocumentTypeByDocumentCategoryCode(code);
    if (documentTypeTOS == null || documentTypeTOS.isEmpty()) {
      responseDTO = ResponseDTO.responseBuilder(200, "PR006", "/document-type", "documentType", documentTypeTOS);
      return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }
    responseDTO = ResponseDTO.responseBuilder(200, "PR003", "/document-type", "documentType", documentTypeTOS);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/delete", method = RequestMethod.DELETE, name = "Document Type Master Delete->DTMCR")
  public ResponseEntity<?> deleteDocumentType(@RequestParam(name = "documentTypeId") List<Long> documentTypeId) {
    documentTypeService.deleteDocumentType(documentTypeId);
    responseDTO = ResponseDTO.responseBuilder(200, "PR005", "/document-type", "documentType", documentTypeId);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }
}
