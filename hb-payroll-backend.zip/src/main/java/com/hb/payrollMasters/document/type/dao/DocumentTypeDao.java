package com.hb.payrollMasters.document.type.dao;

import com.hb.common.PaginationCriteria;
import com.hb.master.dto.CommonListTO;
import com.hb.payrollMasters.document.type.entity.DocumentTypeBO;

import java.util.List;

public interface DocumentTypeDao {

  DocumentTypeBO addDocumentType(DocumentTypeBO documentTypeTO);

  DocumentTypeBO updateDocumentType(DocumentTypeBO documentTypeTO);

  CommonListTO<DocumentTypeBO> getDocumentTypeList(PaginationCriteria paginationCriteria);

  DocumentTypeBO getDocumentTypeById(Long id);

  void deleteDocumentType(List<Long> id);

  List<DocumentTypeBO> getDocumentTypeByDocumentCategoryCode(String code);
}
