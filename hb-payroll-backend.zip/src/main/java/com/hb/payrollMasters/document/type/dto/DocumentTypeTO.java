package com.hb.payrollMasters.document.type.dto;

import com.hb.common.AuditTO;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DocumentTypeTO extends AuditTO {

  private Long id;
  private String documentCategoryCode;
  private String documentCategoryName;
  private String name;
  private boolean deleteFlag;

}
