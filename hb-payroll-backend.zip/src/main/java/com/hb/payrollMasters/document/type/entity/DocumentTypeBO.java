package com.hb.payrollMasters.document.type.entity;

import com.hb.common.Audit;
import com.hb.common.TABLES;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = TABLES.DOCUMENT_TYPE_MASTER)
public class DocumentTypeBO extends Audit {

  private static final long serialVersionUID = 8997069568047857398L;

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "id", updatable = false)
  private Long id;

  @Column(name = "document_category_code")
  private String documentCategoryCode;

  @Column(name = "name")
  private String name;

  @Column(name = "delete_flag")
  private boolean deleteFlag;

}
