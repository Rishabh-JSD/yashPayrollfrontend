package com.hb.payrollMasters.document.type.service;

import com.hb.common.PaginationCriteria;
import com.hb.common.SearchResponseTO;
import com.hb.payrollMasters.document.type.dto.DocumentTypeTO;

import java.util.List;

public interface DocumentTypeService {

  DocumentTypeTO addDocumentType(DocumentTypeTO documentTypeTO);

  DocumentTypeTO updateDocumentType(DocumentTypeTO documentTypeTO);

  SearchResponseTO getDocumentTypeList(PaginationCriteria paginationCriteria);

  DocumentTypeTO getDocumentTypeById(Long id);

  List<DocumentTypeTO> getDocumentTypeByDocumentCategoryCode(String code);

  void deleteDocumentType(List<Long> documentTypeId);
}
