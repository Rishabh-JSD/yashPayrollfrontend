package com.hb.payrollMasters.document.type.service;

import com.hb.common.MapperService;
import com.hb.common.PaginationCriteria;
import com.hb.common.SearchResponseTO;
import com.hb.master.dto.CommonListTO;
import com.hb.master.service.UserService;
import com.hb.payrollMasters.document.category.service.DocumentCategoryService;
import com.hb.payrollMasters.document.type.dao.DocumentTypeDao;
import com.hb.payrollMasters.document.type.dto.DocumentTypeTO;
import com.hb.payrollMasters.document.type.entity.DocumentTypeBO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;

@Service
@Transactional
public class DocumentTypeServiceImpl implements DocumentTypeService {

  @Autowired
  private DocumentTypeDao documentTypeDao;

  @Autowired
  private DocumentCategoryService documentCategoryService;

  @Autowired
  private MapperService mapperService;

  @Autowired
  private UserService userService;

  @Override
  public DocumentTypeTO addDocumentType(DocumentTypeTO documentTypeTO) {
    DocumentTypeBO documentTypeBO = mapperService.map(documentTypeTO, DocumentTypeBO.class);
    return mapperService.map(documentTypeDao.addDocumentType(documentTypeBO), DocumentTypeTO.class);
  }

  @Override
  public DocumentTypeTO updateDocumentType(DocumentTypeTO documentTypeTO) {
    DocumentTypeBO documentTypeBO = mapperService.map(documentTypeTO, DocumentTypeBO.class);
    return mapperService.map(documentTypeDao.updateDocumentType(documentTypeBO), DocumentTypeTO.class);
  }

  @Override
  @Transactional(Transactional.TxType.NOT_SUPPORTED)
  public SearchResponseTO getDocumentTypeList(PaginationCriteria paginationCriteria) {
    SearchResponseTO searchResponseTO = new SearchResponseTO();
    CommonListTO<DocumentTypeBO> commonListTO = documentTypeDao.getDocumentTypeList(paginationCriteria);

    List<DocumentTypeTO> documentTypeTOS = null;
    if (commonListTO.getDataList() != null && !commonListTO.getDataList().isEmpty()) {
      documentTypeTOS = new ArrayList<>();
      for (DocumentTypeBO documentTypeBO : commonListTO.getDataList()) {
        DocumentTypeTO documentTypeTO = mapperService.map(documentTypeBO, DocumentTypeTO.class);
        if (documentTypeTO.getDocumentCategoryCode() != null) {
          documentTypeTO.setDocumentCategoryName(documentCategoryService
                  .getDocumentCategoryByCode(documentTypeTO.getDocumentCategoryCode()).getName());
        }
        if (documentTypeTO.getCreatedBy() != null) {
          documentTypeTO.setCreatedByName(userService.getUserById(documentTypeTO.getCreatedBy()).getName());
        }
        if (documentTypeTO.getUpdatedBy() != null) {
          documentTypeTO.setUpdatedByName(userService.getUserById(documentTypeTO.getUpdatedBy()).getName());
        }
        documentTypeTOS.add(documentTypeTO);
      }
    }
    searchResponseTO.setList(documentTypeTOS);
    searchResponseTO.setPageCount(commonListTO.getPageCount());
    searchResponseTO.setTotalRowCount(commonListTO.getTotalRow().intValue());
    return searchResponseTO;
  }

  @Override
  @Transactional(Transactional.TxType.NOT_SUPPORTED)
  public DocumentTypeTO getDocumentTypeById(Long id) {
    return mapperService.map(documentTypeDao.getDocumentTypeById(id), DocumentTypeTO.class);
  }

  @Override
  @Transactional(Transactional.TxType.NOT_SUPPORTED)
  public List<DocumentTypeTO> getDocumentTypeByDocumentCategoryCode(String code) {
    return mapperService.map(documentTypeDao.getDocumentTypeByDocumentCategoryCode(code), DocumentTypeTO.class);
  }

  @Override
  public void deleteDocumentType(List<Long> id) {
    documentTypeDao.deleteDocumentType(id);
  }
}
