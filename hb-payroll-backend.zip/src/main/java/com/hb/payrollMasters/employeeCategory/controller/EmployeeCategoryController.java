package com.hb.payrollMasters.employeeCategory.controller;

import com.hb.common.PaginationCriteria;
import com.hb.common.ResponseDTO;
import com.hb.common.SearchResponseTO;
import com.hb.common.ValidationError;
import com.hb.payrollMasters.employeeCategory.dto.EmployeeCategoryTO;
import com.hb.payrollMasters.employeeCategory.service.EmployeeCategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/employee-category")
public class EmployeeCategoryController {

  @Autowired
  private Validator employeeCategoryValidator;

  @Autowired
  private EmployeeCategoryService employeeCategoryService;

  private ResponseDTO responseDTO;

  @InitBinder
  private void initBinder(WebDataBinder binder) {
    binder.setValidator(employeeCategoryValidator);
  }

  @RequestMapping(value = "/add", method = RequestMethod.POST, name = "EmployeeCategory Master Add->ECMCR")
  public ResponseEntity<?> addEmployeeCategory(@Valid @RequestBody EmployeeCategoryTO employeeCategoryTO, Errors errors) {
    if (errors.hasErrors()) {
      ValidationError validationError = ValidationError.fromBindingErrors(errors);
      return new ResponseEntity<>(validationError, HttpStatus.OK);
    }
    EmployeeCategoryTO employeeCategoryTO_return = employeeCategoryService.addEmployeeCategory(employeeCategoryTO);
    responseDTO = ResponseDTO.responseBuilder(200, "PR001", "/employee-category", "employeeCategory", employeeCategoryTO_return);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/update", method = RequestMethod.POST, name = "EmployeeCategory Master Update->ECMCR")
  public ResponseEntity<?> updateEmployeeCategory(@Valid @RequestBody EmployeeCategoryTO employeeCategoryTO, Errors errors) {
    if (errors.hasErrors()) {
      ValidationError validationError = ValidationError.fromBindingErrors(errors);
      return new ResponseEntity<>(validationError, HttpStatus.OK);
    }
    EmployeeCategoryTO employeeCategoryTO_return = employeeCategoryService.updateEmployeeCategory(employeeCategoryTO);
    responseDTO = ResponseDTO.responseBuilder(200, "PR002", "/employee-category", "employeeCategory", employeeCategoryTO_return);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/list", method = RequestMethod.POST, name = "EmployeeCategory Master List->ECMCR")
  public ResponseEntity<?> getEmployeeCategoryList(@RequestBody PaginationCriteria paginationCriteria) {
    SearchResponseTO searchResponseTO = employeeCategoryService.getEmployeeCategoryList(paginationCriteria);
    if (searchResponseTO.getList() == null || searchResponseTO.getList().isEmpty()) {
      responseDTO = ResponseDTO.responseBuilder(200, "PR006", "/employee-category", "employeeCategory", searchResponseTO);
      return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }
    responseDTO = ResponseDTO.responseBuilder(200, "PR003", "/employee-category", "employeeCategory", searchResponseTO);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/{id}", method = RequestMethod.GET, name = "EmployeeCategory Master View->ECMCR")
  public ResponseEntity<?> getEmployeeCategoryById(@PathVariable Long id) {
    EmployeeCategoryTO employeeCategoryTO = employeeCategoryService.getEmployeeCategoryById(id);
    if (employeeCategoryTO == null) {
      responseDTO = ResponseDTO.responseBuilder(200, "PR007", "/employee-category", "employeeCategory", null);
      return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }
    responseDTO = ResponseDTO.responseBuilder(200, "PR004", "/employee-category", "employeeCategory", employeeCategoryTO);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/delete", method = RequestMethod.DELETE, name = "EmployeeCategory Master Delete->ECMCR")
  public ResponseEntity<?> deleteEmployeeCategory(@RequestParam(name = "employeeCategoryId") List<Long> employeeCategoryId) {
    employeeCategoryService.deleteEmployeeCategory(employeeCategoryId);
    responseDTO = ResponseDTO.responseBuilder(200, "PR005", "/employee-category", "employeeCategory", employeeCategoryId);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }
}
