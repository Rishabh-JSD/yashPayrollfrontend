package com.hb.payrollMasters.employeeCategory.dao;

import com.hb.common.PaginationCriteria;
import com.hb.master.dto.CommonListTO;
import com.hb.payrollMasters.employeeCategory.entity.EmployeeCategoryBO;

import java.util.List;

public interface EmployeeCategoryDao {

  EmployeeCategoryBO addEmployeeCategory(EmployeeCategoryBO employeeCategoryTO);

  EmployeeCategoryBO updateEmployeeCategory(EmployeeCategoryBO employeeCategoryTO);

  CommonListTO<EmployeeCategoryBO> getEmployeeCategoryList(PaginationCriteria paginationCriteria);

  EmployeeCategoryBO getEmployeeCategoryById(Long id);

  void deleteEmployeeCategory(List<Long> id);

}
