package com.hb.payrollMasters.employeeCategory.dao;

import com.hb.common.PaginationCriteria;
import com.hb.master.dto.CommonListTO;
import com.hb.payrollMasters.employeeCategory.entity.EmployeeCategoryBO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.*;
import java.util.List;

@Repository
public class EmployeeCategoryDaoImpl implements EmployeeCategoryDao {

  @PersistenceContext
  private EntityManager entityManager;

  private static final Logger logger = LoggerFactory.getLogger(EmployeeCategoryDaoImpl.class);

  @Override
  public EmployeeCategoryBO addEmployeeCategory(EmployeeCategoryBO employeeCategoryBO) {
    entityManager.persist(employeeCategoryBO);
    logger.info("EmployeeCategory has added successfully, EmployeeCategory details=" + employeeCategoryBO);
    return employeeCategoryBO;
  }

  @Override
  public EmployeeCategoryBO updateEmployeeCategory(EmployeeCategoryBO employeeCategoryBO) {
    entityManager.merge(employeeCategoryBO);
    logger.info("EmployeeCategory has updated successfully, EmployeeCategory details=" + employeeCategoryBO);
    return employeeCategoryBO;
  }

  @Override
  public CommonListTO<EmployeeCategoryBO> getEmployeeCategoryList(PaginationCriteria paginationCriteria) {
    CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
    CriteriaQuery<EmployeeCategoryBO> criteriaQuery = criteriaBuilder.createQuery(EmployeeCategoryBO.class);
    Root<EmployeeCategoryBO> root = criteriaQuery.from(EmployeeCategoryBO.class);
    criteriaQuery.where(criteriaBuilder.equal(root.get("deleteFlag"), false));

    //condition for search
    if (paginationCriteria.getSearchFor() != null && !paginationCriteria.getSearchFor().isEmpty() ) {
      Path<String> pathName = root.get("name");
      Predicate predicateForName = criteriaBuilder.like(pathName, "%" + paginationCriteria.getSearchFor() + "%");
      // Assuming "deleteFlag" is the field representing the deletion status
      Path<Boolean> pathDeleteFlag = root.get("deleteFlag");
      Predicate predicateNotDeleted = criteriaBuilder.isFalse(pathDeleteFlag);
      criteriaQuery.where(criteriaBuilder.and(predicateForName, predicateNotDeleted));
    }

    // Condition for sorting.
    if (paginationCriteria.getSortField() != null && !paginationCriteria.getSortField().isEmpty()) {
      Order order;
      if (paginationCriteria.getSortType() == 2) {
        order = criteriaBuilder.desc(root.get(paginationCriteria.getSortField()));
      } else {
        order = criteriaBuilder.asc(root.get(paginationCriteria.getSortField()));
      }
      criteriaQuery.orderBy(order);
    } else {
      Order order = criteriaBuilder.desc(root.get("id"));
      criteriaQuery.orderBy(order);
    }

    // Adding Pagination total Count
    CommonListTO<EmployeeCategoryBO> commonListTO = new CommonListTO<>();
    CriteriaQuery<Long> criteriaQuery2 = criteriaBuilder.createQuery(Long.class);
    Root<EmployeeCategoryBO> root2 = criteriaQuery2.from(EmployeeCategoryBO.class);
    criteriaQuery2.where(criteriaBuilder.equal(root2.get("deleteFlag"), false));
    CriteriaQuery<Long> select = criteriaQuery2.select(criteriaBuilder.count(root2));
    Long count = entityManager.createQuery(select).getSingleResult();
    commonListTO.setTotalRow(count);
    int size = count.intValue();
    int limit = paginationCriteria.getLimit();
    if (limit != 0) {
      commonListTO.setPageCount((size + limit - 1) / limit);
    } else {
      commonListTO.setPageCount(1);
    }

    TypedQuery<EmployeeCategoryBO> typedQuery = entityManager.createQuery(criteriaQuery);
    // Condition for paging.
    if (paginationCriteria.getPage() != 0 && paginationCriteria.getLimit() > 0) {
      typedQuery.setFirstResult((paginationCriteria.getPage() - 1) * paginationCriteria.getLimit());
      typedQuery.setMaxResults(paginationCriteria.getLimit());
    }
    commonListTO.setDataList(typedQuery.getResultList());
    return commonListTO;
  }

  @Override
  public EmployeeCategoryBO getEmployeeCategoryById(Long id) {
    CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
    CriteriaQuery<EmployeeCategoryBO> criteriaQuery = criteriaBuilder.createQuery(EmployeeCategoryBO.class);

    Root<EmployeeCategoryBO> root = criteriaQuery.from(EmployeeCategoryBO.class);
    Predicate predicateForId = criteriaBuilder.equal(root.get("id"), id);
    Predicate predicateForDeleteFlag = criteriaBuilder.equal(root.get("deleteFlag"), false);
    Predicate predicate = criteriaBuilder.and(predicateForId, predicateForDeleteFlag);
    criteriaQuery.where(predicate);
    return entityManager.createQuery(criteriaQuery).getSingleResult();
  }

  @Override
  public void deleteEmployeeCategory(List<Long> id) {
    CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
    CriteriaUpdate<EmployeeCategoryBO> criteriaUpdate = criteriaBuilder.createCriteriaUpdate(EmployeeCategoryBO.class);
    Root<EmployeeCategoryBO> root = criteriaUpdate.from(EmployeeCategoryBO.class);
    criteriaUpdate.set("deleteFlag", true);
    criteriaUpdate.where(root.get("id").in(id));
    entityManager.createQuery(criteriaUpdate).executeUpdate();
  }
}
