package com.hb.payrollMasters.employeeCategory.dto;

import com.hb.common.AuditTO;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EmployeeCategoryTO extends AuditTO {

  private Long id;
  private String name;
  private boolean preDefinedFlag;
  private boolean deleteFlag;
}
