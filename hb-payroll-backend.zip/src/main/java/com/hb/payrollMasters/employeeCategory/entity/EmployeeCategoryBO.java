package com.hb.payrollMasters.employeeCategory.entity;

import com.hb.common.Audit;
import com.hb.common.TABLES;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = TABLES.EMPLOYEE_CATEGORY)
public class EmployeeCategoryBO extends Audit {

  private static final long serialVersionUID = -3763870634671777505L;

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "id", updatable = false)
  private Long id;

  @Column(name = "name")
  private String name;

  @Column(name = "pre_defined_flag")
  private boolean preDefinedFlag;

  @Column(name = "delete_flag")
  private boolean deleteFlag;
}
