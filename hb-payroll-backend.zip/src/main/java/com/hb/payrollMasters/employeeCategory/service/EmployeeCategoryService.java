package com.hb.payrollMasters.employeeCategory.service;

import com.hb.common.PaginationCriteria;
import com.hb.common.SearchResponseTO;
import com.hb.payrollMasters.employeeCategory.dto.EmployeeCategoryTO;

import java.util.List;

public interface EmployeeCategoryService {

  EmployeeCategoryTO addEmployeeCategory(EmployeeCategoryTO employeeCategoryTO);

  EmployeeCategoryTO updateEmployeeCategory(EmployeeCategoryTO employeeCategoryTO);

  SearchResponseTO getEmployeeCategoryList(PaginationCriteria paginationCriteria);

  EmployeeCategoryTO getEmployeeCategoryById(Long id);

  void deleteEmployeeCategory(List<Long> employeeCategoryId);
}
