package com.hb.payrollMasters.employeeCategory.service;

import com.hb.common.MapperService;
import com.hb.common.PaginationCriteria;
import com.hb.common.SearchResponseTO;
import com.hb.master.dto.CommonListTO;
import com.hb.master.service.UserService;
import com.hb.payrollMasters.employeeCategory.dao.EmployeeCategoryDao;
import com.hb.payrollMasters.employeeCategory.dto.EmployeeCategoryTO;
import com.hb.payrollMasters.employeeCategory.entity.EmployeeCategoryBO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;

@Service
@Transactional
public class EmployeeCategoryServiceImpl implements EmployeeCategoryService {

  @Autowired
  private EmployeeCategoryDao employeeCategoryDao;

  @Autowired
  private MapperService mapperService;

  @Autowired
  private UserService userService;

  @Override
  public EmployeeCategoryTO addEmployeeCategory(EmployeeCategoryTO employeeCategoryTO) {
    EmployeeCategoryBO employeeCategoryBO = mapperService.map(employeeCategoryTO, EmployeeCategoryBO.class);
    return mapperService.map(employeeCategoryDao.addEmployeeCategory(employeeCategoryBO), EmployeeCategoryTO.class);
  }

  @Override
  public EmployeeCategoryTO updateEmployeeCategory(EmployeeCategoryTO employeeCategoryTO) {
    EmployeeCategoryBO employeeCategoryBO = mapperService.map(employeeCategoryTO, EmployeeCategoryBO.class);
    return mapperService.map(employeeCategoryDao.updateEmployeeCategory(employeeCategoryBO), EmployeeCategoryTO.class);
  }

  @Override
  @Transactional(Transactional.TxType.NOT_SUPPORTED)
  public SearchResponseTO getEmployeeCategoryList(PaginationCriteria paginationCriteria) {
    SearchResponseTO searchResponseTO = new SearchResponseTO();
    CommonListTO<EmployeeCategoryBO> commonListTO = employeeCategoryDao.getEmployeeCategoryList(paginationCriteria);

    List<EmployeeCategoryTO> employeeCategoryTOS = null;
    if (commonListTO.getDataList() != null && !commonListTO.getDataList().isEmpty()) {
      employeeCategoryTOS = new ArrayList<>();
      for (EmployeeCategoryBO employeeCategoryBO : commonListTO.getDataList()) {
        EmployeeCategoryTO employeeCategoryTO = mapperService.map(employeeCategoryBO, EmployeeCategoryTO.class);
        if (employeeCategoryTO.getCreatedBy() != null) {
          employeeCategoryTO.setCreatedByName(userService.getUserById(employeeCategoryTO.getCreatedBy()).getName());
        }
        if (employeeCategoryTO.getUpdatedBy() != null) {
          employeeCategoryTO.setUpdatedByName(userService.getUserById(employeeCategoryTO.getUpdatedBy()).getName());
        }
        employeeCategoryTOS.add(employeeCategoryTO);
      }
    }
    searchResponseTO.setList(employeeCategoryTOS);
    searchResponseTO.setPageCount(commonListTO.getPageCount());
    searchResponseTO.setTotalRowCount(commonListTO.getTotalRow().intValue());
    return searchResponseTO;
  }

  @Override
  @Transactional(Transactional.TxType.NOT_SUPPORTED)
  public EmployeeCategoryTO getEmployeeCategoryById(Long id) {
    return mapperService.map(employeeCategoryDao.getEmployeeCategoryById(id), EmployeeCategoryTO.class);
  }

  @Override
  public void deleteEmployeeCategory(List<Long> id) {
    employeeCategoryDao.deleteEmployeeCategory(id);
  }
}
