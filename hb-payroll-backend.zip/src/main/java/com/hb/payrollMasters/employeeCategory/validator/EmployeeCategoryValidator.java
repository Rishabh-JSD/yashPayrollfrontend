package com.hb.payrollMasters.employeeCategory.validator;

import com.hb.common.PaginationCriteria;
import com.hb.payrollMasters.employeeCategory.controller.EmployeeCategoryController;
import com.hb.payrollMasters.employeeCategory.dto.EmployeeCategoryTO;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.ControllerAdvice;

@ControllerAdvice(assignableTypes = EmployeeCategoryController.class)
public class EmployeeCategoryValidator implements Validator {

  @Override
  public boolean supports(Class<?> aClass) {
    boolean support = EmployeeCategoryTO.class.equals(aClass);
    if (!support) {
      support = PaginationCriteria.class.equals(aClass);
    }
    return support;
  }

  @Override
  public void validate(Object o, Errors errors) {
    EmployeeCategoryTO employeeCategoryTO = (EmployeeCategoryTO) o;

//    ValidationUtils.rejectIfEmptyOrWhitespace(errors, "name", "PMS001E", APP_MSG.MESSAGE.get("PR001E"));

  }
}
