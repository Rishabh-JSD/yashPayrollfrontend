package com.hb.payrollMasters.employeeLevel.controller;

import com.hb.common.PaginationCriteria;
import com.hb.common.ResponseDTO;
import com.hb.common.SearchResponseTO;
import com.hb.common.ValidationError;
import com.hb.payrollMasters.employeeLevel.dto.EmployeeLevelTO;
import com.hb.payrollMasters.employeeLevel.service.EmployeeLevelService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/employee-level")
public class EmployeeLevelController {

  @Autowired
  private Validator employeeLevelValidator;

  @Autowired
  private EmployeeLevelService employeeLevelService;

  private ResponseDTO responseDTO;

  @InitBinder
  private void initBinder(WebDataBinder binder) {
    binder.setValidator(employeeLevelValidator);
  }

  @RequestMapping(value = "/add", method = RequestMethod.POST, name = "Employee Level Master Add->ELMCR")
  public ResponseEntity<?> addEmployeeLevel(@Valid @RequestBody EmployeeLevelTO employeeLevelTO, Errors errors) {
    if (errors.hasErrors()) {
      ValidationError validationError = ValidationError.fromBindingErrors(errors);
      return new ResponseEntity<>(validationError, HttpStatus.OK);
    }
    EmployeeLevelTO employeeLevelTO_return = employeeLevelService.addEmployeeLevel(employeeLevelTO);
    responseDTO = ResponseDTO.responseBuilder(200, "PR001", "/employee-level", "employeeLevel", employeeLevelTO_return);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/update", method = RequestMethod.POST, name = "Employee Level Master Update->ELMCR")
  public ResponseEntity<?> updateEmployeeLevel(@Valid @RequestBody EmployeeLevelTO employeeLevelTO, Errors errors) {
    if (errors.hasErrors()) {
      ValidationError validationError = ValidationError.fromBindingErrors(errors);
      return new ResponseEntity<>(validationError, HttpStatus.OK);
    }
    EmployeeLevelTO employeeLevelTO_return = employeeLevelService.updateEmployeeLevel(employeeLevelTO);
    responseDTO = ResponseDTO.responseBuilder(200, "PR002", "/employee-level", "employeeLevel", employeeLevelTO_return);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/list", method = RequestMethod.POST, name = "Employee Level Master List->ELMCR")
  public ResponseEntity<?> getEmployeeLevelList(@RequestBody PaginationCriteria paginationCriteria) {
    SearchResponseTO searchResponseTO = employeeLevelService.getEmployeeLevelList(paginationCriteria);
    if (searchResponseTO.getList() == null || searchResponseTO.getList().isEmpty()) {
      responseDTO = ResponseDTO.responseBuilder(200, "PR006", "/employee-level", "employeeLevel", searchResponseTO);
      return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }
    responseDTO = ResponseDTO.responseBuilder(200, "PR003", "/employee-level", "employeeLevel", searchResponseTO);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/{id}", method = RequestMethod.GET, name = "Employee Level Master View->ELMCR")
  public ResponseEntity<?> getEmployeeLevelById(@PathVariable Long id) {
    EmployeeLevelTO employeeLevelTO = employeeLevelService.getEmployeeLevelById(id);
    if (employeeLevelTO == null) {
      responseDTO = ResponseDTO.responseBuilder(200, "PR007", "/employee-level", "employeeLevel", null);
      return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }
    responseDTO = ResponseDTO.responseBuilder(200, "PR004", "/employee-level", "employeeLevel", employeeLevelTO);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/delete", method = RequestMethod.DELETE, name = "Employee Level Master Delete->ELMCR")
  public ResponseEntity<?> deleteEmployeeLevel(@RequestParam(name = "employeeLevelId") List<Long> employeeLevelId) {
    employeeLevelService.deleteEmployeeLevel(employeeLevelId);
    responseDTO = ResponseDTO.responseBuilder(200, "PR005", "/employee-level", "employeeLevel", employeeLevelId);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }
}
