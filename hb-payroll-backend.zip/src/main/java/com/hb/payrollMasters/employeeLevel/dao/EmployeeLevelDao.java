package com.hb.payrollMasters.employeeLevel.dao;

import com.hb.common.PaginationCriteria;
import com.hb.master.dto.CommonListTO;
import com.hb.payrollMasters.employeeLevel.entity.EmployeeLevelBO;

import java.util.List;

public interface EmployeeLevelDao {

  EmployeeLevelBO addEmployeeLevel(EmployeeLevelBO employeeLevelTO);

  EmployeeLevelBO updateEmployeeLevel(EmployeeLevelBO employeeLevelTO);

  CommonListTO<EmployeeLevelBO> getEmployeeLevelList(PaginationCriteria paginationCriteria);

  EmployeeLevelBO getEmployeeLevelById(Long id);

  void deleteEmployeeLevel(List<Long> id);

}
