package com.hb.payrollMasters.employeeLevel.dao;

import com.hb.common.PaginationCriteria;
import com.hb.master.dto.CommonListTO;
import com.hb.payrollMasters.employeeLevel.entity.EmployeeLevelBO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.*;
import java.util.List;

@Repository
public class EmployeeLevelDaoImpl implements EmployeeLevelDao {

  @PersistenceContext
  private EntityManager entityManager;

  private static final Logger logger = LoggerFactory.getLogger(EmployeeLevelDaoImpl.class);

  @Override
  public EmployeeLevelBO addEmployeeLevel(EmployeeLevelBO employeeLevelBO) {
    entityManager.persist(employeeLevelBO);
    logger.info("Employee Level has added successfully, Employee Level details=" + employeeLevelBO);
    return employeeLevelBO;
  }

  @Override
  public EmployeeLevelBO updateEmployeeLevel(EmployeeLevelBO employeeLevelBO) {
    entityManager.merge(employeeLevelBO);
    logger.info("Employee Level has updated successfully, Employee Level details=" + employeeLevelBO);
    return employeeLevelBO;
  }

  @Override
  public CommonListTO<EmployeeLevelBO> getEmployeeLevelList(PaginationCriteria paginationCriteria) {
    CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
    CriteriaQuery<EmployeeLevelBO> criteriaQuery = criteriaBuilder.createQuery(EmployeeLevelBO.class);
    Root<EmployeeLevelBO> root = criteriaQuery.from(EmployeeLevelBO.class);
    criteriaQuery.where(criteriaBuilder.equal(root.get("deleteFlag"), false));

    //condition for search
    if (paginationCriteria.getSearchFor() != null && !paginationCriteria.getSearchFor().isEmpty()) {
      Path<String> pathName = root.get("name");
      Predicate predicateForName = criteriaBuilder.like(pathName, "%" + paginationCriteria.getSearchFor() + "%");
      // Assuming "deleteFlag" is the field representing the deletion status
      Path<Boolean> pathDeleteFlag = root.get("deleteFlag");
      Predicate predicateNotDeleted = criteriaBuilder.isFalse(pathDeleteFlag);
      criteriaQuery.where(criteriaBuilder.and(predicateForName, predicateNotDeleted));
    }

    // Condition for sorting.
    if (paginationCriteria.getSortField() != null && !paginationCriteria.getSortField().isEmpty()) {
      Order order = null;
      if (paginationCriteria.getSortType() == 2) {
        order = criteriaBuilder.desc(root.get(paginationCriteria.getSortField()));
      } else {
        order = criteriaBuilder.asc(root.get(paginationCriteria.getSortField()));
      }
      criteriaQuery.orderBy(order);
    } else {
      Order order = criteriaBuilder.desc(root.get("id"));
      criteriaQuery.orderBy(order);
    }

    // Adding Pagination total Count
    CommonListTO<EmployeeLevelBO> commonListTO = new CommonListTO<>();
    CriteriaQuery<Long> criteriaQuery2 = criteriaBuilder.createQuery(Long.class);
    Root<EmployeeLevelBO> root2 = criteriaQuery2.from(EmployeeLevelBO.class);
    criteriaQuery2.where(criteriaBuilder.equal(root2.get("deleteFlag"), false));
    CriteriaQuery<Long> select = criteriaQuery2.select(criteriaBuilder.count(root2));
    Long count = entityManager.createQuery(select).getSingleResult();
    commonListTO.setTotalRow(count);
    int size = count.intValue();
    int limit = paginationCriteria.getLimit();
    if (limit != 0) {
      commonListTO.setPageCount((size + limit - 1) / limit);
    } else {
      commonListTO.setPageCount(1);
    }

    TypedQuery<EmployeeLevelBO> typedQuery = entityManager.createQuery(criteriaQuery);
    // Condition for paging.
    if (paginationCriteria.getPage() != 0 && paginationCriteria.getLimit() > 0) {
      typedQuery.setFirstResult((paginationCriteria.getPage() - 1) * paginationCriteria.getLimit());
      typedQuery.setMaxResults(paginationCriteria.getLimit());
    }
    commonListTO.setDataList(typedQuery.getResultList());
    return commonListTO;
  }

  @Override
  public EmployeeLevelBO getEmployeeLevelById(Long id) {
    CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
    CriteriaQuery<EmployeeLevelBO> criteriaQuery = criteriaBuilder.createQuery(EmployeeLevelBO.class);

    Root<EmployeeLevelBO> root = criteriaQuery.from(EmployeeLevelBO.class);
    Predicate predicateForId = criteriaBuilder.equal(root.get("id"), id);
    Predicate predicateForDeleteFlag = criteriaBuilder.equal(root.get("deleteFlag"), false);
    Predicate predicate = criteriaBuilder.and(predicateForId, predicateForDeleteFlag);
    criteriaQuery.where(predicate);
    return entityManager.createQuery(criteriaQuery).getSingleResult();
  }

  @Override
  public void deleteEmployeeLevel(List<Long> id) {
    CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
    CriteriaUpdate<EmployeeLevelBO> criteriaUpdate = criteriaBuilder.createCriteriaUpdate(EmployeeLevelBO.class);
    Root<EmployeeLevelBO> root = criteriaUpdate.from(EmployeeLevelBO.class);
    criteriaUpdate.set("deleteFlag", true);
    criteriaUpdate.where(root.get("id").in(id));
    entityManager.createQuery(criteriaUpdate).executeUpdate();
  }
}
