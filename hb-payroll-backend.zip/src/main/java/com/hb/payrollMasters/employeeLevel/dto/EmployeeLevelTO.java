package com.hb.payrollMasters.employeeLevel.dto;

import com.hb.common.AuditTO;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EmployeeLevelTO extends AuditTO {

  private Long id;
  private String name;
  private int level;
  private boolean deleteFlag;

}
