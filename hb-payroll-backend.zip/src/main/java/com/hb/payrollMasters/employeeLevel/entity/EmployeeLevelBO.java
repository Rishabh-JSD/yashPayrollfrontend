package com.hb.payrollMasters.employeeLevel.entity;

import com.hb.common.Audit;
import com.hb.common.TABLES;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = TABLES.EMPLOYEE_LEVEL_MASTER)
public class EmployeeLevelBO extends Audit {

  private static final long serialVersionUID = 5921059843143441715L;

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "id", updatable = false)
  private Long id;

  @Column(name = "name")
  private String name;

  @Column(name = "level")
  private int level;

  @Column(name = "delete_flag")
  private boolean deleteFlag;

}
