package com.hb.payrollMasters.employeeLevel.service;

import com.hb.common.PaginationCriteria;
import com.hb.common.SearchResponseTO;
import com.hb.payrollMasters.employeeLevel.dto.EmployeeLevelTO;

import java.util.List;

public interface EmployeeLevelService {

  EmployeeLevelTO addEmployeeLevel(EmployeeLevelTO employeeLevelTO);

  EmployeeLevelTO updateEmployeeLevel(EmployeeLevelTO employeeLevelTO);

  SearchResponseTO getEmployeeLevelList(PaginationCriteria paginationCriteria);

  EmployeeLevelTO getEmployeeLevelById(Long id);

  void deleteEmployeeLevel(List<Long> employeeLevelId);
}
