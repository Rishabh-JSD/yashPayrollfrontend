package com.hb.payrollMasters.employeeLevel.service;

import com.hb.common.MapperService;
import com.hb.common.PaginationCriteria;
import com.hb.common.SearchResponseTO;
import com.hb.master.dto.CommonListTO;
import com.hb.master.service.UserService;
import com.hb.payrollMasters.employeeLevel.dao.EmployeeLevelDao;
import com.hb.payrollMasters.employeeLevel.dto.EmployeeLevelTO;
import com.hb.payrollMasters.employeeLevel.entity.EmployeeLevelBO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;

@Service
@Transactional
public class EmployeeLevelServiceImpl implements EmployeeLevelService {

  @Autowired
  private EmployeeLevelDao employeeLevelDao;

  @Autowired
  private MapperService mapperService;

  @Autowired
  private UserService userService;

  @Override
  public EmployeeLevelTO addEmployeeLevel(EmployeeLevelTO employeeLevelTO) {
    EmployeeLevelBO employeeLevelBO = mapperService.map(employeeLevelTO, EmployeeLevelBO.class);
    return mapperService.map(employeeLevelDao.addEmployeeLevel(employeeLevelBO), EmployeeLevelTO.class);
  }

  @Override
  public EmployeeLevelTO updateEmployeeLevel(EmployeeLevelTO employeeLevelTO) {
    EmployeeLevelBO employeeLevelBO = mapperService.map(employeeLevelTO, EmployeeLevelBO.class);
    return mapperService.map(employeeLevelDao.updateEmployeeLevel(employeeLevelBO), EmployeeLevelTO.class);
  }

  @Override
  @Transactional(Transactional.TxType.NOT_SUPPORTED)
  public SearchResponseTO getEmployeeLevelList(PaginationCriteria paginationCriteria) {
    SearchResponseTO searchResponseTO = new SearchResponseTO();
    CommonListTO<EmployeeLevelBO> commonListTO = employeeLevelDao.getEmployeeLevelList(paginationCriteria);


    List<EmployeeLevelTO> employeeLevelTOS = null;
    if (commonListTO.getDataList() != null && !commonListTO.getDataList().isEmpty()) {
      employeeLevelTOS = new ArrayList<>();
      for (EmployeeLevelBO employeeLevelBO : commonListTO.getDataList()) {
        EmployeeLevelTO employeeLevelTO = mapperService.map(employeeLevelBO, EmployeeLevelTO.class);
        if (employeeLevelTO.getCreatedBy() != null) {
          employeeLevelTO.setCreatedByName(userService.getUserById(employeeLevelTO.getCreatedBy()).getName());
        }
        if (employeeLevelTO.getUpdatedBy() != null) {
          employeeLevelTO.setUpdatedByName(userService.getUserById(employeeLevelTO.getUpdatedBy()).getName());
        }
        employeeLevelTOS.add(employeeLevelTO);
      }
    }
    searchResponseTO.setList(employeeLevelTOS);
    searchResponseTO.setPageCount(commonListTO.getPageCount());
    searchResponseTO.setTotalRowCount(commonListTO.getTotalRow().intValue());
    return searchResponseTO;
  }

  @Override
  @Transactional(Transactional.TxType.NOT_SUPPORTED)
  public EmployeeLevelTO getEmployeeLevelById(Long id) {
    return mapperService.map(employeeLevelDao.getEmployeeLevelById(id), EmployeeLevelTO.class);
  }

  @Override
  public void deleteEmployeeLevel(List<Long> id) {
    employeeLevelDao.deleteEmployeeLevel(id);
  }
}
