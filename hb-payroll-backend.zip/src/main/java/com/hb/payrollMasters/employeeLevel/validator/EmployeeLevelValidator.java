package com.hb.payrollMasters.employeeLevel.validator;

import com.hb.common.PaginationCriteria;
import com.hb.payrollMasters.employeeLevel.controller.EmployeeLevelController;
import com.hb.payrollMasters.employeeLevel.dto.EmployeeLevelTO;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.ControllerAdvice;

@ControllerAdvice(assignableTypes = EmployeeLevelController.class)
public class EmployeeLevelValidator implements Validator {

  @Override
  public boolean supports(Class<?> aClass) {
    boolean support = EmployeeLevelTO.class.equals(aClass);
    if (!support) {
      support = PaginationCriteria.class.equals(aClass);
    }
    return support;
  }

  @Override
  public void validate(Object o, Errors errors) {
    EmployeeLevelTO employeeLevelTO = (EmployeeLevelTO) o;

//    ValidationUtils.rejectIfEmptyOrWhitespace(errors, "name", "PMS001E", APP_MSG.MESSAGE.get("PR001E"));

  }
}
