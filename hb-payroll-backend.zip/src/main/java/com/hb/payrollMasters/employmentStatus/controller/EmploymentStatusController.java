package com.hb.payrollMasters.employmentStatus.controller;

import com.hb.common.PaginationCriteria;
import com.hb.common.ResponseDTO;
import com.hb.common.SearchResponseTO;
import com.hb.common.ValidationError;
import com.hb.payrollMasters.employmentStatus.dto.EmploymentStatusTO;
import com.hb.payrollMasters.employmentStatus.service.EmploymentStatusService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/employment-status")
public class EmploymentStatusController {

  @Autowired
  private Validator employmentStatusValidator;

  @Autowired
  private EmploymentStatusService employmentStatusService;

  private ResponseDTO responseDTO;

  @InitBinder
  private void initBinder(WebDataBinder binder) {
    binder.setValidator(employmentStatusValidator);
  }

  @RequestMapping(value = "/add", method = RequestMethod.POST, name = "Employment Status Master Add->ESMCR")
  public ResponseEntity<?> addEmploymentStatus(@Valid @RequestBody EmploymentStatusTO employmentStatusTO, Errors errors) {
    if (errors.hasErrors()) {
      ValidationError validationError = ValidationError.fromBindingErrors(errors);
      return new ResponseEntity<>(validationError, HttpStatus.OK);
    }
    EmploymentStatusTO employmentStatusTO_return = employmentStatusService.addEmploymentStatus(employmentStatusTO);
    responseDTO = ResponseDTO.responseBuilder(200, "PR001", "/employment-status", "employmentStatus", employmentStatusTO_return);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/update", method = RequestMethod.POST, name = "Employment Status Master Update->ESMCR")
  public ResponseEntity<?> updateEmploymentStatus(@Valid @RequestBody EmploymentStatusTO employmentStatusTO, Errors errors) {
    if (errors.hasErrors()) {
      ValidationError validationError = ValidationError.fromBindingErrors(errors);
      return new ResponseEntity<>(validationError, HttpStatus.OK);
    }
    EmploymentStatusTO employmentStatusTO_return = employmentStatusService.updateEmploymentStatus(employmentStatusTO);
    responseDTO = ResponseDTO.responseBuilder(200, "PR002", "/employment-status", "employmentStatus", employmentStatusTO_return);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/list", method = RequestMethod.POST, name = "Employment Status Master List->ESMCR")
  public ResponseEntity<?> getEmploymentStatusList(@RequestBody PaginationCriteria paginationCriteria) {
    SearchResponseTO searchResponseTO = employmentStatusService.getEmploymentStatusList(paginationCriteria);
    if (searchResponseTO.getList() == null || searchResponseTO.getList().isEmpty()) {
      responseDTO = ResponseDTO.responseBuilder(200, "PR006", "/employment-status", "employmentStatus", searchResponseTO);
      return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }
    responseDTO = ResponseDTO.responseBuilder(200, "PR003", "/employment-status", "employmentStatus", searchResponseTO);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/{id}", method = RequestMethod.GET, name = "Employment Status Master View->ESMCR")
  public ResponseEntity<?> getEmploymentStatusById(@PathVariable Long id) {
    EmploymentStatusTO employmentStatusTO = employmentStatusService.getEmploymentStatusById(id);
    if (employmentStatusTO == null) {
      responseDTO = ResponseDTO.responseBuilder(200, "PR007", "/employment-status", "employmentStatus", null);
      return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }
    responseDTO = ResponseDTO.responseBuilder(200, "PR004", "/employment-status", "employmentStatus", employmentStatusTO);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/delete", method = RequestMethod.DELETE, name = "Employment Status Master Delete->ESMCR")
  public ResponseEntity<?> deleteEmploymentStatus(@RequestParam(name = "employmentStatusId") List<Long> employmentStatusId) {
    employmentStatusService.deleteEmploymentStatus(employmentStatusId);
    responseDTO = ResponseDTO.responseBuilder(200, "PR005", "/employment-status", "employmentStatus", employmentStatusId);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }
}
