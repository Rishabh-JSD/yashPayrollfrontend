package com.hb.payrollMasters.employmentStatus.dao;

import com.hb.common.PaginationCriteria;
import com.hb.master.dto.CommonListTO;
import com.hb.payrollMasters.employmentStatus.entity.EmploymentStatusBO;

import java.util.List;

public interface EmploymentStatusDao {

  EmploymentStatusBO addEmploymentStatus(EmploymentStatusBO employmentStatusTO);

  EmploymentStatusBO updateEmploymentStatus(EmploymentStatusBO employmentStatusTO);

  CommonListTO<EmploymentStatusBO> getEmploymentStatusList(PaginationCriteria paginationCriteria);

  EmploymentStatusBO getEmploymentStatusById(Long id);

  void deleteEmploymentStatus(List<Long> id);

}
