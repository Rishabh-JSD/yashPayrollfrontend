package com.hb.payrollMasters.employmentStatus.service;

import com.hb.common.PaginationCriteria;
import com.hb.common.SearchResponseTO;
import com.hb.payrollMasters.employmentStatus.dto.EmploymentStatusTO;

import java.util.List;

public interface EmploymentStatusService {

  EmploymentStatusTO addEmploymentStatus(EmploymentStatusTO employmentStatusTO);

  EmploymentStatusTO updateEmploymentStatus(EmploymentStatusTO employmentStatusTO);

  SearchResponseTO getEmploymentStatusList(PaginationCriteria paginationCriteria);

  EmploymentStatusTO getEmploymentStatusById(Long id);

  void deleteEmploymentStatus(List<Long> employmentStatusId);
}
