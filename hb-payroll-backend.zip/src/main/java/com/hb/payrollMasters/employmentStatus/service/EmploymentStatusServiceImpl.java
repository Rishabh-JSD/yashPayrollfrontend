package com.hb.payrollMasters.employmentStatus.service;

import com.hb.common.MapperService;
import com.hb.common.PaginationCriteria;
import com.hb.common.SearchResponseTO;
import com.hb.master.dto.CommonListTO;
import com.hb.master.service.UserService;
import com.hb.payrollMasters.employmentStatus.dao.EmploymentStatusDao;
import com.hb.payrollMasters.employmentStatus.dto.EmploymentStatusTO;
import com.hb.payrollMasters.employmentStatus.entity.EmploymentStatusBO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;

@Service
@Transactional
public class EmploymentStatusServiceImpl implements EmploymentStatusService {

  @Autowired
  private EmploymentStatusDao employmentStatusDao;

  @Autowired
  private MapperService mapperService;

  @Autowired
  private UserService userService;

  @Override
  public EmploymentStatusTO addEmploymentStatus(EmploymentStatusTO employmentStatusTO) {
    EmploymentStatusBO employmentStatusBO = mapperService.map(employmentStatusTO, EmploymentStatusBO.class);
    return mapperService.map(employmentStatusDao.addEmploymentStatus(employmentStatusBO), EmploymentStatusTO.class);
  }

  @Override
  public EmploymentStatusTO updateEmploymentStatus(EmploymentStatusTO employmentStatusTO) {
    EmploymentStatusBO employmentStatusBO = mapperService.map(employmentStatusTO, EmploymentStatusBO.class);
    return mapperService.map(employmentStatusDao.updateEmploymentStatus(employmentStatusBO), EmploymentStatusTO.class);
  }

  @Override
  @Transactional(Transactional.TxType.NOT_SUPPORTED)
  public SearchResponseTO getEmploymentStatusList(PaginationCriteria paginationCriteria) {
    SearchResponseTO searchResponseTO = new SearchResponseTO();
    CommonListTO<EmploymentStatusBO> commonListTO = employmentStatusDao.getEmploymentStatusList(paginationCriteria);

    List<EmploymentStatusTO> employmentStatusTOS = null;
    if (commonListTO.getDataList() != null && !commonListTO.getDataList().isEmpty()) {
      employmentStatusTOS = new ArrayList<>();
      for (EmploymentStatusBO employmentStatusBO : commonListTO.getDataList()) {
        EmploymentStatusTO employmentStatusTO = mapperService.map(employmentStatusBO, EmploymentStatusTO.class);
        if (employmentStatusTO.getCreatedBy() != null) {
          employmentStatusTO.setCreatedByName(userService.getUserById(employmentStatusTO.getCreatedBy()).getName());
        }
        if (employmentStatusTO.getUpdatedBy() != null) {
          employmentStatusTO.setUpdatedByName(userService.getUserById(employmentStatusTO.getUpdatedBy()).getName());
        }
        employmentStatusTOS.add(employmentStatusTO);
      }
    }
    searchResponseTO.setList(employmentStatusTOS);
    searchResponseTO.setPageCount(commonListTO.getPageCount());
    searchResponseTO.setTotalRowCount(commonListTO.getTotalRow().intValue());
    return searchResponseTO;
  }

  @Override
  @Transactional(Transactional.TxType.NOT_SUPPORTED)
  public EmploymentStatusTO getEmploymentStatusById(Long id) {
    return mapperService.map(employmentStatusDao.getEmploymentStatusById(id), EmploymentStatusTO.class);
  }

  @Override
  public void deleteEmploymentStatus(List<Long> id) {
    employmentStatusDao.deleteEmploymentStatus(id);
  }
}
