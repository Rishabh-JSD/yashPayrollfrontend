package com.hb.payrollMasters.employmentStatus.validator;

import com.hb.common.PaginationCriteria;
import com.hb.payrollMasters.employmentStatus.controller.EmploymentStatusController;
import com.hb.payrollMasters.employmentStatus.dto.EmploymentStatusTO;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.ControllerAdvice;

@ControllerAdvice(assignableTypes = EmploymentStatusController.class)
public class EmploymentStatusValidator implements Validator {

  @Override
  public boolean supports(Class<?> aClass) {
    boolean support = EmploymentStatusTO.class.equals(aClass);
    if (!support) {
      support = PaginationCriteria.class.equals(aClass);
    }
    return support;
  }

  @Override
  public void validate(Object o, Errors errors) {
    EmploymentStatusTO employmentStatusTO = (EmploymentStatusTO) o;

//    ValidationUtils.rejectIfEmptyOrWhitespace(errors, "name", "PMS001E", APP_MSG.MESSAGE.get("PR001E"));

  }
}
