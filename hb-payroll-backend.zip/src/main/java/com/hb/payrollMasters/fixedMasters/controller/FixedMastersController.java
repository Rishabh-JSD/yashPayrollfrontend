package com.hb.payrollMasters.fixedMasters.controller;

import com.hb.common.PaginationCriteria;
import com.hb.common.ResponseDTO;
import com.hb.common.SearchResponseTO;
import com.hb.common.ValidationError;
import com.hb.payrollMasters.fixedMasters.dto.FixedMastersTO;
import com.hb.payrollMasters.fixedMasters.service.FixedMastersService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/fixed-masters")
public class FixedMastersController {

  @Autowired
  private Validator fixedMastersValidator;

  @Autowired
  private FixedMastersService fixedMastersService;

  private ResponseDTO responseDTO;

  @InitBinder
  private void initBinder(WebDataBinder binder) {
    binder.setValidator(fixedMastersValidator);
  }

  @RequestMapping(value = "/add", method = RequestMethod.POST, name = "Fixed Master Add(Dependency)->FMSCR")
  public ResponseEntity<?> addFixedMaster(@Valid @RequestBody final FixedMastersTO requestTO, Errors result) {
    if (result.hasErrors()) {
      ValidationError validationError = ValidationError.fromBindingErrors(result);
      return new ResponseEntity<ValidationError>(validationError, HttpStatus.OK);
    }
    FixedMastersTO fixedMastersTO = fixedMastersService.addFixedMaster(requestTO);
    responseDTO = ResponseDTO.responseBuilder(200, "PR001", "/fixed-masters", "master", fixedMastersTO);
    return new ResponseEntity<>(responseDTO, HttpStatus.CREATED);
  }

  @RequestMapping(value = "/update", method = RequestMethod.PUT, name = "Fixed Master Update(Dependency)->FMSCR")
  public ResponseEntity<?> updateFixedMaster(@Valid @RequestBody final FixedMastersTO requestTO, Errors result) {
    if (result.hasErrors()) {
      ValidationError validationError = ValidationError.fromBindingErrors(result);
      return new ResponseEntity<ValidationError>(validationError, HttpStatus.OK);
    }
    FixedMastersTO fixedMastersTO = fixedMastersService.updateFixedMaster(requestTO);
    responseDTO = ResponseDTO.responseBuilder(200, "PR002", "/fixed-masters", "master", fixedMastersTO);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/list", method = RequestMethod.POST, name = "Fixed Master All Details(Dependency)->FMSCR")
  public ResponseEntity<?> getFixedMasterList(@RequestBody PaginationCriteria paginationCriteria) {
    SearchResponseTO searchResponseTO = fixedMastersService.getFixedMasterList(paginationCriteria);
    if (searchResponseTO.getList() == null || searchResponseTO.getList().isEmpty()) {
      responseDTO = ResponseDTO.responseBuilder(200, "PR006", "/allowance", "allowance", searchResponseTO);
      return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }
    responseDTO = ResponseDTO.responseBuilder(200, "PR003", "/fixed-masters", "master", searchResponseTO);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/{id}", method = RequestMethod.GET, name = "Fixed Master view(Dependency)->FMSCR")
  public ResponseEntity<?> getFixedMasterById(@PathVariable("id") Long id) {
    FixedMastersTO fixedMastersTO = fixedMastersService.getFixedMasterById(id);
    if (fixedMastersTO == null) {
      responseDTO = ResponseDTO.responseBuilder(200, "PR007", "/fixed-masters", "master", null);
      return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }
    responseDTO = ResponseDTO.responseBuilder(200, "PR004", "/fixed-masters", "master", fixedMastersTO);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/type/{type}", method = RequestMethod.GET, name = "Get Fixed Masters type(Dependency)->FMSCR")
  public ResponseEntity<?> getFixedMasterListByType(@PathVariable("type") String type) {
    List<FixedMastersTO> list = fixedMastersService.getFixedMasterListByType(type);
    if (list == null || list.isEmpty()) {
      responseDTO = ResponseDTO.responseBuilder(200, "PR006", "/fixed-masters", "master", list);
      return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }
    responseDTO = ResponseDTO.responseBuilder(200, "PR003", "/fixed-masters", "master", list);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/delete", method = RequestMethod.DELETE, name = "Fixed Master Delete(Dependency)->FMSCR")
  public ResponseEntity<?> deleteFixedMaster(@RequestParam(name = "masterId") List<Long> masterId) {
    fixedMastersService.deleteFixedMaster(masterId);
    responseDTO = ResponseDTO.responseBuilder(200, "PR005", "/fixed-masters", "master", null);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }
}
