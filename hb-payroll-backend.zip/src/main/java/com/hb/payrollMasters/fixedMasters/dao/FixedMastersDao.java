package com.hb.payrollMasters.fixedMasters.dao;

import com.hb.common.PaginationCriteria;
import com.hb.master.dto.CommonListTO;
import com.hb.payrollMasters.fixedMasters.entity.FixedMastersBO;

import java.util.List;

public interface FixedMastersDao {

  FixedMastersBO addFixedMaster(FixedMastersBO fixedMastersTO);

  FixedMastersBO updateFixedMaster(FixedMastersBO fixedMastersTO);

  CommonListTO<FixedMastersBO> getFixedMasterList(PaginationCriteria paginationCriteria);

  FixedMastersBO getFixedMasterById(Long id);

  List<FixedMastersBO> getFixedMasterListByType(String type);

  void deleteFixedMaster(List<Long> id);

}
