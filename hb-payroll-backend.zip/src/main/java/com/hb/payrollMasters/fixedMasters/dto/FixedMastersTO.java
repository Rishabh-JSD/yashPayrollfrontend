package com.hb.payrollMasters.fixedMasters.dto;

import com.hb.common.AuditTO;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class FixedMastersTO extends AuditTO {

  private Long id;
  private String name;
  private String code;
  private String type;
  private String description;
}
