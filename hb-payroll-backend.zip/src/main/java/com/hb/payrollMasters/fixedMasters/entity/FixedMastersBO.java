package com.hb.payrollMasters.fixedMasters.entity;

import com.hb.common.Audit;
import com.hb.common.TABLES;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = TABLES.FIXED_MASTERS)
public class FixedMastersBO extends Audit {

  private static final long serialVersionUID = 6073032528968598334L;

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "id", updatable = false)
  private Long id;

  @Column(name = "name")
  private String name;

  @Column(name = "code", unique = true)
  private String code;

  @Column(name = "type")
  private String type;

  @Column(name = "description")
  private String description;

}
