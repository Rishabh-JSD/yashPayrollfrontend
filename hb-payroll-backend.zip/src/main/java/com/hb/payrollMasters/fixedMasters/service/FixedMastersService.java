package com.hb.payrollMasters.fixedMasters.service;

import com.hb.common.PaginationCriteria;
import com.hb.common.SearchResponseTO;
import com.hb.payrollMasters.fixedMasters.dto.FixedMastersTO;

import java.util.List;

public interface FixedMastersService {

  FixedMastersTO addFixedMaster(FixedMastersTO requestTO);

  FixedMastersTO updateFixedMaster(FixedMastersTO fixedMastersTO);

  SearchResponseTO getFixedMasterList(PaginationCriteria paginationCriteria);

  FixedMastersTO getFixedMasterById(Long id);

  List<FixedMastersTO> getFixedMasterListByType(String type);

  void deleteFixedMaster(List<Long> masterId);
}
