package com.hb.payrollMasters.fixedMasters.service;

import com.hb.common.MapperService;
import com.hb.common.PaginationCriteria;
import com.hb.common.SearchResponseTO;
import com.hb.master.dto.CommonListTO;
import com.hb.master.service.UserService;
import com.hb.payrollMasters.fixedMasters.dao.FixedMastersDao;
import com.hb.payrollMasters.fixedMasters.dto.FixedMastersTO;
import com.hb.payrollMasters.fixedMasters.entity.FixedMastersBO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;

@Service
@Transactional
public class FixedMastersServiceImpl implements FixedMastersService {

  @Autowired
  private FixedMastersDao fixedMastersDao;

  @Autowired
  private MapperService mapperService;

  @Autowired
  private UserService userService;

  @Override
  public FixedMastersTO addFixedMaster(FixedMastersTO fixedMastersTO) {
    FixedMastersBO fixedMastersBO = mapperService.map(fixedMastersTO, FixedMastersBO.class);
    return mapperService.map(fixedMastersDao.addFixedMaster(fixedMastersBO), FixedMastersTO.class);
  }

  @Override
  public FixedMastersTO updateFixedMaster(FixedMastersTO fixedMastersTO) {
    FixedMastersBO fixedMastersBO = mapperService.map(fixedMastersTO, FixedMastersBO.class);
    return mapperService.map(fixedMastersDao.updateFixedMaster(fixedMastersBO), FixedMastersTO.class);
  }

  @Override
  @Transactional(Transactional.TxType.NOT_SUPPORTED)
  public SearchResponseTO getFixedMasterList(PaginationCriteria paginationCriteria) {
    SearchResponseTO searchResponseTO = new SearchResponseTO();
    CommonListTO<FixedMastersBO> commonListTO = fixedMastersDao.getFixedMasterList(paginationCriteria);
    List<FixedMastersTO> fixedMastersTOS = mapperService.map(commonListTO.getDataList(), FixedMastersTO.class);

    searchResponseTO.setList(fixedMastersTOS);
    searchResponseTO.setPageCount(commonListTO.getPageCount());
    searchResponseTO.setTotalRowCount(commonListTO.getTotalRow().intValue());
    return searchResponseTO;
  }

  @Override
  @Transactional(Transactional.TxType.NOT_SUPPORTED)
  public FixedMastersTO getFixedMasterById(Long id) {
    return mapperService.map(fixedMastersDao.getFixedMasterById(id), FixedMastersTO.class);
  }

  @Override
  public List<FixedMastersTO> getFixedMasterListByType(String type) {
    return mapperService.map(fixedMastersDao.getFixedMasterListByType(type), FixedMastersTO.class);
  }

  @Override
  public void deleteFixedMaster(List<Long> id) {
    fixedMastersDao.deleteFixedMaster(id);
  }
}
