package com.hb.payrollMasters.fixedMasters.validator;

import com.hb.payrollMasters.fixedMasters.controller.FixedMastersController;
import com.hb.payrollMasters.fixedMasters.dto.FixedMastersTO;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.ControllerAdvice;

@ControllerAdvice(assignableTypes = FixedMastersController.class)
public class FixedMastersValidator implements Validator {

  @Override
  public boolean supports(Class<?> paramClass) {
    return FixedMastersTO.class.equals(paramClass);
  }

  @Override
  public void validate(Object obj, Errors errors) {
//    ValidationUtils.rejectIfEmptyOrWhitespace(errors, "code", "CTYPE006E", APP_MSG.RESPONSE.get("CTYPE006E"));
  }
}
