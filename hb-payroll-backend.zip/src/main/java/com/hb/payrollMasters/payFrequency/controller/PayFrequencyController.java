package com.hb.payrollMasters.payFrequency.controller;

import com.hb.common.PaginationCriteria;
import com.hb.common.ResponseDTO;
import com.hb.common.SearchResponseTO;
import com.hb.common.ValidationError;
import com.hb.payrollMasters.payFrequency.dto.PayFrequencyTO;
import com.hb.payrollMasters.payFrequency.service.PayFrequencyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/pay-frequency")
public class PayFrequencyController {

  @Autowired
  private Validator payFrequencyValidator;

  @Autowired
  private PayFrequencyService payFrequencyService;

  private ResponseDTO responseDTO;

  @InitBinder
  private void initBinder(WebDataBinder binder) {
    binder.setValidator(payFrequencyValidator);
  }

  @RequestMapping(value = "/add", method = RequestMethod.POST, name = "Pay Frequency Master Add->PFMCR")
  public ResponseEntity<?> addPayFrequency(@Valid @RequestBody PayFrequencyTO payFrequencyTO, Errors errors) {
    if (errors.hasErrors()) {
      ValidationError validationError = ValidationError.fromBindingErrors(errors);
      return new ResponseEntity<>(validationError, HttpStatus.OK);
    }
    PayFrequencyTO payFrequencyTO_return = payFrequencyService.addPayFrequency(payFrequencyTO);
    responseDTO = ResponseDTO.responseBuilder(200, "PR001", "/pay-frequency", "payFrequency", payFrequencyTO_return);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/update", method = RequestMethod.POST, name = "Pay Frequency Master Update->PFMCR")
  public ResponseEntity<?> updatePayFrequency(@Valid @RequestBody PayFrequencyTO payFrequencyTO, Errors errors) {
    if (errors.hasErrors()) {
      ValidationError validationError = ValidationError.fromBindingErrors(errors);
      return new ResponseEntity<>(validationError, HttpStatus.OK);
    }
    PayFrequencyTO payFrequencyTO_return = payFrequencyService.updatePayFrequency(payFrequencyTO);
    responseDTO = ResponseDTO.responseBuilder(200, "PR002", "/pay-frequency", "payFrequency", payFrequencyTO_return);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/list", method = RequestMethod.POST, name = "Pay Frequency Master List->PFMCR")
  public ResponseEntity<?> getPayFrequencyList(@RequestBody PaginationCriteria paginationCriteria) {
    SearchResponseTO searchResponseTO = payFrequencyService.getPayFrequencyList(paginationCriteria);
    if (searchResponseTO.getList() == null || searchResponseTO.getList().isEmpty()) {
      responseDTO = ResponseDTO.responseBuilder(200, "PR006", "/pay-frequency", "payFrequency", searchResponseTO);
      return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }
    responseDTO = ResponseDTO.responseBuilder(200, "PR003", "/pay-frequency", "payFrequency", searchResponseTO);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/{id}", method = RequestMethod.GET, name = "Pay Frequency Master View->PFMCR")
  public ResponseEntity<?> getPayFrequencyById(@PathVariable Long id) {
    PayFrequencyTO payFrequencyTO = payFrequencyService.getPayFrequencyById(id);
    if (payFrequencyTO == null) {
      responseDTO = ResponseDTO.responseBuilder(200, "PR007", "/pay-frequency", "payFrequency", null);
      return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }
    responseDTO = ResponseDTO.responseBuilder(200, "PR004", "/pay-frequency", "payFrequency", payFrequencyTO);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/delete", method = RequestMethod.DELETE, name = "Pay Frequency Master Delete->PFMCR")
  public ResponseEntity<?> deletePayFrequency(@RequestParam(name = "payFrequencyId") List<Long> payFrequencyId) {
    payFrequencyService.deletePayFrequency(payFrequencyId);
    responseDTO = ResponseDTO.responseBuilder(200, "PR005", "/pay-frequency", "payFrequency", payFrequencyId);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }
}
