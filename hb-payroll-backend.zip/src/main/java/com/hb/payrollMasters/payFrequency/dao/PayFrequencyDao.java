package com.hb.payrollMasters.payFrequency.dao;

import com.hb.common.PaginationCriteria;
import com.hb.master.dto.CommonListTO;
import com.hb.payrollMasters.payFrequency.entity.PayFrequencyBO;

import java.util.List;

public interface PayFrequencyDao {

  PayFrequencyBO addPayFrequency(PayFrequencyBO payFrequencyTO);

  PayFrequencyBO updatePayFrequency(PayFrequencyBO payFrequencyTO);

  CommonListTO<PayFrequencyBO> getPayFrequencyList(PaginationCriteria paginationCriteria);

  PayFrequencyBO getPayFrequencyById(Long id);

  void deletePayFrequency(List<Long> id);

}
