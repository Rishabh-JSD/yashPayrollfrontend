package com.hb.payrollMasters.payFrequency.dto;

import com.hb.common.AuditTO;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PayFrequencyTO extends AuditTO {

  private Long id;
  private String name;
  private boolean deleteFlag;

}
