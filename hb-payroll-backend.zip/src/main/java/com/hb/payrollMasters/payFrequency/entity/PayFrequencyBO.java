package com.hb.payrollMasters.payFrequency.entity;

import com.hb.common.Audit;
import com.hb.common.TABLES;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = TABLES.PAY_FREQUENCY_MASTER)
public class PayFrequencyBO extends Audit {

  private static final long serialVersionUID = -8870137852977311990L;

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "id", updatable = false)
  private Long id;

  @Column(name = "name")
  private String name;

  @Column(name = "delete_flag")
  private boolean deleteFlag;

}
