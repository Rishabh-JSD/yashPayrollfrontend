package com.hb.payrollMasters.payFrequency.service;

import com.hb.common.PaginationCriteria;
import com.hb.common.SearchResponseTO;
import com.hb.payrollMasters.payFrequency.dto.PayFrequencyTO;

import java.util.List;

public interface PayFrequencyService {

  PayFrequencyTO addPayFrequency(PayFrequencyTO payFrequencyTO);

  PayFrequencyTO updatePayFrequency(PayFrequencyTO payFrequencyTO);

  SearchResponseTO getPayFrequencyList(PaginationCriteria paginationCriteria);

  PayFrequencyTO getPayFrequencyById(Long id);

  void deletePayFrequency(List<Long> payFrequencyId);

}
