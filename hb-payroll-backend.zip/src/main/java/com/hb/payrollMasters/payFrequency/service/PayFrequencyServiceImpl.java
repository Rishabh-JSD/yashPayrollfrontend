package com.hb.payrollMasters.payFrequency.service;

import com.hb.common.MapperService;
import com.hb.common.PaginationCriteria;
import com.hb.common.SearchResponseTO;
import com.hb.master.dto.CommonListTO;
import com.hb.master.service.UserService;
import com.hb.payrollMasters.payFrequency.dao.PayFrequencyDao;
import com.hb.payrollMasters.payFrequency.dto.PayFrequencyTO;
import com.hb.payrollMasters.payFrequency.entity.PayFrequencyBO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;

@Service
@Transactional
public class PayFrequencyServiceImpl implements PayFrequencyService {

  @Autowired
  private PayFrequencyDao payFrequencyDao;

  @Autowired
  private MapperService mapperService;

  @Autowired
  private UserService userService;

  @Override
  public PayFrequencyTO addPayFrequency(PayFrequencyTO payFrequencyTO) {
    PayFrequencyBO payFrequencyBO = mapperService.map(payFrequencyTO, PayFrequencyBO.class);
    return mapperService.map(payFrequencyDao.addPayFrequency(payFrequencyBO), PayFrequencyTO.class);
  }

  @Override
  public PayFrequencyTO updatePayFrequency(PayFrequencyTO payFrequencyTO) {
    PayFrequencyBO payFrequencyBO = mapperService.map(payFrequencyTO, PayFrequencyBO.class);
    return mapperService.map(payFrequencyDao.updatePayFrequency(payFrequencyBO), PayFrequencyTO.class);
  }

  @Override
  @Transactional(Transactional.TxType.NOT_SUPPORTED)
  public SearchResponseTO getPayFrequencyList(PaginationCriteria paginationCriteria) {
    SearchResponseTO searchResponseTO = new SearchResponseTO();
    CommonListTO<PayFrequencyBO> commonListTO = payFrequencyDao.getPayFrequencyList(paginationCriteria);

    List<PayFrequencyTO> payFrequencyTOS = null;
    if (commonListTO.getDataList() != null && !commonListTO.getDataList().isEmpty()) {
      payFrequencyTOS = new ArrayList<>();
      for (PayFrequencyBO payFrequencyBO : commonListTO.getDataList()) {
        PayFrequencyTO payFrequencyTO = mapperService.map(payFrequencyBO, PayFrequencyTO.class);
        if (payFrequencyTO.getCreatedBy() != null) {
          payFrequencyTO.setCreatedByName(userService.getUserById(payFrequencyTO.getCreatedBy()).getName());
        }
        if (payFrequencyTO.getUpdatedBy() != null) {
          payFrequencyTO.setUpdatedByName(userService.getUserById(payFrequencyTO.getUpdatedBy()).getName());
        }
        payFrequencyTOS.add(payFrequencyTO);
      }
    }
    searchResponseTO.setList(payFrequencyTOS);
    searchResponseTO.setPageCount(commonListTO.getPageCount());
    searchResponseTO.setTotalRowCount(commonListTO.getTotalRow().intValue());
    return searchResponseTO;
  }

  @Override
  @Transactional(Transactional.TxType.NOT_SUPPORTED)
  public PayFrequencyTO getPayFrequencyById(Long id) {
    return mapperService.map(payFrequencyDao.getPayFrequencyById(id), PayFrequencyTO.class);
  }

  @Override
  public void deletePayFrequency(List<Long> id) {
    payFrequencyDao.deletePayFrequency(id);
  }
}
