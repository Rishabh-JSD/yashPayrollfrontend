package com.hb.payrollMasters.payrollMasters.controller;

import com.hb.common.PaginationCriteria;
import com.hb.common.ResponseDTO;
import com.hb.common.SearchResponseTO;
import com.hb.common.ValidationError;
import com.hb.payrollMasters.payrollMasters.dto.PayrollMastersTO;
import com.hb.payrollMasters.payrollMasters.service.PayrollMastersService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/payroll-masters")
public class PayrollMastersController {
    @Autowired
    private Validator payrollMastersValidator;

    @Autowired
    private PayrollMastersService payrollMastersService;

    private ResponseDTO responseDTO;

    @InitBinder
    private void initBinder(WebDataBinder binder) {
        binder.setValidator(payrollMastersValidator);
    }

    @RequestMapping(value = "/add", method = RequestMethod.POST, name = "Payroll Masters Add->STMCR")
    public ResponseEntity<?> addPayrollMasters(@Valid @RequestBody PayrollMastersTO payrollMastersTO, Errors errors) {
        if (errors.hasErrors()) {
            ValidationError validationError = ValidationError.fromBindingErrors(errors);
            return new ResponseEntity<>(validationError, HttpStatus.OK);
        }
        PayrollMastersTO payrollMastersTO_return = payrollMastersService.addPayrollMasters(payrollMastersTO);
        responseDTO = ResponseDTO.responseBuilder(200, "PR001", "/payroll-masters", "payrollMasters", payrollMastersTO_return);
        return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }

    @RequestMapping(value = "/update", method = RequestMethod.POST, name = "Payroll Masters Update->STMCR")
    public ResponseEntity<?> updatePayrollMasters(@Valid @RequestBody PayrollMastersTO payrollMastersTO, Errors errors) {
        if (errors.hasErrors()) {
            ValidationError validationError = ValidationError.fromBindingErrors(errors);
            return new ResponseEntity<>(validationError, HttpStatus.OK);
        }
        PayrollMastersTO payrollMastersTO_return = payrollMastersService.updatePayrollMasters(payrollMastersTO);
        responseDTO = ResponseDTO.responseBuilder(200, "PR002", "/payroll-masters", "payrollMasters", payrollMastersTO_return);
        return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }

    @RequestMapping(value = "/list", method = RequestMethod.POST, name = "Payroll Masters List->STMCR")
    public ResponseEntity<?> getPayrollMastersList(@RequestBody PaginationCriteria paginationCriteria) {
        SearchResponseTO searchResponseTO = payrollMastersService.getPayrollMastersList(paginationCriteria);
        if (searchResponseTO.getList() == null || searchResponseTO.getList().isEmpty()) {
            responseDTO = ResponseDTO.responseBuilder(200, "PR006", "/payroll-masters", "payrollMasters", searchResponseTO);
            return new ResponseEntity<>(responseDTO, HttpStatus.OK);
        }
        responseDTO = ResponseDTO.responseBuilder(200, "PR003", "/payroll-masters", "payrollMasters", searchResponseTO);
        return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }

    @RequestMapping(value = "/{id}", method = RequestMethod.GET, name = "Payroll Masters View->STMCR")
    public ResponseEntity<?> getPayrollMastersById(@PathVariable Long id) {
        PayrollMastersTO payrollMastersTO = payrollMastersService.getPayrollMastersById(id);
        if (payrollMastersTO == null) {
            responseDTO = ResponseDTO.responseBuilder(200, "PR007", "/payroll-masters", "payrollMasters", null);
            return new ResponseEntity<>(responseDTO, HttpStatus.OK);
        }
        responseDTO = ResponseDTO.responseBuilder(200, "PR004", "/payroll-masters", "payrollMasters", payrollMastersTO);
        return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }

    @RequestMapping(value = "/delete", method = RequestMethod.DELETE, name = "Payroll Masters Delete->STMCR")
    public ResponseEntity<?> deletePayrollMasters(@RequestParam(name = "payrollMastersId") List<Long> payrollMastersId) {
        payrollMastersService.deletePayrollMasters(payrollMastersId);
        responseDTO = ResponseDTO.responseBuilder(200, "PR005", "/payroll-masters", "payrollMasters", payrollMastersId);
        return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }
}
