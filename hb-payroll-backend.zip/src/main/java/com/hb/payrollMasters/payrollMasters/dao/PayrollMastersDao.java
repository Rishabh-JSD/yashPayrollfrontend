package com.hb.payrollMasters.payrollMasters.dao;

import com.hb.common.PaginationCriteria;
import com.hb.master.dto.CommonListTO;
import com.hb.payrollMasters.payrollMasters.entity.PayrollMastersBO;

import java.util.List;

public interface PayrollMastersDao {
    PayrollMastersBO addPayrollMasters(PayrollMastersBO payrollMastersBO);

    PayrollMastersBO updatePayrollMasters(PayrollMastersBO payrollMastersBO);

    CommonListTO<PayrollMastersBO> getPayrollMastersList(PaginationCriteria paginationCriteria);

    PayrollMastersBO getPayrollMastersById(Long id);

    void deletePayrollMasters(List<Long> payrollMastersId);
}
