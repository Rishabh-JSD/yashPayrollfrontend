package com.hb.payrollMasters.payrollMasters.dao;

import com.hb.common.PaginationCriteria;
import com.hb.master.dto.CommonListTO;
import com.hb.payrollMasters.payrollMasters.entity.PayrollMastersBO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.*;
import java.util.List;

@Repository
public class PayrollMastersDaoImpl implements PayrollMastersDao {
    @PersistenceContext
    private EntityManager entityManager;

    private static final Logger logger = LoggerFactory.getLogger(PayrollMastersDaoImpl.class);

    @Override
    public PayrollMastersBO addPayrollMasters(PayrollMastersBO payrollMastersBO) {
        entityManager.persist(payrollMastersBO);
        logger.info("PayrollMasters has added successfully, PayrollMasters details=" + payrollMastersBO);
        return payrollMastersBO;
    }

    @Override
    public PayrollMastersBO updatePayrollMasters(PayrollMastersBO payrollMastersBO) {
        entityManager.merge(payrollMastersBO);
        logger.info("PayrollMasters has updated successfully, PayrollMasters details=" + payrollMastersBO);
        return payrollMastersBO;
    }

    @Override
    public CommonListTO<PayrollMastersBO> getPayrollMastersList(PaginationCriteria paginationCriteria) {
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<PayrollMastersBO> criteriaQuery = criteriaBuilder.createQuery(PayrollMastersBO.class);
        Root<PayrollMastersBO> root = criteriaQuery.from(PayrollMastersBO.class);
        criteriaQuery.where(criteriaBuilder.equal(root.get("deleteFlag"), false));

        //condition for search
        if (paginationCriteria.getSearchFor() != null && !paginationCriteria.getSearchFor().isEmpty()) {
            Path<String> pathName = root.get("name");
            Predicate predicateForName = criteriaBuilder.like(pathName, "%" + paginationCriteria.getSearchFor() + "%");
            // Assuming "deleteFlag" is the field representing the deletion status
            Path<Boolean> pathDeleteFlag = root.get("deleteFlag");
            Predicate predicateNotDeleted = criteriaBuilder.isFalse(pathDeleteFlag);
            criteriaQuery.where(criteriaBuilder.and(predicateForName, predicateNotDeleted));
        }

        // Condition for sorting.
        if (paginationCriteria.getSortField() != null && !paginationCriteria.getSortField().isEmpty()) {
            Order order = null;
            if (paginationCriteria.getSortType() == 2) {
                order = criteriaBuilder.desc(root.get(paginationCriteria.getSortField()));
            } else {
                order = criteriaBuilder.asc(root.get(paginationCriteria.getSortField()));
            }
            criteriaQuery.orderBy(order);
        } else {
            Order order = criteriaBuilder.desc(root.get("id"));
            criteriaQuery.orderBy(order);
        }

        // Adding Pagination total Count
        CommonListTO<PayrollMastersBO> commonListTO = new CommonListTO<>();
        CriteriaQuery<Long> criteriaQuery2 = criteriaBuilder.createQuery(Long.class);
        Root<PayrollMastersBO> root2 = criteriaQuery2.from(PayrollMastersBO.class);
        criteriaQuery2.where(criteriaBuilder.equal(root2.get("deleteFlag"), false));
        CriteriaQuery<Long> select = criteriaQuery2.select(criteriaBuilder.count(root2));
        Long count = entityManager.createQuery(select).getSingleResult();
        commonListTO.setTotalRow(count);
        int size = count.intValue();
        int limit = paginationCriteria.getLimit();
        if (limit != 0) {
            commonListTO.setPageCount((size + limit - 1) / limit);
        } else {
            commonListTO.setPageCount(1);
        }

        TypedQuery<PayrollMastersBO> typedQuery = entityManager.createQuery(criteriaQuery);
        // Condition for paging.
        if (paginationCriteria.getPage() != 0 && paginationCriteria.getLimit() > 0) {
            typedQuery.setFirstResult((paginationCriteria.getPage() - 1) * paginationCriteria.getLimit());
            typedQuery.setMaxResults(paginationCriteria.getLimit());
        }
        commonListTO.setDataList(typedQuery.getResultList());
        return commonListTO;
    }

    @Override
    public PayrollMastersBO getPayrollMastersById(Long id) {
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<PayrollMastersBO> criteriaQuery = criteriaBuilder.createQuery(PayrollMastersBO.class);

        Root<PayrollMastersBO> root = criteriaQuery.from(PayrollMastersBO.class);
        Predicate predicateForId = criteriaBuilder.equal(root.get("id"), id);
        Predicate predicateForDeleteFlag = criteriaBuilder.equal(root.get("deleteFlag"), false);
        Predicate predicate = criteriaBuilder.and(predicateForId, predicateForDeleteFlag);
        criteriaQuery.where(predicate);
        return entityManager.createQuery(criteriaQuery).getSingleResult();
    }

    @Override
    public void deletePayrollMasters(List<Long> payrollMastersId) {
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaUpdate<PayrollMastersBO> criteriaUpdate = criteriaBuilder.createCriteriaUpdate(PayrollMastersBO.class);
        Root<PayrollMastersBO> root = criteriaUpdate.from(PayrollMastersBO.class);
        criteriaUpdate.set("deleteFlag", true);
        criteriaUpdate.where(root.get("id").in(payrollMastersId));
        entityManager.createQuery(criteriaUpdate).executeUpdate();
    }
}
