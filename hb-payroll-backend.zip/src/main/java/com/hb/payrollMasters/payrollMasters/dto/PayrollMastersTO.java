package com.hb.payrollMasters.payrollMasters.dto;

import com.hb.common.AuditTO;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PayrollMastersTO extends AuditTO {
    private int id;
    private String code;
    private String name;
    private boolean deleteFlag;
}
