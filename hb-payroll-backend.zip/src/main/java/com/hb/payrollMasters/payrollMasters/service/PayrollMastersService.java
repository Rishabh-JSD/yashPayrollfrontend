package com.hb.payrollMasters.payrollMasters.service;

import com.hb.common.PaginationCriteria;
import com.hb.common.SearchResponseTO;
import com.hb.payrollMasters.payrollMasters.dto.PayrollMastersTO;

import java.util.List;

public interface PayrollMastersService {
    PayrollMastersTO addPayrollMasters(PayrollMastersTO payrollMastersTO);

    PayrollMastersTO updatePayrollMasters(PayrollMastersTO payrollMastersTO);

    SearchResponseTO getPayrollMastersList(PaginationCriteria paginationCriteria);

    PayrollMastersTO getPayrollMastersById(Long id);

    void deletePayrollMasters(List<Long> payrollMastersId);
}
