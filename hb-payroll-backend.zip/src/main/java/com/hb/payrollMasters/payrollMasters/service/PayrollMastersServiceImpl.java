package com.hb.payrollMasters.payrollMasters.service;

import com.hb.common.MapperService;
import com.hb.common.PaginationCriteria;
import com.hb.common.SearchResponseTO;
import com.hb.master.dto.CommonListTO;
import com.hb.master.service.UserService;
import com.hb.payrollMasters.payrollMasters.dao.PayrollMastersDao;
import com.hb.payrollMasters.payrollMasters.dto.PayrollMastersTO;
import com.hb.payrollMasters.payrollMasters.entity.PayrollMastersBO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;

@Service
@Transactional
public class PayrollMastersServiceImpl implements PayrollMastersService {
    @Autowired
    private PayrollMastersDao payrollMastersDao;

    @Autowired
    private MapperService mapperService;

    @Autowired
    private UserService userService;

    @Override
    public PayrollMastersTO addPayrollMasters(PayrollMastersTO payrollMastersTO) {
        payrollMastersTO.setCode(payrollMastersTO.getCode().toUpperCase());
        PayrollMastersBO payrollMastersBO = mapperService.map(payrollMastersTO, PayrollMastersBO.class);
        return mapperService.map(payrollMastersDao.addPayrollMasters(payrollMastersBO), PayrollMastersTO.class);
    }

    @Override
    public PayrollMastersTO updatePayrollMasters(PayrollMastersTO payrollMastersTO) {
        PayrollMastersBO payrollMastersBO = mapperService.map(payrollMastersTO, PayrollMastersBO.class);
        return mapperService.map(payrollMastersDao.updatePayrollMasters(payrollMastersBO), PayrollMastersTO.class);
    }

    @Override
    @Transactional(Transactional.TxType.NOT_SUPPORTED)
    public SearchResponseTO getPayrollMastersList(PaginationCriteria paginationCriteria) {
        SearchResponseTO searchResponseTO = new SearchResponseTO();
        CommonListTO<PayrollMastersBO> commonListTO = payrollMastersDao.getPayrollMastersList(paginationCriteria);

        List<PayrollMastersTO> payrollMastersTOS = null;
        if (commonListTO.getDataList() != null && !commonListTO.getDataList().isEmpty()) {
            payrollMastersTOS = new ArrayList<>();
            for (PayrollMastersBO payrollMastersBO : commonListTO.getDataList()) {
                PayrollMastersTO payrollMastersTO = mapperService.map(payrollMastersBO, PayrollMastersTO.class);
                if (payrollMastersTO.getCreatedBy() != null) {
                    payrollMastersTO.setCreatedByName(userService.getUserById(payrollMastersTO.getCreatedBy()).getName());
                }
                if (payrollMastersTO.getUpdatedBy() != null) {
                    payrollMastersTO.setUpdatedByName(userService.getUserById(payrollMastersTO.getUpdatedBy()).getName());
                }
                payrollMastersTOS.add(payrollMastersTO);
            }
        }
        searchResponseTO.setList(payrollMastersTOS);
        searchResponseTO.setPageCount(commonListTO.getPageCount());
        searchResponseTO.setTotalRowCount(commonListTO.getTotalRow().intValue());
        return searchResponseTO;
    }

    @Override
    @Transactional(Transactional.TxType.NOT_SUPPORTED)
    public PayrollMastersTO getPayrollMastersById(Long id) {
        return mapperService.map(payrollMastersDao.getPayrollMastersById(id), PayrollMastersTO.class);
    }

    @Override
    public void deletePayrollMasters(List<Long> id) {
        payrollMastersDao.deletePayrollMasters(id);
    }
}
