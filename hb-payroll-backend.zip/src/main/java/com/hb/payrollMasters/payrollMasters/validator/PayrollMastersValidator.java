package com.hb.payrollMasters.payrollMasters.validator;

import com.hb.common.PaginationCriteria;
import com.hb.payrollMasters.payrollMasters.controller.PayrollMastersController;
import com.hb.payrollMasters.payrollMasters.dto.PayrollMastersTO;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.ControllerAdvice;

@ControllerAdvice(assignableTypes = PayrollMastersController.class)
public class PayrollMastersValidator implements Validator {
    @Override
    public boolean supports(Class<?> aClass) {
        boolean support = PayrollMastersTO.class.equals(aClass);
        if (!support) {
            support = PaginationCriteria.class.equals(aClass);
        }
        return support;
    }

    @Override
    public void validate(Object o, Errors errors) {
        PayrollMastersTO payrollMastersTO = (PayrollMastersTO) o;

//    ValidationUtils.rejectIfEmptyOrWhitespace(errors, "name", "PMS001E", APP_MSG.MESSAGE.get("PR001E"));

    }
}
