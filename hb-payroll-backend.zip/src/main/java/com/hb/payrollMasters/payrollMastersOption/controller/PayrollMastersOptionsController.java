package com.hb.payrollMasters.payrollMastersOption.controller;

import com.hb.common.PaginationCriteria;
import com.hb.common.ResponseDTO;
import com.hb.common.SearchResponseTO;
import com.hb.common.ValidationError;
import com.hb.payrollMasters.payrollMastersOption.dto.PayrollMastersOptionsTO;
import com.hb.payrollMasters.payrollMastersOption.service.PayrollMastersOptionsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/payroll-masters-options")
public class PayrollMastersOptionsController {
    @Autowired
    private Validator payrollMastersOptionsValidator;

    @Autowired
    private PayrollMastersOptionsService payrollMastersOptionsService;

    private ResponseDTO responseDTO;

    @InitBinder
    private void initBinder(WebDataBinder binder) {
        binder.setValidator(payrollMastersOptionsValidator);
    }

    @RequestMapping(value = "/add", method = RequestMethod.POST, name = "Payroll Masters Options Add->STMCR")
    public ResponseEntity<?> addPayrollMastersOptions(@Valid @RequestBody PayrollMastersOptionsTO payrollMastersOptionsTO, Errors errors) {
        if (errors.hasErrors()) {
            ValidationError validationError = ValidationError.fromBindingErrors(errors);
            return new ResponseEntity<>(validationError, HttpStatus.OK);
        }
        PayrollMastersOptionsTO payrollMastersOptionsTO_return = payrollMastersOptionsService.addPayrollMastersOptions(payrollMastersOptionsTO);
        responseDTO = ResponseDTO.responseBuilder(200, "PR001", "/payroll-masters-options", "payrollMastersOptions", payrollMastersOptionsTO_return);
        return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }

    @RequestMapping(value = "/update", method = RequestMethod.POST, name = "Payroll Masters Options Update->STMCR")
    public ResponseEntity<?> updatePayrollMastersOptions(@Valid @RequestBody PayrollMastersOptionsTO payrollMastersOptionsTO, Errors errors) {
        if (errors.hasErrors()) {
            ValidationError validationError = ValidationError.fromBindingErrors(errors);
            return new ResponseEntity<>(validationError, HttpStatus.OK);
        }
        PayrollMastersOptionsTO payrollMastersOptionsTO_return = payrollMastersOptionsService.updatePayrollMastersOptions(payrollMastersOptionsTO);
        responseDTO = ResponseDTO.responseBuilder(200, "PR002", "/payroll-masters-options", "payrollMastersOptions", payrollMastersOptionsTO_return);
        return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }

    @RequestMapping(value = "/list/{catCode}", method = RequestMethod.POST, name = "Payroll Masters Options List->STMCR")
    public ResponseEntity<?> getPayrollMastersOptionsList(@RequestBody PaginationCriteria paginationCriteria, @PathVariable String catCode) {
        SearchResponseTO searchResponseTO = payrollMastersOptionsService.getPayrollMastersOptionsList(paginationCriteria, catCode);
        if (searchResponseTO.getList() == null || searchResponseTO.getList().isEmpty()) {
            responseDTO = ResponseDTO.responseBuilder(200, "PR006", "/payroll-masters-options", "payrollMastersOptions", searchResponseTO);
            return new ResponseEntity<>(responseDTO, HttpStatus.OK);
        }
        responseDTO = ResponseDTO.responseBuilder(200, "PR003", "/payroll-masters-options", "payrollMastersOptions", searchResponseTO);
        return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }

    @RequestMapping(value = "/{id}", method = RequestMethod.GET, name = "Payroll Masters Options View->STMCR")
    public ResponseEntity<?> getPayrollMastersOptionsById(@PathVariable Long id) {
        PayrollMastersOptionsTO payrollMastersOptionsTO = payrollMastersOptionsService.getPayrollMastersOptionsById(id);
        if (payrollMastersOptionsTO == null) {
            responseDTO = ResponseDTO.responseBuilder(200, "PR007", "/payroll-masters-options", "payrollMastersOptions", null);
            return new ResponseEntity<>(responseDTO, HttpStatus.OK);
        }
        responseDTO = ResponseDTO.responseBuilder(200, "PR004", "/payroll-masters-options", "payrollMastersOptions", payrollMastersOptionsTO);
        return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }
    @RequestMapping(value = "/delete", method = RequestMethod.DELETE, name = "Payroll Masters Options Delete->STMCR")
    public ResponseEntity<?> deletePayrollMastersOptions(@RequestParam(name = "payrollMastersOptionsId") List<Long> payrollMastersOptionsId) {
        payrollMastersOptionsService.deletePayrollMastersOptions(payrollMastersOptionsId);
        responseDTO = ResponseDTO.responseBuilder(200, "PR005", "/payroll-masters-options", "payrollMastersOptions", payrollMastersOptionsId);
        return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }

    @RequestMapping(value = "/list/{catCode}/{code}", method = RequestMethod.POST, name = "Payroll Masters Options List->STMCR")
    public ResponseEntity<?> getPayrollMastersOptionsList(@RequestBody PaginationCriteria paginationCriteria, @PathVariable String catCode,@PathVariable String code) {
        SearchResponseTO searchResponseTO = payrollMastersOptionsService.getPayrollMastersOptionsListWithCode(paginationCriteria, catCode, code);
        if (searchResponseTO.getList() == null || searchResponseTO.getList().isEmpty()) {
            responseDTO = ResponseDTO.responseBuilder(200, "PR006", "/payroll-masters-options", "payrollMastersOptions", searchResponseTO);
            return new ResponseEntity<>(responseDTO, HttpStatus.OK);
        }
        responseDTO = ResponseDTO.responseBuilder(200, "PR003", "/payroll-masters-options", "payrollMastersOptions", searchResponseTO);
        return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }
}

