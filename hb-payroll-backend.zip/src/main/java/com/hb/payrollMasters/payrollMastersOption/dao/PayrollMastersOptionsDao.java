package com.hb.payrollMasters.payrollMastersOption.dao;

import com.hb.common.PaginationCriteria;
import com.hb.master.dto.CommonListTO;
import com.hb.payrollMasters.payrollMastersOption.entity.PayrollMastersOptionsBO;

import java.util.List;

public interface PayrollMastersOptionsDao {
    PayrollMastersOptionsBO addPayrollMastersOptions(PayrollMastersOptionsBO payrollMastersOptionsBO);

    PayrollMastersOptionsBO updatePayrollMastersOptions(PayrollMastersOptionsBO payrollMastersOptionsBO);

    CommonListTO<PayrollMastersOptionsBO> getPayrollMastersOptionsList(PaginationCriteria paginationCriteria, String catCode);

    PayrollMastersOptionsBO getPayrollMastersOptionsById(Long id);

    void deletePayrollMastersOptions(List<Long> payrollMastersOptionsId);

    CommonListTO<PayrollMastersOptionsBO> getPayrollMastersOptionsListWithCode(PaginationCriteria paginationCriteria, String catCode,String code);
}
