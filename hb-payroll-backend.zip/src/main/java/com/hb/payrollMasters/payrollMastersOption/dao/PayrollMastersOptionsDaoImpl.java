package com.hb.payrollMasters.payrollMastersOption.dao;

import com.hb.common.PaginationCriteria;
import com.hb.master.dto.CommonListTO;
import com.hb.payrollMasters.payrollMastersOption.entity.PayrollMastersOptionsBO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.*;
import java.util.List;

@Repository
public class PayrollMastersOptionsDaoImpl implements PayrollMastersOptionsDao{
    @PersistenceContext
    private EntityManager entityManager;

    private static final Logger logger = LoggerFactory.getLogger(PayrollMastersOptionsDaoImpl.class);

    @Override
    public PayrollMastersOptionsBO addPayrollMastersOptions(PayrollMastersOptionsBO payrollMastersOptionsBO) {
        entityManager.persist(payrollMastersOptionsBO);
        logger.info("PayrollMastersOptions has added successfully, PayrollMastersOptions details=" + payrollMastersOptionsBO);
        return payrollMastersOptionsBO;
    }

    @Override
    public PayrollMastersOptionsBO updatePayrollMastersOptions(PayrollMastersOptionsBO payrollMastersOptionsBO) {
        entityManager.merge(payrollMastersOptionsBO);
        logger.info("PayrollMastersOptions has updated successfully, PayrollMastersOptions details=" + payrollMastersOptionsBO);
        return payrollMastersOptionsBO;
    }

    @Override
    public CommonListTO<PayrollMastersOptionsBO> getPayrollMastersOptionsList(PaginationCriteria paginationCriteria, String catCode) {
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<PayrollMastersOptionsBO> criteriaQuery = criteriaBuilder.createQuery(PayrollMastersOptionsBO.class);
        Root<PayrollMastersOptionsBO> root = criteriaQuery.from(PayrollMastersOptionsBO.class);
        criteriaQuery.where(criteriaBuilder.and(
                        criteriaBuilder.equal(root.get("deleteFlag"), false),
                        criteriaBuilder.equal(root.get("catCode"), catCode)));

        //condition for search
        if (paginationCriteria.getSearchFor() != null && !paginationCriteria.getSearchFor().isEmpty()) {
            Path<String> pathName = root.get("name");
            Path<String> pathCatCode=root.get("catCode");
            Predicate predicateForName = criteriaBuilder.like(pathName, "%" + paginationCriteria.getSearchFor() + "%");
            Predicate predicateForCatCode=criteriaBuilder.equal(pathCatCode,catCode);
            // Assuming "deleteFlag" is the field representing the deletion status
            Path<Boolean> pathDeleteFlag = root.get("deleteFlag");
            Predicate predicateNotDeleted = criteriaBuilder.isFalse(pathDeleteFlag);
            criteriaQuery.where(criteriaBuilder.and(predicateForName, predicateNotDeleted,predicateForCatCode));
        }

        // Condition for sorting.
        if (paginationCriteria.getSortField() != null && !paginationCriteria.getSortField().isEmpty()) {
            Order order = null;
            if (paginationCriteria.getSortType() == 2) {
                order = criteriaBuilder.desc(root.get(paginationCriteria.getSortField()));
            } else {
                order = criteriaBuilder.asc(root.get(paginationCriteria.getSortField()));
            }
            criteriaQuery.orderBy(order);
        } else {
            Order order = criteriaBuilder.desc(root.get("id"));
            criteriaQuery.orderBy(order);
        }

        // Adding Pagination total Count
        CommonListTO<PayrollMastersOptionsBO> commonListTO = new CommonListTO<>();
        CriteriaQuery<Long> criteriaQuery2 = criteriaBuilder.createQuery(Long.class);
        Root<PayrollMastersOptionsBO> root2 = criteriaQuery2.from(PayrollMastersOptionsBO.class);
        criteriaQuery2.where(criteriaBuilder.and(
                        criteriaBuilder.equal(root2.get("deleteFlag"), false),
                        criteriaBuilder.equal(root2.get("catCode"), catCode)));
        CriteriaQuery<Long> select = criteriaQuery2.select(criteriaBuilder.count(root2));
        Long count = entityManager.createQuery(select).getSingleResult();
        commonListTO.setTotalRow(count);
        int size = count.intValue();
        int limit = paginationCriteria.getLimit();
        if (limit != 0) {
            commonListTO.setPageCount((size + limit - 1) / limit);
        } else {
            commonListTO.setPageCount(1);
        }

        TypedQuery<PayrollMastersOptionsBO> typedQuery = entityManager.createQuery(criteriaQuery);
        // Condition for paging.
        if (paginationCriteria.getPage() != 0 && paginationCriteria.getLimit() > 0) {
            typedQuery.setFirstResult((paginationCriteria.getPage() - 1) * paginationCriteria.getLimit());
            typedQuery.setMaxResults(paginationCriteria.getLimit());
        }
        commonListTO.setDataList(typedQuery.getResultList());
        return commonListTO;
    }

    @Override
    public PayrollMastersOptionsBO getPayrollMastersOptionsById(Long id) {
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<PayrollMastersOptionsBO> criteriaQuery = criteriaBuilder.createQuery(PayrollMastersOptionsBO.class);

        Root<PayrollMastersOptionsBO> root = criteriaQuery.from(PayrollMastersOptionsBO.class);
        Predicate predicateForId = criteriaBuilder.equal(root.get("id"), id);
        Predicate predicateForDeleteFlag = criteriaBuilder.equal(root.get("deleteFlag"), false);
        Predicate predicate = criteriaBuilder.and(predicateForId, predicateForDeleteFlag);
        criteriaQuery.where(predicate);
        return entityManager.createQuery(criteriaQuery).getSingleResult();
    }

    @Override
    public void deletePayrollMastersOptions(List<Long> payrollMastersOptionsId) {
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaUpdate<PayrollMastersOptionsBO> criteriaUpdate = criteriaBuilder.createCriteriaUpdate(PayrollMastersOptionsBO.class);
        Root<PayrollMastersOptionsBO> root = criteriaUpdate.from(PayrollMastersOptionsBO.class);
        criteriaUpdate.set("deleteFlag", true);
        criteriaUpdate.where(root.get("id").in(payrollMastersOptionsId));
        entityManager.createQuery(criteriaUpdate).executeUpdate();
    }

    @Override
    public CommonListTO<PayrollMastersOptionsBO> getPayrollMastersOptionsListWithCode(PaginationCriteria paginationCriteria, String catCode,String code) {
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<PayrollMastersOptionsBO> criteriaQuery = criteriaBuilder.createQuery(PayrollMastersOptionsBO.class);
        Root<PayrollMastersOptionsBO> root = criteriaQuery.from(PayrollMastersOptionsBO.class);
        criteriaQuery.where(criteriaBuilder.and(
                criteriaBuilder.equal(root.get("deleteFlag"), false),
                criteriaBuilder.equal(root.get("catCode"), catCode),
                criteriaBuilder.equal(root.get("code"), code)));

        //condition for search
        if (paginationCriteria.getSearchFor() != null && !paginationCriteria.getSearchFor().isEmpty()) {
            Path<String> pathName = root.get("name");
            Path<String> pathCatCode=root.get("catCode");
            Path<String> pathCode=root.get("code");
            Predicate predicateForName = criteriaBuilder.like(pathName, "%" + paginationCriteria.getSearchFor() + "%");
            Predicate predicateForCatCode=criteriaBuilder.equal(pathCatCode,catCode);
            Predicate predicateForCode=criteriaBuilder.equal(pathCode,code);
            // Assuming "deleteFlag" is the field representing the deletion status
            Path<Boolean> pathDeleteFlag = root.get("deleteFlag");
            Predicate predicateNotDeleted = criteriaBuilder.isFalse(pathDeleteFlag);
            criteriaQuery.where(criteriaBuilder.and(predicateForName, predicateNotDeleted,predicateForCatCode,predicateForCode));
        }

        // Condition for sorting.
        if (paginationCriteria.getSortField() != null && !paginationCriteria.getSortField().isEmpty()) {
            Order order = null;
            if (paginationCriteria.getSortType() == 2) {
                order = criteriaBuilder.desc(root.get(paginationCriteria.getSortField()));
            } else {
                order = criteriaBuilder.asc(root.get(paginationCriteria.getSortField()));
            }
            criteriaQuery.orderBy(order);
        } else {
            Order order = criteriaBuilder.desc(root.get("id"));
            criteriaQuery.orderBy(order);
        }

        // Adding Pagination total Count
        CommonListTO<PayrollMastersOptionsBO> commonListTO = new CommonListTO<>();
        CriteriaQuery<Long> criteriaQuery2 = criteriaBuilder.createQuery(Long.class);
        Root<PayrollMastersOptionsBO> root2 = criteriaQuery2.from(PayrollMastersOptionsBO.class);
        criteriaQuery2.where(criteriaBuilder.and(
                criteriaBuilder.equal(root2.get("deleteFlag"), false),
                criteriaBuilder.equal(root2.get("catCode"), catCode),
                criteriaBuilder.equal(root2.get("code"), code)));
        CriteriaQuery<Long> select = criteriaQuery2.select(criteriaBuilder.count(root2));
        Long count = entityManager.createQuery(select).getSingleResult();
        commonListTO.setTotalRow(count);
        int size = count.intValue();
        int limit = paginationCriteria.getLimit();
        if (limit != 0) {
            commonListTO.setPageCount((size + limit - 1) / limit);
        } else {
            commonListTO.setPageCount(1);
        }

        TypedQuery<PayrollMastersOptionsBO> typedQuery = entityManager.createQuery(criteriaQuery);
        // Condition for paging.
        if (paginationCriteria.getPage() != 0 && paginationCriteria.getLimit() > 0) {
            typedQuery.setFirstResult((paginationCriteria.getPage() - 1) * paginationCriteria.getLimit());
            typedQuery.setMaxResults(paginationCriteria.getLimit());
        }
        commonListTO.setDataList(typedQuery.getResultList());
        return commonListTO;
    }
}
