package com.hb.payrollMasters.payrollMastersOption.dto;

import com.hb.common.AuditTO;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PayrollMastersOptionsTO extends AuditTO {
    private int id;
    private String name;
    private String catCode;
    private Long reportingToId;
    private String description;
    private Long parentId;
    private Long parent_cat_option_id;
    private String startTime;
    private String endTime;
    private Double workingHours;
    private boolean preDefinedFlag;
    private String code;
    private String docType;
    private Long level;
    private boolean deleteFlag;

}
