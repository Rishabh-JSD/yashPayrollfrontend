package com.hb.payrollMasters.payrollMastersOption.entity;

import com.hb.common.Audit;
import com.hb.common.TABLES;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;


@Getter
@Setter
@Entity
@Table(name = TABLES.PAYROLL_MASTER_OPTION)
public class PayrollMastersOptionsBO extends Audit {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;

    @Column(name = "name")
    private String name;

    @Column(name = "cat_code")
    private String catCode;

    @Column(name = "reporting_to_id")
    private Long reportingToId;

    @Column(name = "description")
    private String description;

    @Column(name = "parent_id")
    private Long parentId;

    @Column(name = "parent_cat_option_id")
    private Long parentCatOptionId;

    @Column(name = "start_time")
    private String startTime;

    @Column(name = "end_time")
    private String endTime;

    @Column(name = "working_hours")
    private Double workingHours;

    @Column(name = "pre_defined_flag")
    private boolean preDefinedFlag;

    @Column(name = "code")
    private String code;

    @Column(name = "document_type")
    private String docType;

    @Column(name = "level")
    private Long level;

    @Column(name = "delete_flag")
    private boolean deleteFlag;

}
