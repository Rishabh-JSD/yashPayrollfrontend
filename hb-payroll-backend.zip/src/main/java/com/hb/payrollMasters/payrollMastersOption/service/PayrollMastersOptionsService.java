package com.hb.payrollMasters.payrollMastersOption.service;

import com.hb.common.PaginationCriteria;
import com.hb.common.SearchResponseTO;
import com.hb.payrollMasters.payrollMastersOption.dto.PayrollMastersOptionsTO;

import java.util.List;

public interface PayrollMastersOptionsService {
    PayrollMastersOptionsTO addPayrollMastersOptions(PayrollMastersOptionsTO payrollMastersOptionsTO);

    PayrollMastersOptionsTO updatePayrollMastersOptions(PayrollMastersOptionsTO payrollMastersOptionsTO);

    SearchResponseTO getPayrollMastersOptionsList(PaginationCriteria paginationCriteria, String catCode);

    PayrollMastersOptionsTO getPayrollMastersOptionsById(Long id);

    void deletePayrollMastersOptions(List<Long> payrollMastersOptionsId);

    SearchResponseTO getPayrollMastersOptionsListWithCode(PaginationCriteria paginationCriteria, String catCode,String code);

}
