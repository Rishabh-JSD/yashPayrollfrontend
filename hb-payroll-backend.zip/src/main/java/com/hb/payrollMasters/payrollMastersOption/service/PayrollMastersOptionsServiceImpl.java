package com.hb.payrollMasters.payrollMastersOption.service;

import com.hb.common.MapperService;
import com.hb.common.PaginationCriteria;
import com.hb.common.SearchResponseTO;
import com.hb.master.dto.CommonListTO;
import com.hb.master.service.UserService;
import com.hb.payrollMasters.payrollMastersOption.dao.PayrollMastersOptionsDao;
import com.hb.payrollMasters.payrollMastersOption.dto.PayrollMastersOptionsTO;
import com.hb.payrollMasters.payrollMastersOption.entity.PayrollMastersOptionsBO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;

@Service
@Transactional
public class PayrollMastersOptionsServiceImpl implements PayrollMastersOptionsService {
    @Autowired
    private PayrollMastersOptionsDao payrollMastersOptionsDao;

    @Autowired
    private MapperService mapperService;

    @Autowired
    private UserService userService;

    @Override
    public PayrollMastersOptionsTO addPayrollMastersOptions(PayrollMastersOptionsTO payrollMastersOptionsTO) {
        PayrollMastersOptionsBO payrollMastersOptionsBO = mapperService.map(payrollMastersOptionsTO, PayrollMastersOptionsBO.class);
        return mapperService.map(payrollMastersOptionsDao.addPayrollMastersOptions(payrollMastersOptionsBO), PayrollMastersOptionsTO.class);
    }

    @Override
    public PayrollMastersOptionsTO updatePayrollMastersOptions(PayrollMastersOptionsTO payrollMastersOptionsTO) {
        PayrollMastersOptionsBO payrollMastersOptionsBO = mapperService.map(payrollMastersOptionsTO, PayrollMastersOptionsBO.class);
        return mapperService.map(payrollMastersOptionsDao.updatePayrollMastersOptions(payrollMastersOptionsBO), PayrollMastersOptionsTO.class);
    }

    @Override
    @Transactional(Transactional.TxType.NOT_SUPPORTED)
    public SearchResponseTO getPayrollMastersOptionsList(PaginationCriteria paginationCriteria,String catCode) {
        SearchResponseTO searchResponseTO = new SearchResponseTO();
        CommonListTO<PayrollMastersOptionsBO> commonListTO = payrollMastersOptionsDao.getPayrollMastersOptionsList(paginationCriteria,catCode);

        List<PayrollMastersOptionsTO> payrollMastersOptionsTOS = null;
        if (commonListTO.getDataList() != null && !commonListTO.getDataList().isEmpty()) {
            payrollMastersOptionsTOS = new ArrayList<>();
            for (PayrollMastersOptionsBO payrollMastersOptionsBO : commonListTO.getDataList()) {
                PayrollMastersOptionsTO payrollMastersOptionsTO = mapperService.map(payrollMastersOptionsBO, PayrollMastersOptionsTO.class);
                if (payrollMastersOptionsTO.getCreatedBy() != null) {
                    payrollMastersOptionsTO.setCreatedByName(userService.getUserById(payrollMastersOptionsTO.getCreatedBy()).getName());
                }
                if (payrollMastersOptionsTO.getUpdatedBy() != null) {
                    payrollMastersOptionsTO.setUpdatedByName(userService.getUserById(payrollMastersOptionsTO.getUpdatedBy()).getName());
                }
                payrollMastersOptionsTOS.add(payrollMastersOptionsTO);
            }
        }
        searchResponseTO.setList(payrollMastersOptionsTOS);
        searchResponseTO.setPageCount(commonListTO.getPageCount());
        searchResponseTO.setTotalRowCount(commonListTO.getTotalRow().intValue());
        return searchResponseTO;
    }

    @Override
    @Transactional(Transactional.TxType.NOT_SUPPORTED)
    public PayrollMastersOptionsTO getPayrollMastersOptionsById(Long id) {
        return mapperService.map(payrollMastersOptionsDao.getPayrollMastersOptionsById(id), PayrollMastersOptionsTO.class);
    }

    @Override
    public void deletePayrollMastersOptions(List<Long> id) {
        payrollMastersOptionsDao.deletePayrollMastersOptions(id);
    }

    @Override
    @Transactional(Transactional.TxType.NOT_SUPPORTED)
    public SearchResponseTO getPayrollMastersOptionsListWithCode(PaginationCriteria paginationCriteria,String catCode, String code) {
        SearchResponseTO searchResponseTO = new SearchResponseTO();
        CommonListTO<PayrollMastersOptionsBO> commonListTO = payrollMastersOptionsDao.getPayrollMastersOptionsListWithCode(paginationCriteria,catCode,code);

        List<PayrollMastersOptionsTO> payrollMastersOptionsTOS = null;
        if (commonListTO.getDataList() != null && !commonListTO.getDataList().isEmpty()) {
            payrollMastersOptionsTOS = new ArrayList<>();
            for (PayrollMastersOptionsBO payrollMastersOptionsBO : commonListTO.getDataList()) {
                PayrollMastersOptionsTO payrollMastersOptionsTO = mapperService.map(payrollMastersOptionsBO, PayrollMastersOptionsTO.class);
                if (payrollMastersOptionsTO.getCreatedBy() != null) {
                    payrollMastersOptionsTO.setCreatedByName(userService.getUserById(payrollMastersOptionsTO.getCreatedBy()).getName());
                }
                if (payrollMastersOptionsTO.getUpdatedBy() != null) {
                    payrollMastersOptionsTO.setUpdatedByName(userService.getUserById(payrollMastersOptionsTO.getUpdatedBy()).getName());
                }
                payrollMastersOptionsTOS.add(payrollMastersOptionsTO);
            }
        }
        searchResponseTO.setList(payrollMastersOptionsTOS);
        searchResponseTO.setPageCount(commonListTO.getPageCount());
        searchResponseTO.setTotalRowCount(commonListTO.getTotalRow().intValue());
        return searchResponseTO;
    }
}
