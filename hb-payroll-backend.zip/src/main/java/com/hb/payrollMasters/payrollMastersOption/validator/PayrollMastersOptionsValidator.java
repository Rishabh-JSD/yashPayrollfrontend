package com.hb.payrollMasters.payrollMastersOption.validator;

import com.hb.common.PaginationCriteria;
import com.hb.payrollMasters.payrollMastersOption.controller.PayrollMastersOptionsController;
import com.hb.payrollMasters.payrollMastersOption.dto.PayrollMastersOptionsTO;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.ControllerAdvice;

@ControllerAdvice(assignableTypes = PayrollMastersOptionsController.class)
public class PayrollMastersOptionsValidator implements Validator {
    @Override
    public boolean supports(Class<?> aClass) {
        boolean support = PayrollMastersOptionsTO.class.equals(aClass);
        if (!support) {
            support = PaginationCriteria.class.equals(aClass);
        }
        return support;
    }

    @Override
    public void validate(Object o, Errors errors) {
        PayrollMastersOptionsTO payrollMastersOptionsTO = (PayrollMastersOptionsTO) o;

//    ValidationUtils.rejectIfEmptyOrWhitespace(errors, "name", "PMS001E", APP_MSG.MESSAGE.get("PR001E"));

    }
}
