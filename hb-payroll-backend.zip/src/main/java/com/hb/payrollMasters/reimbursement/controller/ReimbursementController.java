package com.hb.payrollMasters.reimbursement.controller;

import com.hb.common.PaginationCriteria;
import com.hb.common.ResponseDTO;
import com.hb.common.SearchResponseTO;
import com.hb.common.ValidationError;
import com.hb.payrollMasters.reimbursement.dto.ReimbursementTO;
import com.hb.payrollMasters.reimbursement.service.ReimbursementService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/reimbursement")
public class ReimbursementController {

  @Autowired
  private Validator reimbursementValidator;

  @Autowired
  private ReimbursementService reimbursementService;

  private ResponseDTO responseDTO;

  @InitBinder
  private void initBinder(WebDataBinder binder) {
    binder.setValidator(reimbursementValidator);
  }

  @RequestMapping(value = "/add", method = RequestMethod.POST, name = "Reimbursement Master Add->RIMCR")
  public ResponseEntity<?> addReimbursement(@Valid @RequestBody ReimbursementTO reimbursementTO, Errors errors) {
    if (errors.hasErrors()) {
      ValidationError validationError = ValidationError.fromBindingErrors(errors);
      return new ResponseEntity<>(validationError, HttpStatus.OK);
    }
    ReimbursementTO reimbursementTO_return = reimbursementService.addReimbursement(reimbursementTO);
    responseDTO = ResponseDTO.responseBuilder(200, "PR001", "/reimbursement", "reimbursement", reimbursementTO_return);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/update", method = RequestMethod.POST, name = "Reimbursement Master Update->RIMCR")
  public ResponseEntity<?> updateReimbursement(@Valid @RequestBody ReimbursementTO reimbursementTO, Errors errors) {
    if (errors.hasErrors()) {
      ValidationError validationError = ValidationError.fromBindingErrors(errors);
      return new ResponseEntity<>(validationError, HttpStatus.OK);
    }
    ReimbursementTO reimbursementTO_return = reimbursementService.updateReimbursement(reimbursementTO);
    responseDTO = ResponseDTO.responseBuilder(200, "PR002", "/reimbursement", "reimbursement", reimbursementTO_return);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/list", method = RequestMethod.POST, name = "Reimbursement Master List->RIMCR")
  public ResponseEntity<?> getReimbursementList(@RequestBody PaginationCriteria paginationCriteria) {
    SearchResponseTO searchResponseTO = reimbursementService.getReimbursementList(paginationCriteria);
    if (searchResponseTO.getList() == null || searchResponseTO.getList().isEmpty()) {
      responseDTO = ResponseDTO.responseBuilder(200, "PR006", "/reimbursement", "reimbursement", searchResponseTO);
      return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }
    responseDTO = ResponseDTO.responseBuilder(200, "PR003", "/reimbursement", "reimbursement", searchResponseTO);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/{id}", method = RequestMethod.GET, name = "Reimbursement Master View->RIMCR")
  public ResponseEntity<?> getReimbursementById(@PathVariable Long id) {
    ReimbursementTO reimbursementTO = reimbursementService.getReimbursementById(id);
    if (reimbursementTO == null) {
      responseDTO = ResponseDTO.responseBuilder(200, "PR007", "/reimbursement", "reimbursement", null);
      return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }
    responseDTO = ResponseDTO.responseBuilder(200, "PR004", "/reimbursement", "reimbursement", reimbursementTO);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/delete", method = RequestMethod.DELETE, name = "Reimbursement Master Delete->RIMCR")
  public ResponseEntity<?> deleteReimbursement(@RequestParam(name = "reimbursementId") List<Long> reimbursementId) {
    reimbursementService.deleteReimbursement(reimbursementId);
    responseDTO = ResponseDTO.responseBuilder(200, "PR005", "/reimbursement", "reimbursement", reimbursementId);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }
}
