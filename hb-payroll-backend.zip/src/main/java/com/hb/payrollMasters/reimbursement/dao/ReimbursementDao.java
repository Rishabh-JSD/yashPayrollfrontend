package com.hb.payrollMasters.reimbursement.dao;

import com.hb.common.PaginationCriteria;
import com.hb.master.dto.CommonListTO;
import com.hb.payrollMasters.reimbursement.entity.ReimbursementBO;

import java.util.List;

public interface ReimbursementDao {

  ReimbursementBO addReimbursement(ReimbursementBO reimbursementTO);

  ReimbursementBO updateReimbursement(ReimbursementBO reimbursementTO);

  CommonListTO<ReimbursementBO> getReimbursementList(PaginationCriteria paginationCriteria);

  ReimbursementBO getReimbursementById(Long id);

  void deleteReimbursement(List<Long> id);

}
