package com.hb.payrollMasters.reimbursement.dto;

import com.hb.common.AuditTO;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ReimbursementTO extends AuditTO {

  private Long id;
  private String name;
  private boolean deleteFlag;

}
