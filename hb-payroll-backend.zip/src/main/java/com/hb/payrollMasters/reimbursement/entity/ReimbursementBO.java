package com.hb.payrollMasters.reimbursement.entity;

import com.hb.common.Audit;
import com.hb.common.TABLES;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name = TABLES.REIMBURSEMENT_MASTER)
public class ReimbursementBO extends Audit {

  private static final long serialVersionUID = -8932503480398863902L;

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "id", updatable = false)
  private Long id;

  @Column(name = "name")
  private String name;

  @Column(name = "delete_flag")
  private boolean deleteFlag;

}
