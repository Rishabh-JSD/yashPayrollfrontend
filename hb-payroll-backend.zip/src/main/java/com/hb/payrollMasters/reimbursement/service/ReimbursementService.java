package com.hb.payrollMasters.reimbursement.service;

import com.hb.common.PaginationCriteria;
import com.hb.common.SearchResponseTO;
import com.hb.payrollMasters.reimbursement.dto.ReimbursementTO;

import java.util.List;

public interface ReimbursementService {

  ReimbursementTO addReimbursement(ReimbursementTO reimbursementTO);

  ReimbursementTO updateReimbursement(ReimbursementTO reimbursementTO);

  SearchResponseTO getReimbursementList(PaginationCriteria paginationCriteria);

  ReimbursementTO getReimbursementById(Long id);

  void deleteReimbursement(List<Long> reimbursementId);
}
