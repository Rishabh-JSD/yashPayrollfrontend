package com.hb.payrollMasters.reimbursement.validator;

import com.hb.common.PaginationCriteria;
import com.hb.payrollMasters.reimbursement.controller.ReimbursementController;
import com.hb.payrollMasters.reimbursement.dto.ReimbursementTO;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.ControllerAdvice;

@ControllerAdvice(assignableTypes = ReimbursementController.class)
public class ReimbursementValidator implements Validator {

  @Override
  public boolean supports(Class<?> aClass) {
    boolean support = ReimbursementTO.class.equals(aClass);
    if (!support) {
      support = PaginationCriteria.class.equals(aClass);
    }
    return support;
  }

  @Override
  public void validate(Object o, Errors errors) {
    ReimbursementTO reimbursementTO = (ReimbursementTO) o;

//    ValidationUtils.rejectIfEmptyOrWhitespace(errors, "name", "PMS001E", APP_MSG.MESSAGE.get("PR001E"));

  }
}
