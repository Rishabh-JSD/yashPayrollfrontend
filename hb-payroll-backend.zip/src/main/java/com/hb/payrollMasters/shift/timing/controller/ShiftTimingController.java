package com.hb.payrollMasters.shift.timing.controller;

import com.hb.common.PaginationCriteria;
import com.hb.common.ResponseDTO;
import com.hb.common.SearchResponseTO;
import com.hb.common.ValidationError;
import com.hb.payrollMasters.shift.timing.dto.ShiftTimingTO;
import com.hb.payrollMasters.shift.timing.service.ShiftTimingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/shift-timing")
public class ShiftTimingController {

  @Autowired
  private Validator shiftTimingValidator;

  @Autowired
  private ShiftTimingService shiftTimingService;

  private ResponseDTO responseDTO;

  @InitBinder
  private void initBinder(WebDataBinder binder) {
    binder.setValidator(shiftTimingValidator);
  }

  @RequestMapping(value = "/add", method = RequestMethod.POST, name = "Shift Timing Master Add->STMCR")
  public ResponseEntity<?> addShiftTiming(@Valid @RequestBody ShiftTimingTO shiftTimingTO, Errors errors) {
    if (errors.hasErrors()) {
      ValidationError validationError = ValidationError.fromBindingErrors(errors);
      return new ResponseEntity<>(validationError, HttpStatus.OK);
    }
    ShiftTimingTO shiftTimingTO_return = shiftTimingService.addShiftTiming(shiftTimingTO);
    responseDTO = ResponseDTO.responseBuilder(200, "PR001", "/shift-timing", "shiftTiming", shiftTimingTO_return);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/update", method = RequestMethod.POST, name = "Shift Timing Master Update->STMCR")
  public ResponseEntity<?> updateShiftTiming(@Valid @RequestBody ShiftTimingTO shiftTimingTO, Errors errors) {
    if (errors.hasErrors()) {
      ValidationError validationError = ValidationError.fromBindingErrors(errors);
      return new ResponseEntity<>(validationError, HttpStatus.OK);
    }
    ShiftTimingTO shiftTimingTO_return = shiftTimingService.updateShiftTiming(shiftTimingTO);
    responseDTO = ResponseDTO.responseBuilder(200, "PR002", "/shift-timing", "shiftTiming", shiftTimingTO_return);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/list", method = RequestMethod.POST, name = "Shift Timing Master List->STMCR")
  public ResponseEntity<?> getShiftTimingList(@RequestBody PaginationCriteria paginationCriteria) {
    SearchResponseTO searchResponseTO = shiftTimingService.getShiftTimingList(paginationCriteria);
    if (searchResponseTO.getList() == null || searchResponseTO.getList().isEmpty()) {
      responseDTO = ResponseDTO.responseBuilder(200, "PR006", "/shift-timing", "shiftTiming", searchResponseTO);
      return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }
    responseDTO = ResponseDTO.responseBuilder(200, "PR003", "/shift-timing", "shiftTiming", searchResponseTO);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/{id}", method = RequestMethod.GET, name = "Shift Timing Master View->STMCR")
  public ResponseEntity<?> getShiftTimingById(@PathVariable Long id) {
    ShiftTimingTO shiftTimingTO = shiftTimingService.getShiftTimingById(id);
    if (shiftTimingTO == null) {
      responseDTO = ResponseDTO.responseBuilder(200, "PR007", "/shift-timing", "shiftTiming", null);
      return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }
    responseDTO = ResponseDTO.responseBuilder(200, "PR004", "/shift-timing", "shiftTiming", shiftTimingTO);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }
  @RequestMapping(value = "/delete", method = RequestMethod.DELETE, name = "Shift Timing Master Delete->STMCR")
  public ResponseEntity<?> deleteShiftTiming(@RequestParam(name = "shiftTimingId") List<Long> shiftTimingId) {
    shiftTimingService.deleteShiftTiming(shiftTimingId);
    responseDTO = ResponseDTO.responseBuilder(200, "PR005", "/shift-timing", "shiftTiming", shiftTimingId);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }
}
