package com.hb.payrollMasters.shift.timing.dao;

import com.hb.common.PaginationCriteria;
import com.hb.master.dto.CommonListTO;
import com.hb.payrollMasters.shift.timing.entity.ShiftTimingBO;

import java.util.List;

public interface ShiftTimingDao {

  ShiftTimingBO addShiftTiming(ShiftTimingBO shiftTimingTO);

  ShiftTimingBO updateShiftTiming(ShiftTimingBO shiftTimingTO);

  CommonListTO<ShiftTimingBO> getShiftTimingList(PaginationCriteria paginationCriteria);

  ShiftTimingBO getShiftTimingById(Long id);

  void deleteShiftTiming(List<Long> id);

}
