package com.hb.payrollMasters.shift.timing.dto;

import com.hb.common.AuditTO;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.Date;

@Getter
@Setter
public class ShiftTimingTO extends AuditTO {

  private Long id;
  private Long shiftTypeId;
  private String shiftTypeName;
  private Date startTime;
  private Date endTime;
  private BigDecimal workingHours;
  private boolean deleteFlag;

}
