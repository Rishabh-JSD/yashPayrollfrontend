package com.hb.payrollMasters.shift.timing.entity;

import com.hb.common.Audit;
import com.hb.common.TABLES;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;

@Getter
@Setter
@Entity
@Table(name = TABLES.SHIFT_TIMING_MASTER)
public class ShiftTimingBO extends Audit {

  private static final long serialVersionUID = 94344316735395982L;

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "id", updatable = false)
  private Long id;

  @Column(name = "shift_type_id")
  private Long shiftTypeId;

  @Column(name = "start_time")
  private Date startTime;

  @Column(name = "end_time")
  private Date endTime;

  @Column(name = "working_hours")
  private BigDecimal workingHours;

  @Column(name = "delete_flag")
  private boolean deleteFlag;


}
