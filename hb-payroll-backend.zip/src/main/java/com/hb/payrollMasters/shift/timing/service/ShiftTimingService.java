package com.hb.payrollMasters.shift.timing.service;

import com.hb.common.PaginationCriteria;
import com.hb.common.SearchResponseTO;
import com.hb.payrollMasters.shift.timing.dto.ShiftTimingTO;

import java.util.List;

public interface ShiftTimingService {

  ShiftTimingTO addShiftTiming(ShiftTimingTO shiftTimingTO);

  ShiftTimingTO updateShiftTiming(ShiftTimingTO shiftTimingTO);

  SearchResponseTO getShiftTimingList(PaginationCriteria paginationCriteria);

  ShiftTimingTO getShiftTimingById(Long id);

  void deleteShiftTiming(List<Long> shiftTimingId);
}
