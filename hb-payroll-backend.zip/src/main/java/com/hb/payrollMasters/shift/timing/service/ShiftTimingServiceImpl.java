package com.hb.payrollMasters.shift.timing.service;

import com.hb.common.MapperService;
import com.hb.common.PaginationCriteria;
import com.hb.common.SearchResponseTO;
import com.hb.master.dto.CommonListTO;
import com.hb.master.service.UserService;
import com.hb.payrollMasters.shift.timing.dao.ShiftTimingDao;
import com.hb.payrollMasters.shift.timing.dto.ShiftTimingTO;
import com.hb.payrollMasters.shift.timing.entity.ShiftTimingBO;
import com.hb.payrollMasters.shift.type.service.ShiftTypeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;

@Service
@Transactional
public class ShiftTimingServiceImpl implements ShiftTimingService {

  @Autowired
  private ShiftTimingDao shiftTimingDao;

  @Autowired
  private MapperService mapperService;

  @Autowired
  private ShiftTypeService shiftTypeService;

  @Autowired
  private UserService userService;

  @Override
  public ShiftTimingTO addShiftTiming(ShiftTimingTO shiftTimingTO) {
    ShiftTimingBO shiftTimingBO = mapperService.map(shiftTimingTO, ShiftTimingBO.class);
    return mapperService.map(shiftTimingDao.addShiftTiming(shiftTimingBO), ShiftTimingTO.class);
  }

  @Override
  public ShiftTimingTO updateShiftTiming(ShiftTimingTO shiftTimingTO) {
    ShiftTimingBO shiftTimingBO = mapperService.map(shiftTimingTO, ShiftTimingBO.class);
    return mapperService.map(shiftTimingDao.updateShiftTiming(shiftTimingBO), ShiftTimingTO.class);
  }

  @Override
  @Transactional(Transactional.TxType.NOT_SUPPORTED)
  public SearchResponseTO getShiftTimingList(PaginationCriteria paginationCriteria) {
    SearchResponseTO searchResponseTO = new SearchResponseTO();
    CommonListTO<ShiftTimingBO> commonListTO = shiftTimingDao.getShiftTimingList(paginationCriteria);

    List<ShiftTimingTO> shiftTimingTOS = null;
    if (commonListTO.getDataList() != null && !commonListTO.getDataList().isEmpty()) {
      shiftTimingTOS = new ArrayList<>();
      for (ShiftTimingBO shiftTimingBO : commonListTO.getDataList()) {
        ShiftTimingTO shiftTimingTO = mapperService.map(shiftTimingBO, ShiftTimingTO.class);
        if (shiftTimingTO.getShiftTypeId() != null) {
          shiftTimingTO.setShiftTypeName(shiftTypeService.getShiftTypeById(shiftTimingTO.getShiftTypeId()).getName());
        }
        if (shiftTimingTO.getCreatedBy() != null) {
          shiftTimingTO.setCreatedByName(userService.getUserById(shiftTimingTO.getCreatedBy()).getName());
        }
        if (shiftTimingTO.getUpdatedBy() != null) {
          shiftTimingTO.setUpdatedByName(userService.getUserById(shiftTimingTO.getUpdatedBy()).getName());
        }
        shiftTimingTOS.add(shiftTimingTO);
      }
    }
    searchResponseTO.setList(shiftTimingTOS);
    searchResponseTO.setPageCount(commonListTO.getPageCount());
    searchResponseTO.setTotalRowCount(commonListTO.getTotalRow().intValue());
    return searchResponseTO;
  }

  @Override
  @Transactional(Transactional.TxType.NOT_SUPPORTED)
  public ShiftTimingTO getShiftTimingById(Long id) {
    return mapperService.map(shiftTimingDao.getShiftTimingById(id), ShiftTimingTO.class);
  }

  @Override
  public void deleteShiftTiming(List<Long> id) {
    shiftTimingDao.deleteShiftTiming(id);
  }
}
