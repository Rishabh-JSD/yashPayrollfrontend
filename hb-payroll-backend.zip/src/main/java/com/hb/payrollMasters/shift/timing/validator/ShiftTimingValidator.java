package com.hb.payrollMasters.shift.timing.validator;

import com.hb.common.PaginationCriteria;
import com.hb.payrollMasters.shift.timing.controller.ShiftTimingController;
import com.hb.payrollMasters.shift.timing.dto.ShiftTimingTO;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.ControllerAdvice;

@ControllerAdvice(assignableTypes = ShiftTimingController.class)
public class ShiftTimingValidator implements Validator {

  @Override
  public boolean supports(Class<?> aClass) {
    boolean support = ShiftTimingTO.class.equals(aClass);
    if (!support) {
      support = PaginationCriteria.class.equals(aClass);
    }
    return support;
  }

  @Override
  public void validate(Object o, Errors errors) {
    ShiftTimingTO shiftTimingTO = (ShiftTimingTO) o;

//    ValidationUtils.rejectIfEmptyOrWhitespace(errors, "name", "PMS001E", APP_MSG.MESSAGE.get("PR001E"));

  }
}
