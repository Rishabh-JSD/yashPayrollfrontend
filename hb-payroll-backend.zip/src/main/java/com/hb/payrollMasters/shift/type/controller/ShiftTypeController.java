package com.hb.payrollMasters.shift.type.controller;

import com.hb.common.PaginationCriteria;
import com.hb.common.ResponseDTO;
import com.hb.common.SearchResponseTO;
import com.hb.common.ValidationError;
import com.hb.payrollMasters.shift.type.dto.ShiftTypeTO;
import com.hb.payrollMasters.shift.type.service.ShiftTypeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/shift-type")
public class ShiftTypeController {

  @Autowired
  private Validator shiftTypeValidator;

  @Autowired
  private ShiftTypeService shiftTypeService;

  private ResponseDTO responseDTO;

  @InitBinder
  private void initBinder(WebDataBinder binder) {
    binder.setValidator(shiftTypeValidator);
  }

  @RequestMapping(value = "/add", method = RequestMethod.POST, name = "Shift Type Master Add->STPCR")
  public ResponseEntity<?> addShiftType(@Valid @RequestBody ShiftTypeTO shiftTypeTO, Errors errors) {
    if (errors.hasErrors()) {
      ValidationError validationError = ValidationError.fromBindingErrors(errors);
      return new ResponseEntity<>(validationError, HttpStatus.OK);
    }
    ShiftTypeTO shiftTypeTO_return = shiftTypeService.addShiftType(shiftTypeTO);
    responseDTO = ResponseDTO.responseBuilder(200, "PR001", "/shift-type", "shiftType", shiftTypeTO_return);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/update", method = RequestMethod.POST, name = "Shift Type Master Update->STPCR")
  public ResponseEntity<?> updateShiftType(@Valid @RequestBody ShiftTypeTO shiftTypeTO, Errors errors) {
    if (errors.hasErrors()) {
      ValidationError validationError = ValidationError.fromBindingErrors(errors);
      return new ResponseEntity<>(validationError, HttpStatus.OK);
    }
    ShiftTypeTO shiftTypeTO_return = shiftTypeService.updateShiftType(shiftTypeTO);
    responseDTO = ResponseDTO.responseBuilder(200, "PR002", "/shift-type", "shiftType", shiftTypeTO_return);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/list", method = RequestMethod.POST, name = "Shift Type Master List->STPCR")
  public ResponseEntity<?> getShiftTypeList(@RequestBody PaginationCriteria paginationCriteria) {
    SearchResponseTO searchResponseTO = shiftTypeService.getShiftTypeList(paginationCriteria);
    if (searchResponseTO.getList() == null || searchResponseTO.getList().isEmpty()) {
      responseDTO = ResponseDTO.responseBuilder(200, "PR006", "/shift-type", "shiftType", searchResponseTO);
      return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }
    responseDTO = ResponseDTO.responseBuilder(200, "PR003", "/shift-type", "shiftType", searchResponseTO);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/{id}", method = RequestMethod.GET, name = "Shift Type Master View->STPCR")
  public ResponseEntity<?> getShiftTypeById(@PathVariable Long id) {
    ShiftTypeTO shiftTypeTO = shiftTypeService.getShiftTypeById(id);
    if (shiftTypeTO == null) {
      responseDTO = ResponseDTO.responseBuilder(200, "PR007", "/shift-type", "shiftType", null);
      return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }
    responseDTO = ResponseDTO.responseBuilder(200, "PR004", "/shift-type", "shiftType", shiftTypeTO);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }

  @RequestMapping(value = "/delete", method = RequestMethod.DELETE, name = "Shift Type Master Delete->STPCR")
  public ResponseEntity<?> deleteShiftType(@RequestParam(name = "shiftTypeId") List<Long> shiftTypeId) {
    shiftTypeService.deleteShiftType(shiftTypeId);
    responseDTO = ResponseDTO.responseBuilder(200, "PR005", "/shift-type", "shiftType", shiftTypeId);
    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
  }
}
