package com.hb.payrollMasters.shift.type.dao;

import com.hb.common.PaginationCriteria;
import com.hb.master.dto.CommonListTO;
import com.hb.payrollMasters.shift.type.entity.ShiftTypeBO;

import java.util.List;

public interface ShiftTypeDao {

  ShiftTypeBO addShiftType(ShiftTypeBO shiftTypeTO);

  ShiftTypeBO updateShiftType(ShiftTypeBO shiftTypeTO);

  CommonListTO<ShiftTypeBO> getShiftTypeList(PaginationCriteria paginationCriteria);

  ShiftTypeBO getShiftTypeById(Long id);

  void deleteShiftType(List<Long> id);

}
