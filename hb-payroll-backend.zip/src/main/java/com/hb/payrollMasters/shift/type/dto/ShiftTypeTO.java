package com.hb.payrollMasters.shift.type.dto;

import com.hb.common.AuditTO;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ShiftTypeTO extends AuditTO {

  private Long id;
  private String name;
  private boolean deleteFlag;

}
