package com.hb.payrollMasters.shift.type.service;

import com.hb.common.PaginationCriteria;
import com.hb.common.SearchResponseTO;
import com.hb.payrollMasters.shift.type.dto.ShiftTypeTO;

import java.util.List;

public interface ShiftTypeService {

  ShiftTypeTO addShiftType(ShiftTypeTO shiftTypeTO);

  ShiftTypeTO updateShiftType(ShiftTypeTO shiftTypeTO);

  SearchResponseTO getShiftTypeList(PaginationCriteria paginationCriteria);

  ShiftTypeTO getShiftTypeById(Long id);

  void deleteShiftType(List<Long> shiftTypeId);
}
