package com.hb.payrollMasters.shift.type.service;

import com.hb.common.MapperService;
import com.hb.common.PaginationCriteria;
import com.hb.common.SearchResponseTO;
import com.hb.master.dto.CommonListTO;
import com.hb.master.service.UserService;
import com.hb.payrollMasters.shift.type.dao.ShiftTypeDao;
import com.hb.payrollMasters.shift.type.dto.ShiftTypeTO;
import com.hb.payrollMasters.shift.type.entity.ShiftTypeBO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;

@Service
@Transactional
public class ShiftTypeServiceImpl implements ShiftTypeService {

  @Autowired
  private ShiftTypeDao shiftTypeDao;

  @Autowired
  private MapperService mapperService;

  @Autowired
  private UserService userService;

  @Override
  public ShiftTypeTO addShiftType(ShiftTypeTO shiftTypeTO) {
    ShiftTypeBO shiftTypeBO = mapperService.map(shiftTypeTO, ShiftTypeBO.class);
    return mapperService.map(shiftTypeDao.addShiftType(shiftTypeBO), ShiftTypeTO.class);
  }

  @Override
  public ShiftTypeTO updateShiftType(ShiftTypeTO shiftTypeTO) {
    ShiftTypeBO shiftTypeBO = mapperService.map(shiftTypeTO, ShiftTypeBO.class);
    return mapperService.map(shiftTypeDao.updateShiftType(shiftTypeBO), ShiftTypeTO.class);
  }

  @Override
  @Transactional(Transactional.TxType.NOT_SUPPORTED)
  public SearchResponseTO getShiftTypeList(PaginationCriteria paginationCriteria) {
    SearchResponseTO searchResponseTO = new SearchResponseTO();
    CommonListTO<ShiftTypeBO> commonListTO = shiftTypeDao.getShiftTypeList(paginationCriteria);

    List<ShiftTypeTO> shiftTypeTOS = null;
    if (commonListTO.getDataList() != null && !commonListTO.getDataList().isEmpty()) {
      shiftTypeTOS = new ArrayList<>();
      for (ShiftTypeBO shiftTypeBO : commonListTO.getDataList()) {
        ShiftTypeTO shiftTypeTO = mapperService.map(shiftTypeBO, ShiftTypeTO.class);
        if (shiftTypeTO.getCreatedBy() != null) {
          shiftTypeTO.setCreatedByName(userService.getUserById(shiftTypeTO.getCreatedBy()).getName());
        }
        if (shiftTypeTO.getUpdatedBy() != null) {
          shiftTypeTO.setUpdatedByName(userService.getUserById(shiftTypeTO.getUpdatedBy()).getName());
        }
        shiftTypeTOS.add(shiftTypeTO);
      }
    }
    searchResponseTO.setList(shiftTypeTOS);
    searchResponseTO.setPageCount(commonListTO.getPageCount());
    searchResponseTO.setTotalRowCount(commonListTO.getTotalRow().intValue());
    return searchResponseTO;
  }

  @Override
  @Transactional(Transactional.TxType.NOT_SUPPORTED)
  public ShiftTypeTO getShiftTypeById(Long id) {
    return mapperService.map(shiftTypeDao.getShiftTypeById(id), ShiftTypeTO.class);
  }

  @Override
  public void deleteShiftType(List<Long> id) {
    shiftTypeDao.deleteShiftType(id);
  }
}
