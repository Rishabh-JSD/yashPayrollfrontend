import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { UserLoggedOutGuard } from './core/guard/user-logged-out.guard';
import { CompanyLoggedInGuard } from './core/guard/company-logged-in.guard';
import { UserLoggedInGuard } from './core/guard/user-logged-in.guard';
import { CompanyLoggedOutGuard } from './core/guard/company-logged-out.guard';

const routes: Routes = [
  { path: '', redirectTo: 'auth', pathMatch: 'full' },
  { path: 'auth', loadChildren: () => import('./auth/auth.module').then(mod => mod.AuthModule), canActivate: [UserLoggedOutGuard] },
  { path: 'tenant', loadChildren: () => import('./tenant/tenant.module').then(mod => mod.TenantModule), canActivate: [UserLoggedInGuard, CompanyLoggedOutGuard] },
  { path: 'payroll', loadChildren: () => import('./payroll/payroll.module').then(mod => mod.PayrollModule), canActivate: [UserLoggedInGuard, CompanyLoggedInGuard] },
  { path: '**', redirectTo: 'auth', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)], exports: [RouterModule],
})
export class AppRoutingModule {
}
