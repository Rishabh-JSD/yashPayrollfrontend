import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HttpClientModule } from '@angular/common/http';
import { AppInitProvider, AppInitService } from './core/services/app-init.service';
import { HBHttpService } from './core/services/hb-http-service.service';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { SharedModule } from './shared/shared.module';
import { NgOptimizedImage } from '@angular/common';
import { RequestInterceptorProvider } from './core/services/request.interceptor';
import { ResponseInterceptorProvider } from './core/services/response.interceptor';

@NgModule({
  declarations: [AppComponent],
  imports: [BrowserModule, AppRoutingModule, HttpClientModule, BrowserAnimationsModule, SharedModule, NgOptimizedImage],
  providers: [HBHttpService, AppInitService, AppInitProvider, RequestInterceptorProvider, ResponseInterceptorProvider],
  bootstrap: [AppComponent],
  exports: []
})
export class AppModule {
}

export function initializeApp(appInitService: AppInitService): any {
  return () => appInitService.initializeApp();
}
