import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SignUpComponent } from './sign-up/sign-up.component';
import { LoginComponent } from './login/login.component';
import { ResetPasswordComponent } from './reset-password/reset-password.component';
import { RouterModule, Routes } from '@angular/router';
import { InputTextModule } from 'primeng/inputtext';
import { PasswordModule } from 'primeng/password';
import { DividerModule } from 'primeng/divider';
import { DialogModule } from 'primeng/dialog';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { VerifyOtpComponent } from './verify-otp/verify-otp.component';
import { VerifyMailComponent } from './verify-mail/verify-mail.component';
import { ResetPassSuccessComponent } from './reset-pass-success/reset-pass-success.component';
import { FormsModule } from '@angular/forms';
import { SharedModule } from '../shared/shared.module';
import { LayoutAuthComponent } from './layout-auth/layout-auth.component';

const routing: Routes = [
  {
    path: '',
    component: LayoutAuthComponent,
    children: [
      { path: '', redirectTo: 'login', pathMatch: 'full', },
      { path: 'login', component: LoginComponent, pathMatch: 'full', },
      { path: 'sign-up', component: SignUpComponent },
      { path: 'reset/:email', component: ResetPasswordComponent },
      { path: 'forgot-pass', component: ForgotPasswordComponent },
      { path: 'verify-otp', component: VerifyOtpComponent },
      { path: 'verify-mail', component: VerifyMailComponent },
    ],
  },
];

@NgModule({
  declarations: [SignUpComponent, LoginComponent, ResetPasswordComponent, ForgotPasswordComponent, VerifyOtpComponent, VerifyMailComponent, ResetPassSuccessComponent,
    LayoutAuthComponent],
  exports: [],
  imports: [CommonModule, RouterModule.forChild(routing), InputTextModule, PasswordModule, DividerModule, DialogModule, FormsModule, SharedModule]
})
export class AuthModule {
}
