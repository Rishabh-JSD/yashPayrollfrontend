import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HbErrorHandler, HbErrorHandlerData } from '../../shared/models/hb-error-handler';
import { ResetPassword } from '../models/reset-password';
import { HelperService } from 'src/app/helper/helper.service';
import { AuthService } from '../services/auth.service';
import { User } from '../models/user';
import { SnackBarPopupService } from '../../shared/services/snack-bar-popup.service';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.scss']
})
export class ForgotPasswordComponent implements OnInit, OnDestroy {
  body = document.getElementsByTagName('body')[0];
  hbErrorHandler = new HbErrorHandler();
  resetPassword = new ResetPassword();

  constructor(private router: Router, private authService: AuthService, private snackBarPopupService: SnackBarPopupService) {

  }

  ngOnInit(): void {
    this.body.classList.add('withoutHeaderSidebar');
  }

  ngOnDestroy(): void {
    this.body.classList.remove('withoutHeaderSidebar');
  }

  resetPasswordApi() {
    this.validateData();
    if (!this.hbErrorHandler.invalid) {
      this.authService.resetPassword(this.resetPassword).subscribe({
        next: value => {
          if (value.status === 200 && value.data && value.data.auth) {
            const user: User = value.data.auth;
            if (user) {
              this.snackBarPopupService.snackBar(value.message);
              this.router.navigate(['login']).then();
            } else {
              this.snackBarPopupService.snackBar('Something went wrong.');
            }
          } else if (value.status === 401) {
            this.snackBarPopupService.snackBar(value.customMessage);
          } else {
            this.snackBarPopupService.snackBar('Something went wrong.');
          }
        }, error: err => {
          this.snackBarPopupService.snackBar(err);
        }, complete: () => {
          console.log('Inside complete');
        }
      });
    }
  }

  validateData() {
    this.hbErrorHandler.clearErrors();
    // this.;
    this.hbErrorHandler.emptyCheck(this.resetPassword.email, 'email');
    if (!this.resetPassword.password) {
      this.hbErrorHandler.addError('Required', 'password');
    } else if (!HelperService.passwordValidator(this.resetPassword.password)) {
      this.hbErrorHandler.addError('Password should have min 8 characters, 1 uppercase letter, 1 lowercase letter & 1 numeric', 'password');
    }
    this.hbErrorHandler.emptyCheck(this.resetPassword.confirmPassword, 'confirmPassword');
    if (this.resetPassword.email && !HelperService.emailValidator(this.resetPassword.email)) {
      this.hbErrorHandler.addError('Invalid Email', 'email');
    }
    if (this.resetPassword.password && this.resetPassword.confirmPassword && this.resetPassword.password !== this.resetPassword.confirmPassword) {
      this.hbErrorHandler.addError('Password mismatch', 'confirmPassword');
    }
  }

  errorHandler(parentKey: string, childKey?: string, keyIndex?: number): HbErrorHandlerData {
    return this.hbErrorHandler.getErrorHandlerData(parentKey, childKey, keyIndex);
  }
}
