import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../services/auth.service';
import { HbErrorHandler, HbErrorHandlerData } from 'src/app/shared/models/hb-error-handler';
import { LoginRequest } from 'src/app/auth/models/login-request';
import { User } from '../models/user';
import { SnackBarPopupService } from '../../shared/services/snack-bar-popup.service';
import { LocalStorageService } from '../../core/services/local-storage-service';

@Component({
  selector: 'app-login', templateUrl: './login.component.html', styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit, OnDestroy {
  body = document.getElementsByTagName('body')[0];
  loginRequest: LoginRequest = new LoginRequest();
  hbErrorHandler = new HbErrorHandler();

  constructor(private router: Router, private authService: AuthService, private snackBarPopupService: SnackBarPopupService) {

  }

  ngOnInit(): void {
    this.body.classList.add('withoutHeaderSidebar');
  }

  ngOnDestroy(): void {
    this.body.classList.remove('withoutHeaderSidebar');
  }

  login() {
    this.validateData();
    if (!this.hbErrorHandler.invalid) {
      this.authService.loginUser(this.loginRequest).subscribe({
        next: value => {
          if (value.status === 200 && value.data && value.data.auth) {
            const user: User = value.data.auth;
            if (user.enabled) {
              if (user.token) {
                this.snackBarPopupService.snackBar('Logged in successfully.');
                LocalStorageService.setByKey('user', user.id);
                LocalStorageService.setToken(user.token);
                this.router.navigate(['/tenant']).then();
              } else {
                this.snackBarPopupService.snackBar('Something went wrong.');
              }
            } else {
              this.snackBarPopupService.snackBar('User Inactive.');
            }
          } else if (value.status === 401) {
            this.snackBarPopupService.snackBar(value.customMessage);
          } else {
            this.snackBarPopupService.snackBar('Something went wrong.');
          }
        }, error: err => {
          this.snackBarPopupService.snackBar(err);
        }, complete: () => {
          console.log('Inside complete');
        }
      });
    }
  }

  validateData() {
    this.hbErrorHandler.clearErrors();
    this.hbErrorHandler.emptyCheck(this.loginRequest.email, 'email');
    this.hbErrorHandler.emptyCheck(this.loginRequest.password, 'password');
  }

  errorHandler(parentKey: string, childKey?: string, keyIndex?: number): HbErrorHandlerData {
    return this.hbErrorHandler.getErrorHandlerData(parentKey, childKey, keyIndex);
  }
}
