export class ResetPassword {
  email: string;
  password: string;
  confirmPassword: string;
}
