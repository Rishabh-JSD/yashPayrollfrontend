import { Address } from "src/app/shared/models/address";

export class UserDetail{
    public id: number;
    public addressId: number;
    public tenantCreationLimit: number = 5;
    public industryId:number
    public phone:string;
    public secondaryEmail: string;
    public landline: string;
    public address: Address;
    public gender:string
}