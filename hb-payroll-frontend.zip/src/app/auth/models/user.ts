import { UserDetail } from './user-detail';

export class User {
  public name: string;
  public username: string;
  public password: string;
  public email: string;
  public enabled: number;
  public updatedAt: Date;
  public createdAt: Date;
  public userDetail: UserDetail = new UserDetail();
  public confirmPassword: string;
  public id:number
  public token: string;
  public oldPassword: string;
  public newPassword: string;
}
