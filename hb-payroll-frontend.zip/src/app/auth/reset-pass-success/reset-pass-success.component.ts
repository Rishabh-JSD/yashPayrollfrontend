import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-reset-pass-success',
  templateUrl: './reset-pass-success.component.html',
  styleUrls: ['./reset-pass-success.component.scss']
})
export class ResetPassSuccessComponent {
  @Input() display = false;


  businessCloseDialog() {
    this.display = false;
  }
}
