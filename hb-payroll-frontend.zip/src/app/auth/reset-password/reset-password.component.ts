import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.scss']
})
export class ResetPasswordComponent implements OnInit, OnDestroy {
  display: boolean = false;
  body = document.getElementsByTagName('body')[0];

  constructor(private router: Router, private route: ActivatedRoute) {
  }


  ngOnInit(): void {
    this.body.classList.add('withoutHeaderSidebar');
  }

  ngOnDestroy(): void {
    this.body.classList.remove('withoutHeaderSidebar');
  }

}
