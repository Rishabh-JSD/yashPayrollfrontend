import { Injectable } from '@angular/core';
import { LocalStorageService } from '../../core/services/local-storage-service';
import { HBHttpService } from '../../core/services/hb-http-service.service';
import { User } from '../models/user';
import { Observable } from 'rxjs';
import { LoginRequest } from 'src/app/auth/models/login-request';
import { ResetPassword } from '../models/reset-password';

@Injectable({ providedIn: 'root' })
export class AuthService {

  constructor(private hbHttpClient: HBHttpService) { }

  loginAuth(): boolean {
    return LocalStorageService.TOKEN != null;
  }

  companyAuth(): boolean {
    return LocalStorageService.TENANT != null;
  }

  registerUser(user: User): Observable<any> {
    return this.hbHttpClient.getResponse('payroll/register', this.hbHttpClient.POST, user, true);
  }

  loginUser(user: LoginRequest): Observable<any> {
    return this.hbHttpClient.getResponse('payroll/login', this.hbHttpClient.POST, user, true);
  }

  resetPassword(resetPassword: ResetPassword): Observable<any> {
    return this.hbHttpClient.getResponse('payroll/reset-password', this.hbHttpClient.POST, resetPassword, true);
  }
}
