import { Component, OnDestroy, OnInit } from '@angular/core';
import { HbErrorHandler, HbErrorHandlerData } from '../../shared/models/hb-error-handler';
import { User } from '../models/user';
import { Router } from '@angular/router';
import { AuthService } from '../services/auth.service';
import { SnackBarPopupService } from '../../shared/services/snack-bar-popup.service';
import { HelperService } from 'src/app/helper/helper.service';
import { ApiFieldValidError } from '../../core/models/api-response';

@Component({
  selector: 'app-sign-up', templateUrl: './sign-up.component.html', styleUrls: ['./sign-up.component.scss']
})
export class SignUpComponent implements OnInit, OnDestroy {
  body = document.getElementsByTagName('body')[0];
  hbErrorHandler = new HbErrorHandler();
  user = new User();

  constructor(private authService: AuthService, private router: Router, private snackBarPopupService: SnackBarPopupService) { }

  ngOnInit(): void {
    this.body.classList.add('withoutHeaderSidebar');
  }

  ngOnDestroy(): void {
    this.body.classList.remove('withoutHeaderSidebar');
  }

  signUp() {
    this.validateData();
    if (!this.hbErrorHandler.invalid) {
      this.authService.registerUser(this.user).subscribe({
        next: value => {
          if (value.status === 200 && value.data && value.data.auth) {
            this.snackBarPopupService.snackBar('Registered successfully.');
            this.router.navigate(['/login']).then();
          } else if (value.status === 401) {
            this.snackBarPopupService.snackBar(value.customMessage);
          } else {
            const fieldErrors: Array<ApiFieldValidError> = value.fieldErrors;
            if (fieldErrors && fieldErrors.length > 0) {
              this.apiError(fieldErrors);
            } else {
              this.snackBarPopupService.snackBar('Something went wrong.');
            }
          }
        }, error: err => {
          this.snackBarPopupService.snackBar(err);
        }, complete: () => {
          console.log('Inside complete');
        }
      });
    }
  }

  apiError(fieldErrors: Array<ApiFieldValidError>) {
    fieldErrors.forEach(error => {
      this.hbErrorHandler.addError(error.message, error.fieldName);
    });
  }

  validateData() {
    this.hbErrorHandler.clearErrors();
    this.hbErrorHandler.emptyCheck(this.user.name, 'name');
    this.hbErrorHandler.emptyCheck(this.user.username, 'username');
    this.hbErrorHandler.emptyCheck(this.user.email, 'email');
    if (this.user.email && !HelperService.emailValidator(this.user.email)) {
      this.hbErrorHandler.addError('Invalid Email', 'email');
    }
    if (!this.user.password) {
      this.hbErrorHandler.addError('Required', 'password');
    } else if (!HelperService.passwordValidator(this.user.password)) {
      this.hbErrorHandler.addError('Password should have min 8 characters, 1 uppercase letter, 1 lowercase letter & 1 numeric', 'password');
    }
    this.hbErrorHandler.emptyCheck(this.user.confirmPassword, 'confirmPassword');
    if (this.user.password && this.user.confirmPassword && this.user.password !== this.user.confirmPassword) {
      this.hbErrorHandler.addError('Password mismatch', 'confirmPassword');
    }
  }


  errorHandler(parentKey: string, childKey?: string, keyIndex?: number): HbErrorHandlerData {
    return this.hbErrorHandler.getErrorHandlerData(parentKey, childKey, keyIndex);
  }
}
