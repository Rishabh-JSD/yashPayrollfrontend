import { Component, OnDestroy, OnInit } from '@angular/core';

@Component({
  selector: 'app-mail-password',
  templateUrl: './verify-mail.component.html',
  styleUrls: ['./verify-mail.component.scss']
})
export class VerifyMailComponent implements OnInit, OnDestroy {
  body = document.getElementsByTagName('body')[0];

  ngOnInit(): void {
    this.body.classList.add('withoutHeaderSidebar');
  }

  ngOnDestroy(): void {
    this.body.classList.remove('withoutHeaderSidebar');
  }
}
