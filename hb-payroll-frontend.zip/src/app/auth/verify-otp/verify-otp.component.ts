import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-verify-otp',
  templateUrl: './verify-otp.component.html',
  styleUrls: ['./verify-otp.component.scss']
})
export class VerifyOtpComponent implements OnInit, OnDestroy {
  body = document.getElementsByTagName('body')[0];
  display: any;
  resendOtp: boolean = false;
  displayTimer: boolean = false;

  constructor(private router: Router, private route: ActivatedRoute) {
  }

  ngOnInit(): void {
    this.body.classList.add('withoutHeaderSidebar');
  }

  ngOnDestroy(): void {
    this.body.classList.remove('withoutHeaderSidebar');
  }

  start(minute: number) {
    this.displayTimer = true;
    this.resendOtp = false;
    let seconds = minute * 60;
    let textSec: any = '0';
    let statSec = 60;

    const prefix = minute < 10 ? '0' : '';

    const timer = setInterval(() => {
      seconds--;
      if (statSec != 0) {
        statSec--;
      } else {
        statSec = 59;
      }

      if (statSec < 10) {
        textSec = '0' + statSec;
      } else {
        textSec = statSec;
      }

      this.display = `${ prefix }${ Math.floor(seconds / 60) }:${ textSec }`;

      if (seconds == 0) {
        clearInterval(timer);
        this.resendOtp = true;
        this.displayTimer = false;
      }
    }, 1000);
  }
}

