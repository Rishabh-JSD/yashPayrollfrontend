import { environment } from '../../../environments/environment';

export const API_BASE_URL = environment.apiBaseUrl;
export const IS_PROD_MODE = environment.production;
