export class AppConst {
  public static STATUS = 'status';
  public static LOCK_DATE: string;
  public static decimalRoundLimit = 2;

  public static MONTH_LIST: string[] = ['', 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

  public static STATUS_CODE = {
    ACTIVE: 'ACTIVE',
    INACTIVE: 'INACTIVE'
  };

  public static MODULE_CODE = {
    EMPLOYEE: 'EMP',
  };

  public static MASTER_CODE = {
    ALLOWANCE: 'ALW',
    DEDUCTION: 'DED',
    REIMBURSEMENT: 'REIM',
    PAY_FREQUENCY: 'PAYF',
    DESIGNATION: 'DES',
    EMPLOYEE_TYPE: 'EMPT',
    EMPLOYEE_STATUS: 'EMPS',
    EMPLOYEE_LEVEL: 'EMPL',
    SHIFT_TYPE: 'SHIFTTYPE',
    SHIFT_TIMING: 'SHIFTTIME',
    DOCUMENT_TYPE: 'DOCTYPE',
    DOCUMENT_CATEGORY: 'DOCCAT'
  };

  public static ATTENDANCE_LEAVE_TYPE = {
    LEAVE_TYPE: 'LT',
    ATTENDANCE_TYPE: 'AT'
  }

  public static SAVE_TYPE = {
    SAVE_AS_DRAFT: 'DRAFT',
    SAVE_FOR_APPROVAL: 'APPROVED'
  }

  public static REIMBURSEMENT_CLAIM_STATUS = {
    DRAFT: 'RCDT',
    APPROVED: 'RCAP',
    REJECTED: 'RCRT',
    PENDING_APPROVAL: 'RCPAP',
    WITHDRAWN:'RCWN',
    DELETE:'RCDL'
  }

  public static DOC_CODE = {
    EMPLOYEE: 'EMP',
    REIMBURSEMENT_CLAIM:'RECLAIM'
  };
}
