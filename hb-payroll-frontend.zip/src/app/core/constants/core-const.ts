export class CoreConst {
  public static AUTH_TOKEN = 'Authorization';
  public static TENANT_HEADER = 'x-tenant';
  public static CONTENT_TYPE = 'Content-Type';
  public static ACCESS_CONTROL_ALLOW_ORIGIN = 'Access-Control-Allow-Origin';
  public static GET_VIA_POST = 'GET_VIA_POST';
}
