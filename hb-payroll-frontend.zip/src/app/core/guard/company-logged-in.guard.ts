import { inject } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivateFn, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { AuthService } from '../../auth/services/auth.service';

export const CompanyLoggedInGuard: CanActivateFn = (route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree => {
  if (inject(AuthService).companyAuth()) {
    return true;
  } else if (inject(AuthService).loginAuth()) {
    inject(Router).navigate(['tenant/list']);
    return false;
  } else {
    inject(Router).navigate(['auth']);
    return false;
  }
};
