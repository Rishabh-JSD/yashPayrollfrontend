import { inject } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivateFn, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { AuthService } from '../../auth/services/auth.service';

export const UserLoggedOutGuard: CanActivateFn = (route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree => {
  if (inject(AuthService).loginAuth() && inject(AuthService).companyAuth()) {
    inject(Router).navigate(['payroll']);
    return false;
  } else if (inject(AuthService).loginAuth() && !inject(AuthService).companyAuth()) {
    inject(Router).navigate(['tenant/list']);
    return false;
  } else {
    return true;
  }
};
