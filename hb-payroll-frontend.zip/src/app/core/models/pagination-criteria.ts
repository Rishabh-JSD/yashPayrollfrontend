export class PaginationCriteria {
  page: number;
  limit: number;
  firstLimit: number;
  endLimit: number;
  sortType: number;
  sortField: string;
  searchFor: string;
  id: number;
  departmentId: number;
  name: string;
  catCode: string;
  code: string;


  constructor(data: any = {}) {
    this.page = data.page || 1;
    this.limit = data.limit || 10;
  }
}
