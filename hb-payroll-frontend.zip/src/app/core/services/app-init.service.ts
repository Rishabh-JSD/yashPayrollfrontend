import { APP_INITIALIZER, Injectable } from '@angular/core';
import { LocalStorageService } from './local-storage-service';
import { environment } from '../../../environments/environment';
import { initializeApp } from '../../app.module';

@Injectable()
export class AppInitService {
  cmpUUID: string[] | undefined;

  constructor() {}

  initializeApp(): Promise<any> {
    this.cmpUUID = window.location.href.toString().split('?');
    return new Promise((resolve, reject) => {
      // LocalStorageService.clearEveryThing();
      if (environment.production) {
        // Live Configuration
        // LocalStorageService.setToken(environment.token);
        // LocalStorageService.setTenant(environment.tenant);
        console.log('Production/Staging');
        resolve(true);
      } else {
        // Local Configuration
        LocalStorageService.setToken(environment.token);
        LocalStorageService.setTenant(environment.tenant);
        console.log('Local');
        resolve(true);
      }
    });
  }
}

export const AppInitProvider = [
  {
    provide: APP_INITIALIZER,
    useFactory: initializeApp,
    deps: [AppInitService],
    multi: true,
  },
];
