import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { catchError, map } from 'rxjs/operators';
import { API_BASE_URL } from '../constants/app-config';
import { Observable, throwError } from 'rxjs';
import { LocalStorageService } from './local-storage-service';
import { ApiResponse } from '../models/api-response';
import { CoreConst } from '../constants/core-const';
import { PopupService } from '../../shared/services/popup.service';
import { HBLoaderService } from '../../shared/services/hb-loader.service';

export type HttpRequestType = 'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH' | 'GET_VIA_POST';

@Injectable()
export class HBHttpService {
  readonly GET = 'GET';
  readonly POST = 'POST';
  readonly GET_VIA_POST = 'GET_VIA_POST';
  readonly PUT = 'PUT';
  readonly DELETE = 'DELETE';

  apiUrl = '';

  constructor(private httpClient: HttpClient, private router: Router) {}

  static get checkInternetConnection(): boolean {
    if (navigator.onLine) {
      return true;
    } else {
      PopupService.failedAlert('', 'No Internet Connection');
      return false;
    }
  }

  getResponse(secondUrl: string, method: HttpRequestType, data: any = null, masterFlag: boolean = false): Observable<ApiResponse> | any {
    this.apiUrl = API_BASE_URL + secondUrl;

    let headers = new HttpHeaders();
    headers = headers.append(CoreConst.CONTENT_TYPE, 'application/json; charset=utf-8');
    if (LocalStorageService.TOKEN) {
      headers = headers.append(CoreConst.AUTH_TOKEN, 'Bearer ' + LocalStorageService.TOKEN);
    }
    if (LocalStorageService.TENANT && !masterFlag) {
      headers = headers.append(CoreConst.TENANT_HEADER, LocalStorageService.TENANT);
    }
    headers = headers.append(CoreConst.ACCESS_CONTROL_ALLOW_ORIGIN, '*');

    if (method === this.GET_VIA_POST) {
      headers = headers.append(CoreConst.GET_VIA_POST, 'TRUE');
    }
    const options = { headers };
    switch (method) {
      case this.GET: {
        return this.httpClient.get(this.apiUrl, options).pipe(map((res: any) => {
          return this.extractData(res, this.httpClient);
        }), catchError(this.handleError));
      }
      case this.POST: {
        return this.httpClient.post(this.apiUrl, data, options).pipe(map((res: any) => {
          return this.extractData(res, this.httpClient);
        }), catchError(this.handleError));
      }
      case this.GET_VIA_POST: {
        return this.httpClient.post(this.apiUrl, data, options).pipe(map((res: any) => {
          return this.extractData(res, this.httpClient);
        }), catchError(this.handleError));
      }
      case this.PUT: {
        return this.httpClient.put(this.apiUrl, data, options).pipe(map((res: any) => {
          return this.extractData(res, this.httpClient);
        }), catchError(this.handleError));
      }
      case this.DELETE: {
        return this.httpClient.delete(this.apiUrl, options).pipe(map((res: any) => {
          return this.extractData(res, this.httpClient);
        }), catchError(this.handleError));
      }
    }
  }

  private extractData(res: any, httpLocal: HttpClient): any {
    const body = res.body;
    if (body?.status === 401) {
      PopupService.failedAlert('', 'Session out please login Again').then(() => {
        // window.location.href = Config.CLIENT_LOGIN_PAGE;
      });
    } else if (body?.status === 403) {
      // CommonService.setapiUrl(headerUrl);
      // CommonService.openAccessDeniedPopup(true);
    } else if (body?.status === 500) {
      PopupService.failedAlert('', body.message).then(() => {});
    }
    return res;
  }

  private handleError(error: any): Observable<any> {
    HBLoaderService.hideLoader();
    console.error('error', error);
    return throwError('Error Found');
  }
}
