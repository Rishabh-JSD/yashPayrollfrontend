export class LocalStorageService {

  public static get TOKEN(): string | null {
    return localStorage.getItem('auth-token');
  }

  public static get TENANT(): string | null {
    return localStorage.getItem('auth-tenant');
  }

  public static isToken(): boolean {
    return !!(this.TOKEN?.trim() && LocalStorageService.TENANT != null && LocalStorageService.TENANT?.trim);
  }

  public static clearEveryThing() {
    localStorage.clear();
  }

  public static setToken(token: string) {
    this.clearToken();
    if (token) {
      localStorage.setItem('auth-token', token);
    }
  }

  public static getAccountId(): string | null {
    return localStorage.getItem('accountId');
  }

  public static setAccountId(accountId: string) {
    localStorage.setItem('accountId', accountId);
  }

  public static clearToken() {
    localStorage.removeItem('auth-token');
  }

  public static setTenant(tenant: string) {
    this.clearTenant();
    if (tenant) {
      localStorage.setItem('auth-tenant', tenant);
    }
  }

  public static clearTenant() {
    localStorage.removeItem('auth-tenant');
  }

  public static setByKey(key: string, data: any): void {
    localStorage.setItem(key, data);
  }

  public static setJsonObjectsByKey(key: string, data: any): void {
    localStorage.setItem(key, JSON.stringify(data));
  }

  public static getCookie(cname: string) {
    const name = cname + '=';
    const decodedCookie = decodeURIComponent(document.cookie);
    const ca = decodedCookie.split(';');
    for (let el of ca) {
      while (el.charAt(0) === ' ') {
        el = el.substring(1);
      }
      if (el.indexOf(name) === 0) {
        return el.substring(name.length, el.length);
      }
    }
    return '';
  }

  public static setCookie(name: string, value: string) {
    let expires = '';
    const date = new Date();
    date.setTime(date.getTime() + (60 * 60 * 1000));
    expires = '; expires=' + date.toUTCString();
    document.cookie = name + '=' + (value || '') + expires + '; path=/';
  }

  public static deleteCookie(cookie_name: string) {
    const date = new Date();  // current date & time
    date.setTime(date.getTime() - 1);
    document.cookie = cookie_name += '=; expires=' + date.toUTCString();
  }

  public static getByKey(key: string): string | null {
    return localStorage.getItem(key);
  }

  public static getJsonObjectsByKey(key: string): string | null {
    const data = localStorage.getItem(key);
    if (data) {
      return JSON.parse(data);
    }
    return data;
  }

  public static getUser(): string | null {
    return this.getByKey('user');
  }

}
