import { Injectable } from '@angular/core';
import { HTTP_INTERCEPTORS, HttpErrorResponse, HttpEvent, HttpHandler, HttpInterceptor, HttpRequest, HttpResponse } from '@angular/common/http';
import { Observable, of, throwError } from 'rxjs';
import { catchError, finalize, tap } from 'rxjs/operators';
import { LocalStorageService } from './local-storage-service';

@Injectable()
export class ResponseInterceptor implements HttpInterceptor {

  constructor() {}

  intercept(request: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>> {
    const started = Date.now();
    const ok: string = 'ok';

    return next.handle(request).pipe(
      tap(evt => {
        if (evt instanceof HttpResponse) {
          if (evt.body && evt.body.status === 200) {
            console.log(evt.body);
          } else if (evt.body.status === 403) {
            LocalStorageService.clearEveryThing();
            window.location.reload();
          }
        }
      }),
      catchError((err: any) => {
        if (err instanceof HttpErrorResponse) {
          if (err.error) {
            LocalStorageService.clearEveryThing();
            window.location.reload();
            return of(null);
          }
        }
        return throwError(err);
      }),
      finalize(() => {
        console.log(`${ request.method } "${ request.urlWithParams }"${ ok } in ${ Date.now() - started } ms.`);
      })
    );
  }
}

export const ResponseInterceptorProvider = [
  {
    provide: HTTP_INTERCEPTORS,
    useClass: ResponseInterceptor,
    multi: true,
  },
];
