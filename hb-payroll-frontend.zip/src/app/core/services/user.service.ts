import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HBHttpService } from 'src/app/core/services/hb-http-service.service';
import { User } from '../../auth/models/user';

@Injectable({
  providedIn: 'root',
})
export class UserService {
  constructor(private hbHttpClient: HBHttpService) {}

  addUser(user: User): Observable<any> {
    return this.hbHttpClient.getResponse('user/add', this.hbHttpClient.POST, user, true);
  }


  updateUser(user: User): Observable<any> {
    return this.hbHttpClient.getResponse('user/update', this.hbHttpClient.PUT, user, true);
  }

  getUserList(): Observable<any> {
    return this.hbHttpClient.getResponse('user/list', this.hbHttpClient.GET_VIA_POST);
  }

  getUserById(id: number): Observable<any> {
    return this.hbHttpClient.getResponse(`user/get/${ id }`, this.hbHttpClient.GET);
  }
}
