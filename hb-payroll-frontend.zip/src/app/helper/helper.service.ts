import { AppConst } from '../core/constants/app-const';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class HelperService {
  public static mathRound(num: number): number {
    // return Math.round(num * 100) / 100;
    const decimalPoint = AppConst.decimalRoundLimit;
    return Math.round(num * Math.pow(10, decimalPoint)) / Math.pow(10, decimalPoint);
  }

  public static emailValidator(email: string) {
    // string@string.string
    return new RegExp('^\\S+@\\S+\\.\\S+$').test(email);
  }
  
  public static passwordValidator(password: string) {
    // The password should be a minimum of eight characters long
    // It has at least one lower case letter, one upper case letter, one number
    return new RegExp('^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9]).{8,}$').test(password);
  }

  public static validateMobile(mobileNumber) {
    return /^[+0]{0,1}[0-9]{0,10}[-]{0,1}[0-9]{10,20}$/.test(mobileNumber);
  }
}
