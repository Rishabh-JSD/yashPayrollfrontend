import { Component, EventEmitter, Input, OnInit, Output, TemplateRef, ViewChild } from '@angular/core';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import Swal from 'sweetalert2';
import { LeaveTypeListing } from 'src/app/payroll/leave/leave-type/leave-type';

@Component({
  selector: 'app-leave-type-modal',
  templateUrl: './leave-type-modal.component.html',
  styleUrls: ['./leave-type-modal.component.scss'],
})
export class LeaveTypeModalComponent implements OnInit {
  @ViewChild('addLeaveType') addLeaveType: TemplateRef<any>;
  @Output() leaveTypeListEvent = new EventEmitter();
  errorList = new Array<string>();
  isError: boolean = false;
  errorType: string = '';
  leaveType = new LeaveTypeListing();
  dialogRef: MatDialogRef<any>;

  constructor(public dialog: MatDialog) { }

  @Input()
  set openLeaveTypeModal(data: any) {
    if (data && !data.leaveTypeId) {
      this.leaveType = new LeaveTypeListing();
      this.isError = false;
      this.openModal(this.addLeaveType);
    }
    if (data && data.leaveTypeId) {
      this.openModal(this.addLeaveType, data.leaveTypeId);
    }
  }

  ngOnInit(): void {}

  openModal(template: TemplateRef<any>, leaveTypeId = null) {
    if (leaveTypeId) {
      //	this.getLeaveType(leaveTypeId);
    }
    this.dialogRef = this.dialog.open(template, {
      minHeight: '150px',
      width: '400px',

    });
  }

  // addUpdateLeaveType() {
  // 	if (this.validate()) {
  // 		if (!this.leaveType.id) {
  //       HBLoaderService.showLoader()
  // 			this.leaveTypeService.addLeaveType(this.leaveType).subscribe(response => {
  // 				console.log(response);
  // 				if (response.status === 200 && response.data && response.data.leaveType) {
  // 					this.confirmationPopup(response.message);
  //           HBLoaderService.hideLoader()
  // 				}
  // 			});
  // 		} else {
  //       HBLoaderService.showLoader()
  // 			this.leaveTypeService.updateLeaveType(this.leaveType).subscribe(response => {
  // 				console.log(response);
  // 				if (response.status === 200 && response.data && response.data.leaveType) {
  // 					this.confirmationPopup(response.message);
  //           HBLoaderService.hideLoader()
  // 				}
  // 			});
  // 		}
  // 	} else {
  // 		window.scrollTo(0, 0);
  // 		this.isError = true;
  //     HBLoaderService.hideLoader()
  // 	}
  // }

  // getLeaveType(id: any) {
  //   HBLoaderService.showLoader()
  // 	this.leaveTypeService.getLeaveType(id).subscribe(response => {
  // 		if (response.status === 200 && response.data && response.data.leaveType) {
  // 			this.leaveType = response.data.leaveType;
  //       HBLoaderService.hideLoader()
  // 		}
  // 	});
  // }

  validate(): boolean {
    this.errorType = 'Complete these fields:';
    this.errorList = new Array<string>();
    let isValid = true;

    // if (!this.leaveType.name) {
    // 	this.errorList.push('Name');
    // }

    if (this.errorList.length > 0) {
      isValid = false;
    }
    return isValid;
  }

  confirmationPopup(message: any) {
    Swal.fire({
      title: 'LeaveType',
      html: message,
      icon: 'success',
      allowOutsideClick: false,
      allowEscapeKey: false,
    }).then(() => {
      this.leaveTypeListEvent.emit();
      this.closeDialog();
    });
  }

  closeDialog(): void {
    if (this.dialogRef) {
      this.dialogRef.close();
    }
  }

}
