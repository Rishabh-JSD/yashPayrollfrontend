import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AppliedAdvanceComponent } from './applied-advance.component';

describe('AppliedAdvanceComponent', () => {
  let component: AppliedAdvanceComponent;
  let fixture: ComponentFixture<AppliedAdvanceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [AppliedAdvanceComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AppliedAdvanceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
