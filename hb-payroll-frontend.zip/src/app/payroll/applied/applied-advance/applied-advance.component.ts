import { Component, OnInit } from '@angular/core';
import { HbDataTableColumnOption } from '@hostbooks/hb-lib/hb-list-table/src/hb-list-table-columns';
import { AppliedAdvanceListing } from './applied-advance';

@Component({
  selector: 'app-applied-advance',
  templateUrl: './applied-advance.component.html',
  styleUrls: ['./applied-advance.component.scss']
})
export class AppliedAdvanceComponent implements OnInit {

  columns: HbDataTableColumnOption[] = [];
  data: AppliedAdvanceListing[] = [];
  total: number;
  dataSource = [
    {
      s_no: 2,
      check: '',
      requsOn: '10-08-2021',
      amt: '1000',
      install: '6',
      reason: 'personal',
    },

  ];

  constructor() { }

  ngOnInit(): void {
    this.data = this.dataSource;

    this.columns = [
      {
        header: 'S_No',
        columnData: (inv: AppliedAdvanceListing) => {
          return 's_no';
        },
        type: 'SR_NO'
      },
      {
        header: 'check',
        columnData: (inv: AppliedAdvanceListing) => {
          return 'check';
        },
        type: 'CHECK'
      },
      {
        header: 'RequsOn',
        columnData: (inv: AppliedAdvanceListing) => {
          return inv.requsOn;
        },
        type: 'DATE'
      },
      {
        header: 'Amt',
        columnData: (inv: AppliedAdvanceListing) => {
          return inv.amt;
        },
        type: 'NUMBER'
      },
      {
        header: 'Install',
        columnData: (inv: AppliedAdvanceListing) => {
          return inv.install;
        },
        type: 'NUMBER'
      },
      {
        header: 'Reason',
        columnData: (inv: AppliedAdvanceListing) => {
          return inv.reason;
        },
        type: 'TEXT'
      }
    ];
    this.total = this.data.length;
  }

}
