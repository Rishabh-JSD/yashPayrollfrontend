export class AppliedAdvanceListing {
  public s_no: any;
  public check: any;
  public requsOn: any;
  public amt: any;
  public install: any;
  public reason: any;
}
