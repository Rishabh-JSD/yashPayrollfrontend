import { Component, OnInit } from '@angular/core';
import { AppliedLeaveListing } from './applied-leave';
import { HbDataTableColumnOption } from '@hostbooks/hb-lib/hb-list-table/src/hb-list-table-columns';
import { HbDateFormatPipe } from '../../../shared/pipes/hb-date-format.pipe';

@Component({
  selector: 'app-applied-leave',
  templateUrl: './applied-leave.component.html',
  styleUrls: ['./applied-leave.component.scss'],
  providers: [HbDateFormatPipe]
})
export class AppliedLeaveComponent implements OnInit {
  columns: HbDataTableColumnOption[] = [];
  data: AppliedLeaveListing[] = [];
  total: number;
  dataSource = [
    {
      s_no: 1,
      check: '',
      leaveType: 'CL',
      from: '09-08-2021',
      to: '10-08-2021',
      noOfDays: '1',
      reason: 'Not Well',
    },
  ];

  constructor(private datePipe: HbDateFormatPipe) { }

  ngOnInit(): void {
    this.data = this.dataSource;
    this.total = this.data.length;
    this.columns = [
      {
        header: 's_no',
        columnData: (inv: AppliedLeaveListing) => {
          return 's_no';
        },
        type: 'SR_NO'
      },
      {
        header: 'check',
        columnData: (inv: AppliedLeaveListing) => {
          return 'check';
        },
        type: 'CHECK'
      },
      {
        header: 'leaveType',
        columnData: (inv: AppliedLeaveListing) => {
          return inv.leaveType;
        },
        type: 'TEXT'
      },
      {
        header: 'from',
        columnData: (inv: AppliedLeaveListing) => {
          return this.datePipe.transform(inv.from);
        },
        type: 'DATE'
      },
      {
        header: 'to',
        columnData: (inv: AppliedLeaveListing) => {
          return this.datePipe.transform(inv.to);
        },
        type: 'DATE'
      },
      {
        header: 'noOfDays',
        columnData: (inv: AppliedLeaveListing) => {
          return inv.noOfDays;
        },
        type: 'NUMBER'
      },
      {
        header: 'reason',
        columnData: (inv: AppliedLeaveListing) => {
          return inv.reason;
        },
        type: 'TEXT'
      },
    ];
  }

}
