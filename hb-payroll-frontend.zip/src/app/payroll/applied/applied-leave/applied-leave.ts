export class AppliedLeaveListing {
  public s_no: any;
  public check: any;
  public leaveType: any;
  public from: any;
  public to: any;
  public noOfDays: any;
  public reason: any;
}
