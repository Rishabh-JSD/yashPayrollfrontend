import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AppliedReimbursementComponent } from './applied-reimbursement.component';

describe('AppliedReimbursementComponent', () => {
  let component: AppliedReimbursementComponent;
  let fixture: ComponentFixture<AppliedReimbursementComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [AppliedReimbursementComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AppliedReimbursementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
