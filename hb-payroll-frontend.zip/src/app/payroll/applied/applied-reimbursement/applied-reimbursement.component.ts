import { Component, OnInit } from '@angular/core';
import { HbDataTableColumnOption } from '@hostbooks/hb-lib/hb-list-table/src/hb-list-table-columns';
import { AppliedReimbursementListing } from './applied-reimbursement';
import { HbDateFormatPipe } from '../../../shared/pipes/hb-date-format.pipe';

@Component({
  selector: 'app-applied-reimbursement',
  templateUrl: './applied-reimbursement.component.html',
  styleUrls: ['./applied-reimbursement.component.scss'],
  providers: [HbDateFormatPipe]
})
export class AppliedReimbursementComponent implements OnInit {
  columns: HbDataTableColumnOption[] = [];
  data: AppliedReimbursementListing[] = [];
  total: number;
  dataSource = [
    {
      s_no: 1,
      check: '',
      from: '09-08-2021',
      to: '10-08-2021',
      type: 'Food',
      des: 'Food',
      amt: '1000',
      img: '',
    },
  ];

  constructor(private datePipe: HbDateFormatPipe) { }

  ngOnInit(): void {
    this.data = this.dataSource;
    this.total = this.data.length;
    this.columns = [
      {
        header: 's_no',
        columnData: (inv: AppliedReimbursementListing) => {
          return 's_no';
        },
        type: 'SR_NO'
      },
      {
        header: 'check',
        columnData: (inv: AppliedReimbursementListing) => {
          return 'check';
        },
        type: 'CHECK'
      },
      {
        header: 'from',
        columnData: (inv: AppliedReimbursementListing) => {
          return this.datePipe.transform(inv.from);
        },
        type: 'DATE'
      },
      {
        header: 'to',
        columnData: (inv: AppliedReimbursementListing) => {
          return this.datePipe.transform(inv.to);
        },
        type: 'DATE'
      },
      {
        header: 'type',
        columnData: (inv: AppliedReimbursementListing) => {
          return inv.type;
        },
        type: 'TEXT'
      },
      {
        header: 'des',
        columnData: (inv: AppliedReimbursementListing) => {
          return inv.des;
        },
        type: 'TEXT'
      },
      {
        header: 'amt',
        columnData: (inv: AppliedReimbursementListing) => {
          return inv.amt;
        },
        type: 'NUMBER'
      },
      {
        header: 'img',
        columnData: (inv: AppliedReimbursementListing) => {
          return inv.img;
        },
        type: 'TEXT'
      },
    ];
  }
}
