export class AppliedReimbursementListing {
  public s_no: any;
  public check: any;
  public from: any;
  public to: any;
  public type: any;
  public des: any;
  public amt: any;
  public img: any;
}
