import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../../shared/shared.module';
import { AppliedReimbursementComponent } from './applied-reimbursement/applied-reimbursement.component';
import { AppliedAdvanceComponent } from './applied-advance/applied-advance.component';
import { AppliedLeaveComponent } from './applied-leave/applied-leave.component';

const routes: Routes = [

  { path: 'applied-reimburse', component: AppliedReimbursementComponent },
  { path: 'applied-advance', component: AppliedAdvanceComponent },
  { path: 'applied-leave', component: AppliedLeaveComponent },


  { path: '**', redirectTo: '', pathMatch: 'full' }
];

@NgModule({
  declarations: [
    AppliedReimbursementComponent,
    AppliedAdvanceComponent,
    AppliedLeaveComponent
  ],
  imports: [
    CommonModule,
    SharedModule,

    RouterModule.forChild(routes)
  ]
})
export class AppliedModule {
}
