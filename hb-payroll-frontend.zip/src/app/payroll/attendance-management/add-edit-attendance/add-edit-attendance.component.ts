import { Location } from '@angular/common';
import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { MasterOption } from '../../master-rules/common/models/masters-options';
import { MasterOptionService } from '../../master-rules/common/services/master-option.service';
import { HBLoaderService } from 'src/app/shared/services/hb-loader.service';
import { AppConst } from 'src/app/core/constants/app-const';
import { MasterSearchRequest } from '../../master-rules/master-search-request';
import { DropDownModel } from 'src/app/shared/models/hb-field-option';
import { HbErrorHandler, HbErrorHandlerData } from 'src/app/shared/models/hb-error-handler';
import { AttendanceSearchRequest } from '../modal/attendance-search-request';
import { EmployeeAttendanceService } from '../service/employee-attendance.service';

@Component({
  selector: 'app-add-edit-attendance',
  templateUrl: './add-edit-attendance.component.html',
  styleUrls: ['./add-edit-attendance.component.scss']
})
export class AddEditAttendanceComponent {

  editModal = false;
  tableData: any[];
  attendancedata: any[];
  payFrequency = new MasterOption();
  payFrequencyList: MasterOption[] = [];
  masterSearchRequest = new MasterSearchRequest();
  selectedPayFrequencyId: any;
  payFrequencyOption: DropDownModel[] = [];
  isDaillyOrWeeklyPayFrequency: boolean = false;
  startDate: any
  endDate: any
  selectedYear: any
  selectedMonth: any
  selectedYearError: boolean = false;
  selectedMonthError: boolean = false;
  hbErrorHandler = new HbErrorHandler();
  attendanceSearchRequest = new AttendanceSearchRequest()

  ngOnInit(): void {
    this.tableData = [{}];
    this.attendancedata = [{}];
    this.getPayFrequencyList();
  }

  constructor(private router: Router, 
    private _location: Location, 
    private masterOptionService: MasterOptionService,
    private attendanceService: EmployeeAttendanceService) { }

  editModalOpen() {
    this.editModal = !this.editModal;
  }

  import() {
    this.router.navigateByUrl('/payroll/importMaster/import?title=attendance');
  }

  back() {
    this._location.back();
  }

  getPayFrequencyList() {
    HBLoaderService.showLoader();
    this.masterSearchRequest.catCode = AppConst.MASTER_CODE.PAY_FREQUENCY;
    this.masterOptionService.getListMasterOption(this.masterSearchRequest).subscribe(response => {
      if (response.status === 200 && response.data && response.data.masterOption) {
        this.payFrequencyList = response.data.masterOption.list;
        this.setPayFrequencyDropDown();
        console.log(this.payFrequencyList);
      }
    });
    HBLoaderService.hideLoader();
  }

  setPayFrequencyDropDown() {
    this.payFrequencyOption = this.payFrequencyList.map(item => ({
      label: this.capitalizeFirstLetter(item.name) + " - " + item.code,
      id: item.id,
      code: item.code,
      value: undefined
    } as DropDownModel));
  }

  capitalizeFirstLetter(str: string): string {
    return str.charAt(0).toUpperCase() + str.slice(1).toLowerCase();
  }

  onPayFrequencyChange(selectedPayFrequencyId: any) {
    this.hbErrorHandler.clearErrors()
    this.selectedPayFrequencyId = selectedPayFrequencyId
    const filteredPayFrequency = this.payFrequencyList.filter(item => item.id === selectedPayFrequencyId);
    this.payFrequency = filteredPayFrequency[0];
    if (this.payFrequency) {
      if (this.payFrequency.name === "DAILY" || this.payFrequency.name === "WEEKLY") {
        this.isDaillyOrWeeklyPayFrequency = true;
      } else {
        this.isDaillyOrWeeklyPayFrequency = false;
        this.createPayFrequencyDateRange(this.payFrequency)
      }
    }
  }

  createPayFrequencyDateRange(payFrequency: MasterOption) {
    this.selectedMonthError = false
    this.selectedYearError = false
    if (this.selectedYear !== undefined && this.selectedMonth !== undefined) {
      if (this.selectedPayFrequencyId) {
        const selectedMonth = this.selectedMonth.getMonth();
        const selectedYear = this.selectedYear.getFullYear();
        const startDate = new Date(selectedYear, selectedMonth, payFrequency.startDay);
          const endDate = new Date(selectedYear, selectedMonth + 1 , payFrequency.startDay);
          endDate.setDate(endDate.getDate() - 1);
          this.startDate = startDate;
          this.endDate = endDate;               
      } else{
        this.hbErrorHandler.addError("PayFrequecy is Required", 'selectedPayFrequencyId');
      }
    } else {
      if(this.selectedYear == undefined){
        this.selectedYearError = true
      }
      if(this.selectedMonth == undefined){
        this.selectedMonthError = true
      }
    }
  }

  getEmployeeAttendanceList() {
    HBLoaderService.showLoader(); 
    this.attendanceSearchRequest.startDate = this.startDate   
    this.attendanceSearchRequest.endDate = this.endDate
    this.attendanceService.getEmployeeAttendanceList(this.attendanceSearchRequest).subscribe(response => {
      console.log(response)
      if (response.status === 200 && response.data && response.data.leaveType && response.data.leaveType.list) {          
      } 
    });
    HBLoaderService.hideLoader();
  }

  errorHandler(parentkey: string, childkey?: string, keyIndex?: number): HbErrorHandlerData {
    const hData = this.hbErrorHandler.getErrorHandlerData(parentkey, childkey, keyIndex);
    return hData;
  }

}
