import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AttendanceDashboardComponent } from './attendance-dashboard/attendance-dashboard.component';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../../shared/shared.module';
import { RegularisationComponent } from './regularisation/regularisation.component';
import { EmployeeAttendanceComponent } from './employee-attendance/employee-attendance.component';
import { AddEditAttendanceComponent } from './add-edit-attendance/add-edit-attendance.component';


const routes: Routes = [
  { path: '', component: AttendanceDashboardComponent },
  { path: 'apply-regularisation', component: RegularisationComponent },
  { path: 'employee-attendance', component: EmployeeAttendanceComponent },
  { path: 'add-edit-attendance', component: AddEditAttendanceComponent },
  { path: '**', redirectTo: '', pathMatch: 'full' }
];


@NgModule({
  declarations: [
    AttendanceDashboardComponent,
    RegularisationComponent,
    EmployeeAttendanceComponent,
    AddEditAttendanceComponent,
  ],
  imports: [
    CommonModule,
    SharedModule,
    RouterModule.forChild(routes),
  ]
})
export class AttendanceManagementModule {
}
