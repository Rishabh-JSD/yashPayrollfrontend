import { Component, ElementRef, ViewChild } from '@angular/core';
import { Location } from '@angular/common';
import { HbDataTableColumnOption } from '@hostbooks/hb-lib/hb-list-table/src/hb-list-table-columns';
import { AttendanceType } from '../modal/attendance-type';
import { LeaveTypeService } from '../../leave/service/leave-type.service';
import { HBLoaderService } from 'src/app/shared/services/hb-loader.service';
import { LeaveSearchRequest } from '../../leave/modal/leave-search-request';
import { HbErrorHandler, HbErrorHandlerData } from 'src/app/shared/models/hb-error-handler';
import Swal from 'sweetalert2';
import { Router } from '@angular/router';
import { AppConst } from 'src/app/core/constants/app-const';

@Component({
  selector: 'app-employee-attendance',
  templateUrl: './employee-attendance.component.html',
  styleUrls: ['./employee-attendance.component.scss']
})

export class EmployeeAttendanceComponent {

  columns: HbDataTableColumnOption[] = [];
  tableData: any [];
  attendanceTypes: AttendanceType[] = []
  data: any[] = [];
  total: number;
  attendanceModal = false;
  settingModal = false;
  editModal = false;
  dataSource = [];
  leaveSearchRequest = new LeaveSearchRequest();
  hbErrorHandler: HbErrorHandler = new HbErrorHandler();
  isError: boolean = false;
  errorMessage: string;

  constructor(private _location: Location, 
    private leaveTypeService: LeaveTypeService,
    private router: Router) { }


  ngOnInit(): void {
    this.getAttendanceTypeList()
    this.tableData = [{}];
    this.attendanceTypes = [
      {id: null, name: 'Present', code: '', type:AppConst.ATTENDANCE_LEAVE_TYPE.ATTENDANCE_TYPE, status: AppConst.STATUS_CODE.ACTIVE},
      {id: null, name: 'Absent', code: '', type:AppConst.ATTENDANCE_LEAVE_TYPE.ATTENDANCE_TYPE, status: AppConst.STATUS_CODE.ACTIVE},
      {id: null, name: 'Week Off', code: '', type:AppConst.ATTENDANCE_LEAVE_TYPE.ATTENDANCE_TYPE, status: AppConst.STATUS_CODE.ACTIVE},
      {id: null, name: 'Short Leave', code: '', type:AppConst.ATTENDANCE_LEAVE_TYPE.ATTENDANCE_TYPE, status: AppConst.STATUS_CODE.ACTIVE},
    ];
    this.data = this.dataSource;
    this.total = this.data.length;
    this.columns = [
      {
        header: 'Year',
        columnData: () => { },
        type: 'TEXT'
      },
      {
        header: 'Month',
        columnData: () => { },
        type: 'TEXT'
      },
      {
        header: 'Pay Frequency',
        columnData: () => { },
        type: 'TEXT'
      },
      {
        header: 'Start Date',
        columnData: () => { },
        type: 'DATE'
      },
      {
        header: 'End Date',
        columnData: () => { },
        type: 'DATE'
      },
      {
        header: 'Employee (Nos.)',
        columnData: () => { },
        type: 'NUMBER'
      },
    ];
  }

  back() {
    this._location.back();
  }
  // attendanceModalOpen() {
  //   this.attendanceModal = !this.attendanceModal;    
  // }

  settingModalOpen() {
    this.settingModal = !this.settingModal;
    this.hbErrorHandler.clearErrors();
    this.getAttendanceTypeList();
  }

  editModalOpen() {
    this.editModal = !this.editModal;
  }

  getAttendanceTypeList() {
    HBLoaderService.showLoader();
    this.leaveSearchRequest.type = AppConst.ATTENDANCE_LEAVE_TYPE.ATTENDANCE_TYPE;
    this.leaveTypeService.getLeaveTypeList(this.leaveSearchRequest).subscribe(response => {
      if (response.status === 200 && response.data && response.data.leaveType && response.data.leaveType.list) {  
        this.attendanceTypes = response.data.leaveType.list.length > 0 ? response.data.leaveType.list : this.attendanceTypes;
      } 
    });
    HBLoaderService.hideLoader();
  }

  addUpdateAttendanceTypes() {
    this.validateData();
    this.isError = false;
    const isAddattendanceType = this.attendanceTypes.filter(item => !item.id);
    if (!this.hbErrorHandler.invalid) {
      if (isAddattendanceType.length > 0) {
        debugger
        HBLoaderService.showLoader();
        this.leaveTypeService.addAttendanceTypes(this.attendanceTypes).subscribe(response => {
          if (response.status === 201 && response.data && response.data.leaveType) {
            this.confirmationPopup(response.message);
            this.settingModalOpen()
          } else if (response.status === 400 && response.fieldErrors.length != 0) {
            this.isError = true;
            this.errorMessage = response.fieldErrors[0].message;
            
          }
        });
        HBLoaderService.hideLoader();
      } else {
        HBLoaderService.showLoader()
        this.leaveTypeService.updateAttendanceTypes(this.attendanceTypes).subscribe(response => {
          if (response.status === 200 && response.data && response.data.leaveType) {
            this.confirmationPopup(response.message);
            this.settingModalOpen()
          } else if (response.status === 400 && response.fieldErrors.length != 0) {
            this.isError = true;
            this.errorMessage = response.fieldErrors[0].message;
          }
        });
        HBLoaderService.hideLoader();
      }
    } else {
      window.scrollTo(0, 0);
      HBLoaderService.hideLoader();
    }
  }

  validateData() {
    this.hbErrorHandler.clearErrors();
    this.attendanceTypes.forEach(attendanceType=>{
      this.hbErrorHandler.emptyCheck(attendanceType.code, 'code');
    })    
  }

  confirmationPopup(message: any) {
    Swal.fire({
      title: 'Attendance Types',
      html: message,
      icon: 'success',
      allowOutsideClick: false,
      allowEscapeKey: false,
    }).then(() => {
      this.router.navigateByUrl('/payroll/attendance-management/employee-attendance');
    });
  }

  errorHandler(parentkey: string, childkey?: string, keyIndex?: number): HbErrorHandlerData {
    const hData = this.hbErrorHandler.getErrorHandlerData(parentkey, childkey, keyIndex);
    return hData;
  }

  import(){
    this.router.navigateByUrl('/payroll/importMaster/import?title=attendance');
  }

}
