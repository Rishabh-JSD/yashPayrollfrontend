import { SearchRequest } from "src/app/shared/models/search-request";

export class AttendanceSearchRequest  extends SearchRequest{
    startDate: string;
    endDate: string
  }