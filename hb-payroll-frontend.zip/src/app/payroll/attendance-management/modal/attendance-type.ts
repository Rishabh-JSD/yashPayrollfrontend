export class AttendanceType {
    public id: number;
    public name: string;
    public code: string;
    public status: string;
    public type: string;
  }