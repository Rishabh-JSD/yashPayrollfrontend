import { Component, OnInit } from '@angular/core';
import { DropDownModel } from '../../../shared/models/hb-field-option';

@Component({
  selector: 'app-regularisation',
  templateUrl: './regularisation.component.html',
  styleUrls: ['./regularisation.component.scss']
})
export class RegularisationComponent implements OnInit {
  regularisationFor: DropDownModel[] = [
    { label: 'Option 1', code: 'Option 1', id: undefined, value: undefined },
  ];
  Reason: DropDownModel[] = [
    { label: 'Ajmer', code: 'Ajmer', id: undefined, value: undefined },
  ];
  Reporting: DropDownModel[] = [
    { label: 'Manager', code: 'Manager', id: undefined, value: undefined },
  ];
  CC: DropDownModel[] = [
    { label: 'CC', code: 'CC', id: undefined, value: undefined },
  ];

  constructor() { }

  ngOnInit(): void {
  }

}
