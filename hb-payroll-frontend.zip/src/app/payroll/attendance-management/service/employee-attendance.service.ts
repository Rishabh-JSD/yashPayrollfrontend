import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HBHttpService } from 'src/app/core/services/hb-http-service.service';

@Injectable({
  providedIn: 'root'
})
export class EmployeeAttendanceService {

  constructor(private hbHttpClient: HBHttpService) {}

  addEmployeeAttendance(data: any): Observable<any> {
    return this.hbHttpClient.getResponse('employee-attendance/add', this.hbHttpClient.POST, data);
  }

  updateEmployeeAttendance(data: any): Observable<any> {
    return this.hbHttpClient.getResponse('employee-attendance/update', this.hbHttpClient.POST, data);
  }

  getEmployeeAttendanceList(data: any): Observable<any> {
    return this.hbHttpClient.getResponse('employee-attendance/list', this.hbHttpClient.POST, data);
  }

  getEmployeeAttendanceById(id: any): Observable<any> {
    return this.hbHttpClient.getResponse(`employee-attendance/${ id }`, this.hbHttpClient.GET);
  }

  deleteEmployeeAttendance(id: any): Observable<any> {
    return this.hbHttpClient.getResponse('employee-attendance/delete?empAttendanceIdList=' + id, this.hbHttpClient.DELETE);
  }
}
