import { DatePipe, Location } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { BranchService } from '../../services/branch.service';
import { Branch } from '../../models/branch';
import { Component, OnInit } from '@angular/core';
import Swal from 'sweetalert2';
import { Address } from 'src/app/shared/models/address';
import { HBLoaderService } from '../../../../shared/services/hb-loader.service';
import { HbErrorHandler, HbErrorHandlerData } from 'src/app/shared/models/hb-error-handler';
import { MasterOptionService } from 'src/app/payroll/master-rules/common/services/master-option.service';
import { MasterOption } from 'src/app/payroll/master-rules/common/models/masters-options';


@Component({
  selector: 'app-add-branch',
  templateUrl: './add-branch.component.html',
  styleUrls: ['./add-branch.component.scss'],
  providers: [DatePipe]
})
export class AddBranchComponent implements OnInit {

  branch = new Branch();
  errorType: string = '';
  branchId: number;
  isEdit: boolean = false;
  hbErrorHandler = new HbErrorHandler();

  constructor(
    private _location: Location,
    private branchService: BranchService,
    private masterOptionService: MasterOptionService,
    private router: Router,
    private activatedRoute: ActivatedRoute,
  ) { }

  ngOnInit(): void {
    this.branch.address = new Address();
    this.editBranch();
  }

  back() {
    this._location.back();
  }

  editBranch() {
    this.activatedRoute.params.subscribe(params => {
      if (params['id']) {
        this.branchId = params['id'];
        this.getBranch();
        this.isEdit = true;
      }
    });
  }

  getBranch() {
    HBLoaderService.showLoader();
    this.branchService.getBranch(this.branchId).subscribe(response => {
      console.log(response);
      if (response.status === 200 && response.data && response.data.branch) {
        this.branch = response.data.branch;
      }
      HBLoaderService.hideLoader();
    },
    () => {
      HBLoaderService.hideLoader();
    }
    );
  }

  addUpdateBranch() {
    this.hbErrorHandler.clearErrors()
    this.validate();
    if (!this.hbErrorHandler.invalid) {
      if (!this.branch.id) {
        HBLoaderService.showLoader();
        this.branchService.addBranch(this.branch).subscribe(response => {
          console.log(response);
          if (response.status === 200 && response.data && response.data.branch) {
            this.confirmationPopup(response.message);
          }
          HBLoaderService.hideLoader();
        },
        () => {
          HBLoaderService.hideLoader();
        }
        );
      } else {
        HBLoaderService.showLoader();
        this.branchService.updateBranch(this.branch).subscribe(response => {
          console.log(response);
          if (response.status === 200 && response.data && response.data.branch) {
            this.confirmationPopup(response.message);
          }
          HBLoaderService.hideLoader();
        },
        () => {
          HBLoaderService.hideLoader();
        }
        );
      }
    } else {
      window.scrollTo(0, 0);
      HBLoaderService.hideLoader();
    }

  }

  setWorkingHours() {
    if (this.branch.shiftTimingId != null) {
      this.masterOptionService.getMasterOptionById(this.branch.shiftTimingId).subscribe(response => {
        console.log(response);
        if (response.status === 200 && response.data && response.data.masterOption) {
          let shiftTiming: MasterOption = response.data.masterOption;
          this.branch.workingHours = shiftTiming.workingHours;
        }
      });
    } else {
      this.branch.workingHours = null
    }
  }

  validate(): void {
    this.hbErrorHandler.emptyCheck(this.branch.name, 'name');
    this.hbErrorHandler.emptyCheck(this.branch.code, 'code');
    this.hbErrorHandler.emptyCheck(this.branch.shiftTypeId, 'operationalHours');
    this.hbErrorHandler.emptyCheck(this.branch.shiftTimingId, 'timing');
    if(this.branch.address){
      this.hbErrorHandler.emptyCheck(this.branch.address.addressOne , 'address.addressOne')
      this.hbErrorHandler.emptyCheck(this.branch.address.cityName , 'address.cityName')
      this.hbErrorHandler.emptyCheck(this.branch.address.stateName , 'address.stateName')
      this.hbErrorHandler.emptyCheck(this.branch.address.pincode , 'address.pincode')
      this.hbErrorHandler.emptyCheck(this.branch.address.countryName , 'address.countryName')
    }
  }

  confirmationPopup(message: any) {
    Swal.fire({
      title: 'Branch',
      html: message,
      icon: 'success',
      allowOutsideClick: false,
      allowEscapeKey: false,
    }).then(() => {
      this.router.navigateByUrl('/payroll/company/branch');
    });
  }

  errorHandler(parentkey: string, childkey?: string, keyIndex?: number): HbErrorHandlerData {
    const hData = this.hbErrorHandler.getErrorHandlerData(parentkey, childkey, keyIndex);
    return hData;
  }

}
