import { Branch } from '../../models/branch';
import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import { BranchService } from '../../services/branch.service';
import Swal from 'sweetalert2';
import { HbDataTableColumnOption } from '@hostbooks/hb-lib/hb-list-table/src/hb-list-table-columns';
import { Router } from '@angular/router';
import { HBLoaderService } from '../../../../shared/services/hb-loader.service';
import { CompanySearchRequest } from '../../company-search-request';

@Component({
  selector: 'app-branch-listing',
  templateUrl: './branch-listing.component.html',
  styleUrls: ['./branch-listing.component.scss'],
})
export class BranchListingComponent implements OnInit {

  companySearchRequest = new CompanySearchRequest()
  searchBranch;

  total: number;
  columns: HbDataTableColumnOption[] = [];
  data: Branch[] = [];

  constructor(private _location: Location, private branchService: BranchService, private router: Router) { }

  ngOnInit(): void {
    this.getBranchList();
    this.companySearchRequest.page = 1;
    this.companySearchRequest.limit = 10;
    this.branchColumns();
  }

  back() {
    this._location.back();
  }

  branchColumns(){
    this.columns = [
      {
        header: 'S. NO.',
        columnData: (inv: Branch) => {
        },
        type: 'SR_NO'
      },
      {
        header: 'Branch Name',
        columnData: (inv: Branch) => {
          return inv.name;
        },
        type: 'TEXT'
      },
      {
        header: 'Branch Head',
        columnData: (inv: Branch) => {
          return inv.headName;
        },
        type: 'TEXT'
      },
      {
        header: 'Total Employees (Nos.)',
        columnData: (inv: Branch) => {
          return inv.totalEmployees;
        },
        type: 'NUMBER'
      },
      {
        header: 'GSTIN',
        columnData: (inv: Branch) => {
          return inv.gstin;
        },
        type: 'TEXT'
      },
      {
        header: 'City',
        columnData: (inv: Branch) => {
          return inv.address.cityName;
        },
        type: 'TEXT'
      },
      {
        header: 'State',
        columnData: (inv: Branch) => {
          return inv.address.stateName;
        },
        type: 'TEXT'
      },
      {
        header: 'Actions',
        columnData: (inv: Branch) => {
        },
        type: 'ACTION',
        actionOptions: ['EDIT', 'DELETE']
      },
    ];
  }

  getBranchList() {
    HBLoaderService.showLoader();
    this.companySearchRequest.searchFor = this.searchBranch;
    this.branchService.getListBranch(this.companySearchRequest).subscribe(response => {
      console.log(response);
      if (response.status === 200 && response.data && response.data.branch) {
        this.data = response.data.branch.list;
        this.total = response.data.branch.totalRowCount;
      }
      HBLoaderService.hideLoader();
    },
    () => {
      HBLoaderService.hideLoader();
    }
    );
  }


  deleteBranch(id: number) {
    this.deleteConfirmationPopup().then(result => {
      if (result.value) {
        HBLoaderService.showLoader();
        this.branchService.deleteBranch(id).subscribe(response => {
          console.log(response);
          this.deletedConfirmationPopup(response.message, 'Branch');
          HBLoaderService.hideLoader();
        });
      }
    });
  }

  deleteConfirmationPopup() {
    return Swal.fire({
      title: 'Warning',
      text: 'Are you sure that you want to perform this action?',
      icon: 'question',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes',
      cancelButtonText: 'No',
      allowOutsideClick: false,
      allowEscapeKey: false,
    });
  }

  deletedConfirmationPopup(message, title) {
    Swal.fire({
      title: title,
      text: message,
      icon: 'success',
      allowOutsideClick: false,
      allowEscapeKey: false,
    }).then(result => {
      if (result.value) {
        this.getBranchList();
      }
    });
  }

  onAction(_event: any) {
    if (_event && _event.actionType && _event.data) {
      if (_event.actionType === 'DELETE') {
        this.deleteBranch(_event.data.id);
      }
      if (_event.actionType === 'EDIT') {
        this.router.navigate(['/payroll/company/edit-branch', _event.data.id]);
      }
    }
  }
}
