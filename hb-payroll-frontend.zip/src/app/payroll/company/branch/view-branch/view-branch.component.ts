import { Component, OnInit } from '@angular/core';

import { PaginationCriteria } from 'src/app/core/models/pagination-criteria';
import { Branch } from '../../models/branch';
import { BranchService } from '../../services/branch.service';
import { HBLoaderService } from '../../../../shared/services/hb-loader.service';

@Component({
  selector: 'app-view-branch',
  templateUrl: './view-branch.component.html',
  styleUrls: ['./view-branch.component.scss'],
})
export class ViewBranchComponent implements OnInit {
  branchList = new Array<Branch>();

  constructor(private branchService: BranchService) {}

  ngOnInit(): void {
    this.getBranchList();
  }

  getBranchList() {
    // HBLoaderService.showLoader();
    let paginationCriteriaBranch = new PaginationCriteria();
    this.branchService.getListBranch(paginationCriteriaBranch).subscribe(response => {
      console.log(response);
      if (response.status === 200 && response.data && response.data.branch) {
        this.branchList = response.data.branch.list;
      }
      HBLoaderService.hideLoader();
    },
    () => {
      HBLoaderService.hideLoader();
    }
    );
  }
}
