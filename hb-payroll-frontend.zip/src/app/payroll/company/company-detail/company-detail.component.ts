import { Location } from '@angular/common';
import { Company } from '../models/company';
import { Component, Input, OnInit } from '@angular/core';
import { Address } from 'src/app/shared/models/address';
import { HbErrorHandler, HbErrorHandlerData } from 'src/app/shared/models/hb-error-handler';

@Component({
  selector: 'app-company-detail',
  templateUrl: './company-detail.component.html',
  styleUrls: ['./company-detail.component.scss'],
})
export class CompanyDetailComponent implements OnInit {
  company = new Company();
  sameAsFlag: boolean = false;
  hbErrorHandler = new HbErrorHandler();
  @Input() viewFlag: boolean = false;
  @Input() sameFlag: boolean = false;

  workingDaysSelected: string[];
  workingDays1 = [
    { label: 'Sunday', code: 'Sunday', id: undefined, value: undefined },
    { label: 'Monday', code: 'Monday', id: undefined, value: undefined },
    { label: 'Tuesday', code: 'Tuesday', id: undefined, value: undefined },
    { label: 'Wednesday', code: 'Wednesday', id: undefined, value: undefined },
    { label: 'Thursday', code: 'Thursday', id: undefined, value: undefined },
    { label: 'Friday', code: 'Friday', id: undefined, value: undefined },
    { label: 'Saturday', code: 'Saturday', id: undefined, value: undefined }
  ];

  constructor(private _location: Location) {}

  ngOnInit(): void {
    this.company.workingDays1 = '';
    this.workingDaysSelected = this.company.workingDays1.split(',');
    this.company.addressOperational = new Address();
    this.company.addressRegistered = new Address();
  }

  back() {
    this._location.back();
  }

  setWorkingDays() {
    this.company.workingDays1 = this.workingDaysSelected.toString();
  }

  setFlag(){
    if(this.company){
      this.sameAsFlag = this.company.sameAsRegistered
    }else{
      this.sameAsFlag
    }
    return this.sameAsFlag
    }

  setSameAsFlag(event) {
    this.company.sameAsRegistered = event;
    // if (this.company.sameAsRegistered) {
      if(event){
      // this.company.addressOperational = Object.create(this.company.addressRegistered);
      // this.company.addressOperational.id = this.company.addressRegistered.id;
      this.company.addressOperational.addressOne = this.company.addressRegistered.addressOne;
      this.company.addressOperational.addressTwo = this.company.addressRegistered.addressTwo;
      this.company.addressOperational.cityName = this.company.addressRegistered.cityName;      
      this.company.addressOperational.pincode = this.company.addressRegistered.pincode;      
      this.company.addressOperational.stateName = this.company.addressRegistered.stateName;      
      this.company.addressOperational.countryName = this.company.addressRegistered.countryName;
    }
  }

  // errorHandler(parentkey: string, childkey?: string, keyIndex?: number): HbErrorHandlerData {
  //   const hData = this.hbErrorHandler.getErrorHandlerData(parentkey, childkey, keyIndex);
  //   return hData;
  // }
}
