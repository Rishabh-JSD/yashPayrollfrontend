import { SearchRequest } from "src/app/shared/models/search-request";

export class CompanySearchRequest extends SearchRequest {
  searchFor: string;
  id: number;
  name: string;
  departmentFlag: boolean;

}
