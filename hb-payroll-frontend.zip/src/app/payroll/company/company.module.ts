import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CompanyDetailComponent } from './company-detail/company-detail.component';
import { SharedModule } from '../../shared/shared.module';
import { RouterModule, Routes } from '@angular/router';
import { AddBranchComponent } from './branch/add-branch/add-branch.component';
import { BranchListingComponent } from './branch/branch-listing/branch-listing.component';
import { ViewBranchComponent } from './branch/view-branch/view-branch.component';
import { CostCenterComponent } from './cost-center/cost-center.component';
import { HelpCenterComponent } from './help-center/help-center.component';
import { AddCostComponent } from './cost-center/add-cost/add-cost.component';
import { DepartmentComponent } from './department/department.component';
import { AddLocationComponent } from './location/add-location/add-location.component';
import { AddDepartmentComponent } from './department/add-department/add-department.component';
import { LocationComponent } from './location/location.component';

const routes: Routes = [
  { path: '', pathMatch: 'full', component: CompanyDetailComponent },
  { path: 'branch', component: BranchListingComponent },
  { path: 'add-branch', component: AddBranchComponent },
  { path: 'edit-branch/:id', component: AddBranchComponent },
  { path: 'view-branch', component: ViewBranchComponent },
  { path: 'cost-center', component: CostCenterComponent },
  { path: 'add-cost', component: AddCostComponent },
  { path: 'edit-cost/:id', component: AddCostComponent },
  { path: 'help-center', component: HelpCenterComponent },
  { path: 'add-location', component: AddLocationComponent },
  { path: 'edit-location/:id', component: AddLocationComponent },
  { path: 'location', component: LocationComponent },
  { path: 'department', component: DepartmentComponent },
  { path: 'add-department', component: AddDepartmentComponent },
  { path: 'edit-department/:id', component: AddDepartmentComponent },
  { path: '**', redirectTo: '', pathMatch: 'full' },
];

@NgModule({
  declarations: [
    CompanyDetailComponent,
    AddBranchComponent,
    BranchListingComponent,
    ViewBranchComponent,
    CostCenterComponent,
    HelpCenterComponent,
    AddCostComponent,
    DepartmentComponent,
    AddDepartmentComponent,
    AddLocationComponent,
    LocationComponent,
  ],
  imports: [CommonModule, SharedModule, RouterModule.forChild(routes)],
})
export class CompanyModule {
}
