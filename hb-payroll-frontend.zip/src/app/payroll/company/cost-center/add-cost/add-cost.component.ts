import { CostCenterService } from '../../services/cost-center.service';
import { CostCenter } from '../../models/cost-center';
import { DatePipe, Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Address } from 'src/app/shared/models/address';
import { BranchService } from '../../services/branch.service';
import { ActivatedRoute, Router } from '@angular/router';
import Swal from 'sweetalert2';
import { HBLoaderService } from '../../../../shared/services/hb-loader.service';
import { HbErrorHandler, HbErrorHandlerData } from 'src/app/shared/models/hb-error-handler';
import { MasterOption } from 'src/app/payroll/master-rules/common/models/masters-options';
import { MasterOptionService } from 'src/app/payroll/master-rules/common/services/master-option.service';
import { Branch } from '../../models/branch';

@Component({
  selector: 'app-cost-add',
  templateUrl: './add-cost.component.html',
  styleUrls: ['./add-cost.component.scss'],
  providers: [DatePipe]
})
export class AddCostComponent implements OnInit {

  sameAsFlag: boolean = false;
  costCenter = new CostCenter();

  hbErrorHandler = new HbErrorHandler();
  costCenterId: boolean;
  isEdit: boolean = false;
  branch = new Branch()
  addressCopy;

  constructor(
    private _location: Location,
    private costCenterService: CostCenterService,
    private branchService: BranchService,
    private masterOptionService: MasterOptionService,
    private router: Router,
    private activatedRoute: ActivatedRoute,
  ) { }

  ngOnInit(): void {
    this.costCenter.address = new Address();
    this.editCostCenter();
  }

  back() {
    this._location.back();
  }

  editCostCenter() {
    this.activatedRoute.params.subscribe(params => {
      if (params['id']) {
        this.costCenterId = params['id'];
        this.getCostCenter();
        this.isEdit = true
      }
    });
  }

  getCostCenter() {
    HBLoaderService.showLoader();
    this.costCenterService.getCostCenter(this.costCenterId).subscribe(response => {
      console.log(response);
      if (response.status === 200 && response.data && response.data.costCenter) {
        this.costCenter = response.data.costCenter;
        if (this.costCenter.branchId) {
          this.getBranch()
        }
      }
      HBLoaderService.hideLoader();
    },
    () => {
      HBLoaderService.hideLoader();
    }
    );
  }

  addUpdateCostCenter() {
    this.hbErrorHandler.clearErrors()
    this.validate();
    if (!this.hbErrorHandler.invalid) {
      if (!this.costCenter.id) {
        HBLoaderService.showLoader();
        this.costCenterService.addCostCenter(this.costCenter).subscribe(response => {
          console.log(response);
          if (response.status === 200 && response.data && response.data.costCenter) {
            this.confirmationPopup(response.message);
          }
          HBLoaderService.hideLoader();
        },
        () => {
          HBLoaderService.hideLoader();
        }
        );
      } else {
        HBLoaderService.showLoader();
        this.costCenterService.updateCostCenter(this.costCenter).subscribe(response => {
          console.log(response);
          if (response.status === 200 && response.data && response.data.costCenter) {
            this.confirmationPopup(response.message);
          }
          HBLoaderService.hideLoader();
        },
        () => {
          HBLoaderService.hideLoader();
        }
        );
      }
    } else {
      window.scrollTo(0, 0);
      HBLoaderService.hideLoader();
    }
  }

  setWorkingHours() {
    if (this.costCenter.shiftTimingId != null) {
      this.masterOptionService.getMasterOptionById(this.costCenter.shiftTimingId).subscribe(response => {
        console.log(response);
        if (response.status === 200 && response.data && response.data.masterOption) {
          let shiftTiming: MasterOption = response.data.masterOption;
          this.costCenter.workingHours = shiftTiming.workingHours;
        }
      });
    } else {
      this.costCenter.workingHours = null
    }
  }

  validate(): void {
    this.hbErrorHandler.emptyCheck(this.costCenter.shiftTimingId, 'department');
    this.hbErrorHandler.emptyCheck(this.costCenter.name, 'name');
    this.hbErrorHandler.emptyCheck(this.costCenter.branchId, 'branch');
    this.hbErrorHandler.emptyCheck(this.costCenter.headId, 'head');
    this.hbErrorHandler.emptyCheck(this.costCenter.shiftTypeId, 'operationalHours');
    this.hbErrorHandler.emptyCheck(this.costCenter.shiftTimingId, 'timing');
    if(this.costCenter.address){
      this.hbErrorHandler.emptyCheck(this.costCenter.address.cityName , 'address.cityName')
      this.hbErrorHandler.emptyCheck(this.costCenter.address.addressOne , 'address.addressOne')
      this.hbErrorHandler.emptyCheck(this.costCenter.address.stateName , 'address.stateName')
      this.hbErrorHandler.emptyCheck(this.costCenter.address.pincode , 'address.pincode')
      this.hbErrorHandler.emptyCheck(this.costCenter.address.countryName , 'address.countryName')
    }
  }

  confirmationPopup(message: any) {
    Swal.fire({
      title: 'Cost Center',
      html: message,
      icon: 'success',
      allowOutsideClick: false,
      allowEscapeKey: false,
    }).then(() => {
      this.router.navigateByUrl('payroll/company/cost-center');
    });
  }

  errorHandler(parentkey: string, childkey?: string, keyIndex?: number): HbErrorHandlerData {
    const hData = this.hbErrorHandler.getErrorHandlerData(parentkey, childkey, keyIndex);
    return hData;
  }

  getBranch() {
    this.branchService.getBranch(this.costCenter.branchId).subscribe(response => {
      console.log(response);
      if (response.status === 200 && response.data && response.data.branch) {
        this.branch = response.data.branch;
      }
    });
  }

  setSameAsFlag(event) {
    this.costCenter.sameAsBranchFlag = event;
    if (event) {
      this.costCenter.address.addressOne = this.branch.address.addressOne
      this.costCenter.address.addressTwo = this.branch.address.addressTwo
      this.costCenter.address.cityName = this.branch.address.cityName
      this.costCenter.address.stateName = this.branch.address.stateName
      this.costCenter.address.countryName = this.branch.address.countryName
      this.costCenter.address.pincode = this.branch.address.pincode
      this.costCenter.headId = this.branch.headId
    } else {
      this.costCenter.address = new Address()
      this.costCenter.headId = null
    }
  }
}
