import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import Swal from 'sweetalert2';
import { CostCenter } from '../models/cost-center';
import { CostCenterService } from '../services/cost-center.service';
import { HbDataTableColumnOption } from '@hostbooks/hb-lib/hb-list-table/src/hb-list-table-columns';
import { Router } from '@angular/router';
import { HBLoaderService } from '../../../shared/services/hb-loader.service';
import { CompanySearchRequest } from '../company-search-request';


@Component({
  selector: 'app-cost-center',
  templateUrl: './cost-center.component.html',
  styleUrls: ['./cost-center.component.scss'],
})
export class CostCenterComponent implements OnInit {

  companySearchRequest = new CompanySearchRequest()
  total: number;
  columns: HbDataTableColumnOption[] = [];
  data: CostCenter[] = [];
  searchCostCenter;

  constructor(private _location: Location, private costCenterService: CostCenterService, private router: Router) { }

  ngOnInit(): void {
    this.getCostCenterList();
    this.companySearchRequest.page = 1;
    this.companySearchRequest.limit = 10;
    this.costCenterColumns();
  }

  back() {
    this._location.back();
  }

  costCenterColumns() {
    this.columns = [
      {
        header: 'S. No.',
        columnData: (inv: CostCenter) => {
        },
        type: 'SR_NO'
      },
      {
        header: 'Cost Center',
        columnData: (inv: CostCenter) => {
          return inv.name;
        },
        type: 'TEXT'
      },
      {
        header: 'Branch',
        columnData: (inv: CostCenter) => {
          return inv.branchName;
        },
        type: 'TEXT'
      },
      {
        header: 'Total Employees (Nos.)',
        columnData: (inv: CostCenter) => {
          return inv.totalEmployees;
        },
        type: 'NUMBER'
      },
      {
        header: 'City',
        columnData: (inv: CostCenter) => {
          return inv.address.cityName;
        },
        type: 'TEXT'
      },
      {
        header: 'State',
        columnData: (inv: CostCenter) => {
          return inv.address.stateName;
        },
        type: 'TEXT'
      },
      {
        header: 'Actions',
        columnData: (inv: CostCenter) => {
        },
        type: 'ACTION',
        actionOptions: ['EDIT', 'DELETE']
      },
    ];
  }

  getCostCenterList() {
    HBLoaderService.showLoader();
    this.companySearchRequest.searchFor = this.searchCostCenter;
    this.costCenterService.getListCostCenter(this.companySearchRequest).subscribe(response => {
      console.log(response);
      if (response.status === 200 && response.data && response.data.costCenter) {
        this.data = response.data.costCenter.list;
        this.total = response.data.costCenter.totalRowCount;
      }
      HBLoaderService.hideLoader();
    },
    () => {
      HBLoaderService.hideLoader();
    }
    );
  }


  deleteCostCenter(id: number) {
    this.deleteConfirmationPopup().then(result => {
      if (result.value) {
        this.costCenterService.deleteCostCenter(id).subscribe(response => {
          console.log(response);
          this.deletedConfirmationPopup(response.message, 'Cost Center');
        });
      }
    });
  }

  deleteConfirmationPopup() {
    return Swal.fire({
      title: 'Warning',
      text: 'Are you sure that you want to perform this action?',
      icon: 'question',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes',
      cancelButtonText: 'No',
      allowOutsideClick: false,
      allowEscapeKey: false,
    });
  }

  deletedConfirmationPopup(message, title) {
    Swal.fire({
      title: title,
      text: message,
      icon: 'success',
      allowOutsideClick: false,
      allowEscapeKey: false,
    }).then(result => {
      if (result.value) {
        this.getCostCenterList();
      }
    });
  }

  onAction(_event: any) {
    if (_event && _event.actionType && _event.data) {
      if (_event.actionType === 'DELETE') {
        this.deleteCostCenter(_event.data.id);
      }
      if (_event.actionType === 'EDIT') {
        this.router.navigate(['payroll/company/edit-cost', _event.data.id]);
      }
    }
  }

  onChange(event) {
    this.companySearchRequest.page = event.page;
    this.companySearchRequest.limit = event.limit;
    this.getCostCenterList();
  }
}
