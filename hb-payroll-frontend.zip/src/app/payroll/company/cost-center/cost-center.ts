export class CostcenterListing {
  public sno: any;
  public name: any;
  public branchName: any;
  public totalEmployees: any;
  public city: any;
  public state: any;
  public action: any;
}
