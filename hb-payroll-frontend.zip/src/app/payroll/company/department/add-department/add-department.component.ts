import { Department } from '../../models/department';
import { DatePipe, Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import Swal from 'sweetalert2';
import { DepartmentService } from '../../services/department.service';
import { HBLoaderService } from '../../../../shared/services/hb-loader.service';
import { HbErrorHandler, HbErrorHandlerData } from 'src/app/shared/models/hb-error-handler';
import { MasterOption } from 'src/app/payroll/master-rules/common/models/masters-options';
import { MasterOptionService } from 'src/app/payroll/master-rules/common/services/master-option.service';

@Component({
  selector: 'app-department-add',
  templateUrl: './add-department.component.html',
  styleUrls: ['./add-department.component.scss'],
  providers: [DatePipe]
})
export class AddDepartmentComponent implements OnInit {
  radio = [
    { label: 'department', code: 'department', id: undefined, value: undefined },
    { label: 'sub-department', code: 'sub-department', id: undefined, value: undefined },
  ];
  departmentRadio = 'department';
  hbErrorHandler = new HbErrorHandler();

  // employeeList1 = [];
  department = new Department();
  // errorList = new Array<string>();

  // branchList1 = [];

  // shiftTypeList1 = [];

  // departmentList1 = [];

  // costCenterList1 = [];

  // shiftTimingList1 = [];
  // paginationCriteriaBranch = new PaginationCriteria();
  // paginationCriteriaEmployee = new PaginationCriteria();
  // paginationCriteriaShiftType = new PaginationCriteria();

  // isError: boolean = false;
  errorType: string = '';
  departmentId: number;

  constructor(
    private router: Router,
    private _location: Location,
    // private shiftService: ShiftService,
    // private branchService: BranchService,
    private activatedRoute: ActivatedRoute,
    // private employeeService: EmployeeService,
    private departmentService: DepartmentService,
    // private costCenterService: CostCenterService,
    private masterOptionService: MasterOptionService,
    // private datePipe: DatePipe
  ) { }

  ngOnInit(): void {
    // this.isError = false;
    // this.getBranchList();
    this.editDepartment();
    // this.getEmployeeList();
    // this.getShiftTypeList();
    // this.getDepartmentList();
    // this.getCostCenterList();
    this.departmentType('department');
  }

  back() {
    this._location.back();
  }

  editDepartment() {
    this.activatedRoute.params.subscribe(params => {
      if (params['id']) {
        this.departmentId = params['id'];
        this.getDepartment();
      }
    });
  }

  // getDepartmentList() {
  //   let paginationCriteriaDepartment = new PaginationCriteria();
  //   this.departmentService.getListDepartment(paginationCriteriaDepartment).subscribe(response => {
  //     console.log(response);
  //     if (response.status === 200 && response.data && response.data.department) {
  //       this.departmentList1 = response.data.department.list;
  //       this.departmentList1.map(x => {
  //         x['label'] = x.name;

  //       });
  //     }
  //   });
  // }

  // getBranchList() {
  //   this.branchService.getListBranch(this.paginationCriteriaBranch).subscribe(response => {
  //     console.log(response);
  //     if (response.status === 200 && response.data && response.data.branch) {
  //       this.branchList1 = response.data.branch.list;
  //       this.branchList1.map(x => {
  //         x['label'] = x.name;
  //       });
  //     }
  //   });
  // }

  // getCostCenterList() {
  //   let paginationCriteriaCostCenter = new PaginationCriteria();
  //   this.costCenterService.getListCostCenter(paginationCriteriaCostCenter).subscribe(response => {
  //     console.log(response);
  //     if (response.status === 200 && response.data && response.data.costCenter) {
  //       this.costCenterList1 = response.data.costCenter.list;
  //       this.costCenterList1.map(x => {
  //         x['label'] = x.name;
  //       });
  //     }
  //   });
  // }

  // getEmployeeList() {
  //   this.employeeService.getListEmployee(this.paginationCriteriaEmployee).subscribe(response => {
  //     console.log(response);
  //     if (response.status === 200 && response.data && response.data.employee && response.data.employee.list) {
  //       this.employeeList1 = response.data.employee.list;
  //       this.employeeList1.map(x => {
  //         x['label'] = x.name;
  //       });
  //     }
  //   });
  // }

  // getShiftTypeList() {
  //   this.shiftService.getListShiftType(this.paginationCriteriaShiftType).subscribe(response => {
  //     console.log(response);
  //     if (response.status === 200 && response.data && response.data.shiftType && response.data.shiftType.list) {
  //       this.shiftTypeList1 = response.data.shiftType.list;
  //       this.shiftTypeList1.map(x => {
  //         x['label'] = x.name;
  //       });
  //     }
  //   });
  // }

  getDepartment() {
    HBLoaderService.showLoader();
    this.departmentService.getDepartment(this.departmentId).subscribe(response => {
      console.log(response);
      if (response.status === 200 && response.data && response.data.department) {
        this.department = response.data.department;
        // this.getShiftTimingsByTypeId();
        if(!this.department.departmentFlag){
          this.departmentRadio = 'sub-department'
        }
      }
      HBLoaderService.hideLoader();
    },
    () => {
      HBLoaderService.hideLoader();
    }
    );
  }

  addUpdateDepartment() {
    this.hbErrorHandler.clearErrors()
    this.validate();
    if (!this.hbErrorHandler.invalid) {
      if (!this.department.id) {
        HBLoaderService.showLoader();
        this.departmentService.addDepartment(this.department).subscribe(response => {
          console.log(response);
          if (response.status === 200 && response.data && response.data.department) {
            this.confirmationPopup(response.message);
          }
          HBLoaderService.hideLoader();
        },
        () => {
          HBLoaderService.hideLoader();
        }
        );
      } else {
        HBLoaderService.showLoader();
        this.departmentService.updateDepartment(this.department).subscribe(response => {
          console.log(response);
          if (response.status === 200 && response.data && response.data.department) {
            this.confirmationPopup(response.message);
          }
          HBLoaderService.hideLoader();
        },
        () => {
          HBLoaderService.hideLoader();
        }
        );
      }
    } else {
      window.scrollTo(0, 0);
      // this.isError = true;
      HBLoaderService.hideLoader();
    }
  }

  // getShiftTimingsByTypeId() {
  //   let paginationCriteriaShiftTiming = new PaginationCriteria();
  //   paginationCriteriaShiftTiming.id = this.department.shiftTypeId;
  //   this.shiftService.getListShiftTiming(paginationCriteriaShiftTiming).subscribe(response => {
  //     console.log(response);
  //     if (response.status === 200 && response.data && response.data.shiftTiming && response.data.shiftTiming.list) {
  //       this.shiftTimingList1 = response.data.shiftTiming.list;
  //       this.shiftTimingList1.map(x => {
  //         x['label'] = this.datePipe.transform(x.startTime, 'h:mm a') + ' to ' + this.datePipe.transform(x.endTime, 'h:mm a');
  //       });
  //     }
  //   });
  // }

  // setWorkingHours() {
  //   this.shiftService.getShiftTiming(this.department.shiftTimingId).subscribe(response => {
  //     console.log(response);
  //     if (response.status === 200 && response.data && response.data.shiftTiming) {
  //       let shiftTiming: ShiftTiming = response.data.shiftTiming;
  //       this.department.workingHours = shiftTiming.workingHours;
  //     }
  //   });
  // }

  departmentType(event) {
    this.department = new Department();
    switch (event) {
      case 'department':
        this.department.departmentFlag = true;
        break;
      case 'sub-department':
        this.department.departmentFlag = false;
        break;
    }
  }

  // validate(): boolean {
  //   this.errorType = 'Complete these fields:';
  //   this.errorList = new Array<string>();
  //   let isValid = true;

  //   if (!this.department.name) {
  //     this.errorList.push('Name');
  //   }

  //   if (this.errorList.length > 0) {
  //     isValid = false;
  //   }
  //   return isValid;
  // }

  validate(): void {
    if (!this.department.departmentFlag) {
      this.hbErrorHandler.emptyCheck(this.department.departmentId, 'department');
    }
    this.hbErrorHandler.emptyCheck(this.department.name, 'name');
    this.hbErrorHandler.emptyCheck(this.department.branchId, 'branch');
    this.hbErrorHandler.emptyCheck(this.department.costCenterId, 'costCenter');
    this.hbErrorHandler.emptyCheck(this.department.headId, 'head');
    this.hbErrorHandler.emptyCheck(this.department.shiftTypeId, 'operationalHours');
    this.hbErrorHandler.emptyCheck(this.department.shiftTimingId, 'timing');

  }

  confirmationPopup(message: any) {
    Swal.fire({
      title: 'Department',
      html: message,
      icon: 'success',
      allowOutsideClick: false,
      allowEscapeKey: false,
    }).then(() => {
      this.router.navigateByUrl('payroll/company/department');
    });
  }

  log() {
    console.log(this.department);
  }

  setWorkingHours() {
    if (this.department.shiftTimingId != null) {
      this.masterOptionService.getMasterOptionById(this.department.shiftTimingId).subscribe(response => {
        console.log(response);
        if (response.status === 200 && response.data && response.data.masterOption) {
          let shiftTiming: MasterOption = response.data.masterOption;
          this.department.workingHours = shiftTiming.workingHours;
        }
      });
    } else {
      this.department.workingHours = null
    }
  }

  errorHandler(parentkey: string, childkey?: string, keyIndex?: number): HbErrorHandlerData {
    const hData = this.hbErrorHandler.getErrorHandlerData(parentkey, childkey, keyIndex);
    return hData;
  }
}
