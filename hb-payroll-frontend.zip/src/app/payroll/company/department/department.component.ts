import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import Swal from 'sweetalert2';
import { Department } from '../models/department';
import { DepartmentService } from '../services/department.service';
import { HbDataTableColumnOption } from '@hostbooks/hb-lib/hb-list-table/src/hb-list-table-columns';
import { Router } from '@angular/router';
import { HBLoaderService } from '../../../shared/services/hb-loader.service';
import { CompanySearchRequest } from '../company-search-request';

@Component({
  selector: 'app-department',
  templateUrl: './department.component.html',
  styleUrls: ['./department.component.scss'],
})
export class DepartmentComponent implements OnInit {

  companySearchRequest = new CompanySearchRequest()

  totalDepartment: number;
  columnsDepartment: HbDataTableColumnOption[] = [];
  dataDepartment: Department[] = [];

  totalSubDepartment: number;
  columnsSubDepartment: HbDataTableColumnOption[] = [];
  dataSubDepartment: Department[] = [];

  searchDepartment;

  constructor(private _location: Location, private departmentService: DepartmentService, private router: Router) {}

  ngOnInit(): void {
    this.getDepartmentList();
    this.getSubDepartmentList()
    this.companySearchRequest.page = 1;
    this.companySearchRequest.limit = 10;
    this.departmentColumns()
    this.subDepartmentColumns()
  }

  back() {
    this._location.back();
  }

  departmentColumns(){
    this.columnsDepartment = [
      {
        header: 'S. No.',
        columnData: (inv: Department) => {
        },
        type: 'SR_NO'
      },
      {
        header: 'Department Name',
        columnData: (inv: Department) => {
          return inv.name;
        },
        type: 'TEXT'
      },
      {
        header: 'Branch',
        columnData: (inv: Department) => {
          return inv.branchName;
        },
        type: 'TEXT'
      },
      {
        header: 'Cost Center',
        columnData: (inv: Department) => {
          return inv.costCenterName;
        },
        type: 'TEXT'
      },
      {
        header: 'Head',
        columnData: (inv: Department) => {
          return inv.headName;
        },
        type: 'TEXT'
      },
      {
        header: 'Total Employees (Nos.)',
        columnData: (inv: Department) => {
          return inv.totalEmployees;
        },
        type: 'NUMBER'
      },
      {
        header: 'Actions',
        columnData: (inv: Department) => {
        },
        type: 'ACTION',
        actionOptions: ['EDIT', 'DELETE']
      },
    ];
  }

  subDepartmentColumns(){
    this.columnsSubDepartment = [
      {
        header: 'S. No.',
        columnData: (inv: Department) => {
        },
        type: 'SR_NO'
      },
      {
        header: 'Department Name',
        columnData: (inv: Department) => {
          return inv.departmentName;
        },
        type: 'TEXT'
      },
      {
        header: 'Sub Department Name',
        columnData: (inv: Department) => {
          return inv.name;
        },
        type: 'TEXT'
      },
      {
        header: 'Branch',
        columnData: (inv: Department) => {
          return inv.branchName;
        },
        type: 'TEXT'
      },
      {
        header: 'Cost Center',
        columnData: (inv: Department) => {
          return inv.costCenterName;
        },
        type: 'TEXT'
      },
      {
        header: 'Head',
        columnData: (inv: Department) => {
          return inv.headName;
        },
        type: 'TEXT'
      },
      {
        header: 'Total Employees (Nos.)',
        columnData: (inv: Department) => {
          return inv.totalEmployees;
        },
        type: 'NUMBER'
      },
      {
        header: 'Actions',
        columnData: (inv: Department) => {
        },
        type: 'ACTION',
        actionOptions: ['EDIT', 'DELETE']
      },
    ];
  }

  getDepartmentList() {
    HBLoaderService.showLoader();
    this.companySearchRequest.searchFor = this.searchDepartment;
    this.companySearchRequest.departmentFlag = true
    this.departmentService.getListDepartment(this.companySearchRequest).subscribe(response => {
      console.log(response);
      if (response.status === 200 && response.data && response.data.department) {
        this.dataDepartment = response.data.department.list;
        this.totalDepartment = response.data.department.totalRowCount;
      }
      HBLoaderService.hideLoader();
    },
    () => {
      HBLoaderService.hideLoader();
    }
    );
  }

  getSubDepartmentList(){
    HBLoaderService.showLoader();
    this.companySearchRequest.searchFor = this.searchDepartment;
    this.companySearchRequest.departmentFlag = false
    this.departmentService.getListDepartment(this.companySearchRequest).subscribe(response => {
      console.log(response);
      if (response.status === 200 && response.data && response.data.department) {
        this.dataSubDepartment = response.data.department.list;
        this.totalSubDepartment = response.data.department.totalRowCount;
      }
      HBLoaderService.hideLoader();
    },
    () => {
      HBLoaderService.hideLoader();
    }
    );
  }


  deleteDepartment(id: number) {
    this.deleteConfirmationPopup().then(result => {
      if (result.value) {
        HBLoaderService.showLoader();
        this.departmentService.deleteDepartment(id).subscribe(response => {
          console.log(response);
          this.deletedConfirmationPopup(response.message, 'Department');
          HBLoaderService.hideLoader();
        });
      }
    });
  }

  deleteConfirmationPopup() {
    return Swal.fire({
      title: 'Warning',
      text: 'Are you sure that you want to perform this action?',
      icon: 'question',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes',
      cancelButtonText: 'No',
      allowOutsideClick: false,
      allowEscapeKey: false,
    });
  }

  deletedConfirmationPopup(message, title) {
    Swal.fire({
      title: title,
      text: message,
      icon: 'success',
      allowOutsideClick: false,
      allowEscapeKey: false,
    }).then(result => {
      if (result.value) {
        this.getDepartmentList();
      }
    });
  }

  onAction(_event: any) {
    if (_event && _event.actionType && _event.data) {
      if (_event.actionType === 'DELETE') {
        this.deleteDepartment(_event.data.id);
      }
      if (_event.actionType === 'EDIT') {
        this.router.navigate(['payroll/company/edit-department', _event.data.id]);
      }
    }
  }

  onChange(event) {
    this.companySearchRequest.page = event.page;
    this.companySearchRequest.limit = event.limit;
    this.getDepartmentList();
  }
}
