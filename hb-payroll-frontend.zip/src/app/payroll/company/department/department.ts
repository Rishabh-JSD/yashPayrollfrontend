export class DepartmentListing {
  public sno: any;
  public name: any;
  public branchName: any;
  public costCenterName: any;
  public headName: any;
  public totalEmployees: any;
  public action: any;
}
