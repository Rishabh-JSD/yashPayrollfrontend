import { Component, OnInit } from '@angular/core';
import { DropDownModel } from '../../../shared/models/hb-field-option';

@Component({
  selector: 'app-help-center',
  templateUrl: './help-center.component.html',
  styleUrls: ['./help-center.component.scss']
})
export class HelpCenterComponent implements OnInit {

  Department: DropDownModel[] = [
    { label: 'Ajmer', code: 'Ajmer', id: undefined, value: undefined },
  ];
  Role: DropDownModel[] = [
    { label: 'Ajmer', code: 'Ajmer', id: undefined, value: undefined },
  ];
  ContactPerson: DropDownModel[] = [
    { label: 'Ajmer', code: 'Ajmer', id: undefined, value: undefined },
  ];

  constructor() { }

  ngOnInit(): void {
  }

}
