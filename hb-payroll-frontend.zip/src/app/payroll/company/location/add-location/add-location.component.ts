import { Component, OnInit } from '@angular/core';
import { DatePipe, Location } from '@angular/common';
import { DropDownModel } from '../../../../shared/models/hb-field-option';
import { ActivatedRoute, Router } from '@angular/router';
import { LocationService } from '../../services/location.service';
import { HBLoaderService } from '../../../../shared/services/hb-loader.service';
import { Locations } from '../../models/location';
import Swal from 'sweetalert2';
import { Address } from '../../../../shared/models/address';
import { HbErrorHandler, HbErrorHandlerData } from 'src/app/shared/models/hb-error-handler';

@Component({
  selector: 'app-location-add',
  templateUrl: './add-location.component.html',
  styleUrls: ['./add-location.component.scss'],
  providers: [DatePipe]
})
export class AddLocationComponent implements OnInit {

  locationId: number;
  location = new Locations();
  hbErrorHandler = new HbErrorHandler();

  constructor(private router: Router, private activatedRoute: ActivatedRoute,
              private _location: Location,
              private locationService: LocationService,
              ) {}

  ngOnInit(): void {
    this.location.address = new Address();
    this.editLocation();
  }

  back() {
    this._location.back();
  }

  editLocation() {
    this.activatedRoute.params.subscribe(params => {
      if (params['id']) {
        this.locationId = params['id'];
        this.getLocation();
      }
    });
  }

  getLocation() {
    HBLoaderService.showLoader();
    this.locationService.getLocation(this.locationId).subscribe(response => {
      console.log(response);
      if (response.status === 200 && response.data && response.data.location) {
        this.location = response.data.location;
      }
      HBLoaderService.hideLoader();
    },
    () => {
      HBLoaderService.hideLoader();
    }
    );
  }

  addUpdateLocation() {
    this.hbErrorHandler.clearErrors()
    this.validate();
    if (!this.hbErrorHandler.invalid) {
      if (!this.location.id) {
        HBLoaderService.showLoader();
        this.locationService.addLocation(this.location).subscribe(response => {
          console.log(response);
          if (response.status === 200 && response.data && response.data.location) {
            this.confirmationPopup(response.message);
          }
          HBLoaderService.hideLoader();
        },
        () => {
          HBLoaderService.hideLoader();
        }
        );
      } else {
        HBLoaderService.showLoader();
        this.locationService.updateLocation(this.location).subscribe(response => {
          console.log(response);
          if (response.status === 200 && response.data && response.data.location) {
            this.confirmationPopup(response.message);
          }
          HBLoaderService.hideLoader();
        },
        () => {
          HBLoaderService.hideLoader();
        }
        );
      }
    } else {
      window.scrollTo(0, 0);
      HBLoaderService.hideLoader();
    }
  }


  validate(): void {
    this.hbErrorHandler.emptyCheck(this.location.name, 'name');
    this.hbErrorHandler.emptyCheck(this.location.costCenterId, 'costCenter');
    this.hbErrorHandler.emptyCheck(this.location.headId, 'head');
    this.hbErrorHandler.emptyCheck(this.location.shiftTypeId, 'operationalHours');
    this.hbErrorHandler.emptyCheck(this.location.shiftTimingId, 'timing');
    if(this.location.address){
      this.hbErrorHandler.emptyCheck(this.location.address.cityName , 'address.cityName')
      this.hbErrorHandler.emptyCheck(this.location.address.addressOne , 'address.addressOne')
      this.hbErrorHandler.emptyCheck(this.location.address.stateName , 'address.stateName')
      this.hbErrorHandler.emptyCheck(this.location.address.pincode , 'address.pincode')
      this.hbErrorHandler.emptyCheck(this.location.address.countryName , 'address.countryName')
    }
  }

  confirmationPopup(message: any) {
    Swal.fire({
      title: 'Location',
      html: message,
      icon: 'success',
      allowOutsideClick: false,
      allowEscapeKey: false,
    }).then(() => {
      this.router.navigateByUrl('/payroll/company/location');
    });
  }

  errorHandler(parentkey: string, childkey?: string, keyIndex?: number): HbErrorHandlerData {
    const hData = this.hbErrorHandler.getErrorHandlerData(parentkey, childkey, keyIndex);
    return hData;
  }
}
