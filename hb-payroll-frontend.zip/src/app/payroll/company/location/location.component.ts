import { Component, OnInit } from '@angular/core';
import { HbDataTableColumnOption } from '@hostbooks/hb-lib/hb-list-table/src/hb-list-table-columns';
import { Location } from '@angular/common';
import { PaginationCriteria } from '../../../core/models/pagination-criteria';
import { HBLoaderService } from '../../../shared/services/hb-loader.service';
import { LocationService } from '../services/location.service';
import { LocationListing } from './location';
import Swal from 'sweetalert2';
import { Router } from '@angular/router';
import { CompanySearchRequest } from '../company-search-request';
import { Locations } from '../models/location';

@Component({
  selector: 'app-location',
  templateUrl: './location.component.html',
  styleUrls: ['./location.component.scss']
})
export class LocationComponent implements OnInit {

  companySearchRequest = new CompanySearchRequest()

  columns: HbDataTableColumnOption[] = [];
  data: LocationListing[] = [];
  total: number;
  locationName;

  constructor(private _location: Location, private locationService: LocationService, private router: Router) { }

  ngOnInit(): void {
    this.getLocationList();
    this.companySearchRequest.page = 1;
    this.companySearchRequest.limit = 10;
    this.locationColumns();
  }

  back() {
    this._location.back();
  }

  locationColumns(){
    this.columns = [
      {
        header: 'S. No.',
        columnData: (inv: Locations) => {
        },
        type: 'SR_NO'
      },
      {
        header: 'Location Name',
        columnData: (inv: Locations) => {
          return inv.name;
        },
        type: 'TEXT'
      },
      {
        header: 'Cost Center',
        columnData: (inv: Locations) => {
          return inv.costCenterName;
        },
        type: 'TEXT'
      },
      {
        header: 'Location Head',
        columnData: (inv: Locations) => {
          return inv.headName;
        },
        type: 'TEXT'
      },
      {
        header: 'Phone',
        columnData: (inv: Locations) => {
          return inv.phoneNo;
        },
        type: 'NUMBER'
      },
      {
        header: 'Email ID',
        columnData: (inv: Locations) => {
          return inv.email;
        },
        type: 'TEXT'
      },
      {
        header: 'Actions',
        columnData: (inv: Locations) => {
        },
        type: 'ACTION',
        actionOptions: ['EDIT', 'DELETE']
      },
    ];
  }

  getLocationList() {
    HBLoaderService.showLoader();
    this.companySearchRequest.searchFor = this.locationName;
    this.locationService.getListLocation(this.companySearchRequest).subscribe(response => {
      console.log(response);
      if (response.status === 200 && response.data && response.data.location) {
        this.data = response.data.location.list;
        this.total = response.data.location.totalRowCount;
      }
      HBLoaderService.hideLoader();
    },
    () => {
      HBLoaderService.hideLoader();
    }
    );
  }


  deleteLocation(id: number) {
    this.deleteConfirmationPopup().then(result => {
      if (result.value) {
        HBLoaderService.showLoader();
        this.locationService.deleteLocation(id).subscribe(response => {
          console.log(response);
          this.deletedConfirmationPopup(response.message, 'Location');
          HBLoaderService.hideLoader();
        });
      }
    });
  }

  deleteConfirmationPopup() {
    return Swal.fire({
      title: 'Warning',
      text: 'Are you sure that you want to perform this action?',
      icon: 'question',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes',
      cancelButtonText: 'No',
      allowOutsideClick: false,
      allowEscapeKey: false,
    });
  }

  deletedConfirmationPopup(message, title) {
    Swal.fire({
      title: title,
      text: message,
      icon: 'success',
      allowOutsideClick: false,
      allowEscapeKey: false,
    }).then(result => {
      if (result.value) {
        this.getLocationList();
      }
    });
  }

  onAction(_event: any) {
    if (_event && _event.actionType && _event.data) {
      if (_event.actionType === 'DELETE') {
        this.deleteLocation(_event.data.id);
      }
      if (_event.actionType === 'EDIT') {
        this.router.navigate(['/payroll/company/edit-location', _event.data.id]);
      }
    }
  }

  onChange(event) {
    this.companySearchRequest.page = event.page;
    this.companySearchRequest.limit = event.limit;
    this.getLocationList();
  }
}
