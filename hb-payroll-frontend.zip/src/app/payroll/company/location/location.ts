export class LocationListing {
  public s_no: any;
  public name: any;
  public phoneNo: any;
  public email: any;
  public actions: any;
}
