import { Address } from 'src/app/shared/models/address';

export class Branch {
  public id: number;
  public name: string;
  public code: string;
  public gstin: string;
  public addressId: number;
  public headId: number;
  public headName: string;
  public phoneNo: number;
  public email: string;
  public shiftTypeId: number;
  public shiftTimingId: number;
  public workingHours: number;
  public deleteFlag: boolean;
  public address: Address;
  public totalEmployees: number;
}
