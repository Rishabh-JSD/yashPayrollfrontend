import { Address } from 'src/app/shared/models/address';

export class Company {
  public id: number;
  public documentId: number;
  public name: string;
  public pan: string;
  public tan: string;
  public gstin: string;
  public phoneNo: number;
  public email: string;
  public addressRegisteredId: number;
  public sameAsRegistered: boolean;
  public addressOperationalId: number;
  public workingDays1: string;
  public startTime: Date;
  public endTime: Date;
  public deleteFlag: boolean;
  public addressRegistered: Address = new Address();
  public addressOperational: Address = new Address();
}
