import { Address } from 'src/app/shared/models/address';

export class CostCenter {
  public id: number;
  public name: string;
  public branchId: number;
  public branchName: string;
  public sameAsBranchFlag: boolean = false;
  public addressId: number;
  public headId: number;
  public headName: string;
  public departmentId: number;
  public departmentName: string;
  public phoneNo: number;
  public email: string;
  public shiftTypeId: number;
  public shiftTimingId: number;
  public workingHours: number;
  public deleteFlag: boolean;
  public address: Address;
  public totalEmployees: number;
}
