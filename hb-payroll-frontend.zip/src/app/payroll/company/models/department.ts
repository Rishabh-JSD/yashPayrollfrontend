export class Department {
  public id: number;
  public departmentFlag: boolean = true;
  public departmentId: number;
  public departmentName: string;
  public typeId: number;
  public name: string;
  public branchId: number;
  public branchName: string;
  public costCenterId: number;
  public costCenterName: string;
  public headId: number;
  public headName: string;
  public phoneNo: number;
  public email: string;
  public shiftTypeId: number;
  public shiftTimingId: number;
  public workingHours: number;
  public description: string;
  public deleteFlag: boolean;
  public totalEmployees: number;
}
