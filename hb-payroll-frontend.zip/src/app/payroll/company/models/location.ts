import { Address } from 'src/app/shared/models/address';

export class Locations {
  public id: number;
  public name: string;
  public costCenterId: number;
  public costCenterName: string;
  public addressId: number;
  public headId: number;
  public headName: string;
  public phoneNo: number;
  public email: string;
  public shiftTypeId: number;
  public shiftTimingId: number;
  public deleteFlag: boolean;
  public address: Address;


}
