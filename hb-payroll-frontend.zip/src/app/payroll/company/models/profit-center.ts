import { Address } from 'src/app/shared/models/address';

export class ProfitCenter {
  public id: number;
  public name: string;
  public branchId: number;
  public sameAsBranch: boolean;
  public addressId: number;
  public headId: number;
  public phoneNo: number;
  public email: string;
  public shiftTypeId: number;
  public shiftTimingId: number;
  public deleteFlag: boolean;
  public address: Address;
}
