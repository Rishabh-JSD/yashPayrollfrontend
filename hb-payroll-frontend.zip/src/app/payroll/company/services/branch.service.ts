import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HBHttpService } from 'src/app/core/services/hb-http-service.service';

@Injectable({
  providedIn: 'root',
})
export class BranchService {
  constructor(private hbHttpClient: HBHttpService) {}

  addBranch(data: any): Observable<any> {
    return this.hbHttpClient.getResponse('branch/add', this.hbHttpClient.POST, data);
  }

  updateBranch(data: any): Observable<any> {
    return this.hbHttpClient.getResponse('branch/update', this.hbHttpClient.POST, data);
  }

  getListBranch(data: any): Observable<any> {
    return this.hbHttpClient.getResponse('branch/list', this.hbHttpClient.POST, data);
  }

  getBranch(id: any): Observable<any> {
    return this.hbHttpClient.getResponse(`branch/${ id }`, this.hbHttpClient.GET);
  }

  deleteBranch(id: any): Observable<any> {
    return this.hbHttpClient.getResponse('branch/delete?branchId=' + id, this.hbHttpClient.DELETE);
  }
}
