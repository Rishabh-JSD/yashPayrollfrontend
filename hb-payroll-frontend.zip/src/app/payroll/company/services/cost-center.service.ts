import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HBHttpService } from 'src/app/core/services/hb-http-service.service';

@Injectable({
  providedIn: 'root',
})
export class CostCenterService {
  constructor(private hbHttpClient: HBHttpService) {}

  addCostCenter(data: any): Observable<any> {
    return this.hbHttpClient.getResponse('cost-center/add', this.hbHttpClient.POST, data);
  }

  updateCostCenter(data: any): Observable<any> {
    return this.hbHttpClient.getResponse('cost-center/update', this.hbHttpClient.POST, data);
  }

  getListCostCenter(data: any): Observable<any> {
    return this.hbHttpClient.getResponse('cost-center/list', this.hbHttpClient.POST, data);
  }

  getCostCenter(id: any): Observable<any> {
    return this.hbHttpClient.getResponse(`cost-center/${ id }`, this.hbHttpClient.GET);
  }

  deleteCostCenter(id: any): Observable<any> {
    return this.hbHttpClient.getResponse('cost-center/delete?costCenterId=' + id, this.hbHttpClient.DELETE);
  }
}
