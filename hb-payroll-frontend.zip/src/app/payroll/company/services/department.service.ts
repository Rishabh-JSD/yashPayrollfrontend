import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HBHttpService } from 'src/app/core/services/hb-http-service.service';

@Injectable({
  providedIn: 'root',
})
export class DepartmentService {
  constructor(private hbHttpClient: HBHttpService) {}

  addDepartment(data: any): Observable<any> {
    return this.hbHttpClient.getResponse('department/add', this.hbHttpClient.POST, data);
  }

  updateDepartment(data: any): Observable<any> {
    return this.hbHttpClient.getResponse('department/update', this.hbHttpClient.POST, data);
  }

  getListDepartment(data: any): Observable<any> {
    return this.hbHttpClient.getResponse('department/list', this.hbHttpClient.POST, data);
  }

  getDepartment(id: any): Observable<any> {
    return this.hbHttpClient.getResponse(`department/${ id }`, this.hbHttpClient.GET);
  }

  deleteDepartment(id: any): Observable<any> {
    return this.hbHttpClient.getResponse('department/delete?departmentId=' + id, this.hbHttpClient.DELETE);
  }
}
