import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HBHttpService } from 'src/app/core/services/hb-http-service.service';

@Injectable({
  providedIn: 'root',
})
export class LocationService {
  constructor(private hbHttpClient: HBHttpService) {}

  addLocation(data: any): Observable<any> {
    return this.hbHttpClient.getResponse('location/add', this.hbHttpClient.POST, data);
  }

  updateLocation(data: any): Observable<any> {
    return this.hbHttpClient.getResponse('location/update', this.hbHttpClient.POST, data);
  }

  getListLocation(data: any): Observable<any> {
    return this.hbHttpClient.getResponse('location/list', this.hbHttpClient.POST, data);
  }

  getLocation(id: any): Observable<any> {
    return this.hbHttpClient.getResponse(`location/${ id }`, this.hbHttpClient.GET);
  }

  deleteLocation(id: any): Observable<any> {
    return this.hbHttpClient.getResponse('location/delete?locationId=' + id, this.hbHttpClient.DELETE);
  }
}
