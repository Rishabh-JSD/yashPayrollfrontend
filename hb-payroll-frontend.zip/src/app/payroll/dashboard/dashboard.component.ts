import { Component, Inject, OnInit } from '@angular/core';
import * as Highcharts from 'highcharts';
import variablepie from 'highcharts/modules/variable-pie';
import solidgauge from 'highcharts/modules/solid-gauge';
import more from 'highcharts/highcharts-more';
import { DOCUMENT } from '@angular/common';
import { CalendarOptions, DateSelectArg, EventApi, EventClickArg } from '@fullcalendar/core';
import { createEventId, INITIAL_EVENTS } from './event-utils';
import dayGridPlugin from '@fullcalendar/daygrid';
import interactionPlugin from '@fullcalendar/interaction';
import { DropDownModel } from '../../shared/models/hb-field-option';

more(Highcharts);


variablepie(Highcharts);
solidgauge(Highcharts);

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {

  Company: DropDownModel[] = [
    { label: 'New', code: 'New', id: undefined, value: undefined },
  ];
  Branch: DropDownModel[] = [
    { label: 'Gainer', code: 'Gainer', id: undefined, value: undefined },
  ];
  CostCenter: DropDownModel[] = [
    { label: 'New', code: 'New', id: undefined, value: undefined },
  ];
  Department: DropDownModel[] = [
    { label: 'Main', code: 'Main', id: undefined, value: undefined },
  ];
  View: DropDownModel[] = [
    { label: 'Branch View', code: '1', id: undefined, value: undefined },
    { label: 'Location View', code: '2', id: undefined, value: undefined },
    { label: 'Cost Center View', code: '3', id: undefined, value: undefined },
  ];
  Year: DropDownModel[] = [
    { label: '2020', code: '2020', id: undefined, value: undefined },
    { label: '2021', code: '2021', id: undefined, value: undefined },
    { label: '2022', code: '2022', id: undefined, value: undefined },
  ];
  Leader: DropDownModel[] = [
    { label: 'Neeraj', code: 'Neeraj', id: undefined, value: undefined },
  ];
  calendarVisible = true;
  highcharts = Highcharts;
  chartOptions: Highcharts.Options = {
    title: {
      text: ''
    },
    tooltip: {
      valueSuffix: ''
    },
    yAxis: {
      min: 0,
      //  title: {
      //     text: 'Rainfall (mm)'
      //  }
    },
    plotOptions: {
      column: {
        pointPadding: 0,
        borderWidth: 0,
        stacking: 'normal'
      },
      series: {
        dataLabels: {
          enabled: false
        }
      }
    },
    series: [{
      data: [62, 68, 43, 35, 20, 90, 70],
      color: 'var(--color-tertiary)',
      name: 'Regularisation',
      type: 'column',
    },
      {
        data: [40, 45, 43, 35, 20, 90, 50],
        color: 'var(--color-primary)',
        name: 'Leave',
        type: 'column',
      },
      {
        data: [40, 45, 43, 35, 20, 90, 50],
        color: 'var(--color-secondary)',
        name: 'CO+',
        type: 'column',
      }]
  };
  AverageChartOptions: Highcharts.Options = {
    chart: {
      type: 'bar',
    },
    title: {
      text: ''
    },

    xAxis: {
      categories: ['Jan 11', 'Jan 12', 'Jan 13', 'Jan 14', 'Jan 15', 'Jan 16'],
      // crosshair: true
    },
    tooltip: {
      valueSuffix: ' '
    },
    yAxis: {
      min: 0,
      //  title: {
      //     text: 'Rainfall (mm)'
      //  }
    },
    plotOptions: {
      column: {
        pointPadding: 0,
        borderWidth: 0,

      },
      series: {
        dataLabels: {
          enabled: true
        }
      }
    },
    series: [{
      data: [80, 60, 50, 60, 30, 50],
      color: 'var(--color-primary)',
      name: 'In',
      type: 'bar'
    },
      {
        data: [80, 30, 50, 40, 30, 50],
        color: 'var(--color-secondary)',
        name: 'Out',
        type: 'bar'
      }]
  };
  SeleryChartOptions: Highcharts.Options = {
    chart: {
      type: 'column',
    },
    title: {
      text: ''
    },

    xAxis: {
      categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
      ],
      // crosshair: true
    },
    tooltip: {
      valueSuffix: ' '
    },
    yAxis: {
      min: 0,
      //  title: {
      //     text: 'Rainfall (mm)'
      //  }
    },
    plotOptions: {
      column: {
        pointPadding: 0,
        borderWidth: 0,

      },
      series: {
        dataLabels: {
          enabled: true
        }
      }
    },
    series: [{
      data: [900, 200, 300, 400, 540, 300, 400, 2323, 2343, 2234, 233, 2324],
      color: 'var(--color-primary)',
      name: 'Selery',
      type: 'column'
    }]
  };
  StatutoryChartOptions: Highcharts.Options = {
    chart: {
      type: 'column',
    },
    title: {
      text: ''
    },

    xAxis: {
      categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
      ],
      // crosshair: true
    },
    tooltip: {
      valueSuffix: ' '
    },
    yAxis: {
      min: 0,
      //  title: {
      //     text: 'Rainfall (mm)'
      //  }
    },
    plotOptions: {
      column: {
        pointPadding: 0,
        borderWidth: 0,

      },
      series: {
        dataLabels: {
          enabled: true
        }
      }
    },
    series: [{
      data: [900, 200, 300, 400, 540, 300, 400, 2323, 2343, 2234, 233, 2324],
      color: 'var(--color-primary)',
      name: 'Paid',
      type: 'column'
    },
      {
        data: [900, 200, 300, 400, 540, 300, 400, 2323, 2343, 2234, 233, 2324],
        color: 'var(--color-secondary)',
        name: 'Dues',
        type: 'column'
      }]
  };
  OverviewChartOptions: Highcharts.Options = {
    chart: {
      type: 'area'
    },
    title: {
      text: ''
    },
    yAxis: {
      title: {
        text: 'Nuclear weapon states'
      },

    },

    plotOptions: {
      area: {
        pointStart: 1940,
        marker: {
          enabled: false,
          symbol: 'circle',
          radius: 2,
          states: {
            hover: {
              enabled: true
            }
          }
        }
      }
    },
    series: [{
      name: 'USA',
      type: 'area',
      color: 'var(--color-primary-m)',
      opacity: 0.7,
      data: [
        11, 32, 110, 235,
        369, 640, 1005, 1436, 2063, 3057, 4618, 6444, 9822, 15468,
        20434, 24126, 27387, 29459, 31056, 31982, 32040, 31233, 29224, 27342,
        26662, 26956, 27912, 28999, 28965, 27826, 25579, 25722, 24826, 24605,
        24304, 23464, 23708, 24099, 24357, 24237, 24401, 24344, 23586, 22380,
        21004, 17287, 14747, 13076, 12555, 12144, 11009, 10950, 10871, 10824,
        10577, 10527, 10475, 10421, 10358, 10295, 10104, 9914, 9620, 9326,
        5113, 5113, 4954, 4804, 4761, 4717, 4368, 4018
      ]
    }, {
      name: 'USSR/Russia',
      type: 'area',
      opacity: 0.7,
      color: 'var(--color-secondary-m)',
      data: [25, 50, 120, 150, 200, 426, 660, 869, 1060,
        1605, 2471, 3322, 4238, 5221, 6129, 7089, 8339, 9399, 10538,
        11643, 13092, 14478, 15915, 17385, 19055, 21205, 23044, 25393, 27935,
        30062, 32049, 33952, 35804, 37431, 39197, 35000, 33000, 31000, 39000,
        37000, 35000, 33000, 31000, 29000, 27000, 25000, 24000, 23000, 22000,
        21000, 20000, 19000, 18000, 18000, 17000, 16000, 15537, 14162, 12787,
        12600, 11400, 5500, 4512, 4502, 4502, 4500, 4500
      ]
    }]
  };
  calendarOptions: CalendarOptions = {
    headerToolbar: {
      left: 'prev,next today',
      center: 'title',
      right: 'dayGridMonth'
    },
    plugins: [dayGridPlugin, interactionPlugin],
    initialView: 'dayGridMonth',
    initialEvents: INITIAL_EVENTS, // alternatively, use the `events` setting to fetch from a feed
    weekends: true,
    editable: true,
    selectable: true,
    selectMirror: true,
    dayMaxEvents: true,
    select: this.handleDateSelect.bind(this),
    eventClick: this.handleEventClick.bind(this),
    eventsSet: this.handleEvents.bind(this)
    /* you can update a remote database when these fire:
     eventAdd:
     eventChange:
     eventRemove:
     */
  };
  currentEvents: EventApi[] = [];

  constructor(@Inject(DOCUMENT) private document: Document) {}

  ngOnInit(): void {
    this.document.body.classList.add('change_color');
  }

  ngOnDestroy(): void {
    this.document.body.classList.remove('change_color');
  }

  handleCalendarToggle() {
    this.calendarVisible = !this.calendarVisible;
  }

  handleWeekendsToggle() {
    const { calendarOptions } = this;
    calendarOptions.weekends = !calendarOptions.weekends;
  }

  handleDateSelect(selectInfo: DateSelectArg) {
    const title = prompt('Please enter a new title for your event');
    const calendarApi = selectInfo.view.calendar;

    calendarApi.unselect(); // clear date selection

    if (title) {
      calendarApi.addEvent({
        id: createEventId(),
        title,
        start: selectInfo.startStr,
        end: selectInfo.endStr,
        allDay: selectInfo.allDay
      });
    }
  }

  handleEventClick(clickInfo: EventClickArg) {
    if (confirm(`Are you sure you want to delete the event '${ clickInfo.event.title }'`)) {
      clickInfo.event.remove();
    }
  }

  handleEvents(events: EventApi[]) {
    this.currentEvents = events;
  }
}
