import { EmployeeService } from 'src/app/payroll/employee/services/employee.service';
import { Location } from '@angular/common';
import { Employee } from '../models/employee';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import Swal from 'sweetalert2';
import { HbErrorHandler, HbErrorHandlerData } from '../../../shared/models/hb-error-handler';
import { HBLoaderService } from '../../../shared/services/hb-loader.service';
import { PopupService } from 'src/app/shared/services/popup.service';

@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.scss'],
})
export class AddEmployeeComponent implements OnInit {

  employee = new Employee();

  genderList: string[] = ['Male', 'Female', 'Other', 'Not willing to specify'];
  maritalStatus: string[] = ['Married', 'Unmarried', 'Not willing to specify'];
  hbErrorHandler: HbErrorHandler = new HbErrorHandler();
  employeeId: number;
  sameFlag: boolean = false;

  constructor(
    private _location: Location,
    private employeeService: EmployeeService,
    private router: Router,
    private activatedRoute: ActivatedRoute
  ) { }

  ngOnInit(): void {
    this.editEmployee();
  }

  back() {
    this._location.back();
  }

  editEmployee() {
    this.activatedRoute.params.subscribe(params => {
      if (params.id) {
        this.employeeId = params.id;
        this.getEmployee();
      }
    });
  }

  addUpdateEmployee() {
    this.validateData();
    if (!this.hbErrorHandler.invalid) {
      console.log(this.employee);
      if (!this.employee.id) {
        HBLoaderService.showLoader();
        this.employeeService.addEmployee(this.employee).subscribe(response => {
          console.log(this.employee);
          if (response.status === 200 && response.data && response.data.employee) {
            this.confirmationPopup(response.message);
          }else{
            PopupService.failedAlert("Employee","Some Thing Went Wrong");
          }
          HBLoaderService.hideLoader();
        });
      } else {
        HBLoaderService.showLoader();
        this.employeeService.updateEmployee(this.employee).subscribe(response => {
          console.log(this.employee);
          if (response.status === 200 && response.data && response.data.employee) {
            this.confirmationPopup(response.message);
          }else{
            PopupService.failedAlert("Employee","Some Thing Went Wrong");
          }
          HBLoaderService.hideLoader();
        });
      }
    } else {
      window.scrollTo(0, 0);
      HBLoaderService.hideLoader();
    }
  }

  errorHandler(parentkey: string, childkey?: string, keyIndex?: number): HbErrorHandlerData {
    const hData = this.hbErrorHandler.getErrorHandlerData(parentkey, childkey, keyIndex);
    return hData;
  }

  getEmployee() {
    HBLoaderService.showLoader();
    this.employeeService.getEmployee(this.employeeId).subscribe(response => {
      console.log(response);
      if (response.status === 200 && response.data && response.data.employee) {
        this.employee = response.data.employee;
        this.sameFlag = this.employee.sameAsCorrespondence
        HBLoaderService.hideLoader();
      }
    });
  }

  validateData() {
    this.hbErrorHandler.clearErrors();
    this.hbErrorHandler.emptyCheck(this.employee.name, 'name');
    this.hbErrorHandler.emptyCheck(this.employee.employmentStatusId, 'employmentStatusId');
    this.hbErrorHandler.emptyCheck(this.employee.maritalStatus, 'maritalStatus');
    this.hbErrorHandler.emptyCheck(this.employee.officialEmail, 'officialEmail');
    this.hbErrorHandler.emptyCheck(this.employee.pan, 'pan');
    this.hbErrorHandler.emptyCheck(this.employee.personalEmail, 'personalEmail');
    this.hbErrorHandler.emptyCheck(this.employee.phoneNo, 'phoneNo');
    this.hbErrorHandler.emptyCheck(this.employee.verificationAddress, 'verificationAddress');
    this.hbErrorHandler.emptyCheck(this.employee.gender, 'gender');
    this.hbErrorHandler.emptyCheck(this.employee.dob, 'date');

    // this.hbErrorHandler.emptyCheck(this.employee.nationName, 'nationName');
    if (this.employee.employeeCompanyDetails) {
      this.hbErrorHandler.emptyCheck(this.employee.employeeCompanyDetails.employeeNumber, 'employee.employeeCompanyDetails', 'employeeNumber');
      this.hbErrorHandler.emptyCheck(this.employee.employeeCompanyDetails.attendanceTypeCode, 'employee.employeeCompanyDetails', 'attendanceTypeCode');
      this.hbErrorHandler.emptyCheck(this.employee.employeeCompanyDetails.designationId, 'employee.employeeCompanyDetails', 'designationId');
      this.hbErrorHandler.emptyCheck(this.employee.employeeCompanyDetails.joiningDate, 'employee.employeeCompanyDetails', 'joiningDate');
      this.hbErrorHandler.emptyCheck(this.employee.employeeCompanyDetails.payFrequencyId, 'employee.employeeCompanyDetails', 'payFrequencyId');
      this.hbErrorHandler.emptyCheck(this.employee.employeeCompanyDetails.shiftTimingId, 'employee.employeeCompanyDetails', 'shiftTimingId');
      this.hbErrorHandler.emptyCheck(this.employee.employeeCompanyDetails.employeeLevelId, 'employee.employeeCompanyDetails', 'employeeLevelId');
    }
    if (this.employee.employeeSalaryDetails) {
      this.hbErrorHandler.emptyCheck(this.employee.employeeSalaryDetails.basicSalary, 'employee.employeeSalaryDetails', 'basicSalary');
      this.hbErrorHandler.emptyCheck(this.employee.employeeSalaryDetails.employeeAllowance, 'employee.employeeSalaryDetails.employeeAllowance', 'basicSalary');
      this.employee.employeeSalaryDetails.employeeAllowance.forEach((element, index) => {
        if (!element.allowanceMasterId) {
          this.hbErrorHandler.emptyCheck(this.employee.employeeSalaryDetails.employeeAllowance[index].amount, 'employee.employeeSalaryDetails.employeeAllowance[' + index + '].amount');
          this.hbErrorHandler.emptyCheck(this.employee.employeeSalaryDetails.employeeAllowance[index].allowanceMasterId, 'employee.employeeSalaryDetails.employeeAllowance[' + index + '].allowanceMasterId');
        }
      });

      this.employee.employeeSalaryDetails.employeeDeduction.forEach((element, index) => {
        if (!element.deductionMasterId) {
          this.hbErrorHandler.emptyCheck(this.employee.employeeSalaryDetails.employeeDeduction[index].deductionMasterId, 'employee.employeeSalaryDetails.employeeDeduction[' + index + '].deductionMasterId');
          this.hbErrorHandler.emptyCheck(this.employee.employeeSalaryDetails.employeeDeduction[index].amount, 'employee.employeeSalaryDetails.employeeDeduction[' + index + '].amount');
        }
      });

      this.employee.employeeSalaryDetails.employeeReimbursement.forEach((element, index) => {
        if (!element.reimbursementMasterId) {
          this.hbErrorHandler.emptyCheck(this.employee.employeeSalaryDetails.employeeReimbursement[index].reimbursementMasterId, 'employee.employeeSalaryDetails.employeeReimbursement[' + index + '].reimbursementMasterId');
          this.hbErrorHandler.emptyCheck(this.employee.employeeSalaryDetails.employeeReimbursement[index].amount, 'employee.employeeSalaryDetails.employeeReimbursement[' + index + '].amount');
        }
      });
    }
    if (this.employee.employeeCompanyDetails.employeeCategoryName === 'Contractual') {
      this.hbErrorHandler.emptyCheck(this.employee.employeeCompanyDetails.contractFrom, 'employee.employeeCompanyDetails', 'contractFrom');
      this.hbErrorHandler.emptyCheck(this.employee.employeeCompanyDetails.contractTo, 'employee.employeeCompanyDetails', 'contractTo');
    }
    if (this.employee.employeeAccount) {
      this.hbErrorHandler.emptyCheckList(this.employee.employeeAccount, 'employee.employeeAccount', [
        { key: 'bankName', duplicateCheck: false },
        { key: 'fullName', duplicateCheck: false },
        { key: 'accountNumber', duplicateCheck: false },
        { key: 'branchName', duplicateCheck: false },
        { key: 'ifsc', duplicateCheck: false }
      ]);
    }
    if (this.employee.employeeExperience) {
      this.employee.employeeExperience.forEach((element, index) => {
        this.hbErrorHandler.emptyCheck(this.employee.employeeExperience[index].companyName, 'employee.employeeExperience[' + index + '].companyName');
        // this.hbErrorHandler.emptyCheck(this.employee.employeeExperience[index].countryId, 'employee.employeeExperience[' + index + '].countryId');
        this.hbErrorHandler.emptyCheck(this.employee.employeeExperience[index].startDate, 'employee.employeeExperience[' + index + '].startDate');
        this.hbErrorHandler.emptyCheck(this.employee.employeeExperience[index].endDate, 'employee.employeeExperience[' + index + '].endDate');
        this.hbErrorHandler.emptyCheck(this.employee.employeeExperience[index].industryId, 'employee.employeeExperience[' + index + '].industryId');
        this.hbErrorHandler.emptyCheck(this.employee.employeeExperience[index].title, 'employee.employeeExperience[' + index + '].title');
        this.hbErrorHandler.emptyCheck(this.employee.employeeExperience[index].employmentTypeCode, 'employee.employeeExperience[' + index + '].employmentTypeCode');
        if (element) {
          const tempError = [];
          tempError.push({ key: 'documentTypeId', duplicateCheck: false });
          tempError.push({ key: 'remark', duplicateCheck: false });
          this.hbErrorHandler.emptyCheckList(element.employeeExperienceAttachments, 'employee.employeeExperience[' + index + '].' + 'employeeExperienceAttachments', tempError);
        }
      });
    }
    if (this.employee.employeeQualification) {
      this.hbErrorHandler.emptyCheckList(this.employee.employeeQualification, 'employee.employeeQualification', [
        { key: 'documentTypeId', duplicateCheck: false },
        { key: 'remark', duplicateCheck: false },
        { key: 'institutionDescription', duplicateCheck: false },
        // { key: 'countryId', duplicateCheck: false },
        // { key: 'stateId', duplicateCheck: false }
      ]);
    }

    if(this.employee.employeeReference){
      this.hbErrorHandler.emptyCheckList(this.employee.employeeReference, 'employee.employeeReference', [
        { key: 'mobile', duplicateCheck: false },
        { key: 'name', duplicateCheck: false },
      ]);
    }
  }

  confirmationPopup(message: any) {
    Swal.fire({
      title: 'Employee',
      html: message,
      icon: 'success',
      allowOutsideClick: false,
      allowEscapeKey: false,
    }).then(() => {
      this.router.navigateByUrl('/payroll/employee/employee-listing');
    });
  }
}
