import { Component, Input, OnInit } from '@angular/core';
import { EmployeeAccount } from '../../models/employee-account';
import { HbErrorHandler, HbErrorHandlerData } from '../../../../shared/models/hb-error-handler';

@Component({
  selector: 'app-bank-account',
  templateUrl: './bank-account.component.html',
  styleUrls: ['./bank-account.component.scss'],
})
export class BankAccountComponent implements OnInit {
  @Input() viewFlag: boolean = false;
  @Input() employeeAccount: EmployeeAccount[];
  @Input() hbErrorHandler: HbErrorHandler;

  constructor() {}

  ngOnInit(): void {
    this.addAccount();
  }

  addAccount() {
    this.employeeAccount.push(new EmployeeAccount());
  }

  removeAccount(index: number) {
    this.employeeAccount.splice(index, 1);
  }

  errorHandler(parentkey: string, childkey?: string, keyIndex?: number): HbErrorHandlerData {
    const hData = this.hbErrorHandler.getErrorHandlerData(parentkey, childkey, keyIndex);
    return hData;
  }
}
