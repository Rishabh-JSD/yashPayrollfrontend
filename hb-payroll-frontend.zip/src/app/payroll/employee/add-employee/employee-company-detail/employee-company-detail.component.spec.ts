import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployeeCompanyDetailComponent } from './employee-company-detail.component';

describe('EmployeeCompanyDetailComponent', () => {
  let component: EmployeeCompanyDetailComponent;
  let fixture: ComponentFixture<EmployeeCompanyDetailComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [EmployeeCompanyDetailComponent],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EmployeeCompanyDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
