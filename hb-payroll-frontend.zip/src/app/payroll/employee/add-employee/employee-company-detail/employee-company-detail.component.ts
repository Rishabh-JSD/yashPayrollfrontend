import { Component, Input, OnInit } from '@angular/core';
import { EmployeeCompanyDetails } from '../../models/employee-company-details';
import { Employee } from '../../models/employee';
import { EmployeeService } from '../../services/employee.service';
import { DatePipe } from '@angular/common';
import { HbErrorHandler, HbErrorHandlerData } from '../../../../shared/models/hb-error-handler';
import { MasterOption } from 'src/app/payroll/master-rules/common/models/masters-options';
import { DocumentSeriesSettingService } from 'src/app/settings/document-series-setting/service/document-series-service';
import { AppConst } from 'src/app/core/constants/app-const';
import { DocumentSeriesResponse } from 'src/app/shared/models/document-series-response';

@Component({
  selector: 'app-employee-company-detail',
  templateUrl: './employee-company-detail.component.html',
  styleUrls: ['./employee-company-detail.component.scss'],
  providers: [DatePipe]
})
export class EmployeeCompanyDetailComponent implements OnInit {
  @Input() viewFlag: boolean = false;
  @Input() employee: Employee;
  @Input() employeeCompanyDetails: EmployeeCompanyDetails;
  @Input() hbErrorHandler: HbErrorHandler;

  masterOption = new MasterOption()

  // employeeListByDepartment1 = [];
  documentSeriesResponse = new DocumentSeriesResponse()
  MODULE_CODE = AppConst.MODULE_CODE;


  constructor(
    private employeeService: EmployeeService,
    private datePipe: DatePipe,
    private documentSeries: DocumentSeriesSettingService
  ) { }

  @Input()
  set editEmployee(value) {
    if (value) {
      // this.getEmployeeListByDepartment();
    }
  }

  ngOnInit(): void {
    if (!this.employeeCompanyDetails) {
      this.employeeCompanyDetails = new EmployeeCompanyDetails();
    }
  }

  // getEmployeeListByDepartment() {
  //   let pagination = new PaginationCriteria();
  //   if (this.employeeCompanyDetails.departmentId) {
  //     pagination.departmentId = this.employeeCompanyDetails.departmentId;
  //     this.employeeService.getListEmployee(pagination).subscribe(response => {
  //       console.log(response);
  //       if (response.status === 200 && response.data && response.data.employee && response.data.employee.list) {
  //         this.employeeListByDepartment1 = response.data.employee.list;
  //         this.employeeListByDepartment1.map(x => {
  //           x['label'] = x.name;
  //         });
  //       }
  //     });
  //   }
  // }


  errorHandler(parentkey: string, childkey?: string, keyIndex?: number): HbErrorHandlerData {
    const hData = this.hbErrorHandler.getErrorHandlerData(parentkey, childkey, keyIndex);
    return hData;
  }

  getAutoCode() {
    if (this.employeeCompanyDetails.branchId) {
      this.documentSeries.getAutoSeriesByDocType(this.MODULE_CODE.EMPLOYEE.trim(), this.employeeCompanyDetails.branchId).subscribe(response => {
        if (response && response.status == 200 && response.data.series != null) {
          this.documentSeriesResponse = response.data.series;
          this.employeeCompanyDetails.employeeNumber = this.documentSeriesResponse.seriesNumber;
          this.employeeCompanyDetails.previousNumber = this.employeeCompanyDetails.employeeNumber;
          this.employeeCompanyDetails.overrideFlag = this.documentSeriesResponse.overrideFlag;
          this.employeeCompanyDetails.displayStyle = this.documentSeriesResponse.displayStyle;
          this.employeeCompanyDetails.currentNumber = this.documentSeriesResponse.currentNumber;
        } else {
          this.employeeCompanyDetails.employeeNumber = "";
          this.employeeCompanyDetails.overrideFlag = false;
          this.employeeCompanyDetails.displayStyle = null;
          this.employeeCompanyDetails.currentNumber = null;
        }
      });
    }
  }

  onEmployeeNumber() {
    if (this.employeeCompanyDetails.employeeNumber === this.employeeCompanyDetails.previousNumber) {
      this.employeeCompanyDetails.displayStyle = this.documentSeriesResponse.displayStyle;
      this.employeeCompanyDetails.currentNumber = this.documentSeriesResponse.currentNumber;
    } else {
      this.employeeCompanyDetails.displayStyle = null;
      this.employeeCompanyDetails.currentNumber = null;
    }
  }

  onCategoryChange(event: any) {
    if (event) {
      this.masterOption.code = event.code
    }
  }
}
