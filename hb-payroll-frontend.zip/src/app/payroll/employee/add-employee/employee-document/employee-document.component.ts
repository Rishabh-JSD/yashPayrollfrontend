import { Component, Input, OnInit } from '@angular/core';
import { EmployeeKyc } from '../../models/employee-kyc';
import { EmployeeQualification } from '../../models/employee-qualification';
import { AddressService } from 'src/app/shared/services/address.service';
import { HbErrorHandler, HbErrorHandlerData } from 'src/app/shared/models/hb-error-handler';

@Component({
  selector: 'app-employee-document',
  templateUrl: './employee-document.component.html',
  styleUrls: ['./employee-document.component.scss'],
})
export class EmployeeDocumentComponent implements OnInit {
  @Input() viewFlag: boolean = false;
  @Input() employeeKyc: EmployeeKyc[];
  @Input() employeeQualification: EmployeeQualification[];
  @Input() hbErrorHandler: HbErrorHandler;


  states1 = [];

  constructor( private addressService: AddressService) {}

  ngOnInit(): void {
    this.addKycRow();
    this.addQualificationRow();
    // this.getStateList();
  }

  // getStateList() {
  //   this.addressService.getStateList().subscribe(response => {
  //     if (response.status === 200 && response.data && response.data.state) {
  //       this.states1 = response.data.state;
  //       this.states1.map(x => {
  //         x['label'] = x.name;
  //       });
  //       console.log(response);
  //     }
  //   });
  // }

  // getCountryList(sortField: string = '') {
  //   this.addressService.getCountryList(sortField).subscribe(response => {
  //     if (response.status === 200 && response.data && response.data.country) {
  //       this.countries = response.data.country;
  //       console.log(response);
  //     }
  //   });
  // }

  // setCountry(country: Countries, index: number) {
  //   this.employeeQualification[index].countryId = country.id;
  //   console.log(this.employeeQualification[index]);
  // }

  addKycRow() {
    this.employeeKyc.push(new EmployeeKyc());
  }

  removeKycRow(index: number) {
    this.employeeKyc.splice(index, 1);
  }

  addQualificationRow() {
    this.employeeQualification.push(new EmployeeQualification());
  }

  removeQualificationRow(index: number) {
    this.employeeQualification.splice(index, 1);
  }

  errorHandler(parentkey: string, childkey?: string, keyIndex?: number): HbErrorHandlerData {
    const hData = this.hbErrorHandler.getErrorHandlerData(parentkey, childkey, keyIndex);
    return hData;
  }
}
