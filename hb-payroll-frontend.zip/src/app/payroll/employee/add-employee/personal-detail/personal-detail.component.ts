import { AddressService } from '../../../../shared/services/address.service';
import { Component, Input, OnInit } from '@angular/core';
import { EmployeeReference } from '../../models/employee-reference';
import { Address } from 'src/app/shared/models/address';
import { HbErrorHandler, HbErrorHandlerData } from '../../../../shared/models/hb-error-handler';
import { Employee } from '../../models/employee';

@Component({
  selector: 'app-personal-detail',
  templateUrl: './personal-detail.component.html',
  styleUrls: ['./personal-detail.component.scss'],
})
export class PersonalDetailComponent implements OnInit {
  @Input() viewFlag: boolean = false;
  @Input() employee: Employee;
  @Input() hbErrorHandler: HbErrorHandler;
  @Input() sameFlag: boolean = false

  status: string;
  sameAsFlag: boolean = false;

  genderList1 = [
    { label: 'Male', code: 'Male', id: undefined, value: undefined },
    { label: 'Female', code: 'Female', id: undefined, value: undefined },
    { label: 'Other', code: 'Other', id: undefined, value: undefined },
    { label: 'Not willing to specify', code: 'Not wiiling to specify', id: undefined, value: undefined },
  ];

  maritalStatus1 = [
    { label: 'Married', code: 'Married', id: undefined, value: undefined },
    { label: 'Unmarried', code: 'Unmarried', id: undefined, value: undefined },
    { label: 'Not willing to specify', code: 'Not willing to specify', id: undefined, value: undefined },
  ];

  addressVerificationList1 = [
    { label: 'Correspondence Verified', code: 'correspondence', id: undefined, value: undefined },
    { label: 'Permanent Verified', code: 'permanent', id: undefined, value: undefined },
    { label: 'Not Verified', code: 'not_verified', id: undefined, value: undefined },
  ];

  constructor( private addressService: AddressService) {}

  ngOnInit(): void {
    this.addReference();
  }

  setFlag(){
  if(this.employee){
    this.sameAsFlag = this.employee.sameAsCorrespondence
  }else{
    this.sameAsFlag
  }
  return this.sameAsFlag
  }

  // setCountry(country: any) {
  //   this.employee.nationalityId = country.id;
  // }

  setSameAsFlag(event) {
    this.employee.sameAsCorrespondence = event;
    if(event){
    this.employee.addressPermanent.addressOne = this.employee.addressCorrespondence.addressOne;
    this.employee.addressPermanent.addressTwo =this.employee.addressCorrespondence.addressTwo;
    this.employee.addressPermanent.cityName =this.employee.addressCorrespondence.cityName;
    this.employee.addressPermanent.countryName =this.employee.addressCorrespondence.countryName;
    this.employee.addressPermanent.pincode =this.employee.addressCorrespondence.pincode;
    this.employee.addressPermanent.stateName =this.employee.addressCorrespondence.stateName;
    } else {
      this.employee.addressPermanent = new Address ();
    }
  }

  addReference() {
    this.employee.employeeReference.push(new EmployeeReference());
  }

  removeReference(index) {
    this.employee.employeeReference.splice(index, 1);
  }

  errorHandler(parentkey: string, childkey?: string, keyIndex?: number): HbErrorHandlerData {
    const hData = this.hbErrorHandler.getErrorHandlerData(parentkey, childkey, keyIndex);
    return hData;
  }
}
