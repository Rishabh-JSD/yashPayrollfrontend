import { Component, Input, OnInit } from '@angular/core';
import { EmployeeAllowance } from '../../models/employee-allowance';
import { EmployeeDeduction } from '../../models/employee-deduction';
import { EmployeeReimbursement } from '../../models/employee-reimbursement';
import { EmployeeSalaryDetails } from '../../models/employee-salary-details';
import { HbErrorHandler, HbErrorHandlerData } from '../../../../shared/models/hb-error-handler';

@Component({
  selector: 'app-salary-detail',
  templateUrl: './salary-detail.component.html',
  styleUrls: ['./salary-detail.component.scss'],
})
export class SalaryDetailComponent implements OnInit {
  @Input() viewFlag: boolean = false;
  @Input() employeeSalaryDetails: EmployeeSalaryDetails;
  @Input() hbErrorHandler: HbErrorHandler;
  x;

  constructor() {}

  ngOnInit(): void {
    // this.addAllowance();
    // this.addDeduction();
    // this.addReimbursement();
  }

  calculateCtc() {
    if (
      this.employeeSalaryDetails.basicSalary != null &&
      this.employeeSalaryDetails.allowanceTotal == null &&
      this.employeeSalaryDetails.reimbursementTotal == null
    ) {
      this.employeeSalaryDetails.ctc = this.employeeSalaryDetails.basicSalary;
    }
    if (
      this.employeeSalaryDetails.basicSalary != null &&
      this.employeeSalaryDetails.allowanceTotal != null &&
      this.employeeSalaryDetails.reimbursementTotal == null
    ) {
      this.employeeSalaryDetails.ctc = this.employeeSalaryDetails.basicSalary + this.employeeSalaryDetails.allowanceTotal;
    }
    if (
      this.employeeSalaryDetails.basicSalary != null &&
      this.employeeSalaryDetails.allowanceTotal == null &&
      this.employeeSalaryDetails.reimbursementTotal != null
    ) {
      this.employeeSalaryDetails.ctc = this.employeeSalaryDetails.basicSalary + this.employeeSalaryDetails.reimbursementTotal;
    }
    if (
      this.employeeSalaryDetails.basicSalary != null &&
      this.employeeSalaryDetails.allowanceTotal != null &&
      this.employeeSalaryDetails.reimbursementTotal != null
    ) {
      this.employeeSalaryDetails.ctc =
        this.employeeSalaryDetails.basicSalary + this.employeeSalaryDetails.allowanceTotal + this.employeeSalaryDetails.reimbursementTotal;
    }
    if (this.employeeSalaryDetails.basicSalary == null) {
      this.employeeSalaryDetails.ctc = null;
    }
    this.calculateNetPay();
  }

  calculateNetPay() {
    if (this.employeeSalaryDetails.ctc != null && this.employeeSalaryDetails.deductionTotal != null) {
      this.employeeSalaryDetails.netPayBeforeTds = this.employeeSalaryDetails.ctc - this.employeeSalaryDetails.deductionTotal;
    }
    if (this.employeeSalaryDetails.ctc != null && this.employeeSalaryDetails.deductionTotal == null) {
      this.employeeSalaryDetails.netPayBeforeTds = this.employeeSalaryDetails.ctc;
    }
    if (this.employeeSalaryDetails.ctc == null) {
      this.employeeSalaryDetails.netPayBeforeTds = null;
    }
  }

  calculateAllowanceTotal() {
    this.employeeSalaryDetails.allowanceTotal = 0;
    if (this.employeeSalaryDetails.employeeAllowance) {
      this.employeeSalaryDetails.employeeAllowance.forEach(allowance => {
        if (allowance.amount != null) {
          this.employeeSalaryDetails.allowanceTotal += allowance.amount;
        }
      });
    }
    this.calculateCtc();
  }

  calculateDeductionTotal() {
    this.employeeSalaryDetails.deductionTotal = 0;
    if (this.employeeSalaryDetails.employeeDeduction) {
      this.employeeSalaryDetails.employeeDeduction.forEach(deduction => {
        if (deduction.amount) {
          this.employeeSalaryDetails.deductionTotal += deduction.amount;
        }
      });
    }
    this.calculateCtc();
  }

  calculateReimbursementTotal() {
    this.employeeSalaryDetails.reimbursementTotal = 0;
    if (this.employeeSalaryDetails.employeeReimbursement) {
      this.employeeSalaryDetails.employeeReimbursement.forEach(reimburse => {
        if (reimburse.amount != null) {
          this.employeeSalaryDetails.reimbursementTotal += reimburse.amount;
        }
      });
    }
    this.calculateCtc();
  }

  addAllowance() {
    this.employeeSalaryDetails.employeeAllowance.push(new EmployeeAllowance());
  }

  removeAllowance(index: number) {
    this.employeeSalaryDetails.employeeAllowance.splice(index, 1);
  }

  addDeduction() {
    this.employeeSalaryDetails.employeeDeduction.push(new EmployeeDeduction());
  }

  removeDeduction(index: number) {
    this.employeeSalaryDetails.employeeDeduction.splice(index, 1);
  }

  addReimbursement() {
    this.employeeSalaryDetails.employeeReimbursement.push(new EmployeeReimbursement());
  }

  removeReimbursement(index: number) {
    this.employeeSalaryDetails.employeeReimbursement.splice(index, 1);
  }

  errorHandler(parentkey: string, childkey?: string, keyIndex?: number): HbErrorHandlerData {
    const hData = this.hbErrorHandler.getErrorHandlerData(parentkey, childkey, keyIndex);
    return hData;
  }
}
