import { IndustryService } from '../../../../shared/services/industry.service';
import { Component, Input, OnInit } from '@angular/core';
import { AddressService } from 'src/app/shared/services/address.service';
import { EmployeeExperience } from '../../models/employee-experience';
import { EmployeeExperienceAttachment } from '../../models/employee-experience-attachment';
import { Industry } from 'src/app/shared/models/industry';
import { HbErrorHandler, HbErrorHandlerData } from '../../../../shared/models/hb-error-handler';

@Component({
  selector: 'app-work-experience',
  templateUrl: './work-experience.component.html',
  styleUrls: ['./work-experience.component.scss'],
})
export class WorkExperienceComponent implements OnInit {
  @Input() viewFlag: boolean = false;
  @Input() employeeExperience: EmployeeExperience[];
  @Input() hbErrorHandler: HbErrorHandler;

  states1 = [];

  constructor(
    private addressService: AddressService,
    private industryService: IndustryService
  ) {}

  @Input() set getIndustry(value: any) {
    if (this.employeeExperience && this.employeeExperience.length > 0) {
      this.employeeExperience.forEach(exp => {
        if (exp.industryId) {
          this.industryService.getIndustryById(exp.industryId).subscribe(response => {
            if (response.status === 200 && response.data && response.data.industry) {
              let industry: Industry = response.data.industry;
              exp.industryName = industry.name;
            }
          });
        }
      });
    }
  }

  ngOnInit(): void {
    this.addExperienceRow();
    // this.getStateList();
  }

  // getStateList() {
  //   this.addressService.getStateList().subscribe(response => {
  //     if (response.status === 200 && response.data && response.data.state) {
  //       this.states1 = response.data.state;
  //       this.states1.map(x => {
  //         x['label'] = x.name;
  //       });
  //     }
  //   });
  // }

  // setCountry(country: Countries, index: number) {
  //   this.employeeExperience[index].countryId = country.id;
  // }

  addExperienceRow() {
    let experience = new EmployeeExperience();
    experience.employeeExperienceAttachments.push(new EmployeeExperienceAttachment());
    this.employeeExperience.push(experience);
  }

  removeExperienceRow(i: number) {
    this.employeeExperience.splice(i, 1);
  }

  addExperienceAttachmentRow(i: number) {
    this.employeeExperience[i].employeeExperienceAttachments.push(new EmployeeExperienceAttachment());
  }

  removeExperienceAttachmentRow(i: number, j: number) {
    this.employeeExperience[i].employeeExperienceAttachments.splice(j, 1);
  }

  errorHandler(parentkey: string, childkey?: string, keyIndex?: number): HbErrorHandlerData {
    const hData = this.hbErrorHandler.getErrorHandlerData(parentkey, childkey, keyIndex);
    return hData;
  }
}
