import { Component, OnInit, ViewChild } from '@angular/core';
import { Location } from '@angular/common';
import { MatPaginator } from '@angular/material/paginator';
import Swal from 'sweetalert2';
import { Employee } from '../models/employee';
import { EmployeeService } from '../services/employee.service';
import { HbDataTableColumnOption } from '@hostbooks/hb-lib/hb-list-table/src/hb-list-table-columns';
import { Router } from '@angular/router';
import { HbDateFormatPipe } from '../../../shared/pipes/hb-date-format.pipe';
import { HBLoaderService } from '../../../shared/services/hb-loader.service';
import { EmployeeSearchRequest } from '../employee-search-request';

@Component({
  selector: 'app-employee-listing',
  templateUrl: './employee-listing.component.html',
  styleUrls: ['./employee-listing.component.scss'],
  providers: [HbDateFormatPipe]
})
export class EmployeeListingComponent implements OnInit {
  @ViewChild('employeePaginator') employeePaginator: MatPaginator;

  employeeSearchRequest = new EmployeeSearchRequest()

  columns: HbDataTableColumnOption[] = [];
  data: Employee[] = [];
  total: number;
  employeeName;

  constructor(private _location: Location, private employeeService: EmployeeService, private router: Router, private datePipe: HbDateFormatPipe) {}

  ngOnInit(): void {
    this.getEmployeeList();
    this.employeeColumns();
  }

  back() {
    this._location.back();
  }

  employeeColumns(){
    this.columns = [
      {
        header: 'S. No.',
        columnData: (inv: Employee) => {
        },
        type: 'SR_NO'
      },
      {
        header: 'Employee Name',
        columnData: (inv: Employee) => {
          return inv?.name;
        },
        type: 'TEXT'
      },
      {
        header: 'Employee Id',
        columnData: (inv: Employee) => {
          return inv?.employeeCompanyDetails?.employeeNumber;
        },
        type: 'NUMBER'
      },
      {
        header: 'Designation',
        columnData: (inv: Employee) => {
          return inv?.employeeCompanyDetails?.designationName;
        },
        type: 'TEXT'
      },
      {
        header: 'Department',
        columnData: (inv: Employee) => {
          return inv?.employeeCompanyDetails?.departmentName;
        },
        type: 'TEXT'
      },
      {
        header: 'Reporting To',
        columnData: (inv: Employee) => {
          return inv?.employeeCompanyDetails?.reportToId;
        },
        type: 'NUMBER'
      },
      {
        header: 'Profile Completion',
        columnData: (inv: Employee) => {
          return inv?.profileCompletion;
        },
        type: 'NUMBER'
      },
      {
        header: 'Status',
        columnData: (inv: Employee) => {
          return inv?.employmentStatusName;
        },
        type: 'TEXT'
      },
      {
        header: 'Date of Joining',
        columnData: (inv: Employee) => {
          return this.datePipe.transform(inv?.employeeCompanyDetails?.joiningDate);
        },
        type: 'DATE'
      },
      {
        header: 'Term Completed',
        columnData: (inv: Employee) => {
          return inv?.termCompleted;
        },
        type: 'NUMBER'
      },
      {
        header: 'Date of Leaving',
        columnData: (inv: Employee) => {
          return this.datePipe.transform(inv?.employeeCompanyDetails?.separationDate);
        },
        type: 'DATE'
      },
      {
        header: 'Actions',
        columnData: (inv: Employee) => {
        },
        type: 'ACTION',
        actionOptions: ['VIEW', 'EDIT', 'DELETE']
      },
    ];
  }

  getEmployeeList() {
    HBLoaderService.showLoader();
    this.employeeSearchRequest.searchFor = this.employeeName;
    this.employeeService.getListEmployee(this.employeeSearchRequest).subscribe(response => {
      console.log(response);
      if (response.status === 200 && response.data && response.data.employee) {
        this.data = response.data.employee.list;
        this.total = response.data.employee.totalRowCount;
        HBLoaderService.hideLoader();
      }
    });
  }


  deleteEmployee(id: number) {
    this.deleteConfirmationPopup().then(result => {
      if (result.value) {
        HBLoaderService.showLoader();
        this.employeeService.deleteEmployee(id).subscribe(response => {
          console.log(response);
          this.deletedConfirmationPopup(response.message, 'Employee');
          HBLoaderService.hideLoader();
        });
      }
    });
  }

  deleteConfirmationPopup() {
    return Swal.fire({
      title: 'Warning',
      text: 'Are you sure that you want to perform this action?',
      icon: 'question',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes',
      cancelButtonText: 'No',
      allowOutsideClick: false,
      allowEscapeKey: false,
    });
  }

  deletedConfirmationPopup(message, title) {
    Swal.fire({
      title: title,
      text: message,
      icon: 'success',
      allowOutsideClick: false,
      allowEscapeKey: false,
    }).then(result => {
      if (result.value) {
        this.getEmployeeList();
      }
    });
  }

  onAction(_event: any) {
    if (_event && _event.actionType && _event.data) {
      if (_event.actionType === 'DELETE') {
        this.deleteEmployee(_event.data.id);
      }
      if (_event.actionType === 'VIEW') {
        this.router.navigate([`/payroll/employee/view-employee`, _event.data.id]);
      }
      if (_event.actionType === 'EDIT') {
        this.router.navigate(['/payroll/employee/edit-employee', _event.data.id]);
      }
    }
  }
  import(){
    this.router.navigateByUrl('/payroll/importMaster/import?title=employee');
  }

}
