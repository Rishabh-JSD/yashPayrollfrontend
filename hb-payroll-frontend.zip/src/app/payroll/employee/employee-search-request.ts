import { SearchRequest } from "src/app/shared/models/search-request";

export class EmployeeSearchRequest extends SearchRequest {
  searchFor: string;
  id: number;
  departmentId: number;
  name: string;
  catCode: string
}
