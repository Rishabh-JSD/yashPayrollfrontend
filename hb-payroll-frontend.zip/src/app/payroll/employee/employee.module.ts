import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';

import { AddEmployeeComponent } from './add-employee/add-employee.component';
import { EmployeeListingComponent } from './employee-listing/employee-listing.component';
import { SharedModule } from '../../shared/shared.module';
import { PersonalDetailComponent } from './add-employee/personal-detail/personal-detail.component';
import { EmployeeCompanyDetailComponent } from './add-employee/employee-company-detail/employee-company-detail.component';
import { SalaryDetailComponent } from './add-employee/salary-detail/salary-detail.component';
import { BankAccountComponent } from './add-employee/bank-account/bank-account.component';
import { WorkExperienceComponent } from './add-employee/work-experience/work-experience.component';
import { EmployeeDocumentComponent } from './add-employee/employee-document/employee-document.component';
import { ViewEmployeeComponent } from './view-employee/view-employee.component';

const routes: Routes = [
  { path: '', pathMatch: 'full', component: EmployeeListingComponent },
  { path: 'add-employee', component: AddEmployeeComponent },
  { path: 'edit-employee/:id', component: AddEmployeeComponent },
  { path: 'view-employee/:id', component: ViewEmployeeComponent },
  { path: 'employee-listing', component: EmployeeListingComponent },
  { path: '**', redirectTo: '', pathMatch: 'full' },
];

@NgModule({
  declarations: [
    AddEmployeeComponent,
    EmployeeListingComponent,
    PersonalDetailComponent,
    EmployeeCompanyDetailComponent,
    SalaryDetailComponent,
    BankAccountComponent,
    WorkExperienceComponent,
    EmployeeDocumentComponent,
    ViewEmployeeComponent,
  ],
  imports: [
    CommonModule,
    SharedModule,
    RouterModule.forChild(routes)
  ],
})
export class EmployeeModule { }
