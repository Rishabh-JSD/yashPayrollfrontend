export class EmployeeAccount {
  public id: number;
  public employeeId: number;
  public fullName: string;
  public bankName: string;
  public accountNumber: string;
  public branchName: string;
  public ifsc: string;
  public deleteFlag: boolean;
}
