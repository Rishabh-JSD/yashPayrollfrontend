export class EmployeeAllowance {
  public id: number;
  public employeeSalaryDetailId: number;
  public allowanceMasterId: number;
  public allowanceMasterName: string;
  public amount: number;
  public deleteFlag: boolean;
}
