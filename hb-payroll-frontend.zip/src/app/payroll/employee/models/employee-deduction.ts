export class EmployeeDeduction {
  public id: number;
  public employeeSalaryDetailId: number;
  public deductionMasterId: number;
  public deductionMasterName: string;
  public amount: number;
  public deleteFlag: boolean;
}
