export class EmployeeExperienceAttachment {
  public id: number;
  public employeeExperienceId: number;
  public documentTypeId: number;
  public documentTypeName: string;
  public remark: string;
  public documentId: number;
  public deleteFlag: boolean;
}
