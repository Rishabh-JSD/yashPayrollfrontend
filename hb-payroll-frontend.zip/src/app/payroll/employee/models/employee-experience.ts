import { HbErrorHandler } from '../../../shared/models/hb-error-handler';
import { EmployeeExperienceAttachment } from './employee-experience-attachment';

export class EmployeeExperience {
  public id: number;
  public employeeId: number;
  public title: string;
  public employmentTypeCode: string;
  public companyName: string;
  public countryName: string;
  public stateName: string;
  public startDate: string;
  public endDate: string;
  public jobTitle: string;
  public industryId: number;
  public industryName: string;
  public jobDescription: string;
  public deleteFlag: boolean;
  public hbErrorHandlerAttachments = new HbErrorHandler();
  public employeeExperienceAttachments = new Array<EmployeeExperienceAttachment>();
}
