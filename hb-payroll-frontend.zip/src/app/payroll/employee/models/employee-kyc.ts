export class EmployeeKyc {
  public id: number;
  public employeeId: number;
  public documentTypeId: number;
  public documentTypeName: string;
  public remark: string;
  public documentId: number;
  public deleteFlag: boolean;
}
