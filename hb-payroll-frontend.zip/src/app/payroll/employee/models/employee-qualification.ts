export class EmployeeQualification {
  public id: number;
  public employeeId: number;
  public documentTypeId: number;
  public documentTypeName: string;
  public remark: string;
  public institutionDescription: string;
  public countryName: string;
  public stateName: string;
  public documentId: number;
  public deleteFlag: boolean;
}
