export class EmployeeReference {
  public id: number;
  public name: string;
  public employeeId: number;
  public mobile: number;
  public deleteFlag: boolean;
}
