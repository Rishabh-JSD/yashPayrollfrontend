export class EmployeeReimbursement {
  public id: number;
  public employeeSalaryDetailId: number;
  public reimbursementMasterId: number;
  public reimbursementMasterName: string;
  public amount: number;
  public deleteFlag: boolean;
}
