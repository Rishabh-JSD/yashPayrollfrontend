import { EmployeeDeduction } from './employee-deduction';
import { EmployeeAllowance } from './employee-allowance';
import { EmployeeReimbursement } from './employee-reimbursement';

export class EmployeeSalaryDetails {
  public id: number;
  public basicSalary: number;
  public ctc: number;
  public netPayBeforeTds: number;
  public taxSummary: string;
  public deleteFlag: boolean;
  public allowanceTotal: number;
  public deductionTotal: number;
  public reimbursementTotal: number;
  public employeeAllowance: EmployeeAllowance[] = new Array<EmployeeAllowance>();
  public employeeDeduction: EmployeeDeduction[] = new Array<EmployeeDeduction>();
  public employeeReimbursement: EmployeeReimbursement[] = new Array<EmployeeReimbursement>();
}
