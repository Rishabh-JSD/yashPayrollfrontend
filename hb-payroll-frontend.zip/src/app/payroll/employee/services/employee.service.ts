import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HBHttpService } from 'src/app/core/services/hb-http-service.service';

@Injectable({
  providedIn: 'root',
})
export class EmployeeService {
  constructor(private hbHttpClient: HBHttpService) {}

  addEmployee(data: any): Observable<any> {
    return this.hbHttpClient.getResponse('employee/add', this.hbHttpClient.POST, data);
  }

  updateEmployee(data: any): Observable<any> {
    return this.hbHttpClient.getResponse('employee/update', this.hbHttpClient.POST, data);
  }

  getListEmployee(data: any): Observable<any> {
    return this.hbHttpClient.getResponse('employee/list', this.hbHttpClient.POST, data);
  }

  getEmployee(id: any): Observable<any> {
    return this.hbHttpClient.getResponse(`employee/${ id }`, this.hbHttpClient.GET);
  }

  deleteEmployee(id: any): Observable<any> {
    return this.hbHttpClient.getResponse('employee/delete?employeeId=' + id, this.hbHttpClient.DELETE);
  }
}
