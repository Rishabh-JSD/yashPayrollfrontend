import { Employee } from 'src/app/payroll/employee/models/employee';
import { Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../services/employee.service';
import { ActivatedRoute } from '@angular/router';
import { HBLoaderService } from '../../../shared/services/hb-loader.service';

@Component({
  selector: 'app-view-employee',
  templateUrl: './view-employee.component.html',
  styleUrls: ['./view-employee.component.scss'],
})
export class ViewEmployeeComponent implements OnInit {
  employee = new Employee();
  employeeId: number;
  getIndustry: any;

  constructor(private _location: Location, private employeeService: EmployeeService, private activatedRoute: ActivatedRoute) {}

  ngOnInit(): void {
    this.viewEmployee();
  }

  back() {
    this._location.back();
  }

  viewEmployee() {
    this.activatedRoute.params.subscribe(params => {
      if (params['id']) {
        this.employeeId = params['id'];
        this.getEmployee();
      }
    });
  }

  getEmployee() {
    HBLoaderService.showLoader();
    this.employeeService.getEmployee(this.employeeId).subscribe(response => {
      console.log(response);
      if (response.status === 200 && response.data && response.data.employee) {
        this.employee = response.data.employee;
        this.getIndustry = {};
        HBLoaderService.hideLoader();
      }
    });
  }
}
