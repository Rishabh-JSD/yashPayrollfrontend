import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AllColumnDescriptionComponent } from './all-column-description.component';

describe('AllColumnDescriptionComponent', () => {
  let component: AllColumnDescriptionComponent;
  let fixture: ComponentFixture<AllColumnDescriptionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AllColumnDescriptionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AllColumnDescriptionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
