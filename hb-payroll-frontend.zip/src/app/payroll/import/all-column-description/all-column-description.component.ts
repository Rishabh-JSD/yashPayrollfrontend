import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { DataSource } from '@angular/cdk/collections';
import { Observable, of as observableOf, Subscription } from 'rxjs';
import { CommonService } from '../../../shared/services/common.service';
import { ColumnDescription } from './column-description.model';
import { HbDataTableColumnOption } from '@hostbooks/hb-lib/hb-list-table/src/hb-list-table-columns';

@Component({
  selector: 'app-all-column-description',
  templateUrl: './all-column-description.component.html',
  styleUrls: ['./all-column-description.component.scss']
})


export class AllColumnDescriptionComponent implements OnInit, OnDestroy {
  displayedColumns = ['columnName', 'description', 'mandatory', 'Validation'];
  @Input() columnDescription = [];
  @Input() importName: string;
  columns: HbDataTableColumnOption[] = [];

  @Input() set colDescriptionData(columnDescription) {
    if (columnDescription) {
      this.columnDescription = columnDescription.data
    }
  }
  sub: Subscription;
  constructor(private commonService: CommonService) {

  }

  ngOnInit() {
    
    this.columns = [
      {
        header: 'Column Name',
        columnData: (sh: any) => {
          return sh.columnName;
        },
        type: 'TEXT'
      },
      {
        header: 'description',
        columnData: (sh: any) => {
          return sh.date;
        },
        type: 'TEXT'
      },
      {
        header: 'mandatory',
        columnData: (sh: any) => {
          return sh.mandatory;
        },
        type: 'TEXT'
      },
      {
        header: 'validation',
        columnData: (so: any) => {
          return so.validation;
        },
        type: 'TEXT',
      }
    ];
  }

  ngOnDestroy() {
    if (this.sub) {
      this.sub.unsubscribe();
    }
  }
}

