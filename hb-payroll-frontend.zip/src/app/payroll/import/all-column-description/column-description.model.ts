
export class ColumnDescription {
    columnName: string;
    description: string;
    mandatory: string;
    validation: string;

    constructor() {
        
    }
}
