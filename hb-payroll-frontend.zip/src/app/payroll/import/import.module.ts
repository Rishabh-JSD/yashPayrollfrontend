import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { SharedModule } from '../../shared/shared.module';
import { ImportComponent } from "./import/import.component";
import { AllColumnDescriptionComponent } from "./all-column-description/all-column-description.component";

const routes: Routes = [
  { path: '', redirectTo: '', pathMatch: 'full' },
  { path: 'import', pathMatch: 'full', component: ImportComponent },
];

@NgModule({
  declarations: [
    ImportComponent,
    AllColumnDescriptionComponent
  ],
  imports: [CommonModule, SharedModule, RouterModule.forChild(routes)],
})
export class ImportModule {
}