import { Location } from '@angular/common';
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { MatSelectChange } from '@angular/material/select';
import { ActivatedRoute } from '@angular/router';
import { LazyLoadEvent } from 'primeng/api';
import { Field, ImportField } from 'src/app/shared/models/column-description';
import { ImportMaster } from 'src/app/shared/models/import-master';
import { FileReaderService } from 'src/app/shared/services/FileReader.service';
import { ColumnDescriptionWritingService } from 'src/app/shared/services/column-description-writing-service';
import { ImportService } from 'src/app/shared/services/import-service';
import { PopupService } from 'src/app/shared/services/popup.service';
import { ImportFieldList } from './import-row-validation';
import { AlphabetService } from 'src/app/shared/services/alphabet.service';
import { ImportMasterTemplate } from 'src/app/shared/models/import-master-template';
import moment from 'moment';

@Component({
  selector: 'app-import',
  templateUrl: './import.component.html',
  styleUrls: ['./import.component.scss'],
  providers: [FileReaderService, ImportService, ColumnDescriptionWritingService]
})
export class ImportComponent implements OnInit {

  @Input() title: string;
  @Input() validFields: ImportField[];
  @Output() emitHbCategoryOption = new EventEmitter<any>();
  validFields1: Field[];
  columnDescription: any;
  fieldSelectionForAllColumns: FieldSelection[];
  containsHeader = true;
  successMSG: boolean;
  errorList: string[] = [];
  progressBarValue: number;
  isFileLoaded = false;
  isDataTested = false;
  isLoading = false;
  loadButton = false;
  importedRows: any[][];
  virtualRows: any[][] = [];
  virtualRowsData: any[][] = [];
  firstRowIndex: number;
  countOfRows: number;
  pageSize = 5;
  pageSizeOptions = [5, 10, 25, 100];
  pageStartRow = 0;
  pageEndRow = this.pageSize;
  total = 0;
  totalHide = false;
  pageChange: number = 1;
  totalRecords = 0;
  totalRecords1 = 10;
  tableHide = false;
  currentPage = 1;
  errorType = 'Complete these fields:';
  successType = 'Tested successfully ready for import';
  showProgressBar = false;
  valueOfProgressBar: number;
  loopBreaker: number;
  restRunner: number;
  checker = 0;
  importReturnArray = new Array();
  importArray = new Array();
  counter = 0;
  validedImportData = new Array();
  validedImportChunkData: any[][];
  importChunkList = new Array();
  clicked = true;
  goimportflag = false;
  //for add master import
  addMasterDataImport: any[] = [];
  addMasterDataImport1: any = [];
  flag = false;

  displayNameMap = new Map<string, any>();
  extraObjectMap = new Map<string, any>();
  mappedData: any[] = new Array();
  headerMap = new Map<number, string>();


  //template
  templateListNew = new Array();
  templateFLag = false;
  templateId: number = 0;
  templateSaveButtom = true;
  templatePrifix: string = 'Stad';
  TemplateNameSet: string;
  templateIndex = {};
  templateList = new Array();
  templateSetting: string = "Select template"
  templateBoxFLag = true;
  importMasterTemplate = new ImportMasterTemplate();
  importHeaderKeys: string[] = [];
  importHeaderValues: string[] = [];
  selectedTemplate: string = 'Standard Template';
  statusImport: string = 'Draft';
  headerList = [];
  colDescriptionData: any;


  ngOnInit(): void {
    this.activatedRoute.queryParams.subscribe(params => {
      if (params['title']) {
        this.title = params['title'];
        this.title = this.title.replace("-", " ");
        this.title = this.title.replace(/-/g, " ").replace(/([a-z])([A-Z])/g, "$1 $2");
      }
    });
    this.validFields = ImportFieldList.filter(importField => importField.moduleTypeList.includes(this.title));
    if (this.validFields) {
      this.validFields.forEach((element) => {
        this.displayNameMap.set(element.displayName, element);
      })
    }
    this.columnDescription = this.columnDescriptionWritingService.write(this.validFields);
    this.colDescriptionData = {
      data: this.columnDescription
    }
    this.importService.fetchImportTemplate(this.title).subscribe(response => {
      this.getTemplateData(response);
    });


  }
  constructor(private _location: Location, private appFileReader: FileReaderService, private importService: ImportService, private activatedRoute: ActivatedRoute, private columnDescriptionWritingService: ColumnDescriptionWritingService) { }


  // Redirecting to import home page
  onBack() {
    this.errorList = [];
    this.mappedData = [];
    this.isFileLoaded = false;
    this.isDataTested = false;
    this.tableHide = false;
    this.showProgressBar = false;
    this.valueOfProgressBar = 0;
    this.validFields.forEach((validField) => {
      validField.importFileColumnIndex = undefined;
    })
    this._location.back();
  }

  // Excel file new load
  loadNewFile(evt: any) {
    this.errorList = [];
    this.isDataTested = false;
    this.importedRows = [];
    this.mappedData = [];
    this.fieldSelectionForAllColumns = new Array<FieldSelection>();
    this.onFileLoad(evt);
  }

  // Excel file load
  onFileLoad(evt) {
    this.errorList = [];
    this.pageChange = 1;
    this.pageSize = 10;
    this.total = 0;
    this.totalHide = true;
    this.validFields.forEach((validField) => {
      validField.importFileColumnIndex = undefined;
    });
    let erroeCheck = 0;
    if (erroeCheck === 0 && !this.errorList.length) {
      const target: DataTransfer = <DataTransfer>(evt.target);
      if (target.files.length !== 1) {
        PopupService.confirmationAlert(this.title, 'Cannot use multiple files').then((result) => {
        })
        throw new Error('Cannot use multiple files');
      }
      const reader: FileReader = new FileReader();
      reader.readAsBinaryString(target.files[0]);
      reader.onload = (e: any) => {
        const dataFromFile = this.appFileReader.getDataFromWorkSheet(e);
        if (dataFromFile.length == 0 || dataFromFile.length == 1) {
          PopupService.confirmationAlert(this.title, 'Sorry! No data found in the file.').then((result) => {
          })
        } else if (dataFromFile.length > 5001) {
          PopupService.confirmationAlert(this.title, 'Sorry! cannot import more than 5000 data in file.').then((result) => {
          })
        } else {
          this.fillImportedRows(dataFromFile);
          this.isFileLoaded = true;
        }
      }
    }
  }
  //validateFields of Employee Allowance
  validateFieldsEmployeAllowance(dataFromFile: string[]) {
    let headersFromFile: any[] = dataFromFile;
    this.validFields = [];
    this.validFields.push({
      apiName: 'option',
      displayName: 'Employee Number',
      inputType: 'text',
      isMandatory: true,
      unique: false,
      listValidValues: undefined,
      importFileColumnIndex: undefined,
      fieldValue: 'employeeNumber',
      isStatic: true,
      moduleTypeList: ['attendance']
    },)
    const targetFormats = ["dd/MM/yy", "MM/dd/yy", "MM/d/yy"];
    for (let i = 1; i < headersFromFile.length; i++) {
      if (this.isSpecificDateFormatValid(headersFromFile[i], targetFormats)) {
        let obj = {
          apiName: 'option',
          displayName: headersFromFile[i],
          inputType: 'text',
          isMandatory: true,
          unique: false,
          listValidValues: undefined,
          importFileColumnIndex: undefined,
          fieldValue: 'leaveType',
          headerValue: 'dateString',
          moduleTypeList: ['attendance']
        }
        this.validFields.push(obj);
      }
    }
    if (this.validFields) {
      this.displayNameMap = new Map<string, any>();
      this.validFields.forEach((element) => {
        this.displayNameMap.set(element.displayName, element);
      })
    }
  }

  isSpecificDateFormatValid(dateString: string, targetFormats: string[]): boolean {
    const regexFormats = targetFormats.map(format =>
      new RegExp(format.replace(/[dmMyY]/g, '\\d'))
    );
    return regexFormats.some(regex => regex.test(dateString));
  }

  // Taking data from Excel sheet
  private fillImportedRows(dataFromFile: any[][]) {
    this.importedRows = [];
    this.insertHeaderAlphabets(dataFromFile[0].length);
    if (this.title === 'attendance') {
      this.validateFieldsEmployeAllowance(dataFromFile[0]);
    }
    for (let i = 0; i < dataFromFile.length; i++) {
      if (dataFromFile[i].length > 0) {
        let row = dataFromFile[i];
        if (i == 0) {
          row.unshift("Index");  // to display at first <th>
        } else {
          row.unshift(i);
        }
        this.importedRows.push(row);
      }
    }
    //we are creating virtual rows data to Show on table
    this.virtualRows = new Array();
    for (let i = 0; i < this.importedRows.length; i++) {
      if (i > 1) {
        this.virtualRows.push(this.importedRows[i]);
      }
    }
    this.virtualRowsData = this.virtualRows;
    this.totalRecords = this.virtualRows.length;
    const virtualRows1 = this.virtualRowsData;
    this.virtualRowsData = virtualRows1.slice(0, this.pageSize);
    this.firstRowIndex = 2; // [0] for headerAlphabets [1] for Headers from File
    this.countOfRows = this.importedRows.length - this.firstRowIndex;
    this.matchValidFieldsWithImportFileCols();
    this.fillFieldSelection();
  }


  private insertHeaderAlphabets(countOfColumns: number) {
    let headerAlphabets = [];
    headerAlphabets.push("Index");
    for (let i = 0; i < countOfColumns; i++) {
      headerAlphabets.push(AlphabetService.Alaphabet(i));
    }
    this.importedRows.push(headerAlphabets);
  }

  // Matching the excel header to required header
  private matchValidFieldsWithImportFileCols() {
    // updates importFileColIndex property of each field inside @Input validFields: Field[]
    // if not already updated and has a matching heading from file
    let headersFromFile = this.importedRows[1]; // importedRows[0] contains headerAlphabets
    for (let i = 1; i < headersFromFile.length; i++) { // i = 1 because this.importedRows[1][0] contains value "Index" for s.no.
      if (headersFromFile[i]) {
        for (let j = 0; j < this.validFields.length; j++) {
          if (!this.templateFLag) {
            if (!this.validFields[j].importFileColumnIndex && this.isMatching(this.validFields[j].displayName, headersFromFile[i])) {
              this.validFields[j].importFileColumnIndex = i;
            }
          } else {
            if (!this.validFields[j].importFileColumnIndex && this.isMatchingHeaderDataBase(this.validFields[j].fieldValue, headersFromFile[i], this.templateIndex)) {
              this.validFields[j].importFileColumnIndex = i;
            }
          }
        }
      }
    }
  }


  private isMatching(str1: string, str2: string): boolean {
    return str1.replace(/\s/g, "").toLowerCase() == str2.replace(/\s/g, "").toLowerCase();
  }

  // Matching the excel header to from previous data from database
  private isMatchingHeaderDataBase(str1: string, str2: string, templateIndex: any = {}): boolean {
    if (templateIndex[str1]) {
      if (templateIndex[str1][str2]) {
        return true;
      } else {
        return false;
      }
    } else {
      return false;
    }
  }


  // Checking data from UI
  onTestImport() {
    this.onCheckImportedfile();
    let list = new Array<Object>()
    this.headerMap = new Map<number, string>();
    if (!this.errorList.length) {
      this.importArray = new Array();
      const header = this.importedRows.slice(1, 2);
      if (header) {
        for (let i = 0; i < header[0].length; i++) {
          this.headerMap.set(i, header[0][i]);
        }
      }
      const data = this.importedRows.slice(2, this.importedRows.length);
      this.importArray = this.divideData(data, 50);
      if (this.importArray) {
        const newVar = new Object();
        newVar[this.headerMap.get(1)] = this.importArray[0][0][1];
        list.push(newVar);
      }
      this.showProgressBar = true;
      this.valueOfProgressBar = 0;
      this.checker = 0;
      this.validedImportData = new Array();
      this.validedImportChunkData = new Array();
      this.onTestImportValidateData();
    }

  }

  // Checking the mandatory field in Frontend
  onCheckImportedfile() {
    this.errorList = [];
    this.validFields.forEach((value) => {
      if (value.isMandatory && !value.importFileColumnIndex) {
        this.errorList.push(value.displayName + ' column is not selected ');
      }
    });

    if (!this.errorList.length) {
      //for duplicate data validation
      // const duplicateIndexies: any = {};
      // let rowIdx = 2;
      let data = JSON.parse(JSON.stringify(this.importedRows));
      // data.forEach(rowData => {
      //   rowIdx++;
      // });
      this.importedRows = data;
      const virtualRows1 = this.importedRows.slice(2);
      this.virtualRowsData = virtualRows1.slice(0, this.pageSize);
      this.fillFieldSelection();
    }
  }

  // validate the import data from backend
  async onTestImportValidateData() {
    if (this.importArray) {
      try {
        for (let i = 0; i < this.importArray.length; i++) {
          await this.checkImportArray(this.importArray[i]);
        }
        this.recheckonTestImportCheck();
      } catch (error) {
        PopupService.failedAlert("Import", "Something Went Wrong").then(result => {
          if (result) {

          }
        });
      }
    }
  }

  checkImportArray(importItem: any): Promise<void> {
    return new Promise<void>((resolve, reject) => {
      let data = new ImportMaster();
      data.rowCellsList = this.makeObjectOfChunckData(importItem);
      data.importType = this.title;
      console.log(data);
      this.valueOfProgressBar += Math.floor(100 / this.importArray.length);
      this.isFileLoaded = false;
      this.tableHide = true;
      this.importService.validImportOption(data).subscribe(response => {
        this.checker++;
        if (response && response.status == 200 && response.data.importValidation) {
          this.validedImportData = response.data.importValidation.rowData;
          this.validedImportChunkData.push(this.validedImportData);
          this.importReturnArray.push(...response.data.importValidation.errorList);
        }
        resolve();
      }, error => {
        reject(error);
      });
    });
  }

  recheckonTestImportCheck() {
    if (this.importReturnArray.length && this.checker === this.importArray.length) {
      this.showProgressBar = false;
      this.errorList.push(...this.importReturnArray);
      this.importReturnArray = [];
      this.isFileLoaded = true;
      this.tableHide = false;
    }
    if (this.checker === this.importArray.length && !this.errorList.length) {
      this.showProgressBar = false;
      PopupService.successAlert(this.title, this.successType)
        .then((result) => {
          if (result) {
            this.isDataTested = true;
            this.successMSG = true;
            this.isFileLoaded = true;
          }
        });
    }
  }

  // Adding to database
  addToDatabase() {
    this.clicked = false;
    this.goimportflag = true;
    this.templateFLag = true;
    this.templateBoxFLag = false;
    this.addMasterDataImport = [];
    if (!this.errorList.length && this.validedImportChunkData.length) {
      this.errorList = [];
      if (this.validedImportChunkData.length > 0) {
        this.showProgressBar = true;
        this.valueOfProgressBar = 0;
        this.checker = 0;
        this.addToDataBase();
      }
    }
  }

  async addToDataBase() {
    try {
      for (let i = 0; i < this.validedImportChunkData.length; i++) {
        await this.addItemToDB(i);
      }
      this.flag = true;
      this.recheckonAddImportCheck();
    } catch (error) {
      PopupService.failedAlert("Import", "Something Went Wrong");
    }
  }

  addItemToDB(counter: number): Promise<void> {
    return new Promise<void>((resolve, reject) => {
      let importMaster = new ImportMaster();
      importMaster.rowCellsList = this.validedImportChunkData[counter];
      importMaster.importType = this.title;
      this.valueOfProgressBar += Math.floor(100 / this.validedImportChunkData.length);
      this.isFileLoaded = false;
      this.tableHide = true;
      this.importService.addImportData(importMaster).subscribe(
        (response) => {
          this.checker++;
          if (response.status === 200) {
            resolve();
          } else if (response.status === 400) {
            this.importReturnArray.push(...response.data.masterAddImport);
            resolve();
          }
        },
        (error) => reject(error)
      );
    });
  }

  // here we are checking that our code is fully tested or not
  async recheckonAddImportCheck() {
    if (this.importReturnArray.length > 0 && this.checker === this.validedImportChunkData.length) {
      this.showProgressBar = false;
      this.errorList.push(...this.importReturnArray);
      await PopupService.failedAlert(this.title, 'Imported Failed');
      this.importReturnArray = [];
      if (this.templateId > 0) {
        this.templateFLag = true;
      } else {
        this.templateFLag = false;
      }
      this.isFileLoaded = true;
      this.tableHide = false;
      this.clicked = true;
      this.isDataTested = false;
    }
    if (this.checker === this.validedImportChunkData.length && this.errorList.length === 0) {
      this.showProgressBar = false;
      this.isDataTested = false;
      if (this.flag) {
        const result = await PopupService.successAlert(this.title.toUpperCase(), 'Imported successfully');
        if (result) {
          this.isFileLoaded = false;
          this.successMSG = false;
          this.onBack();
        }
      }
    }
  }

  makeObjectOfChunckData(chunkData): any {
    if (this.title != 'attendance') {
      this.mappedData = chunkData.map((data) => {
        let object = new Map<string, any>();
        data.forEach((cellData, indexx) => {
          let header = this.headerMap.get(indexx);
          let validField: ImportField = this.displayNameMap.get(header);
          if (validField) {
            if (!validField.extraObject && !validField.parent) {
              object.set(validField.fieldValue, validField.inputType === "date" ? new Date(cellData) : validField.inputType === "number" ? parseInt(cellData):cellData);
            } else if (validField.parent) {
              let parentObject = object.get(validField.parent) || new Map<string, any>();
              let currentObject = parentObject.get(validField.extraObject) || new Map<string, any>();
              currentObject.set(validField.fieldValue, cellData);
              parentObject.set(validField.extraObject, currentObject);
              object.set(validField.parent, parentObject);
            } else {
              let childObject = object.get(validField.extraObject) || new Map<string, any>();
              childObject.set(validField.fieldValue, validField.inputType === "date" ? new Date(cellData) : cellData);
              object.set(validField.extraObject, childObject);
            }
          }
        });
        const jsonData = this.convertMapToJson(object);
        return jsonData;
      });
      return this.mappedData;
    } else {
      return this.makeObjectOfDynamicChunckData(chunkData);
    }
  }

  makeObjectOfDynamicChunckData(chunkData): any {
    chunkData.map((data) => {
      let headerArray: string[][] = new Array<Array<string>>();
      data.forEach((cellData, indexx) => {
        let object = new Map<string, any>();
        let header = this.headerMap.get(indexx);
        let validField: ImportField = this.displayNameMap.get(header);
        if (validField) {
          if (!validField.extraObject && !validField.parent) {
            const targetFormats = ["dd/MM/yy", "MM/dd/yy", "MM/d/yy"];
            if (this.isSpecificDateFormatValid(header, targetFormats)) {
              let headeValue = headerArray[headerArray.length - 1];
              if (headeValue) {
                if (headeValue[0] && headeValue[1]) {
                  object.set(headeValue[0], headeValue[1]);
                }
              }
              object.set(validField.headerValue, header);
              object.set(validField.fieldValue, cellData);
            } else {
              if (validField.isStatic) {
                let map = [];
                map.push(validField.fieldValue);
                map.push(cellData);
                headerArray.push(map);
              } else {
                object.set(validField.fieldValue, cellData);
              }
            }
          } else {
            let childObject = object.get(validField.extraObject) || new Map<string, any>();
            let currentObject = new Map<string, any>();
            currentObject.set(validField.headerValue, validField.inputType === "date" ? new Date(header) : cellData);
            currentObject.set(validField.fieldValue, cellData)
            childObject.set(validField.extraObject, currentObject);
            object.set(validField.extraObject, currentObject);
          }
        }
        if (object && object.size > 0) {
          const jsonData = this.convertMapToJson(object);
          this.mappedData.push(jsonData);
        }
      });
    });
    return this.mappedData;
  }
  isDateStringValid(dateString: string): boolean {
    const parsedDate = new Date(dateString);
    return !isNaN(parsedDate.getTime());
  }

  convertMapToJson(map: Map<string, any>): any {
    const result: any = {};
    map.forEach((value, key) => {
      if (value instanceof Map) {
        result[key] = this.convertMapToJson(value);
      } else {
        result[key] = value;
      }
    });
    return result;
  }

  private writeIndexCol() {
    if (this.firstRowIndex == 1) {
      for (let i = 1; i < this.importedRows.length; i++) {
        this.importedRows[i][0] = i;
      }
    }
    if (this.firstRowIndex == 2) {
      this.importedRows[1][0] = "Index" // to display at first <th>
      for (let i = 2; i < this.importedRows.length; i++) {
        this.importedRows[i][0] = i - 1;
      }
    }
  }


  // new for data seperation chunks of 50 50
  divideData<T>(data: T[], chunkSize: number): T[][] {
    const chunks: T[][] = [];
    const numChunks = Math.floor(data.length / chunkSize);
    for (let i = 0; i < numChunks; i++) {
      const start = i * chunkSize;
      const end = start + chunkSize;
      const chunk = data.slice(start, end);
      chunks.push(chunk);
    }
    const remaining = data.length % chunkSize;
    if (remaining > 0) {
      const lastChunk = data.slice(-remaining);
      chunks.push(lastChunk);
    }
    return chunks;
  }


  // Redirecting to import page
  backToImportPage() {
    this.errorList = [];
    this.isFileLoaded = false;
    this.isDataTested = false;
    this.tableHide = false;
    this.showProgressBar = false;
    this.valueOfProgressBar = 0;
    this.validFields.forEach((validField) => {
      validField.importFileColumnIndex = undefined;
    })
  }


  // Selecting the heading from UI
  onHeadingChange(event: MatSelectChange, fileColIndex: number) {
    for (let i = 0; i < this.validFields.length; i++) {
      if (this.validFields[i].importFileColumnIndex && this.validFields[i].importFileColumnIndex == fileColIndex) {
        this.validFields[i].importFileColumnIndex = undefined;
      }

      if (this.validFields[i].displayName == event['value']) {
        this.validFields[i].importFileColumnIndex = fileColIndex;
      }
    }
    this.fillFieldSelection(true);
    this.errorList = new Array();
  }

  // Required selection field
  // Here we are selectng the Header Which Matched to DropDown;
  private fillFieldSelection(isOnHeadingChange = false) {
    this.fieldSelectionForAllColumns = new Array<FieldSelection>();
    for (let i = 1; i < this.importedRows[1].length; i++) {
      let fieldSelection = new FieldSelection();
      fieldSelection.allOptions = new Array<FieldOption>();
      for (let j = 0; j < this.validFields.length; j++) {
        let fieldOption = new FieldOption();
        fieldOption.apiName = this.validFields[j].apiName;
        fieldOption.displayName = this.validFields[j].displayName;

        if (!this.validFields[j].importFileColumnIndex) {
          fieldOption.disabled = false;
        } else if (this.validFields[j].importFileColumnIndex == i) {
          fieldOption.disabled = false;
          if (this.containsHeader || isOnHeadingChange) {
            fieldSelection.selectedOption = fieldOption;
          }
        } else {
          if (this.containsHeader || isOnHeadingChange) {
            fieldOption.disabled = true;
          }
        }
        fieldSelection.allOptions.push(fieldOption);
        if (!fieldSelection.selectedOption) {
          let noImportMatchOption = new FieldOption();
          noImportMatchOption.apiName = "noImportMatch";
          noImportMatchOption.displayName = "--No Import Match--"
          noImportMatchOption.disabled = false;
          fieldSelection.selectedOption = noImportMatchOption;
          fieldSelection.allOptions.unshift(noImportMatchOption);
        } else {
          let idx = fieldSelection.allOptions.indexOf(fieldSelection.selectedOption);
          fieldSelection.allOptions.splice(idx, 1);
          fieldSelection.allOptions.unshift(fieldSelection.selectedOption);
        }
      }
      let noImportOption = new FieldOption();
      noImportOption.apiName = "noImport";
      noImportOption.displayName = "--No Import--";
      noImportOption.disabled = false;
      fieldSelection.allOptions.push(noImportOption);
      this.fieldSelectionForAllColumns.push(fieldSelection);
    }
  }

  loadCarsLazy(event: LazyLoadEvent) {
    // Simulate remote connection with a timeout
    setTimeout(() => {
      // Load data of the required page
      const loadedCars = this.importedRows.slice(event.first + this.firstRowIndex, (event.first + this.firstRowIndex + event.rows));

      // Splice the loadedCars into virtualRows
      const startIndex = event.first;
      const deleteCount = event.rows;
      this.virtualRows.splice(startIndex, deleteCount, ...loadedCars);

      // Trigger change detection
      this.virtualRows = [...this.virtualRows];
    }, Math.random() * 1000 + 250);

    // Update virtualRowsData and call loadLazy
    this.virtualRowsData = this.virtualRows;
    this.loadLazy(event);
  }

  // pagination
  loadLazy(event: LazyLoadEvent) {
    if (event) {
      let hbEvent = new HbListEvent;
      if ((event.first || event.first === 0) && event.rows) {
        hbEvent.page = (event.first / event.rows) + 1;
      } else {
        hbEvent.page = 0;
      }
      if (event.rows) {
        hbEvent.limit = event.rows;
      } else {
        hbEvent.limit = 0;
      }
      this.onChangeFilter(hbEvent);
    }
  }

  onChangeFilter(event: HbListEvent) {
    if (event) {
      this.currentPage = event.page;
      this.pageSize = event.limit;
      this.filterData();
    }
  }

  onContainsHeaderChange() {
    if (this.containsHeader) {
      this.firstRowIndex = 2
    } else {
      this.firstRowIndex = 1;
    }
    this.writeIndexCol();
    this.countOfRows = this.importedRows.length - this.firstRowIndex;
    this.fillFieldSelection();
  }

  filterData() {
    const startIndex = (this.currentPage - 1) * this.pageSize;
    const endIndex = startIndex + this.pageSize;
    const virtualRows1 = this.importedRows.slice(2);
    this.virtualRowsData = virtualRows1.slice(startIndex, endIndex);
    this.totalRecords = this.virtualRows.length;
  }


  //template Code

  // Template save to database
  templateSave() {
    let headerToDataBase = this.importedRows[1];
    this.importHeaderKeys = [];
    this.importHeaderValues = [];
    this.validFields.forEach((value => {
      if (value.importFileColumnIndex) {
        this.importHeaderKeys.push(value.fieldValue);
        this.importHeaderValues.push(headerToDataBase[value.importFileColumnIndex]);
      }
      this.importMasterTemplate.key = this.importHeaderKeys;
      this.importMasterTemplate.fieldDisplay = this.importHeaderValues;
    }))
    this.importMasterTemplate.txnType = this.title;
    this.importMasterTemplate.templateName = this.TemplateNameSet;
    this.importMasterTemplate.standard_templateFlag = true;
    this.importService.addImportTemplate(this.importMasterTemplate).subscribe(response => {
      if (response.status == 200 && response.data) {
        PopupService.successAlert(this.title, "Template successfully added")
          .then((result) => {
            if (result) {
              this.templateBoxFLag = false;
              this.templateSaveButtom = true;
            }
          });
      } else if (response.status == 400) {
        let message = "";
        for (let i = 0; i < response.fieldErrors.length; i++) {
          message = response.fieldErrors[i].message;
        }
        PopupService.confirmationAlert(this.title, message)
          .then((result) => {
            if (result) {
              this.templateSaveButtom = true;
            } else {
              this.templateSaveButtom = true;
            }
          });
      }
    })
  }

  templateUpdate() {
    let headerToDataBase = this.importedRows[1];
    this.importHeaderKeys = [];
    this.importHeaderValues = [];
    this.validFields.forEach((value => {
      if (value.importFileColumnIndex) {
        this.importHeaderKeys.push(value.fieldValue);
        this.importHeaderValues.push(headerToDataBase[value.importFileColumnIndex]);
      }
      this.importMasterTemplate.key = this.importHeaderKeys;
      this.importMasterTemplate.fieldDisplay = this.importHeaderValues;
    }));
    this.importMasterTemplate.id = this.templateId;
    this.importMasterTemplate.txnType = this.title;
    this.importMasterTemplate.standard_templateFlag = true;
    this.importMasterTemplate.templateName = this.TemplateNameSet;
    this.importService.updateImportTemplate(this.importMasterTemplate).subscribe(response => {
      if (response.status == 200 && response.data) {
        PopupService.successAlert(this.title, "Template successfully updated")
          .then((result) => {
            if (result) {
              this.templateFLag = true;
              this.templateBoxFLag = false;
            }
          });
      } else if (response.status == 400) {
        let message = "";
        for (let i = 0; i < response.fieldErrors.length; i++) {
          message = response.fieldErrors[i].message;
        }
        PopupService.confirmationAlert(this.title, message);
      }
    })
  }

  onSubmit() {
    if (this.templateFLag) {
      this.templateUpdate();
    } else {
      this.templateSaveButtom = false;
      this.templateSave();
    }
  }

  deleteTemplate() {
    PopupService.htmlAlert('Template', 'Are you sure, do you want to delete this template ?', 'warning', true)
      .then((result) => {
        if (result) {
          this.deleteTemplateCall();
        }
      });
  }

  deleteTemplateCall() {
    if (this.templateId && this.templateId > 0) {
      this.importService.deleteTemplateById(this.templateId).subscribe(response => {
        if (response.status == 200 && response.data) {
          PopupService.successAlert(this.title, "Template successfully deleted")
            .then((result) => {
              if (result) {
                this.templateId = 0;
                this.templateSetting = "Select template"
                this.importService.fetchImportTemplate(this.title).subscribe(response => {
                  if (response.status == 200 && response.data) {
                    this.getTemplateData(response);
                  }
                })
                // standard template again
                let event = {
                  value: '0',
                  standard_templateFlag: true
                };
                this.templateFLag = false;
                this.selectedTemplate = 'Standard Template';
                this.TemplateNameSet = undefined;
              }
            });
        } else if (response.status == 400) {
          let message = "Not Found";
          PopupService.confirmationAlert("Template", message);
        }
      })
    }
  }

  // for getting all template List
  getTemplateData(response) {
    if (response.status == 200 && response.data) {
      let txnType = this.title;
      this.templateListNew = new Array();
      let dropDownList = new TemplateDropDown();
      dropDownList.id = 0;
      dropDownList.templatelist = [];
      dropDownList.label = 'Standard Template';
      dropDownList.code = 'Standard Template';
      dropDownList.txnType = undefined;
      dropDownList.standard_templateFlag = true;
      this.templateListNew.push(dropDownList);
      this.templateList = new Array();
      this.templateList.push({ id: 0, templateName: '--None--' })
      let templates = response.data.importTemplate;
      if (templates) {
        templates.forEach(element => {
          if (element.txnType === txnType) {
            this.templateList.push(element);
            let dropDown = new TemplateDropDown();
            dropDown.id = element.id;
            dropDown.label = element.templateName;
            dropDown.code = element.templateName;
            dropDown.templatelist = element.importTemplateTOList;
            dropDown.txnType = element.txnType;
            dropDown.standard_templateFlag = element.standard_templateFlag;
            dropDown.flipkart_templateFlag = element.flipkart_templateFlag;
            dropDown.amazon_templateFlag = element.amazon_templateFlag;
            dropDown.marutiDms_templateFlag = element.marutiDms_templateFlag;
            dropDown.opening_account = element.opening_accountFlag;
            dropDown.branch_assign = element.branch_assigntFlag;
            this.templateListNew.push(dropDown);
          }
        });
      }
    }
  }

  takenTemplateUI(event) {
    let list = this.templateList.filter(template => template.templateName === event);
    if (!list.length) {
      this.onCommerceChange(event);
      this.templateFLag = false;
      this.TemplateNameSet = undefined
      this.templateId = 0;
    } else {
      this.onCommerceChange(event);
      this.headerList = list[0].importTemplateTOList;
      if (list[0].id === 0) {
        this.TemplateNameSet = undefined
      } else {
        this.TemplateNameSet = list[0].templateName;
      }
      this.templateId = list[0].id;
      this.title = list[0].txnType;
      this.buildHeaderIndex(this.headerList);
      if (this.templateId > 0) {
        this.templateFLag = true;
      } else {
        this.templateFLag = false;
      }

    }
  }

  // Changing of template
  onCommerceChange(event) {
    if (event.standard_templateFlag) {
      this.templatePrifix = 'Stad';
      this.statusImport = 'Draft';
      this.validFields = ImportFieldList.filter(importField => importField.moduleTypeList.includes(this.title));
      this.columnDescription = this.columnDescriptionWritingService.write(this.validFields);
      this.colDescriptionData = {
        data: this.columnDescription
      }
    }
  }

  private buildHeaderIndex(arrayOfObject: any = []) {
    let index = {};
    for (let i = 0; i < arrayOfObject.length; i++) {
      const obj = arrayOfObject[i];
      const keys = Object.values(obj);
      const key = obj.key;
      if (index[key] === undefined) {
        index[key] = {};
      }
      index[key][obj.fieldDisplay] = true;
    }
    this.templateIndex = index;
  }

  isValidHeader(value: string): boolean {
    let arr: string[] = ['Employee Id'];
    for (let i = 0; i < arr.length; i++) {
      if (value === arr[i]) {
        return true;
      }
    }
    return false;
  }

  parseDateString(dateString: string): Date | null {
    const dateParts = dateString.split('/');

    if (dateParts.length === 3) {
      const month = parseInt(dateParts[0], 10);
      const day = parseInt(dateParts[1], 10);
      const year = parseInt(dateParts[2], 10);

      if (!isNaN(month) && !isNaN(day) && !isNaN(year)) {
        const adjustedYear = year < 100 ? 2000 + year : year;

        const parsedDate = new Date(adjustedYear, month - 1, day);

        if (!isNaN(parsedDate.getTime())) {
          return parsedDate;
        }
      }
    }
   return  null;
  }

}

class FieldOption {
  apiName: string;
  displayName: string;
  disabled: boolean;
}

class FieldSelection {
  allOptions: FieldOption[];
  selectedOption: FieldOption;
}

export class HbListEvent {
  limit: number;
  page: number;
  sortField: string;
  sortType: number = 1 | 2;
}
class TemplateDropDown {
  public id: any;
  public code: string;
  public templatelist: any[];
  public label: string;
  public txnType: string;
  public standard_templateFlag: boolean;
  public flipkart_templateFlag: boolean;
  public amazon_templateFlag: boolean;
  public marutiDms_templateFlag: boolean;
  public branch_assign: boolean;
  public opening_account: boolean;
}

