import { Component, OnInit } from '@angular/core';
import { LocalStorageService } from '../../../core/services/local-storage-service';
import { Router } from '@angular/router';

declare var header: any;

@Component({
  selector: 'app-header-payroll',
  templateUrl: './header-payroll.component.html',
  styleUrls: ['./header-payroll.component.scss']
})
export class HeaderPayrollComponent implements OnInit {
  themeValue = 'light';
  indexHTML;
  color = [
    // { label: undefined, code: 'dark_theme', id: undefined, value: undefined },
    { label: undefined, code: 'yellow', id: undefined, value: undefined },
    { label: undefined, code: 'pink', id: undefined, value: undefined },
    { label: undefined, code: 'violet', id: undefined, value: undefined },
    { label: undefined, code: 'green', id: undefined, value: undefined },
    { label: undefined, code: 'azure', id: undefined, value: undefined },
    { label: undefined, code: 'orange', id: undefined, value: undefined },
    { label: undefined, code: 'light', id: undefined, value: undefined },
  ];

  constructor(private router: Router) { }

  ngOnInit(): void {
    this.indexHTML = document.documentElement;
    // new header-payroll-tenant();
  }

  exitPayroll() {
    LocalStorageService.clearTenant();
    this.router.navigate(['business']).then(r => console.log(r));
  }

  logout() {
    LocalStorageService.clearEveryThing();
    this.router.navigate(['auth']).then(r => console.log(r));
  }

  onThemeChange() {
    switch (this.themeValue) {
      case 'dark_theme':
        this.indexHTML.classList.add('transition');
        this.indexHTML.setAttribute('data-theme', 'dark');
        break;
      case 'yellow':
        this.indexHTML.classList.add('transition');
        this.indexHTML.setAttribute('data-theme', 'yellow');
        break;
      case 'pink':
        this.indexHTML.classList.add('transition');
        this.indexHTML.setAttribute('data-theme', 'pink');
        break;
      case 'violet':
        this.indexHTML.classList.add('transition');
        this.indexHTML.setAttribute('data-theme', 'violet');
        break;
      case 'green':
        this.indexHTML.classList.add('transition');
        this.indexHTML.setAttribute('data-theme', 'green');
        break;
      case 'azure':
        this.indexHTML.classList.add('transition');
        this.indexHTML.setAttribute('data-theme', 'azure');
        break;
      case 'orange':
        this.indexHTML.classList.add('transition');
        this.indexHTML.setAttribute('data-theme', 'orange');
        break;
      default:
        this.indexHTML.classList.add('transition');
        this.indexHTML.setAttribute('data-theme', 'light');
        break;
    }

  }

}
