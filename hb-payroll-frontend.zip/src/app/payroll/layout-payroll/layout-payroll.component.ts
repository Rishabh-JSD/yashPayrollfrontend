import { Component, OnDestroy, OnInit } from '@angular/core';
import { HBLoaderService } from '../../shared/services/hb-loader.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-layout-payroll',
  templateUrl: './layout-payroll.component.html',
  styleUrls: ['./layout-payroll.component.scss']
})
export class LayoutPayrollComponent implements OnInit, OnDestroy {
  showLoader: boolean = false;
  loaderSubscription: Subscription;

  constructor() {
    this.loaderSubscription = HBLoaderService.loader$.subscribe(arg => this.showLoader = arg);
  }

  ngOnInit(): void {}

  ngOnDestroy(): void {
    this.loaderSubscription.unsubscribe();
  }
}
