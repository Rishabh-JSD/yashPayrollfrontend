import { Component, TemplateRef } from '@angular/core';
import { Location } from '@angular/common';
import { HbDataTableColumnOption } from '@hostbooks/hb-lib/hb-list-table/src/hb-list-table-columns';
import { MasterOption } from '../../master-rules/common/models/masters-options';
import { LeaveApply } from '../modal/leave-apply';
import { HBLoaderService } from 'src/app/shared/services/hb-loader.service';
import { LeaveApplyService } from '../service/leave-apply.service';
import { LeaveSearchRequest } from '../modal/leave-search-request';
import { HbDateFormatPipe } from 'src/app/shared/pipes/hb-date-format.pipe';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-applied-leave',
  templateUrl: './applied-leave.component.html',
  styleUrls: ['./applied-leave.component.scss']
})
export class AppliedLeaveComponent {
  columns: HbDataTableColumnOption[] = [];
  total: number;
  data:  LeaveApply[] = [];
  dataSource = [];
  leaveApply = new LeaveApply();
  leaveSearchRequest = new LeaveSearchRequest();
  leaveApplyModal:boolean = false
  isAddLeaveApply: boolean = false;
  

  constructor(private _location: Location, private leaveApplyService: LeaveApplyService, private datePipe: HbDateFormatPipe) { }

  ngOnInit(): void {
    this.getLeaveApplyList();
    this.resetPagination();
    this.columns = [
      {
        header: 'S No.',
        columnData: () => { },
        type: 'SR_NO'
      },
      {
        header: 'Leave From',
        columnData: (leaveApply: LeaveApply) => { return this.datePipe.transform(leaveApply.startDate) },
        type: 'DATE'
      },
      {
        header: 'Leave To',
        columnData: (leaveApply: LeaveApply) => { return this.datePipe.transform(leaveApply.endDate) },
        type: 'DATE'
      },
      {
        header: 'Reason',
        columnData: (leaveApply: LeaveApply) => { return leaveApply.reason },
        type: 'TEXT'
      },
      // {
      //   header: 'To',
      //   columnData: (leaveApply: LeaveApply) => { leaveApply.reason },
      //   type: 'TEXT'
      // },
      {
        header: 'Status',
        columnData: (leaveApply: LeaveApply) => { return leaveApply.status },
        type: 'TEXT'
      },
      {
        header: 'Actions',
        columnData: (inv: MasterOption) => {
        },
        type: 'ACTION',
        actionOptions: ['EDIT', 'DELETE']
      },
    ];
  }

  back() {
    this._location.back();
  }

  getLeaveApplyList() {
    HBLoaderService.showLoader(); 
    this.leaveApplyService.getLeaveApplyList(this.leaveSearchRequest).subscribe(response => {
      console.log(response);
      this.total = response.data.leaveApply.totalRowCount;
      if (response.status === 200 && response.data && response.data) {
        this.data = response.data.leaveApply.list;
      }
    });
    HBLoaderService.hideLoader();
  }

  resetPagination() {
    this.leaveSearchRequest.page = 1;
    this.leaveSearchRequest.limit = 10;
  }


  onAction(_event: any) {
    if (_event && _event.actionType && _event.data) {
      if (_event.actionType === 'DELETE') {
        this.deleteLeaveApply(_event.data.id);
      }
      if (_event.actionType === 'EDIT') {
        this.openLeaveApplyModal(_event.data.id);
      }
    }
  }

  deleteLeaveApply(leaveApplyIdList: number[]) {
    this.deleteConfirmationPopup().then(result => {
      if (result.value) {
        var idList: any =leaveApplyIdList.length>1 ? leaveApplyIdList.join(','): leaveApplyIdList;
        this.leaveApplyService.deleteLeaveApply(idList).subscribe(response => {
          console.log(response);
          if (response.status === 200 && response.data) {
            this.confirmationPopup(response.message);
            HBLoaderService.hideLoader();
            this.getLeaveApplyList();
          }
        });
      }
    })
  }

  close() {
    this.leaveApplyModal = false;
    this.getLeaveApplyList();
  }

  onChange(event) {
    this.leaveSearchRequest.page = event.page;
    this.leaveSearchRequest.limit = event.limit;
    this.getLeaveApplyList();
  }


  openLeaveApplyModal(id: any = null) {
    if (id) {
      this.getLeaveApplyById(id)
      this.leaveApplyModal = true
      this.isAddLeaveApply = false;
    } else {
      this.leaveApply = new LeaveApply()
      this.leaveApplyModal = true;
      this.isAddLeaveApply = true;
    }
  }

  getLeaveApplyById(id: number){
    HBLoaderService.showLoader();
    this.leaveApplyService.getLeaveApplyById(id).subscribe(response => {
      if (response.status === 200 && response.data && response.data.leaveApply) {
        this.leaveApply = response.data.leaveApply;
      }
    });
    HBLoaderService.hideLoader();
  }

  deleteConfirmationPopup() {
    return Swal.fire({
      title: 'Warning',
      text: 'Are you sure that you want to perform this action?',
      icon: 'question',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes',
      cancelButtonText: 'No',
      allowOutsideClick: false,
      allowEscapeKey: false,
    });
  }

  confirmationPopup(message: any) {
    Swal.fire({
      title: 'Leave Apply',
      html: message,
      icon: 'success',
      allowOutsideClick: false,
      allowEscapeKey: false,
    }).then(() => {
      this.getLeaveApplyList();
    });
  }
}
