import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Location } from '@angular/common';
import { DropDownModel } from '../../../shared/models/hb-field-option';
import { LeaveSearchRequest } from '../modal/leave-search-request';
import { AppConst } from 'src/app/core/constants/app-const';
import { LeaveTypeService } from '../service/leave-type.service';
import { HBLoaderService } from 'src/app/shared/services/hb-loader.service';
import { LeaveType } from '../modal/leave-type';
import { LeaveApply } from '../modal/leave-apply';
import Swal from 'sweetalert2';
import { HbErrorHandler, HbErrorHandlerData } from 'src/app/shared/models/hb-error-handler';
import { LeaveApplyService } from '../service/leave-apply.service';

@Component({
  selector: 'app-apply-leave',
  templateUrl: './apply-leave.component.html',
  styleUrls: ['./apply-leave.component.scss']
})
export class ApplyLeaveComponent implements OnInit {

  leaveTypeSearchName: string;
  leaveSearchRequest = new LeaveSearchRequest();
  leaveTypeList: LeaveType[] = [];
  leaveTypeOption: DropDownModel[] = [];
  fromDate: Date;
  toDate: Date;
  saveOptions: any;
  @Input() leaveApply = new LeaveApply();
  @Input() isAddLeaveApply: boolean = true
  @Output() closeDialog: EventEmitter<void> = new EventEmitter<void>();
  hbErrorHandler = new HbErrorHandler();


  constructor( private leaveTypeService: LeaveTypeService, private leaveApplyService: LeaveApplyService, private _location: Location) { }

  ngOnInit(): void {
    this.leaveApply.startDateType = "BOTH"
    this.leaveApply.endDateType = "BOTH"
    this.saveOptions = [
      {
        label: 'Draft',
        command: () => {
          this.addLeaveApply(AppConst.SAVE_TYPE.SAVE_AS_DRAFT)
        },
      },
      {
        label: 'Approved',
        command: () => {
          this.addLeaveApply(AppConst.SAVE_TYPE.SAVE_FOR_APPROVAL)
        },
      }  
    ];

    this.getLeaveTypeList();
  }

  sessions: DropDownModel[] = [
    { label: 'First Half', code: 'FIRST_HALF', id: undefined, value: undefined },
    { label: 'Second Half', code: 'SECOND_HALF', id: undefined, value: undefined },
    { label: 'Both', code: 'BOTH', id: undefined, value: undefined },
  ];

  employees: DropDownModel[] = [
    { label: 'Same', code: 'FIRST_HALF', id: 1, value: undefined },
    { label: 'John', code: 'SECOND_HALF', id: 2, value: undefined },
    { label: 'Markan', code: 'BOTH', id: 3, value: undefined },
  ];

  applyTo: DropDownModel[] = [
    { label: 'Option 1', code: 'Option 1', id: undefined, value: undefined },
  ];
  CC: DropDownModel[] = [
    { label: 'Option 1', code: 'Option 1', id: undefined, value: undefined },
  ];

  addLeaveApply(saveType: string){
    if(saveType == AppConst.SAVE_TYPE.SAVE_AS_DRAFT){
      this.leaveApply.status = AppConst.SAVE_TYPE.SAVE_AS_DRAFT;
      this.addUpdateLeaveApply()
    }
    if(saveType == AppConst.SAVE_TYPE.SAVE_FOR_APPROVAL){
      this.leaveApply.status = AppConst.SAVE_TYPE.SAVE_FOR_APPROVAL;
      this.addUpdateLeaveApply()      
    }
  }  
  
  getLeaveTypeList() {
    HBLoaderService.showLoader();
    if (this.leaveTypeSearchName !== undefined) {
        this.leaveSearchRequest.name = this.leaveTypeSearchName;
    } 
    this.leaveSearchRequest.type = AppConst.ATTENDANCE_LEAVE_TYPE.LEAVE_TYPE   
    this.leaveTypeService.getLeaveTypeList(this.leaveSearchRequest).subscribe(response => {      
      if (response.status === 200 && response.data && response.data.leaveType) {
        this.leaveTypeList = response.data.leaveType.list;
        this.createLeaveTypeDropDown();
      }
    });
    HBLoaderService.hideLoader();
  }

  createLeaveTypeDropDown(){
    this.leaveTypeOption = this.leaveTypeList.map(item => ({
      label: item.name,
      id: item.id,
      code: item.code,
      value: undefined
    } as DropDownModel));
  }

  addUpdateLeaveApply(){
    HBLoaderService.showLoader();
    this.validate();4
    if(this.leaveApply.id){
      this.leaveApplyService.updateLeaveApply(this.leaveApply).subscribe(response =>{
        this.confirmationPopup(response.message)
      })
    }else {
      this.leaveApplyService.addLeaveApply(this.leaveApply).subscribe(response => {
        this.confirmationPopup(response.message)
      })      
    }
    HBLoaderService.hideLoader();

  }

  onFromDateChange(event){
    this.fromDate = event
    this.calculateTotalLeaveDays()
  }

  onToDateChange(event){
    this.toDate = event
    this.calculateTotalLeaveDays()
  }

  calculateTotalLeaveDays(){   
    if(this.fromDate != null && this.toDate != null ){
     this.leaveApply.numberOfDays =  this.calculateDays(this.fromDate, this.toDate);
    }
  }

  calculateDays(fromDate: Date, toDate: Date): number {
    let from = new Date(fromDate);
    let to = new Date(toDate)
    const millisecondsPerDay = 24 * 60 * 60 * 1000; 
    const differenceInMilliseconds = to.getTime() - from.getTime();
    let totalDays = Math.ceil(differenceInMilliseconds / millisecondsPerDay) + 1;
    if (this.leaveApply.startDateType === 'SECOND_HALF' || this.leaveApply.endDateType === 'SECOND_HALF') {
      totalDays -= 0.5;
    }
    if(this.leaveApply.startDateType === 'FIRST_HALF' || this.leaveApply.endDateType === 'FIRST_HALF'){
      totalDays -=0.5;
    }
    return totalDays;
  }

  errorHandler(parentkey: string, childkey?: string, keyIndex?: number): HbErrorHandlerData {
    const hData = this.hbErrorHandler.getErrorHandlerData(parentkey, childkey, keyIndex);
    return hData;
  }

  confirmationPopup(message: any) {
    Swal.fire({
      title: 'Leave Apply',
      html: message,
      icon: 'success',
      allowOutsideClick: false,
      allowEscapeKey: false,
    }).then(() => {
      this.leaveApply = new LeaveApply();
      this.hbErrorHandler.clearErrors();
      this.closeParentDialog()
    });
  }

  validate(): void {
    this.hbErrorHandler.clearErrors();
    this.hbErrorHandler.emptyCheck(this.leaveApply.startDate, 'startDate');   
    this.hbErrorHandler.emptyCheck(this.leaveApply.endDate, 'endDate');
    this.hbErrorHandler.emptyCheck(this.leaveApply.startDateType, 'startDateType');
    this.hbErrorHandler.emptyCheck(this.leaveApply.endDateType, 'endDateType');
    this.hbErrorHandler.emptyCheck(this.leaveApply.leaveTypeId, 'leaveTypeId');
    this.hbErrorHandler.emptyCheck(this.leaveApply.employeeId, 'employeeId');       
  }

  back() {
    this._location.back();
  }

  closeParentDialog(){
    this.closeDialog.emit();
  }
  
}
