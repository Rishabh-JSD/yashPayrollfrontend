import { Component, OnInit } from '@angular/core';
import { DropDownModel } from '../../../shared/models/hb-field-option';
import { HolidayCalendar, HolidayType } from '../modal/holiday-calendar';
import { HbErrorHandler, HbErrorHandlerData } from 'src/app/shared/models/hb-error-handler';
import { HBLoaderService } from 'src/app/shared/services/hb-loader.service';
import { HolidayService } from '../service/holiday.service';
import Swal from 'sweetalert2';
import { LeaveSearchRequest } from '../modal/leave-search-request';
import { HbDataTableColumnOption } from '@hostbooks/hb-lib/hb-list-table/src/hb-list-table-columns';
import { HbDateFormatPipe } from 'src/app/shared/pipes/hb-date-format.pipe';
import { Router } from '@angular/router';
import { PopupService } from 'src/app/shared/services/popup.service';

@Component({
  selector: 'app-holiday-calendar',
  templateUrl: './holiday-calendar.component.html',
  styleUrls: ['./holiday-calendar.component.scss']
})
export class HolidayCalendarComponent implements OnInit {
  holidayTypeModal = false;
  tableData: any[];
  hbErrorHandler = new HbErrorHandler();
  holidayType = new Array<HolidayType>()
  holidayCalendar = new Array<HolidayCalendar>()
  leaveSearchRequest = new LeaveSearchRequest();
  previousData = new Array()


  columns: HbDataTableColumnOption[] = [];
  data: HolidayType[] = [];
  total: number;
  searchName: string;
  selectedYear: any = new Date()
  selectedMonth: any
  currentTab: string = 'Type';

  isError: boolean = false;
  errorMessage: string

  Year: DropDownModel[] = [
    { label: '2022', code: '2022', id: undefined, value: undefined },
    { label: '2021', code: '2021', id: undefined, value: undefined },
    { label: '2020', code: '2020', id: undefined, value: undefined },
  ];
  Month: DropDownModel[] = [
    { label: 'Jan', code: 'Jan', id: undefined, value: undefined },
    { label: 'Feb', code: 'Feb', id: undefined, value: undefined },
    { label: 'Mar', code: 'Mar', id: undefined, value: undefined },
  ];

  constructor(private router: Router, private holidayservice: HolidayService,
    private datePipe: HbDateFormatPipe) { }


  holidayTypeModalOpen(id: any) {
    this.hbErrorHandler.clearErrors()
    if (id) {
      this.getHolidayTypeById(id);
      this.holidayTypeModal = true;
    } else {
      this.holidayType = new Array<HolidayType>()
      this.holidayTypeModal = true;
      this.addRowType()
    }
  }

  ngOnInit(): void {
    this.tableData = [{}];
    this.holidayTypeColumns();
    this.getHolidayTypeList();
    this.getHolidayCalendarList();
    this.addRowCalendar();
  }



  holidayTypeColumns() {
    this.columns = [
      {
        header: 'S. No.',
        columnData: () => {
        },
        type: 'SR_NO'
      },
      {
        header: 'Holiday Type Name',
        columnData: (inv: HolidayType) => {
          return inv.name;
        },
        type: 'TEXT'
      },
      {
        header: 'Code',
        columnData: (inv: HolidayType) => {
          return inv.code
        },
        type: 'TEXT'
      },
      {
        header: 'Actions',
        columnData: () => {
        },
        type: 'ACTION',
        actionOptions: ['EDIT', 'DELETE']
      },
    ];
  }

  getHolidayTypeById(id: any) {
    HBLoaderService.showLoader();
    this.holidayservice.getHolidayTypeById(id).subscribe(response => {
      if (response.status === 200 && response.data && response.data.holidayTypeMaster) {
        this.holidayType.push(response.data.holidayTypeMaster)
        HBLoaderService.hideLoader();
      }
      () => {
        HBLoaderService.hideLoader();
      }
    });
  }

  setActiveTab(tabName: string) {
    this.currentTab = tabName;
  }

  addRowType() {
    this.holidayType.push(new HolidayType());
  }

  addRowCalendar() {
    this.holidayCalendar.push(new HolidayCalendar());
  }

  removeRowType(index: number) {
    this.holidayType.splice(index, 1);
  }

  addUpdateHolidayType() {
    this.hbErrorHandler.clearErrors()
    this.validateType();
    if (!this.hbErrorHandler.invalid) {
      if (this.holidayType && this.holidayType.length > 0) {
        for (const type of this.holidayType) {
          if (!type.id) {
            HBLoaderService.showLoader();
            this.holidayservice.addHolidayType(type).subscribe(response => {
              console.log(response);
              if (response.status === 200 && response.data && response.data.holidayTypeMaster) {
                this.confirmationPopup(response.message, 'Holiday Type', 'Type');
                HBLoaderService.hideLoader();
              }
            });
          } else {
            HBLoaderService.showLoader();
            this.holidayservice.updateHolidayType(type).subscribe(response => {
              console.log(response);
              if (response.status === 200 && response.data && response.data.holidayTypeMaster) {
                this.confirmationPopup(response.message, 'Holiday Type', 'Type');
                HBLoaderService.hideLoader();
              }
            });
          }
        }
      }
    }
  }

  addUpdateHolidayCalendar() {
    this.hbErrorHandler.clearErrors();
    this.validateCalendar();
    if (!this.hbErrorHandler.invalid && this.holidayCalendar && this.holidayCalendar.length > 0) {
      for (const calendar of this.holidayCalendar) {
        if (!calendar.id) {
          HBLoaderService.showLoader();
          this.holidayservice.addHolidayCalendar(calendar).subscribe(response => {
            console.log(response);
            if (response.status === 200 && response.data && response.data.holidayCalendar) {
              this.confirmationPopup(response.message, 'Holiday Calendar', 'Calendar');
            } else if (response.status === 400 && response.fieldErrors.length !== 0) {
              this.isError = true;
              this.errorMessage = response.fieldErrors[0].message;
            }
            HBLoaderService.hideLoader();
          });
        } else {
          if (calendar.valueChangeFlag) {
            this.holidayservice.updateHolidayCalendar(calendar).subscribe(response => {
              console.log(response);
              if (response.status === 200 && response.data && response.data.holidayCalendar) {
                this.confirmationPopup(response.message, 'Holiday Calendar', 'Calendar');
              }
            });
          } else {
            PopupService.infoAlert("Holiday Calendar", "There is no change found")
          }
        }
      }
    }
  }

  calendarChanges(row: any, index: number) {
    if (row.date) {
      const originalDate = new Date(row.date);
      const day = originalDate.getDate().toString().padStart(2, '0');
      const month = (originalDate.getMonth() + 1).toString().padStart(2, '0');
      const year = originalDate.getFullYear();
      row.date = `${day}/${month}/${year}`;
    }
    if (row.id) {
      row.valueChangeFlag = false;
      const previousRow = this.previousData[index];
      if (previousRow) {
        for (const prop in row) {
          if (row.hasOwnProperty(prop) && previousRow.hasOwnProperty(prop)) {
            if (row[prop] != (previousRow[prop])) {
              row.valueChangeFlag = true;
            }
          }
        }
      }
    }
  }


  close() {
    this.holidayType = new Array<HolidayType>()
    this.holidayTypeModal = false;
  }

  errorHandler(parentkey: string, childkey?: string, keyIndex?: number): HbErrorHandlerData {
    const hData = this.hbErrorHandler.getErrorHandlerData(parentkey, childkey, keyIndex);
    return hData;
  }

  validateType(): void {
    if (this.holidayType) {
      this.holidayType.forEach((element, index) => {
        if (element) {
          this.hbErrorHandler.emptyCheck(this.holidayType[index].name, 'holidayType[' + index + '].name')
          this.hbErrorHandler.emptyCheck(this.holidayType[index].code, 'holidayType[' + index + '].code')
        }
      });
    }
  }

  validateCalendar(): void {
    if (this.holidayCalendar) {
      this.holidayCalendar.forEach((element, index) => {
        if (element) {
          this.hbErrorHandler.emptyCheck(this.holidayCalendar[index].name, 'holidayCalendar[' + index + '].name');
          this.hbErrorHandler.emptyCheck(this.holidayCalendar[index].date, 'holidayCalendar[' + index + '].date');
          this.hbErrorHandler.emptyCheck(this.holidayCalendar[index].masterId, 'holidayCalendar[' + index + '].type');

          for (let i = 0; i < this.holidayCalendar.length; i++) {
            if (i !== index && this.holidayCalendar[i]?.date === element.date) {
              this.hbErrorHandler.addError('Duplicate Date', 'holidayCalendar[' + index + '].date');
              break;
            }
          }
        }
      });
    }
  }

  confirmationPopup(message: any, title: string, code: string) {
    Swal.fire({
      title,
      html: message,
      icon: 'success',
      allowOutsideClick: false,
      allowEscapeKey: false,
    }).then(result => {
      if (result.value) {
        switch (code) {
          case 'Type':
            this.getHolidayTypeList();
            break;
          case 'Calendar':
            this.getHolidayCalendarList();
            break;
        }
      }
      this.close()
    });
  }

  getHolidayCalendarList() {
    HBLoaderService.showLoader()
  this.setLeaveSearchRequestDates()
    this.holidayservice.getHolidayCalendarList(this.leaveSearchRequest).subscribe(response => {
      console.log(response);
      if (response.status === 200 && response.data && response.data.holidayCalendar) {
        this.holidayCalendar = response.data.holidayCalendar.list;
        if (this.holidayCalendar.length <= 0) {
          this.holidayCalendar.push(new HolidayCalendar());
        }
        this.holidayCalendar.forEach(calendar => {
          calendar.date = this.datePipe.transform(calendar.date)
        })
        this.previousData = JSON.parse(JSON.stringify(response.data.holidayCalendar.list));
        HBLoaderService.hideLoader();
      }
    });
  }

  setLeaveSearchRequestDates() {
    let startDate, endDate;
    if (this.selectedYear) {
      const year = this.selectedYear.getFullYear();
      if (this.selectedMonth) {
        const month = this.selectedMonth.getMonth();
        startDate = new Date(year, month, 1);
        endDate = new Date(year, month + 1, 0);
      } else {
        startDate = new Date(year, 0, 1);
        endDate = new Date(year, 11, 31);
      }
      const formattedStartDate = this.formatDate(startDate);
      const formattedEndDate = this.formatDate(endDate);
      this.leaveSearchRequest.startDate = formattedStartDate;
      this.leaveSearchRequest.endDate = formattedEndDate;
    }
  }

  formatDate(date) {
    const day = String(date.getDate()).padStart(2, '0');
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const year = date.getFullYear();
    return `${year}-${month}-${day}`;
  }

  getHolidayTypeList() {
    HBLoaderService.showLoader();
    this.leaveSearchRequest.searchFor = this.searchName;
    this.holidayservice.getHolidayTypeList(this.leaveSearchRequest).subscribe(response => {
      console.log(response);
      if (response.status === 200 && response.data && response.data.holidayTypeMaster) {
        this.data = response.data.holidayTypeMaster.list;
        this.total = response.data.holidayTypeMaster.totalRowCount;
        HBLoaderService.hideLoader();
      } else {
        this.data = new Array<HolidayType>();
        this.total = response.data.holidayTypeMaster.totalRowCount;
        HBLoaderService.hideLoader();
      }
    });
  }

  onAction(_event: any) {
    if (_event && _event.actionType && _event.data) {
      if (_event.actionType === 'DELETE') {
        this.deleteHolidayType(_event.data.id);
      }
      if (_event.actionType === 'EDIT') {
        this.holidayTypeModalOpen(_event.data.id);
      }
    }
  }

  onChange(_event: any) {
    this.leaveSearchRequest.page = _event.page;
    this.leaveSearchRequest.limit = _event.limit;
    this.getHolidayTypeList();
  }

  deleteHolidayType(id: number) {
    this.deleteConfirmationPopup().then(result => {
      if (result.value) {
        HBLoaderService.showLoader();
        this.holidayservice.deleteHolidayType(id).subscribe(response => {
          this.deletedConfirmationPopup(response.message, 'Holiday Type', 'Type');
          HBLoaderService.hideLoader();
        });
      }
    });
  }

  deleteHolidayCalendar(id: number, index: number) {
    if (id) {
      this.deleteConfirmationPopup().then(result => {
        if (result.value) {
          HBLoaderService.showLoader();
          this.holidayservice.deleteHolidayCalendar(id).subscribe(response => {
            console.log(response);
            this.deletedConfirmationPopup(response.message, 'Holiday Calendar', 'Calendar');
            HBLoaderService.hideLoader();
          });
        }
      });
    } else {
      this.holidayCalendar.splice(index, 1);
    }
  }

  deleteConfirmationPopup() {
    return Swal.fire({
      title: 'Warning',
      text: 'Are you sure that you want to perform this action?',
      icon: 'question',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes',
      cancelButtonText: 'No',
      allowOutsideClick: false,
      allowEscapeKey: false,
    });
  }

  deletedConfirmationPopup(message: any, title: string, code: string) {
    Swal.fire({
      titleText: title,
      text: message,
      icon: 'success',
      allowOutsideClick: false,
      allowEscapeKey: false,
    }).then(result => {
      if (result.value) {
        switch (code) {
          case 'Type':
            this.getHolidayTypeList();
            break;
          case 'Calendar':
            this.getHolidayCalendarList();
            break;
        }
      }
      this.close()
    });
  }

  import() {
    this.router.navigateByUrl('/payroll/importMaster/import?title=holiday');
  }
}
