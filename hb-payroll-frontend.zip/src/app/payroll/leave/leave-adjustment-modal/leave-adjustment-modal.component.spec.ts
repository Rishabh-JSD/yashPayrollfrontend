import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LeaveAdjustmentModalComponent } from './leave-adjustment-modal.component';

describe('LeaveAdjustmentModalComponent', () => {
  let component: LeaveAdjustmentModalComponent;
  let fixture: ComponentFixture<LeaveAdjustmentModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [LeaveAdjustmentModalComponent]
    })
      .compileComponents();

    fixture = TestBed.createComponent(LeaveAdjustmentModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
