import { Component, Input } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-leave-adjustment-modal',
  templateUrl: './leave-adjustment-modal.component.html',
  styleUrls: ['./leave-adjustment-modal.component.scss']
})
export class LeaveAdjustmentModalComponent {

  @Input() visible = false;
  dialogRef: MatDialogRef<any>;


  closeDialog(): void {
  }
}
