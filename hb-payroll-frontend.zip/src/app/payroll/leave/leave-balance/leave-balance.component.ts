import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-leave-balance',
  templateUrl: './leave-balance.component.html',
  styleUrls: ['./leave-balance.component.scss']
})
export class LeaveBalanceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
