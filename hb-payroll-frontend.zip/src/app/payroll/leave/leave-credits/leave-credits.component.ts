import { Component } from '@angular/core';
import { Location } from '@angular/common';
import { HbDataTableColumnOption } from '@hostbooks/hb-lib/hb-list-table/src/hb-list-table-columns';
import { AppliedAdvanceListing } from 'src/app/payroll/applied/applied-advance/applied-advance';

@Component({
  selector: 'app-leave-credits',
  templateUrl: './leave-credits.component.html',
  styleUrls: ['./leave-credits.component.scss']
})
export class LeaveCreditsComponent {
  leaveHistoryVisible = false;
  runLeaveCreditVisible = false;
  openingLeaveVisible = false;
  leaveAdjustmentVisible = false;

  columns: HbDataTableColumnOption[] = [];
  data: AppliedAdvanceListing[] = [];
  total: number;
  dataSource = [];

  constructor(private _location: Location,) {}


  ngOnInit(): void {
    this.data = this.dataSource;

    this.columns = [
      {
        header: 'Employee Code',
        columnData: (inv: AppliedAdvanceListing) => {
          return 'emp_code';
        },
        type: 'TEXT'
      },
      {
        header: 'Employee Name',
        columnData: (inv: AppliedAdvanceListing) => {
          return 'emp-name';
        },
        type: 'TEXT'
      },
      {
        header: 'CL',
        columnData: (inv: AppliedAdvanceListing) => {
          return 'cl';
        },
        type: 'NUMBER'
      },
      {
        header: 'PL',
        columnData: (inv: AppliedAdvanceListing) => {
          return 'pl';
        },
        type: 'NUMBER'
      },
      {
        header: 'SL',
        columnData: (inv: AppliedAdvanceListing) => {
          return 'sl';
        },
        type: 'NUMBER'
      },
      {
        header: 'CO',
        columnData: (inv: AppliedAdvanceListing) => {
          return 'co';
        },
        type: 'NUMBER'
      },
      {
        header: 'Total',
        columnData: (inv: AppliedAdvanceListing) => {
          return 'total';
        },
        type: 'NUMBER'
      },
    ];
    this.total = this.data.length;
  }

  back() {
    this._location.back();
  }

  leaveHistoryModal() {
    this.leaveHistoryVisible = true;
  }

  runLeaveCreditsModal() {
    this.runLeaveCreditVisible = true;
  }

  openingLeaveModal() {
    this.openingLeaveVisible = true;
  }

  leaveAdjModal() {
    this.leaveAdjustmentVisible = true;
  }
}
