import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LeaveHistoryModalComponent } from './leave-history-modal.component';

describe('LeaveHistoryModalComponent', () => {
  let component: LeaveHistoryModalComponent;
  let fixture: ComponentFixture<LeaveHistoryModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [LeaveHistoryModalComponent]
    })
      .compileComponents();

    fixture = TestBed.createComponent(LeaveHistoryModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
