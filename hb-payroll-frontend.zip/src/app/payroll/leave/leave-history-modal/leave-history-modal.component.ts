import { Component, Input } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { HbDataTableColumnOption } from '@hostbooks/hb-lib/hb-list-table/src/hb-list-table-columns';
import { AppliedAdvanceListing } from '../../applied/applied-advance/applied-advance';

@Component({
  selector: 'app-leave-history-modal',
  templateUrl: './leave-history-modal.component.html',
  styleUrls: ['./leave-history-modal.component.scss']
})
export class LeaveHistoryModalComponent {

  @Input() visible = false;
  columns: HbDataTableColumnOption[] = [];
  data: AppliedAdvanceListing[] = [];
  total: number;
  dataSource = [];

  dialogRef: MatDialogRef<any>;


  closeDialog(): void {
  }

  ngOnInit(): void {
    this.data = this.dataSource;

    this.columns = [
      {
        header: 'Year',
        columnData: (inv: AppliedAdvanceListing) => {
          return '';
        },
        type: 'TEXT'
      },
      {
        header: 'Month',
        columnData: (inv: AppliedAdvanceListing) => {
          return '';
        },
        type: 'TEXT'
      },
      {
        header: 'Credits',
        columnData: (inv: AppliedAdvanceListing) => {
          return '';
        },
        type: 'NUMBER'
      },
      {
        header: 'Consumed',
        columnData: (inv: AppliedAdvanceListing) => {
          return '';
        },
        type: 'NUMBER'
      },
      {
        header: 'Total',
        columnData: (inv: AppliedAdvanceListing) => {
          return 'sl';
        },
        type: 'NUMBER'
      },
    ];
    this.total = this.data.length;
  }
}
