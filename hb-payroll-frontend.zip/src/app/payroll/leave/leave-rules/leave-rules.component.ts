import { Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { DropDownModel } from '../../../shared/models/hb-field-option';
import { AppConst } from 'src/app/core/constants/app-const';
import { LeaveSearchRequest } from '../modal/leave-search-request';
import { LeaveTypeService } from '../service/leave-type.service';
import { LeaveRuleCreditCarry, LeaveRulePermissible, LeaveRuleSandwich, LeaveRuleUtilisationPeriod, LRCombinedRestriction, LRCombinedRestrictionOptions } from '../modal/leave-rules';
import Swal from 'sweetalert2';
import { Router } from '@angular/router';
import { LeaveRuleService } from '../service/leave-rule.service';
import { HBLoaderService } from 'src/app/shared/services/hb-loader.service';
import { forkJoin } from 'rxjs';
import { LeaveType } from '../modal/leave-type';
import { HbErrorHandler, HbErrorHandlerData } from 'src/app/shared/models/hb-error-handler';
import { PopupService } from 'src/app/shared/services/popup.service';

@Component({
  selector: 'app-leave-rules', templateUrl: './leave-rules.component.html', styleUrls: ['./leave-rules.component.scss']
})
export class LeaveRulesComponent implements OnInit {

  @ViewChild('addRule') addRule: TemplateRef<any> | undefined;
  dialogRef: MatDialogRef<any> | undefined;

  leaveSearchRequest = new LeaveSearchRequest();
  leaveType: LeaveType[] = [];
  lrCombinedRestriction = new Array<LRCombinedRestriction>();
  lrPermissible = new Array<LeaveRulePermissible>();
  lrSandwich = new LeaveRuleSandwich();
  lrUtilisationPeriod = new Array<LeaveRuleUtilisationPeriod>();
  lrCreditCarry = new Array<LeaveRuleCreditCarry>();
  type: DropDownModel[] = [];
  hbErrorHandler = new HbErrorHandler();
  previousLRPermissible = new Array()
  previousLRUtilisationPeriod = new Array()
  previousLRCreditCarry = new Array()
  previousLRCombinedRestriction = new Array()

  Level: DropDownModel[] = [{ label: 'option 1', code: '1', id: undefined, value: undefined }, { label: 'option 2', code: '2', id: undefined, value: undefined },];
  Sequence1: DropDownModel[] = [{ label: 'option 1', code: '1', id: undefined, value: undefined }, { label: 'option 2', code: '2', id: undefined, value: undefined },];
  Sequence2: DropDownModel[] = [{ label: 'option 1', code: '1', id: undefined, value: undefined }, { label: 'option 2', code: '2', id: undefined, value: undefined },];
  Sequence3: DropDownModel[] = [{ label: 'option 1', code: '1', id: undefined, value: undefined }, { label: 'option 2', code: '2', id: undefined, value: undefined },];

  constructor(public dialog: MatDialog, private leaveTypeService: LeaveTypeService, private leaveRuleService: LeaveRuleService, private router: Router) { }

  ngOnInit(): void {
    forkJoin([this.getLeaveTypeList(), this.getLeaveRuleLists(), this.addRowRule_1(), this.addRowRule_2(), this.addRowRule_4(), this.addRowRule_5()]);
  }

  openAddRulePopup(template: TemplateRef<any>): void {
    this.dialogRef = this.dialog.open(template, {
      minHeight: '200px', width: '800px',
    });

  }

  closeDialog(data: any = null): void {
    if (this.dialogRef) {
      this.dialogRef.close(data);
    }
  }

  //getting leavetype multiselect and dyamic columns for rule 1
  getLeaveTypeList() {
    this.leaveSearchRequest.type = AppConst.ATTENDANCE_LEAVE_TYPE.LEAVE_TYPE;
    this.leaveTypeService.getLeaveTypeList(this.leaveSearchRequest).subscribe(response => {
      console.log(response);
      if (response.status === 200 && response.data && response.data.leaveType) {
        this.leaveType = response.data.leaveType.list;
        if (this.leaveType) {
          this.type = new Array<DropDownModel>();
          this.leaveType.forEach(leaveOptions => {
            let typeList = new DropDownModel();
            typeList.id = leaveOptions.id;
            typeList.label = leaveOptions.name;
            typeList.code = leaveOptions.code;
            this.type.push(typeList);
          });
        }
      }
    });
  }

  //to add new row
  addRowRule_1() {
    this.lrCombinedRestriction.push(new LRCombinedRestriction());
    if (this.lrCombinedRestriction) {
      for (let i = 0; i < this.leaveType.length; i++) {
        const option = new LRCombinedRestrictionOptions();
        option.disable = true;
        option.ids = this.leaveType[i].id;
        this.lrCombinedRestriction[this.lrCombinedRestriction.length - 1].lrCombinedRestrictionOptions.push(option);
      }
    }
  }

  addRowRule_2() {
    this.lrPermissible.push(new LeaveRulePermissible());
  }

  addRowRule_4() {
    this.lrUtilisationPeriod.push(new LeaveRuleUtilisationPeriod());
  }

  addRowRule_5() {
    this.lrCreditCarry.push(new LeaveRuleCreditCarry());
  }

  //for setting the leavetypeid in options rule 1
  setTypeRule_1(i, j) {
    this.lrCombinedRestriction[j].lrCombinedRestrictionOptions[i].leaveTypeId = this.leaveType[i].id;
  }

  //for diable enable input fields
  onSelectRule_1(row: any): void {
    if (row.leaveTypeIds && row.leaveTypeIds.length > 0) {
      for (const options of row.lrCombinedRestrictionOptions) {
        if (row.leaveTypeIds.includes(options.leaveTypeId) || row.leaveTypeIds.includes(options.ids)) {
          options.disable = false;
        } else {
          options.disable = true;
          options.quantity = null;
        }
      }
    } else {
      for (const options of row.lrCombinedRestrictionOptions) {
        options.disable = true;
      }
    }
  }


  confirmationPopup(message: any) {
    Swal.fire({
      title: 'LeaveRule', html: message, icon: 'success', allowOutsideClick: false, allowEscapeKey: false,
    }).then(() => {
      this.getLeaveRuleLists();
    });
  }

  //to add update leaveRule
  addUpdateLeaveRuleCombinedRestriction() {
    this.hbErrorHandler.clearErrors();
    this.validateLRCombinedRestriction();
    if (!this.hbErrorHandler.invalid && this.lrCombinedRestriction && this.lrCombinedRestriction.length > 0) {
      for (const option of this.lrCombinedRestriction) {
        if (!option.id && option.lrCombinedRestrictionOptions && option.lrCombinedRestrictionOptions.length > 0) {
          const filteredOptions = option.lrCombinedRestrictionOptions.filter(opt => opt.disable == false);
          if (filteredOptions.length > 0) {
            option.lrCombinedRestrictionOptions = filteredOptions;
            this.leaveRuleService.addLeaveRuleCombinedRestriction(option).subscribe(response => {
              console.log(response);
              if (response.status === 200 && response.data && response.data.leaveRuleCombinedRestriction) {
                this.confirmationPopup(response.message);
              }
            });
          }
        } else if (option.valueChangeFlag) {
          if (option.id && option.lrCombinedRestrictionOptions && option.lrCombinedRestrictionOptions.length > 0) {
            const filteredOptions = option.lrCombinedRestrictionOptions.filter(opt => opt.disable !== true);
            if (filteredOptions.length > 0) {
              option.lrCombinedRestrictionOptions = filteredOptions;

              this.leaveRuleService.updateLeaveRuleCombinedRestriction(option).subscribe(response => {
                console.log(response);
                if (response.status === 200 && response.data && response.data.leaveRuleCombinedRestriction) {
                  this.confirmationPopup(response.message);
                }
              });
            }
          }
        }
        else {
          PopupService.infoAlert("Leave Rule Combined Restriction", "There is no change found")
        }
      }
    }
  }

  addUpdateLeaveRulePermissible() {
    this.hbErrorHandler.clearErrors()
    this.validateLRPermissible();
    if (!this.hbErrorHandler.invalid && this.lrPermissible && this.lrPermissible.length > 0) {
      for (const permissible of this.lrPermissible) {
        if (!permissible.id) {
          this.leaveRuleService.addLeaveRulePermissible(permissible).subscribe(response => {
            console.log(response);
            if (response.status === 200 && response.data && response.data.leaveRulePermissible) {
              this.confirmationPopup(response.message);
            }
          });
        } else {
          if (permissible.valueChangeFlag) {
            this.leaveRuleService.updateLeaveRulePermissible(permissible).subscribe(response => {
              console.log(response);
              if (response.status === 200 && response.data && response.data.leaveRulePermissible) {
                this.confirmationPopup(response.message);
              }
            });
          } else {
            PopupService.infoAlert("Leave Rule Permissible", "There is no change found")
          }
        }
      }
    }
  }

  //to push id inside lrSandwich for sanwich rule 3
  toggle(event: any) {
    if (event) {
      if (!this.lrSandwich.leaveTypeIds) {
        this.lrSandwich.leaveTypeIds = new Array<number>();
      }
      for (const item of this.leaveType) {
        if (item.sandwichFlag && !this.lrSandwich.leaveTypeIds.includes(item.id)) {
          this.lrSandwich.leaveTypeIds.push(item.id);
        }
      }
    } else {
      if (this.lrSandwich.leaveTypeIds) {
        this.lrSandwich.leaveTypeIds = this.lrSandwich.leaveTypeIds.filter(id => {
          const leaveItem = this.leaveType.find(item => item.id === id);
          return !(leaveItem && !leaveItem.sandwichFlag);
        });
      }
    }
  }


  addLeaveRuleSandwich() {
    if (this.lrSandwich && this.lrSandwich.leaveTypeIds.length > 0) {
      if (!this.lrSandwich.id) {
        this.leaveRuleService.addLeaveRuleSandwich(this.lrSandwich).subscribe(response => {
          console.log(response);
          if (response.status === 200 && response.data && response.data.leaveRuleSandwich) {
            this.confirmationPopup(response.message);
          }
        });
      }
      else {
        this.leaveRuleService.updateLeaveRuleSandwich(this.lrSandwich).subscribe(response => {
          console.log(response);
          if (response.status === 200 && response.data && response.data.leaveRuleSandwich) {
            this.confirmationPopup(response.message);
          }
        });
      }
    } else {
      PopupService.infoAlert("Leave Rule Sandwich", "There is no change found")
    }
  }

  addUpdateLeaveRuleUtilisationPeriod() {
    this.hbErrorHandler.clearErrors()
    this.validateLRUtilisationPeriod();
    if (!this.hbErrorHandler.invalid && this.lrUtilisationPeriod && this.lrUtilisationPeriod.length > 0) {
      for (const UtilisationPeriod of this.lrUtilisationPeriod) {
        if (!UtilisationPeriod.id) {
          this.leaveRuleService.addLeaveRuleUtilisationPeriod(UtilisationPeriod).subscribe(response => {
            console.log(response);
            if (response.status === 200 && response.data && response.data.leaveRuleUtilisationPeriod) {
              this.confirmationPopup(response.message);
            }
          });
        } else {
          if (UtilisationPeriod.valueChangeFlag) {
            this.leaveRuleService.updateLeaveRuleUtilisationPeriod(UtilisationPeriod).subscribe(response => {
              console.log(response);
              if (response.status === 200 && response.data && response.data.leaveRuleUtilisationPeriod) {
                this.confirmationPopup(response.message);
              }
            });
          } else {
            PopupService.infoAlert("Leave Rule Utilisation Period", "There is no change found")
          }
        }
      }
    }
  }

  addUpdateLeaveRuleCreditCarry() {
    this.hbErrorHandler.clearErrors()
    this.validateLRCreditCarry();
    if (!this.hbErrorHandler.invalid && this.lrCreditCarry && this.lrCreditCarry.length > 0) {
      for (const creditCarry of this.lrCreditCarry) {
        if (!creditCarry.id) {
          this.leaveRuleService.addLeaveRuleCreditCarry(creditCarry).subscribe(response => {
            console.log(response);
            if (response.status === 200 && response.data && response.data.leaveRuleCreditCarry) {
              this.confirmationPopup(response.message);
            }
          });
        } else {
          if (creditCarry.valueChangeFlag) {
            this.leaveRuleService.updateLeaveRuleCreditCarry(creditCarry).subscribe(response => {
              console.log(response);
              if (response.status === 200 && response.data && response.data.leaveRuleCreditCarry) {
                this.confirmationPopup(response.message);
              }
            });
          } else {
            PopupService.infoAlert("Leave Rule Credit Carry", "There is no change found")
          }
        }
      }
    }
  }


  // delete leave rules and delete row if id is not present
  deleteLeaveRuleCombinedRestriction(id: number, index: number) {
    if (id) {
      this.deleteConfirmationPopup().then(result => {
        if (result.value) {
          HBLoaderService.showLoader();
          this.leaveRuleService.deleteLeaveRuleCombinedRestriction(id).subscribe(response => {
            console.log(response);
            this.deletedConfirmationPopup(response.message, 'LeaveRuleCombinedRestriction');
            HBLoaderService.hideLoader();
          });
        }
      });
    } else {
      this.lrCombinedRestriction.splice(index, 1);
    }
  }

  deleteLeaveRulePermissible(id: number, index: number) {
    if (id) {
      this.deleteConfirmationPopup().then(result => {
        if (result.value) {
          HBLoaderService.showLoader();
          this.leaveRuleService.deleteLeaveRulePermissible(id).subscribe(response => {
            console.log(response);
            this.deletedConfirmationPopup(response.message, 'LeaveRulePermissible');
            HBLoaderService.hideLoader();
          });
        }
      });
    } else {
      this.lrPermissible.splice(index, 1);
    }
  }

  deleteLeaveRuleUtilisationPeriod(id: number, index: number) {
    if (id) {
      this.deleteConfirmationPopup().then(result => {
        if (result.value) {
          HBLoaderService.showLoader();
          this.leaveRuleService.deleteLeaveRuleUtilisationPeriod(id).subscribe(response => {
            console.log(response);
            this.deletedConfirmationPopup(response.message, 'LeaveRuleUtilisationPeriod');
            HBLoaderService.hideLoader();
          });
        }
      });
    } else {
      this.lrUtilisationPeriod.splice(index, 1);
    }
  }

  deleteLeaveRuleCreditCarry(id: number, index: number) {
    if (id) {
      this.deleteConfirmationPopup().then(result => {
        if (result.value) {
          HBLoaderService.showLoader();
          this.leaveRuleService.deleteLeaveRuleCreditCarry(id).subscribe(response => {
            console.log(response);
            this.deletedConfirmationPopup(response.message, 'LeaveRuleCreditCarry');
            HBLoaderService.hideLoader();
          });
        }
      });
    } else {
      this.lrCreditCarry.splice(index, 1);
    }
  }

  deleteConfirmationPopup() {
    return Swal.fire({
      title: 'Warning',
      text: 'Are you sure that you want to perform this action?',
      icon: 'question',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes',
      cancelButtonText: 'No',
      allowOutsideClick: false,
      allowEscapeKey: false,
    });
  }

  deletedConfirmationPopup(message, title) {
    Swal.fire({
      title: title, text: message, icon: 'success', allowOutsideClick: false, allowEscapeKey: false,
    }).then(result => {
      if (result.value) {
        this.getLeaveRuleLists();
      }
    });
  }

  //to get leaveRuleList and on value change
  getLeaveRuleLists() {
    this.getLeaveRuleCombinedRestrictionList();
    this.getLeaveRulePermissibleList();
    this.getLeaveRuleSandwichList();
    this.getLeaveRuleUtilisationPeriodList();
    this.getLeaveRuleCreditCarryList();
  }

  changesLeaveRuleCombinedRestriction(row: any, index: number) {
    if (row.id) {
      row.valueChangeFlag = false;
      const previousRow = this.previousLRCombinedRestriction[index];

      // Check properties in lrCombinedRestrictionOptions arrays
      if (row.lrCombinedRestrictionOptions && previousRow.lrCombinedRestrictionOptions && row.lrCombinedRestrictionOptions.length === previousRow.lrCombinedRestrictionOptions.length) {
        for (let i = 0; i < row.lrCombinedRestrictionOptions.length; i++) {
          const currentOption = row.lrCombinedRestrictionOptions[i];
          const previousOption = previousRow.lrCombinedRestrictionOptions[i];
          for (const optionProp in currentOption) {
            if (currentOption.hasOwnProperty(optionProp) && previousOption.hasOwnProperty(optionProp)) {
              if (currentOption[optionProp] !== previousOption[optionProp]) {
                row.valueChangeFlag = true;
              }
            }
          }
        }
      }

      if (row.leaveTypeIds && previousRow.leaveTypeIds && row.leaveTypeIds.length === previousRow.leaveTypeIds.length) {
        for (let i = 0; i < row.leaveTypeIds.length; i++) {
          if (row.leaveTypeIds[i] !== previousRow.leaveTypeIds[i]) {
            row.valueChangeFlag = true;
          }
        }
      } else {
        row.valueChangeFlag = true;
      }
    }
  }

  changesLeaveRulePermissible(row: any, index: number) {
    if (row.id) {
      row.valueChangeFlag = false;
      const previousRow = this.previousLRPermissible[index];
      if (previousRow) {
        for (const prop in row) {
          if (row.hasOwnProperty(prop) && previousRow.hasOwnProperty(prop)) {
            if (row[prop] != (previousRow[prop])) {
              row.valueChangeFlag = true;
            }
          }
        }
      }
    }
  }

  changesLeaveRuleUtilisationPeriod(row: any, index: number) {
    if (row.id) {
      row.valueChangeFlag = false;
      const previousRow = this.previousLRUtilisationPeriod[index];
      if (previousRow) {
        for (const prop in row) {
          if (row.hasOwnProperty(prop) && previousRow.hasOwnProperty(prop)) {
            if (row[prop] != (previousRow[prop])) {
              row.valueChangeFlag = true;
            }
          }
        }
      }
    }
  }

  changesLeaveRuleCreditCarry(row: any, index: number) {
    if (row.id) {
      row.valueChangeFlag = false;
      const previousRow = this.previousLRCreditCarry[index];
      if (previousRow) {
        for (const prop in row) {
          if (row.hasOwnProperty(prop) && previousRow.hasOwnProperty(prop)) {
            if (row[prop] != (previousRow[prop])) {
              row.valueChangeFlag = true;
            }
          }
        }
      }
    }
  }

  getLeaveRuleCombinedRestrictionList() {
    HBLoaderService.showLoader();
    this.leaveRuleService.getLeaveRuleCombinedRestrictionList(this.leaveSearchRequest).subscribe(response => {
      console.log(response);
      if (response.status === 200 && response.data && response.data.leaveRuleCombinedRestriction) {
        this.lrCombinedRestriction = response.data.leaveRuleCombinedRestriction.list;
        if (this.lrCombinedRestriction.length > 0) {
          // Loop through leaveType
          for (let i = 0; i < this.leaveType.length; i++) {
            // Check and update lrCombinedRestrictionOptions
            for (let j = 0; j < this.lrCombinedRestriction.length; j++) {
              const lr = this.lrCombinedRestriction[j];
              const leaveType = this.leaveType[i].id;
              const matchingLeaveTypeId = lr.lrCombinedRestrictionOptions.some(option => option.leaveTypeId === leaveType);
              // If leaveTypeId doesn't match, add a new option
              if (!matchingLeaveTypeId) {
                let option = new LRCombinedRestrictionOptions();
                option.disable = true;
                option.leaveTypeId = this.leaveType[i].id;
                this.lrCombinedRestriction[j].lrCombinedRestrictionOptions.push(option);
              }
            }
          }

          // After pushing new lrCombinedRestrictionOptions, perform reshuffling if needed
          for (let j = 0; j < this.lrCombinedRestriction.length; j++) {
            const lr = this.lrCombinedRestriction[j];
            const options = lr.lrCombinedRestrictionOptions;

            // Sort the options based on leaveTypeId to ensure they're in ascending order
            options.sort((a, b) => a.leaveTypeId - b.leaveTypeId);

            // Check and reshuffle if the gap between index and leaveTypeId is greater than 1
            for (let k = 0; k < options.length - 1; k++) {
              if (options[k + 1].leaveTypeId - options[k].leaveTypeId > 1) {
                // Reshuffle the array so that leaveTypeId is always greater by 1 than the index
                const diff = options[k + 1].leaveTypeId - options[k].leaveTypeId;
                const newOptions = Array.from({ length: diff - 1 }, (_, idx) => {
                  const option = new LRCombinedRestrictionOptions();
                  option.disable = true;
                  option.leaveTypeId = options[k].leaveTypeId + idx + 1;
                  return option;
                });
                options.splice(k + 1, 0, ...newOptions);
              }
            }
          }
        }

        // if data is not present
        if (this.lrCombinedRestriction.length <= 0) {
          this.lrCombinedRestriction = new Array<LRCombinedRestriction>();
          this.lrCombinedRestriction.push(new LRCombinedRestriction());
          for (let i = 0; i < this.leaveType.length; i++) {
            for (let j = 0; j < this.lrCombinedRestriction.length; j++) {
              let option = new LRCombinedRestrictionOptions();
              option.disable = true;
              option.leaveTypeId = this.leaveType[i].id;
              this.lrCombinedRestriction[j].lrCombinedRestrictionOptions.push(option);
            }
          }
        }
        this.previousLRCombinedRestriction = JSON.parse(JSON.stringify(response.data.leaveRuleCombinedRestriction.list));
        HBLoaderService.hideLoader();
      }
    });
  }

  getLeaveRulePermissibleList() {
    HBLoaderService.showLoader();
    this.leaveRuleService.getLeaveRulePermissibleList(this.leaveSearchRequest).subscribe(response => {
      console.log(response);
      if (response.status === 200 && response.data && response.data.leaveRulePermissible) {
        this.lrPermissible = response.data.leaveRulePermissible.list;

        if (this.lrPermissible.length <= 0) {
          this.lrPermissible.push(new LeaveRulePermissible());
        }
        this.previousLRPermissible = JSON.parse(JSON.stringify(response.data.leaveRulePermissible.list));
        HBLoaderService.hideLoader();
      }
    });
  }

  getLeaveRuleSandwichList() {
    HBLoaderService.showLoader();
    this.leaveRuleService.getLeaveRuleSandwichList(this.leaveSearchRequest).subscribe(response => {
      console.log(response);
      if (response.status === 200 && response.data && response.data.leaveRuleSandwich) {
        this.lrSandwich = response.data.leaveRuleSandwich.list.length > 0
          ? response.data.leaveRuleSandwich.list[0]
          : new LeaveRuleSandwich();
        if (this.lrSandwich.leaveTypeIds) {
          this.leaveType.forEach(item => {
            item.sandwichFlag = this.lrSandwich.leaveTypeIds.includes(item.id);
          });
        } else {
          this.leaveType.forEach(item => {
            item.sandwichFlag = false;
          });
        }
        if (!this.lrSandwich.leaveTypeIds) {
          this.lrSandwich = new LeaveRuleSandwich()
        }
        HBLoaderService.hideLoader();
      }
    });
  }

  getLeaveRuleUtilisationPeriodList() {
    HBLoaderService.showLoader();
    this.leaveRuleService.getLeaveRuleUtilisationPeriodList(this.leaveSearchRequest).subscribe(response => {
      console.log(response);
      if (response.status === 200 && response.data && response.data.leaveRuleUtilisationPeriod) {
        this.lrUtilisationPeriod = response.data.leaveRuleUtilisationPeriod.list;
        if (this.lrUtilisationPeriod.length <= 0) {
          this.lrUtilisationPeriod.push(new LeaveRuleUtilisationPeriod());
        }
        this.previousLRUtilisationPeriod = JSON.parse(JSON.stringify(response.data.leaveRuleUtilisationPeriod.list));
        HBLoaderService.hideLoader();
      }
    });
  }

  getLeaveRuleCreditCarryList() {
    HBLoaderService.showLoader();
    this.leaveRuleService.getLeaveRuleCreditCarryList(this.leaveSearchRequest).subscribe(response => {
      console.log(response);
      if (response.status === 200 && response.data && response.data.leaveRuleCreditCarry) {
        this.lrCreditCarry = response.data.leaveRuleCreditCarry.list;
        if (this.lrCreditCarry.length <= 0) {
          this.lrCreditCarry.push(new LeaveRuleCreditCarry());
        }
        this.previousLRCreditCarry = JSON.parse(JSON.stringify(response.data.leaveRuleCreditCarry.list));
        HBLoaderService.hideLoader();
      }
    });
  }

  errorHandler(parentkey: string, childkey?: string, keyIndex?: number): HbErrorHandlerData {
    const hData = this.hbErrorHandler.getErrorHandlerData(parentkey, childkey, keyIndex);
    return hData;
  }

  validateLRCombinedRestriction(): void {
    if (this.lrCombinedRestriction) {
      this.lrCombinedRestriction.forEach((element, index) => {
        if (element.leaveTypeIds.length <= 1) {
          this.hbErrorHandler.addError('Select Atleast Two ', `lrCombinedRestriction[${index}].leaveTypeIds`)
        }

        element.lrCombinedRestrictionOptions.forEach((option, optionIndex) => {
          if (option && !option.disable) {
            this.hbErrorHandler.emptyCheck(option.quantity, `lrCombinedRestriction[${index}].lrCombinedRestrictionOptions`, 'quantity', optionIndex);
          }
        });
      });
    }
  }


  validateLRPermissible(): void {
    if (this.lrPermissible) {
      this.lrPermissible.forEach((element, index) => {
        if (element) {
          this.hbErrorHandler.emptyCheck(this.lrPermissible[index].leaveTypeId, 'lrPermissible[' + index + '].leaveTypeId')
          this.hbErrorHandler.emptyCheck(this.lrPermissible[index].maxNo, 'lrPermissible[' + index + '].maxNo')
        }
      });
    }
  }

  validateLRUtilisationPeriod(): void {
    if (this.lrUtilisationPeriod) {
      this.lrUtilisationPeriod.forEach((element, index) => {
        if (element) {
          this.hbErrorHandler.emptyCheck(this.lrUtilisationPeriod[index].leaveTypeId, 'lrUtilisationPeriod[' + index + '].leaveTypeId')
          this.hbErrorHandler.emptyCheck(this.lrUtilisationPeriod[index].noOfDays, 'lrUtilisationPeriod[' + index + '].noOfDays')
        }
      });
    }
  }

  validateLRCreditCarry(): void {
    if (this.lrCreditCarry) {
      this.lrCreditCarry.forEach((element, index) => {
        if (element) {
          this.hbErrorHandler.emptyCheck(this.lrCreditCarry[index].leaveTypeId, 'lrCreditCarry[' + index + '].leaveTypeId')
          this.hbErrorHandler.emptyCheck(this.lrCreditCarry[index].creditDays, 'lrCreditCarry[' + index + '].creditDays')
          this.hbErrorHandler.emptyCheck(this.lrCreditCarry[index].carryDays, 'lrCreditCarry[' + index + '].carryDays')
        }
      });
    }
  }
}
