import { Component, ElementRef, HostListener, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { HbDataTableColumnOption } from '@hostbooks/hb-lib/hb-list-table/src/hb-list-table-columns';
import { LeaveType } from '../modal/leave-type';
import { HBLoaderService } from 'src/app/shared/services/hb-loader.service';
import { LeaveTypeService } from '../service/leave-type.service';
import Swal from 'sweetalert2';
import { Router } from '@angular/router';
import { AppConst } from 'src/app/core/constants/app-const';
import { HbErrorHandler, HbErrorHandlerData } from 'src/app/shared/models/hb-error-handler';
import { LeaveSearchRequest } from '../modal/leave-search-request';

@Component({
  selector: 'app-leave-type',
  templateUrl: './leave-type.component.html',
  styleUrls: ['./leave-type.component.scss']
})
export class LeaveTypeComponent implements OnInit {

  @ViewChild('addLeave') addLeave: TemplateRef<any> | undefined;
  dialogRef: MatDialogRef<any> | undefined;
  columns: HbDataTableColumnOption[] = [];
  data: LeaveType[] = [];
  totalRecords: number;
  errorMessage: string;
  leaveType = new LeaveType();
  errorType: string = '';
  hbErrorHandler: HbErrorHandler = new HbErrorHandler();
  isAddLeaveType: boolean = true;
  isError: boolean = false;
  leaveSearchRequest = new LeaveSearchRequest();
  searchName: string;

  constructor(
    public dialog: MatDialog,
    private leaveTypeService: LeaveTypeService,
    private router: Router, private elementRef: ElementRef,) { }

  @HostListener('document:keydown.escape', ['$event']) onKeydownHandler(event: KeyboardEvent) {this.isAddLeaveType = true;}

  @HostListener('document:click', ['$event']) onClickHandler(event: MouseEvent) {
    if (!this.elementRef.nativeElement.contains(event.target)) {
      this.isAddLeaveType = true;
    }
  }

  ngOnInit(): void {
    this.getLeaveTypeList();
    this.resetPagination();
    this.columns = [
      {
        header: 'S. No',
        columnData: () => {
          return 's_no';
        },
        type: 'SR_NO'
      },
      // {
      //   header: 'check',
      //   columnData: () => {
      //     return 'cehck';
      //   },
      //   type: 'CHECK'
      // },
      {
        header: 'Leave Name',
        columnData: (leaveType: LeaveType) => {
          return leaveType.name;
        },
        type: 'TEXT'
      },
      {
        header: 'Short Code',
        columnData: (leaveType: LeaveType) => {
          return leaveType.code;
        },
        type: 'TEXT'
      },
      {
        header: 'Action',
        columnData: () => {
          return 'actions';
        },
        type: 'ACTION',
        actionOptions: ['EDIT', 'DELETE']
      },
    ];
  }

  onAction(_event: any) {
    this.isError = false;
    this.isAddLeaveType = false;
    if (_event.actionType == 'EDIT') {
      this.leaveType = _event.data;
      this.openAddLeavePopup(this.addLeave);
    } else {
      this.leaveType = _event.data;
      let idList: number[] = [];
      if (this.leaveType && this.leaveType.id) {
        idList.push(this.leaveType.id);
        this.deleteLeaveType(idList);
      }
    }
  }

  onChange(event) {
    this.leaveSearchRequest.page = event.page;
    this.leaveSearchRequest.limit = event.limit;
    this.getLeaveTypeList();
  }


  openAddLeavePopup(template: TemplateRef<any>): void {
    if (this.isAddLeaveType) {
      this.leaveType = new LeaveType();
    }
    this.dialogRef = this.dialog.open(template, {
      minHeight: '150px',
      width: '400px',
    });
  }

  closeDialog(data: any = null): void {
    if (this.dialogRef) {
      this.dialogRef.close(data);
      this.hbErrorHandler.clearErrors();
      this.isAddLeaveType = true;
      this.isError = false;
    }
  }

  addUpdateLeaveType() {
    this.validateData();
    this.isError = false;
    if (!this.hbErrorHandler.invalid) {
      if (!this.leaveType.id) {
        this.leaveType.status = AppConst.STATUS_CODE.ACTIVE;
        this.leaveType.type = AppConst.ATTENDANCE_LEAVE_TYPE.LEAVE_TYPE
        HBLoaderService.showLoader();
        this.leaveTypeService.addLeaveType(this.leaveType).subscribe(response => {
          console.log(response);
          if (response.status === 201 && response.data && response.data.leaveType) {
            this.confirmationPopup(response.message);
            HBLoaderService.hideLoader();
            this.getLeaveTypeList();
            this.closeDialog();
          } else if (response.status === 400 && response.fieldErrors.length != 0) {
            this.isError = true;
            this.errorMessage = response.fieldErrors[0].message;
            HBLoaderService.hideLoader();
          }
        });
      } else {
        HBLoaderService.showLoader();
        this.leaveTypeService.updateLeaveType(this.leaveType).subscribe(response => {
          console.log(response);
          if (response.status === 200 && response.data && response.data.leaveType) {
            this.confirmationPopup(response.message);
            this.closeDialog();
            HBLoaderService.hideLoader();
            this.getLeaveTypeList();
          }
        });
      }
    } else {
      window.scrollTo(0, 0);
      HBLoaderService.hideLoader();
    }
  }

  getLeaveTypeList() {
    HBLoaderService.showLoader();
    if (this.searchName !== null) {
        this.leaveSearchRequest.name = this.searchName;
    } 
    this.leaveSearchRequest.type = AppConst.ATTENDANCE_LEAVE_TYPE.LEAVE_TYPE   
    this.leaveTypeService.getLeaveTypeList(this.leaveSearchRequest).subscribe(response => {
      console.log(response);
      this.totalRecords = response.data.leaveType.totalRowCount;
      if (response.status === 200 && response.data && response.data.leaveType) {
        this.data = response.data.leaveType.list;
        HBLoaderService.hideLoader();
      }
    });
  }

  deleteLeaveType(leaveTypeIdList: number[]) {
    this.deleteConfirmationPopup().then(result => {
      if (result.value) {
        var idList: any = leaveTypeIdList.join(',');
        this.leaveTypeService.deleteLeaveType(idList).subscribe(response => {
          console.log(response);
          if (response.status === 200 && response.data) {
            this.confirmationPopup(response.message);
            HBLoaderService.hideLoader();
            this.getLeaveTypeList();
            this.closeDialog();
          }
        });
      }
    })
  }

  validateData() {
    this.hbErrorHandler.clearErrors();
    this.hbErrorHandler.emptyCheck(this.leaveType.name, 'name');
    this.hbErrorHandler.emptyCheck(this.leaveType.code, 'code');
  }

  confirmationPopup(message: any) {
    Swal.fire({
      title: 'Leave Type',
      html: message,
      icon: 'success',
      allowOutsideClick: false,
      allowEscapeKey: false,
    }).then(() => {
      this.router.navigateByUrl('/payroll/leave/leave-type');
    });
  }

  deleteConfirmationPopup() {
    return Swal.fire({
      title: 'Warning',
      text: 'Are you sure that you want to perform this action?',
      icon: 'question',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes',
      cancelButtonText: 'No',
      allowOutsideClick: false,
      allowEscapeKey: false,
    });
  }

  errorHandler(parentkey: string, childkey?: string, keyIndex?: number): HbErrorHandlerData {
    const hData = this.hbErrorHandler.getErrorHandlerData(parentkey, childkey, keyIndex);
    return hData;
  }

  resetPagination() {
    this.leaveSearchRequest.page = 1;
    this.leaveSearchRequest.limit = 10;
  }
}
