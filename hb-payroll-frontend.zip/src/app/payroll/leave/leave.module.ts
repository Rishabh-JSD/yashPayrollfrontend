import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../../shared/shared.module';

import { ApplyLeaveComponent } from './apply-leave/apply-leave.component';
import { LeaveTypeComponent } from './leave-type/leave-type.component';
import { LeaveBalanceComponent } from './leave-balance/leave-balance.component';
import { LeaveRulesComponent } from './leave-rules/leave-rules.component';
import { HolidayCalendarComponent } from './holiday-calendar/holiday-calendar.component';
import { LeaveCreditsComponent } from './leave-credits/leave-credits.component';
import { RunLeaveCreditModalComponent } from './run-leave-credit-modal/run-leave-credit-modal.component';
import { OpeningLeaveModalComponent } from './opening-leave-modal/opening-leave-modal.component';
import { LeaveAdjustmentModalComponent } from './leave-adjustment-modal/leave-adjustment-modal.component';
import { AppliedLeaveComponent } from './applied-leave/applied-leave.component';
import { LeaveHistoryModalComponent } from './leave-history-modal/leave-history-modal.component';

const routes: Routes = [

  { path: '', component: ApplyLeaveComponent },
  { path: 'apply-leave', component: ApplyLeaveComponent },
  { path: 'leave-type', component: LeaveTypeComponent },
  { path: 'leave-balance', component: LeaveBalanceComponent },
  { path: 'leave-rules', component: LeaveRulesComponent },
  { path: 'holiday-calendar', component: HolidayCalendarComponent },
  { path: 'leave-credits', component: LeaveCreditsComponent },
  { path: 'run-leave-credit', component: RunLeaveCreditModalComponent },
  { path: 'opening-leave', component: OpeningLeaveModalComponent },
  { path: 'leave-adjustment', component: LeaveAdjustmentModalComponent },
  { path: 'leave-history-modal', component: LeaveHistoryModalComponent },
  { path: 'applied-leave-listing', component: AppliedLeaveComponent },

  { path: '**', redirectTo: '', pathMatch: 'full' }
];

@NgModule({
  declarations: [
    ApplyLeaveComponent,
    LeaveTypeComponent,
    LeaveBalanceComponent,
    LeaveRulesComponent,
    HolidayCalendarComponent,
    LeaveCreditsComponent,
    RunLeaveCreditModalComponent,
    OpeningLeaveModalComponent,
    LeaveAdjustmentModalComponent,
    LeaveHistoryModalComponent,
    AppliedLeaveComponent
  ],
  imports: [
    CommonModule,
    SharedModule,
    RouterModule.forChild(routes)

  ]
})
export class LeaveModule {
}
