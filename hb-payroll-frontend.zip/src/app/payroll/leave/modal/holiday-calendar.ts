import { Audit } from "src/app/shared/models/audit";

export class HolidayCalendar extends Audit {
  public id: number;
  public masterId: number;
  public name: string;
  public date: Date;
  public valueChangeFlag: boolean;
}


export class HolidayType extends Audit {
  public id: number;
  public code: string;
  public name: string;
}
