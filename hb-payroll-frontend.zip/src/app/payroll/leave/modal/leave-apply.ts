export class LeaveApply {
    public id: number;
    public employeeId: number
    public startDate: Date;
    public endDate: Date;
    public startDateType: string;
    public endDateType: string
    public numberOfDays: number
    public leaveTypeId: number
    public employeeCcIds: string
    public reason: string
    public approverRemarks: string
    public status: string;
  }