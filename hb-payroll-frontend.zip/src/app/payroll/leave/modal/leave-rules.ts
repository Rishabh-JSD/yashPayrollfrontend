import { Audit } from "src/app/shared/models/audit";

export class LRCombinedRestriction extends Audit {
  public id: number;
  public leaveTypeIds = new Array<string>();
  public status: string;
  public lrCombinedRestrictionOptions = new Array<LRCombinedRestrictionOptions>();
  public valueChangeFlag: boolean;
}


export class LRCombinedRestrictionOptions {
  public ids: number; // this for only frontend
  public combinedRestrictionId: number;
  public leaveTypeId: number;
  public quantity: number;
  public disable: boolean = false;
  public id: number;
}

export class LeaveRulePermissible extends Audit {
  public id: number;
  public leaveTypeId: number;
  public maxNo: number;
  public valueChangeFlag: boolean;
}

export class LeaveRuleSandwich extends Audit{
    public id: number;
    public weekOffFlag: boolean;
    public leaveTypeIds = new Array<number>();
    public dayBeforeFlag: boolean;
    public dayAfterFlag: boolean;
    public lopFlag: boolean;
}

export class LeaveRuleUtilisationPeriod extends Audit{
  public id: number;
  public leaveTypeId: number;
  public noOfDays: number;
  public valueChangeFlag: boolean;
}

export class LeaveRuleCreditCarry extends Audit{
  public id: number;
  public leaveTypeId: number;
  public creditDays: number;
  public carryDays: number;
  public valueChangeFlag: boolean;
}
