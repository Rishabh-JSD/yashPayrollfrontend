import { SearchRequest } from "src/app/shared/models/search-request";

export class LeaveSearchRequest extends SearchRequest{
    name: string;
    type: string
    searchFor: string;
    startDate: string;
    endDate: string;
  }
