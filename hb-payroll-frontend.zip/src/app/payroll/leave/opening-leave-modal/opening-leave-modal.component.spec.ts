import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OpeningLeaveModalComponent } from './opening-leave-modal.component';

describe('OpeningLeaveModalComponent', () => {
  let component: OpeningLeaveModalComponent;
  let fixture: ComponentFixture<OpeningLeaveModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [OpeningLeaveModalComponent]
    })
      .compileComponents();

    fixture = TestBed.createComponent(OpeningLeaveModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
