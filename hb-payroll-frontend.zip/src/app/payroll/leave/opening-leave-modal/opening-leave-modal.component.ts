import { Component, Input } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-opening-leave-modal',
  templateUrl: './opening-leave-modal.component.html',
  styleUrls: ['./opening-leave-modal.component.scss']
})
export class OpeningLeaveModalComponent {

  @Input() visible = false;
  dialogRef: MatDialogRef<any>;

  closeDialog(): void {
  }
}
