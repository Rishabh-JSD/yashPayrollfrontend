import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RunLeaveCreditModalComponent } from './run-leave-credit-modal.component';

describe('RunLeaveCreditModalComponent', () => {
  let component: RunLeaveCreditModalComponent;
  let fixture: ComponentFixture<RunLeaveCreditModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [RunLeaveCreditModalComponent]
    })
      .compileComponents();

    fixture = TestBed.createComponent(RunLeaveCreditModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
