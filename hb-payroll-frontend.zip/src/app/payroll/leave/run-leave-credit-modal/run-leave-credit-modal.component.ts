import { Component, Input } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';

@Component({
  selector: 'app-run-leave-credit-modal',
  templateUrl: './run-leave-credit-modal.component.html',
  styleUrls: ['./run-leave-credit-modal.component.scss']
})
export class RunLeaveCreditModalComponent {
  @Input() visible = false;

  constructor(private dialog: MatDialog,) {}

  closeDialog(): void {
  }
}
