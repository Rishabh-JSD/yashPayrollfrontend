import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HBHttpService } from 'src/app/core/services/hb-http-service.service';

@Injectable({
  providedIn: 'root'
})
export class HolidayService {

  constructor(private hbHttpClient: HBHttpService) { }

  addHolidayType(data: any): Observable<any> {
    return this.hbHttpClient.getResponse('holiday-type/add', this.hbHttpClient.POST, data);
  }

  updateHolidayType(data: any): Observable<any> {
    return this.hbHttpClient.getResponse('holiday-type/update', this.hbHttpClient.POST, data);
  }

  getHolidayTypeList(data: any): Observable<any> {
    return this.hbHttpClient.getResponse('holiday-type/list', this.hbHttpClient.GET_VIA_POST, data);
  }

  getHolidayTypeById(id: any): Observable<any> {
    return this.hbHttpClient.getResponse(`holiday-type/${ id }`, this.hbHttpClient.GET);
  }

  deleteHolidayType(id: number): Observable<any> {
    return this.hbHttpClient.getResponse('holiday-type/delete?holidayTypeMasterId=' + id, this.hbHttpClient.DELETE);
  }


  //for calendar

  addHolidayCalendar(data: any): Observable<any> {
    return this.hbHttpClient.getResponse('holiday-calendar/add', this.hbHttpClient.POST, data);
  }

  updateHolidayCalendar(data: any): Observable<any> {
    return this.hbHttpClient.getResponse('holiday-calendar/update', this.hbHttpClient.POST, data);
  }

  getHolidayCalendarList(data: any): Observable<any> {
    return this.hbHttpClient.getResponse('holiday-calendar/list', this.hbHttpClient.GET_VIA_POST, data);
  }

  deleteHolidayCalendar(id: number): Observable<any> {
    return this.hbHttpClient.getResponse('holiday-calendar/delete?holidayCalendarId=' + id, this.hbHttpClient.DELETE);
  }
}
