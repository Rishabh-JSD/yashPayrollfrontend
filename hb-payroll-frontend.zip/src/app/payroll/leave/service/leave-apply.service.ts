import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HBHttpService } from 'src/app/core/services/hb-http-service.service';

@Injectable({
  providedIn: 'root'
})
export class LeaveApplyService {

  constructor(private hbHttpClient: HBHttpService) { }

  
  addLeaveApply(data: any): Observable<any> {
    return this.hbHttpClient.getResponse('leave-apply/add', this.hbHttpClient.POST, data);
  }

  updateLeaveApply(data: any): Observable<any> {
    return this.hbHttpClient.getResponse('leave-apply/update', this.hbHttpClient.PUT, data);
  }

  getLeaveApplyList(data: any): Observable<any> {
    return this.hbHttpClient.getResponse('leave-apply/list', this.hbHttpClient.GET_VIA_POST, data);
  }

  getLeaveApplyById(id: any): Observable<any> {
    return this.hbHttpClient.getResponse(`leave-apply/${ id }`, this.hbHttpClient.GET);
  }

  deleteLeaveApply(leaveApplyIdList: number[]): Observable<any> {
    return this.hbHttpClient.getResponse(`leave-apply/delete?leaveApplyIdList=${ leaveApplyIdList }`, this.hbHttpClient.DELETE);
  }
}
