import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HBHttpService } from 'src/app/core/services/hb-http-service.service';

@Injectable({
  providedIn: 'root'
})
export class LeaveRuleService {

  constructor(private hbHttpClient: HBHttpService) { }

  addLeaveRuleCombinedRestriction(data: any): Observable<any> {
    return this.hbHttpClient.getResponse('leave-rule-combined-restriction/add', this.hbHttpClient.POST, data);
  }

  updateLeaveRuleCombinedRestriction(data: any): Observable<any> {
    return this.hbHttpClient.getResponse('leave-rule-combined-restriction/update', this.hbHttpClient.PUT, data);
  }

  getLeaveRuleCombinedRestrictionList(data: any): Observable<any> {
    return this.hbHttpClient.getResponse('leave-rule-combined-restriction/list', this.hbHttpClient.GET_VIA_POST, data);
  }

  deleteLeaveRuleCombinedRestriction(id: number): Observable<any> {
    return this.hbHttpClient.getResponse('leave-rule-combined-restriction/delete?lrCombinedRestrictionId=' + id, this.hbHttpClient.DELETE);
  }

  addLeaveRulePermissible(data: any): Observable<any> {
    return this.hbHttpClient.getResponse('leave-rule-permissible/add', this.hbHttpClient.POST, data);
  }

  updateLeaveRulePermissible(data: any): Observable<any> {
    return this.hbHttpClient.getResponse('leave-rule-permissible/update', this.hbHttpClient.PUT, data);
  }

  getLeaveRulePermissibleList(data: any): Observable<any> {
    return this.hbHttpClient.getResponse('leave-rule-permissible/list', this.hbHttpClient.GET_VIA_POST, data);
  }

  deleteLeaveRulePermissible(id: number): Observable<any> {
    return this.hbHttpClient.getResponse('leave-rule-permissible/delete?leaveRulePermissibleId=' + id, this.hbHttpClient.DELETE);
  }

  addLeaveRuleSandwich(data: any): Observable<any> {
    return this.hbHttpClient.getResponse('leave-rule-sandwich/add', this.hbHttpClient.POST, data);
  }

  updateLeaveRuleSandwich(data: any): Observable<any> {
    return this.hbHttpClient.getResponse('leave-rule-sandwich/update', this.hbHttpClient.PUT, data);
  }

  getLeaveRuleSandwichList(data: any): Observable<any> {
    return this.hbHttpClient.getResponse('leave-rule-sandwich/list', this.hbHttpClient.GET_VIA_POST, data);
  }

  getLeaveRuleSandwich(id: any): Observable<any> {
    return this.hbHttpClient.getResponse(`leave-rule-sandwich/${ id }`, this.hbHttpClient.GET);
  }

  deleteLeaveRuleSandwich(id: number): Observable<any> {
    return this.hbHttpClient.getResponse('leave-rule-sandwich/delete?leaveRuleSandwichId=' + id, this.hbHttpClient.DELETE);
  }

  addLeaveRuleUtilisationPeriod(data: any): Observable<any> {
    return this.hbHttpClient.getResponse('leave-rule-utilisation-period/add', this.hbHttpClient.POST, data);
  }

  updateLeaveRuleUtilisationPeriod(data: any): Observable<any> {
    return this.hbHttpClient.getResponse('leave-rule-utilisation-period/update', this.hbHttpClient.PUT, data);
  }

  getLeaveRuleUtilisationPeriodList(data: any): Observable<any> {
    return this.hbHttpClient.getResponse('leave-rule-utilisation-period/list', this.hbHttpClient.GET_VIA_POST, data);
  }

  deleteLeaveRuleUtilisationPeriod(id: number): Observable<any> {
    return this.hbHttpClient.getResponse('leave-rule-utilisation-period/delete?leaveRuleUtilisationPeriodId=' + id, this.hbHttpClient.DELETE);
  }

  addLeaveRuleCreditCarry(data: any): Observable<any> {
    return this.hbHttpClient.getResponse('leave-rule-credit-carry/add', this.hbHttpClient.POST, data);
  }

  updateLeaveRuleCreditCarry(data: any): Observable<any> {
    return this.hbHttpClient.getResponse('leave-rule-credit-carry/update', this.hbHttpClient.PUT, data);
  }

  getLeaveRuleCreditCarryList(data: any): Observable<any> {
    return this.hbHttpClient.getResponse('leave-rule-credit-carry/list', this.hbHttpClient.GET_VIA_POST, data);
  }

  deleteLeaveRuleCreditCarry(id: number): Observable<any> {
    return this.hbHttpClient.getResponse('leave-rule-credit-carry/delete?leaveRuleCreditCarryId=' + id, this.hbHttpClient.DELETE);
  }
}
