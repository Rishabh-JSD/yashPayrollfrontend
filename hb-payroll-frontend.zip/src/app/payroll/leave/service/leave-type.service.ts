import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HBHttpService } from 'src/app/core/services/hb-http-service.service';

@Injectable({
  providedIn: 'root'
})
export class LeaveTypeService {

  constructor(private hbHttpClient: HBHttpService) { }

  addLeaveType(data: any): Observable<any> {
    return this.hbHttpClient.getResponse('leave-type/add', this.hbHttpClient.POST, data);
  }

  addAttendanceTypes(data: any): Observable<any> {
    return this.hbHttpClient.getResponse('leave-type/add-attendance-types', this.hbHttpClient.POST, data);
  }

  updateAttendanceTypes(data: any): Observable<any> {
    return this.hbHttpClient.getResponse('leave-type/update-attendance-types', this.hbHttpClient.PUT, data);
  }

  updateLeaveType(data: any): Observable<any> {
    return this.hbHttpClient.getResponse('leave-type/update', this.hbHttpClient.PUT, data);
  }

  getLeaveTypeList(data: any): Observable<any> {
    return this.hbHttpClient.getResponse('leave-type/list', this.hbHttpClient.GET_VIA_POST, data);
  }

  deleteLeaveType(leaveTypeIdList: number[]): Observable<any> {
    return this.hbHttpClient.getResponse(`leave-type/delete?leaveTypeIdList=${ leaveTypeIdList }`, this.hbHttpClient.DELETE);
  }
}
