import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AllowanceDeductionRuleComponent } from './allowance-deduction-rule.component';

describe('AllowanceDeductionRuleComponent', () => {
  let component: AllowanceDeductionRuleComponent;
  let fixture: ComponentFixture<AllowanceDeductionRuleComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [AllowanceDeductionRuleComponent]
    })
      .compileComponents();

    fixture = TestBed.createComponent(AllowanceDeductionRuleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
