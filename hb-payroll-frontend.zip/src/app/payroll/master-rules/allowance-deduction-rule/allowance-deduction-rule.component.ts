import { Component } from '@angular/core';
import { Location } from '@angular/common';
import { HbDataTableColumnOption } from '@hostbooks/hb-lib/hb-list-table/src/hb-list-table-columns';
import { RuleMaster } from '../common/models/rule-master';
import { RuleMasterOption } from '../common/models/rule-master-options';
import { RuleMastersService } from '../common/services/rule-master.service';
import { PopupService } from 'src/app/shared/services/popup.service';
import { MasterSearchRequest } from '../master-search-request';
import { ActivatedRoute, Router } from '@angular/router';


@Component({
  selector: 'app-allowance-deduction-rule',
  templateUrl: './allowance-deduction-rule.component.html',
  styleUrls: ['./allowance-deduction-rule.component.scss']
})
export class AllowanceDeductionRuleComponent {

  columns: HbDataTableColumnOption[] = [];
  tableData: any[];
  data: any[] = [];
  total: number;
  dataSource = [];
  allowanceModal = false;
  deductionModal = false;
  allowanceRule = new RuleMaster();
  allowanceList = new Array<RuleMaster>();
  deductionRuleList = new Array<RuleMaster>();
  isEdit = false;
  deductionRule = new RuleMaster();
  masterSearchRequest = new MasterSearchRequest()
  index: number;
  allowanceId: number;
  constructor(private _location: Location, private ruleMasterService: RuleMastersService, private route: Router, private activatedRoute: ActivatedRoute) {

  }


  back() {
    this._location.back();
  }

  allowanceModalOpen() {
    this.allowanceRule = new RuleMaster();
    this.isEdit = false;
    this.allowanceRule.ruleMasterOptions.push(new RuleMasterOption());
    this.allowanceModal = !this.allowanceModal;
  }

  deductionModalOpen() {
    this.deductionRule = new RuleMaster();
    this.isEdit = false;
    this.deductionRule.ruleMasterOptions.push(new RuleMasterOption());
    this.deductionModal = !this.deductionModal;
  }

  ngOnInit(): void {
    this.activatedRoute.params.subscribe(params => {
      if (+params['id']) {
        this.allowanceId = +params['id'];
        console.log(params, 'ppp');

      }
    })

    this.columns = [
      {
        header: 'Rule Name',
        columnData: (allowance: RuleMaster) => {
          return allowance.ruleName;
        },
        type: 'TEXT'
      },
      {
        header: 'Basic Salary (Up To)',
        columnData: (allowance: RuleMaster) => {
          return allowance.basicSalary;
        },
        type: 'TEXT'
      },
      {
        header: 'Created on',
        columnData: (allowance: RuleMaster) => {
          return allowance.createdAt;
        },
        type: 'TEXT'
      },
      {
        header: 'Action',
        actionOptions: ['EDIT', 'DELETE'],
        type: 'ACTION',
      },
    ];
    this.masterSearchRequest.type = 'ALLOWANCE';
    this.getList();
  }

  addAllowance() {
    this.allowanceRule.ruleMasterOptions.push(new RuleMasterOption());
  }

  addDeductionOption() {
    this.deductionRule.ruleMasterOptions.push(new RuleMasterOption());
  }

  saveAllowance() {
    this.allowanceRule.type = 'ALLOWANCE';
    if (!this.allowanceRule.id) {
      this.ruleMasterService.addRuleMasters(this.allowanceRule).subscribe(response => {
        if (response && response.status == 200 && response.data.ruleMaster) {
          PopupService.successAlert("Allowance Rule", "Saved Sucessfully").then(result => {
            if (result) {
              this.allowanceModal = false;
              this.masterSearchRequest.type = 'ALLOWANCE';
              this.getList();
            }
          })
        } else {
          PopupService.failedAlert("Allowance Rule", "Falied").then(result => {
            if (result) {
              this.allowanceModal = false;
              this.masterSearchRequest.type = 'ALLOWANCE';
              this.getList();
            }
          })
        }
      })
    } else {
      this.ruleMasterService.updateRuleMasters(this.allowanceRule).subscribe(response => {
        if (response && response.status == 200 && response.data.ruleMaster) {
          PopupService.successAlert("Allowance Rule", "Updated Sucessfully").then(result => {
            if (result) {
              this.allowanceModal = false;
              this.masterSearchRequest.type = 'DEDUCTION';
              this.getList();
            }
          })
        } else {
          PopupService.failedAlert("Allowance Rule", "Falied").then(result => {
            if (result) {
              this.allowanceModal = false;
              this.masterSearchRequest.type = 'ALLOWANCE';
              this.getList();
            }
          })
        }
      })
    }
  }

  saveDeductionRule() {
    if (!this.deductionRule.id) {
      this.deductionRule.type = 'DEDUCTION';
      this.ruleMasterService.addRuleMasters(this.deductionRule).subscribe(response => {
        if (response && response.status == 200 && response.data.ruleMaster) {
          PopupService.successAlert("Deduction Rule", "Saved Sucessfully").then(result => {
            if (result) {
              this.deductionModal = false;
              this.masterSearchRequest.type = 'DEDUCTION';
              this.getList();
            }
          })
        } else {
          PopupService.failedAlert("Deduction Rule", "Falied").then(result => {
            if (result) {
              this.deductionModal = false;
              this.masterSearchRequest.type = 'DEDUCTION';
              this.getList();
            }
          })
        }
      })
    } else {
      this.ruleMasterService.updateRuleMasters(this.deductionRule).subscribe(response => {
        if (response && response.status == 200 && response.data.ruleMaster) {
          PopupService.successAlert("Deduction Rule", "Updated Sucessfully").then(result => {
            if (result) {
              this.deductionModal = false;
              this.masterSearchRequest.type = 'DEDUCTION';
              this.getList();
            }
          })
        } else {
          PopupService.failedAlert("Deduction Rule", "Falied").then(result => {
            if (result) {
              this.deductionModal = false;
              this.masterSearchRequest.type = 'DEDUCTION';
              this.getList();
            }
          })
        }
      })
    }
  }

  getList() {
    this.ruleMasterService.getListRuleMasters(this.masterSearchRequest).subscribe(response => {
      if (response && response.status == 200 && response.data.ruleMaster.list) {
        if (this.masterSearchRequest.type == 'ALLOWANCE') {
          this.allowanceList = response.data.ruleMaster.list;
          this.total = response.data.ruleMaster.totalRowCount;
        } else {
          this.deductionRuleList = response.data.ruleMaster.list;
          this.total = response.data.ruleMaster.totalRowCount;
        }
      }
    })
  }

  handleChange(event) {
    this.masterSearchRequest = new MasterSearchRequest();
    if (event && event.index == 0) {
      this.masterSearchRequest.type = 'ALLOWANCE';
      this.getList()
    } else {
      this.masterSearchRequest.type = 'DEDUCTION';
      this.getList();
    }
  }

  deleteAllowanceDeduction(id: number, type: string) {
    this.ruleMasterService.deleteRuleMasters(id).subscribe(response => {
      if (response && response.status == 200 && response.data.ruleMaster) {
        PopupService.successAlert(type, 'Deleted Sucessfully');
      }
    })
  }

  getAllowanceById(id: number) {
    this.masterSearchRequest = new MasterSearchRequest();
    this.masterSearchRequest.type = 'ALLOWANCE';
    this.ruleMasterService.getRuleMaster(id).subscribe(response => {
      if (response && response.status == 200 && response.data.ruleMaster) {
        this.allowanceRule = response.data.ruleMaster;
        this.isEdit = true;
        if (!this.allowanceRule.ruleMasterOptions) {
          this.allowanceRule.ruleMasterOptions = new Array<RuleMasterOption>();
        }
        this.allowanceModal = true;
      }
    })
  }

  getDeductionById(id: number) {
    this.masterSearchRequest = new MasterSearchRequest();
    this.masterSearchRequest.type = 'DEDUCTION';
    this.ruleMasterService.getRuleMaster(id).subscribe(response => {
      if (response && response.status == 200 && response.data.ruleMaster) {
        this.deductionRule = response.data.ruleMaster;
        this.isEdit = true;
        if (!this.deductionRule.ruleMasterOptions) {
          this.deductionRule.ruleMasterOptions = new Array<RuleMasterOption>();
        }
        this.deductionModal = true;
      }
    })
  }

  onAllowance(event: any) {
    console.log(event);
    if (event.actionType == 'DELETE') {
      this.deleteAllowanceDeduction(event.data.id, 'ALLOWANCE');
    } else if (event.actionType == 'EDIT') {
      this.getAllowanceById(event.data.id,);
    }
  }

  onDeduction(event: any) {
    console.log(event);
    if (event.actionType == 'DELETE') {
      this.deleteAllowanceDeduction(event.data.id, 'DEDUCTION');
    } else if (event.actionType == 'EDIT') {
      this.getDeductionById(event.data.id);
    }
  }

  calculateAllowance(index) {
    this.allowanceRule.ruleMasterOptions[index].amount = (this.allowanceRule.ruleMasterOptions[index].percentageOfSalary / 100) * this.allowanceRule.basicSalary
  }

  calculateDeduction(index) {
    this.deductionRule.ruleMasterOptions[index].amount = (this.deductionRule.ruleMasterOptions[index].percentageOfSalary / 100) * this.deductionRule.basicSalary
  }

  onCancelAllownce() {
    this.allowanceModal = false;
  }
  onCancelDeduction() {
    this.deductionModal = false;
  }


}
