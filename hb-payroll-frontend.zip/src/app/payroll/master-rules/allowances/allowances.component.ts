import { AfterViewInit, Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import Swal from 'sweetalert2';
import { HbDataTableColumnOption } from '@hostbooks/hb-lib/hb-list-table/src/hb-list-table-columns';
import { HbDateFormatPipe } from '../../../shared/pipes/hb-date-format.pipe';
import { HBLoaderService } from '../../../shared/services/hb-loader.service';
import { MasterOption } from 'src/app/payroll/master-rules/common/models/masters-options';
import { MasterOptionService } from 'src/app/payroll/master-rules/common/services/master-option.service';
import { AppConst } from 'src/app/core/constants/app-const';
import { MasterSearchRequest } from '../master-search-request';
import { HbErrorHandler, HbErrorHandlerData } from 'src/app/shared/models/hb-error-handler';


@Component({
  selector: 'app-allowances',
  templateUrl: './allowances.component.html',
  styleUrls: ['./allowances.component.scss'],
  providers: [HbDateFormatPipe]
})
export class AllowancesComponent implements OnInit, AfterViewInit {

  columns: HbDataTableColumnOption[] = [];
  data: MasterOption[] = [];
  total: number;
  masterSearchRequest = new MasterSearchRequest();
  searchName: string;
  importPayrollVisible = false;
  allowanceModal = false;
  hbErrorHandler = new HbErrorHandler();
  allowance = new MasterOption();

  constructor(private _location: Location, private datePipe: HbDateFormatPipe,
              private masterOptionService: MasterOptionService) {}

  ngOnInit(): void {
    this.allowanceColumns();
    this.masterSearchRequest.page = 1;
    this.masterSearchRequest.limit = 10;
    this.getAllowanceList();

  }

  allowanceColumns() {
    this.columns = [
      {
        header: 'S. No.',
        columnData: (inv: MasterOption) => {
        },
        type: 'SR_NO'
      },
      {
        header: 'Allowance Name',
        columnData: (inv: MasterOption) => {
          return inv.name;
        },
        type: 'TEXT'
      },
      {
        header: 'Created At',
        columnData: (inv: MasterOption) => {
          return this.datePipe.transform(inv.createdAt);
        },
        type: 'DATE'
      },
      {
        header: 'Created By',
        columnData: (inv: MasterOption) => {
          return inv.createdByName;
        },
        type: 'TEXT'
      },
      {
        header: 'Updated At',
        columnData: (inv: MasterOption) => {
          return this.datePipe.transform(inv.updatedAt);
        },
        type: 'DATE'
      },
      {
        header: 'Updated By',
        columnData: (inv: MasterOption) => {
          return inv.updatedByName;
        },
        type: 'TEXT'
      },
      {
        header: 'Actions',
        columnData: (inv: MasterOption) => {
        },
        type: 'ACTION',
        actionOptions: ['EDIT', 'DELETE']
      },
    ];
  }

  back() {
    this._location.back();
  }

  ngAfterViewInit() {

  }


  deleteAllowance(id: number) {
    this.deleteConfirmationPopup().then(result => {
      if (result.value) {
        HBLoaderService.showLoader();
        this.masterOptionService.deleteMasterOption(id).subscribe(response => {
          this.deletedConfirmationPopup(response.message, 'Allowance');
          HBLoaderService.hideLoader();
        });
      }
    });
  }

  allowanceModalOpen(id: any = null) {
    this.hbErrorHandler.clearErrors()
    if (id) {
      this.getAllowance(id);
      this.allowanceModal = true;
    } else {
      this.allowance = new MasterOption();
      this.allowanceModal = true;
    }
  }

  getAllowance(id: any) {
    HBLoaderService.showLoader();
    this.masterOptionService.getMasterOptionById(id).subscribe(response => {
      if (response.status === 200 && response.data && response.data.masterOption) {
        this.allowance = response.data.masterOption;
      }
      HBLoaderService.hideLoader();
    },
    () => {
      HBLoaderService.hideLoader();
    }
    );
  }

  deleteConfirmationPopup() {
    return Swal.fire({
      title: 'Warning',
      text: 'Are you sure that you want to perform this action?',
      icon: 'question',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes',
      cancelButtonText: 'No',
      allowOutsideClick: false,
      allowEscapeKey: false,
    });
  }

  deletedConfirmationPopup(message, title) {
    Swal.fire({
      titleText: title,
      text: message,
      icon: 'success',
      allowOutsideClick: false,
      allowEscapeKey: false,
    }).then(result => {
      if (result.value) {
        this.getAllowanceList();
      }
    });
  }

  onAction(_event: any) {
    if (_event && _event.actionType && _event.data) {
      if (_event.actionType === 'DELETE') {
        this.deleteAllowance(_event.data.id);
      }
      if (_event.actionType === 'EDIT') {
        this.allowanceModalOpen(_event.data.id);
      }
    }
  }

  onChange(_event: any) {
    this.masterSearchRequest.page = _event.page;
    this.masterSearchRequest.limit = _event.limit;
    this.getAllowanceList();
  }


  importPayrollSheetModalOpen() {
    this.importPayrollVisible = true;
  }

  getAllowanceList() {
    HBLoaderService.showLoader();
    this.masterSearchRequest.searchFor = this.searchName;
    this.masterSearchRequest.catCode = AppConst.MASTER_CODE.ALLOWANCE;
    this.masterOptionService.getListMasterOption(this.masterSearchRequest).subscribe(response => {
      console.log(response);
      if (response.status === 200 && response.data && response.data.masterOption) {
        this.data = response.data.masterOption.list;
        this.total = response.data.masterOption.totalRowCount;
        HBLoaderService.hideLoader();
      } else {
        this.data = new Array<MasterOption>();
        this.total = response.data.masterOption.totalRowCount;
        HBLoaderService.hideLoader();
      }
    });

  }

  validate(): void {
    this.hbErrorHandler.emptyCheck(this.allowance.name, 'name');
  }

  close() {
    this.allowanceModal = false;
  }

  addUpdateAllowance() {
    this.hbErrorHandler.clearErrors()
    this.validate();
    if (!this.hbErrorHandler.invalid) {
      if (!this.allowance.id) {
        HBLoaderService.showLoader();
        this.allowance.catCode = AppConst.MASTER_CODE.ALLOWANCE;
        this.masterOptionService.addMasterOption(this.allowance).subscribe(response => {
          console.log(response);
          if (response.status === 200 && response.data && response.data.masterOption) {
            this.confirmationPopup(response.message);
            HBLoaderService.hideLoader();
          }
        });
      } else {
        HBLoaderService.showLoader();
        this.masterOptionService.updateMasterOption(this.allowance).subscribe(response => {
          console.log(response);
          if (response.status === 200 && response.data && response.data.masterOption) {
            this.confirmationPopup(response.message);
            HBLoaderService.hideLoader();
          }
        });
      }
    }
  }

  errorHandler(parentkey: string, childkey?: string, keyIndex?: number): HbErrorHandlerData {
    const hData = this.hbErrorHandler.getErrorHandlerData(parentkey, childkey, keyIndex);
    return hData;
  }

  confirmationPopup(message: any) {
    Swal.fire({
      title: 'Allowance',
      html: message,
      icon: 'success',
      allowOutsideClick: false,
      allowEscapeKey: false,
    }).then(() => {
      this.getAllowanceList()
      this.close();
    });
  }
}
