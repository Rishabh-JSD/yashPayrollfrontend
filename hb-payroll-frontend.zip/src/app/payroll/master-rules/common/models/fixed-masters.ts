export class FixedMasters {
  public id: number;
  public name: string;
  public code: string;
  public type: string;
  public description: string;
}
