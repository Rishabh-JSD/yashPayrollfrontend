import { Audit } from 'src/app/shared/models/audit';

export class MasterOption extends Audit {
  public id: number;
  public name: string;
  public catCode: string;
  public reportingToId: number;
  public description: string;
  public parentId: number;
  public parentCatOptionId: number;
  public startTime: string;
  public endTime: string;
  public workingHours: number;
  public preDefinedFlag: boolean;
  public level: number;
  public levelRefId: number;
  public status: string;
  public reportingToName: string;
  public shiftTypeName: string;
  public coaId:number;
  // public startDate: string;
  // public endDate: string;
  public shiftStartTolerance: string;
  public shiftEndTolerance: string;
  public fixedShiftFlag: boolean;
  public days: number;
  public maxLevel: number;
  public documentCategoryName: String;
  public designationLevel: number;
  public code: string;
  public startDay: number;
  public endDay: number;
}
