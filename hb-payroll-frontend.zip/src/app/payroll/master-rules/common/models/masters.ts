
import { Audit } from 'src/app/shared/models/audit';
import { MasterOption } from './masters-options';

export class Masters extends Audit {
  public id: number;
  public code: string;
  public name: string;
  public status: boolean;
  public payrollMastersOptions: MasterOption;
}
