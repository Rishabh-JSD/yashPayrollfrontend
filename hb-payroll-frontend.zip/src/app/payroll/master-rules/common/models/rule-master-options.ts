export class RuleMasterOption {
    allowanceId: number;
    percentageOfSalary: number = 0;;
    amount: number = 0;
}