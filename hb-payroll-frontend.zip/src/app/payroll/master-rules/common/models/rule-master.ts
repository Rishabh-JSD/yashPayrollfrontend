import { RuleMasterOption } from "./rule-master-options";

export class RuleMaster{
    basicSalary:number;
    id:number;
    ruleName:string;
    type:string
    createdAt:Date;
    ruleMasterOptions = new Array<RuleMasterOption>();
}