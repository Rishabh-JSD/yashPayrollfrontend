import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HBHttpService } from 'src/app/core/services/hb-http-service.service';

@Injectable({
  providedIn: 'root',
})
export class FixedMastersService {
  constructor(private hbHttpClient: HBHttpService) {}

  addFixedMaster(data: any): Observable<any> {
    return this.hbHttpClient.getResponse('fixed-masters/add', this.hbHttpClient.POST, data);
  }

  updateFixedMaster(data: any): Observable<any> {
    return this.hbHttpClient.getResponse('fixed-masters/update', this.hbHttpClient.PUT, data);
  }

  getListFixedMaster(data: any): Observable<any> {
    return this.hbHttpClient.getResponse('fixed-masters/list', this.hbHttpClient.POST, data);
  }

  getFixedMaster(id: any): Observable<any> {
    return this.hbHttpClient.getResponse(`fixed-masters/${ id }`, this.hbHttpClient.GET);
  }

  getFixedMasterListByType(type: string): Observable<any> {
    return this.hbHttpClient.getResponse(`fixed-masters/type/${ type }`, this.hbHttpClient.GET);
  }

  deleteFixedMaster(id: any): Observable<any> {
    return this.hbHttpClient.getResponse('fixed-masters/delete?masterId=' + id, this.hbHttpClient.DELETE);
  }
}
