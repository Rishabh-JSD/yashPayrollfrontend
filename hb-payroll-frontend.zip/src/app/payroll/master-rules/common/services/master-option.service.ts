import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HBHttpService } from 'src/app/core/services/hb-http-service.service';

@Injectable({
  providedIn: 'root',
})
export class MasterOptionService {
  constructor(private hbHttpClient: HBHttpService) {}

  addMasterOption(data: any): Observable<any> {
    return this.hbHttpClient.getResponse('master-option/add', this.hbHttpClient.POST, data);
  }

  updateMasterOption(data: any): Observable<any> {
    return this.hbHttpClient.getResponse('master-option/update', this.hbHttpClient.POST, data);
  }

  getListMasterOption(data: any): Observable<any> {
    return this.hbHttpClient.getResponse(`master-option/list`, this.hbHttpClient.POST, data);
  }

  getMasterOptionById(id: any): Observable<any> {
    return this.hbHttpClient.getResponse(`master-option/${ id }`, this.hbHttpClient.GET);
  }

  deleteMasterOption(id: any): Observable<any> {
    return this.hbHttpClient.getResponse('master-option/delete?masterOptionId=' + id, this.hbHttpClient.DELETE);
  }

  getListMasterOptionWithCode(data: any): Observable<any> {
    return this.hbHttpClient.getResponse(`master-option/list`, this.hbHttpClient.POST, data);
  }
}
