import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HBHttpService } from 'src/app/core/services/hb-http-service.service';

@Injectable({
  providedIn: 'root',
})
export class PayrollMastersService {
  constructor(private hbHttpClient: HBHttpService) {}

  addPayrollMasters(data: any): Observable<any> {
    return this.hbHttpClient.getResponse('master/add', this.hbHttpClient.POST, data);
  }

  updatePayrollMasters(data: any): Observable<any> {
    return this.hbHttpClient.getResponse('master/update', this.hbHttpClient.POST, data);
  }

  getListPayrollMasters(data: any): Observable<any> {
    return this.hbHttpClient.getResponse('master/list', this.hbHttpClient.POST, data);
  }

  getPayrollMasters(id: any): Observable<any> {
    return this.hbHttpClient.getResponse(`master/${ id }`, this.hbHttpClient.GET);
  }

  deletePayrollMasters(id: any): Observable<any> {
    return this.hbHttpClient.getResponse('master/delete?masterOptionId=' + id, this.hbHttpClient.DELETE);
  }
}
