import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HBHttpService } from 'src/app/core/services/hb-http-service.service';

@Injectable({
  providedIn: 'root',
})
export class RuleMastersService {
  constructor(private hbHttpClient: HBHttpService) {}

  addRuleMasters(data: any): Observable<any> {
    return this.hbHttpClient.getResponse('rule-master/add', this.hbHttpClient.POST, data);
  }

  updateRuleMasters(data: any): Observable<any> {
    return this.hbHttpClient.getResponse('rule-master/update', this.hbHttpClient.POST, data);
  }

  getListRuleMasters(data: any): Observable<any> {
    return this.hbHttpClient.getResponse('rule-master/list', this.hbHttpClient.POST, data);
  }

  getRuleMaster(id: any): Observable<any> {
    return this.hbHttpClient.getResponse(`rule-master/${ id }`, this.hbHttpClient.GET);
  }

  deleteRuleMasters(id: any): Observable<any> {
    return this.hbHttpClient.getResponse('rule-master/delete?ruleMasterId=' + id, this.hbHttpClient.DELETE);
  }
}
