import { AfterViewInit, Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import Swal from 'sweetalert2';
import { HbDataTableColumnOption } from '@hostbooks/hb-lib/hb-list-table/src/hb-list-table-columns';
import { HbDateFormatPipe } from '../../../shared/pipes/hb-date-format.pipe';
import { HBLoaderService } from '../../../shared/services/hb-loader.service';
import { MasterOptionService } from 'src/app/payroll/master-rules/common/services/master-option.service';
import { MasterOption } from 'src/app/payroll/master-rules/common/models/masters-options';
import { AppConst } from 'src/app/core/constants/app-const';
import { MasterSearchRequest } from '../master-search-request';
import { HbErrorHandler, HbErrorHandlerData } from 'src/app/shared/models/hb-error-handler';

@Component({
  selector: 'app-designations',
  templateUrl: './designations.component.html',
  styleUrls: ['./designations.component.scss'],
  providers: [HbDateFormatPipe]
})
export class DesignationsComponent implements OnInit, AfterViewInit {

  masterSearchRequest = new MasterSearchRequest();
  columns: HbDataTableColumnOption[] = [];
  data: MasterOption[] = [];
  total: number;
  searchName: string;
  designationModal = false;
  hbErrorHandler = new HbErrorHandler();
  designation = new MasterOption();

  constructor(private _location: Location, private datePipe: HbDateFormatPipe,
              private masterOptionService: MasterOptionService) {}

  ngOnInit(): void {

    this.getDesignationList();
    this.masterSearchRequest.page = 1;
    this.masterSearchRequest.limit = 10;
    this.designationColumns();
  }

  back() {
    this._location.back();
  }

  ngAfterViewInit() {

  }

designationColumns(){
  this.columns = [
    {
      header: 'S. No.',
      columnData: (inv: MasterOption) => {
      },
      type: 'SR_NO'
    },
    {
      header: 'Designations',
      columnData: (inv: MasterOption) => {
        return inv.name;
      },
      type: 'TEXT'
    },
    {
      header: 'Reporting To',
      columnData: (inv: MasterOption) => {
        return inv.reportingToName;
      },
      type: 'TEXT'
    },
    {
      header: 'Code',
      columnData: (inv: MasterOption) => {
        return inv.catCode;
      },
      type: 'TEXT'
    },
    {
      header: 'Level',
      columnData: (inv: MasterOption) => {
        return inv.designationLevel;
      },
      type: 'TEXT'
    },
    {
      header: 'Description',
      columnData: (inv: MasterOption) => {
        return inv.description;
      },
      type: 'TEXT'
    },
    {
      header: 'Created At',
      columnData: (inv: MasterOption) => {
        return this.datePipe.transform(inv.createdAt);
      },
      type: 'DATE'
    },
    {
      header: 'Created By',
      columnData: (inv: MasterOption) => {
        return inv.createdByName;
      },
      type: 'TEXT'
    },
    {
      header: 'Updated At',
      columnData: (inv: MasterOption) => {
        return this.datePipe.transform(inv.updatedAt);
      },
      type: 'DATE'
    },
    {
      header: 'Updated By',
      columnData: (inv: MasterOption) => {
        return inv.updatedByName;
      },
      type: 'TEXT'
    },
    {
      header: 'Actions',
      columnData: (inv: MasterOption) => {
      },
      type: 'ACTION',
      actionOptions: ['EDIT', 'DELETE']
    },
  ];
}
  deleteDesignation(id: number) {
    this.deleteConfirmationPopup().then(result => {
      if (result.value) {
        HBLoaderService.showLoader();
        this.masterOptionService.deleteMasterOption(id).subscribe(response => {
          this.deletedConfirmationPopup(response.message, 'Designation');
          HBLoaderService.hideLoader();
        });
      }
    });
  }

  designationModalOpen(id: any = null) {
    this.hbErrorHandler.clearErrors()
    if (id) {
      this.getDesignation(id);
      this.designationModal = true;
    } else {
      this.designation = new MasterOption();
      this.designationModal = true;
    }
  }

  getDesignation(id: any) {
    HBLoaderService.showLoader();
    this.masterOptionService.getMasterOptionById(id).subscribe(response => {
      if (response.status === 200 && response.data && response.data.masterOption) {
        this.designation = response.data.masterOption;
        HBLoaderService.hideLoader();
      }
    });
  }

  deleteConfirmationPopup() {
    return Swal.fire({
      title: 'Warning',
      text: 'Are you sure that you want to perform this action?',
      icon: 'question',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes',
      cancelButtonText: 'No',
      allowOutsideClick: false,
      allowEscapeKey: false,
    });
  }

  deletedConfirmationPopup(message, title) {
    Swal.fire({
      title: title,
      text: message,
      icon: 'success',
      allowOutsideClick: false,
      allowEscapeKey: false,
    }).then(result => {
      if (result.value) {
        this.getDesignationList();
      }
    });
  }

  onAction(_event: any) {
    if (_event && _event.actionType && _event.data) {
      if (_event.actionType === 'DELETE') {
        this.deleteDesignation(_event.data.id);
      }

      if (_event.actionType === 'EDIT') {
        this.designationModalOpen(_event.data.id);
      }
    }
  }

  onChange(_event: any) {
    this.masterSearchRequest.page = _event.page;
    this.masterSearchRequest.limit = _event.limit;
    this.getDesignationList();
  }

  getDesignationList() {
    this.masterSearchRequest = new MasterSearchRequest()
    HBLoaderService.showLoader();
    this.masterSearchRequest.searchFor = this.searchName;
    this.masterSearchRequest.catCode = AppConst.MASTER_CODE.DESIGNATION;
    this.masterOptionService.getListMasterOption(this.masterSearchRequest).subscribe(response => {
      console.log(response);
      if (response.status === 200 && response.data && response.data.masterOption) {
        this.data = response.data.masterOption.list;
        this.total = response.data.masterOption.totalRowCount;
        HBLoaderService.hideLoader();
      } else {
        this.data = new Array<MasterOption>();
        this.total = response.data.masterOption.totalRowCount;
        HBLoaderService.hideLoader();
      }
    });
  }

  validate(): void {
    this.hbErrorHandler.emptyCheck(this.designation.name, 'name');
    this.hbErrorHandler.emptyCheck(this.designation.levelRefId, 'level');
  }

  close() {
    this.designationModal = false;
  }

  addUpdateDesignation() {
    this.hbErrorHandler.clearErrors()
    this.validate();
    if (!this.hbErrorHandler.invalid) {
      if (!this.designation.id) {
        HBLoaderService.showLoader();
        this.designation.catCode = AppConst.MASTER_CODE.DESIGNATION;
        this.masterOptionService.addMasterOption(this.designation).subscribe(response => {
          console.log(response);
          if (response.status === 200 && response.data && response.data.masterOption) {
            this.confirmationPopup(response.message);
            HBLoaderService.hideLoader();
          }
        });
      } else {
      HBLoaderService.showLoader();
      this.masterOptionService.updateMasterOption(this.designation).subscribe(response => {
        console.log(response);
        if (response.status === 200 && response.data && response.data.masterOption) {
          this.confirmationPopup(response.message);
          HBLoaderService.hideLoader();
        }
      });
    }
  }
  }

  errorHandler(parentkey: string, childkey?: string, keyIndex?: number): HbErrorHandlerData {
    const hData = this.hbErrorHandler.getErrorHandlerData(parentkey, childkey, keyIndex);
    return hData;
  }

  confirmationPopup(message: any) {
    Swal.fire({
      title: 'Designation',
      html: message,
      icon: 'success',
      allowOutsideClick: false,
      allowEscapeKey: false,
    }).then(() => {
      this.getDesignationList()
      this.close();
    });
  }
}
