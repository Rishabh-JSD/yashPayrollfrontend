import { Component } from '@angular/core';
import { Location } from '@angular/common';
import { HbDataTableColumnOption } from '@hostbooks/hb-lib/hb-list-table/src/hb-list-table-columns';
import { MasterOption } from 'src/app/payroll/master-rules/common/models/masters-options';
import { HBLoaderService } from 'src/app/shared/services/hb-loader.service';
import Swal from 'sweetalert2';
import { MasterOptionService } from 'src/app/payroll/master-rules/common/services/master-option.service';
import { AppConst } from 'src/app/core/constants/app-const';
import { HbErrorHandler, HbErrorHandlerData } from 'src/app/shared/models/hb-error-handler';
import { MasterSearchRequest } from '../master-search-request';

@Component({
  selector: 'app-document-master',
  templateUrl: './document-master.component.html',
  styleUrls: ['./document-master.component.scss']
})
export class DocumentMasterComponent {
  masterSearchRequest = new MasterSearchRequest();
  columnCategory: HbDataTableColumnOption[] = [];
  dataCategory: MasterOption[] = [];
  totalCategory: number;

  columnType: HbDataTableColumnOption[] = [];
  dataType: MasterOption[] = [];
  totalType: number;

  docCategoryModal = false;
  docTypeModal = false;
  document = new MasterOption();
  searchName: string
  hbErrorHandler = new HbErrorHandler();

  constructor(private _location: Location,
    private masterOptionService: MasterOptionService) { }

  ngOnInit(): void {
    this.getCategoryList();
    this.getTypeList();
    this.masterSearchRequest.page = 1;
    this.masterSearchRequest.limit = 10;
    this.documentCategoryColumns();
    this.documentTypeColumns();
  }

  back() {
    this._location.back();
  }

  documentCategoryColumns(){
    this.columnCategory = [
      {
        header: 'S. No.',
        columnData: (inv: MasterOption) => {
        },
        type: 'SR_NO'
      },
      {
        header: 'Document Category',
        columnData: (inv: MasterOption) => {
          return inv.name;
        },
        type: 'TEXT'
      },
      {
        header: 'Action',
        columnData: (inv: MasterOption) => {
        },
        type: 'ACTION',
        actionOptions: ['EDIT', 'DELETE']
      },
    ];
  }

  documentTypeColumns(){
    this.columnType = [
      {
        header: 'S. No.',
        columnData: (inv: MasterOption) => {
        },
        type: 'SR_NO'
      },
      {
        header: 'Document Category',
        columnData: (inv: MasterOption) => {
          return inv.documentCategoryName;
        },
        type: 'TEXT'
      },
      {
        header: 'Document Type',
        columnData: (inv: MasterOption) => {
          return inv.name;
        },
        type: 'TEXT'
      },
      {
        header: 'Action',
        columnData: (inv: MasterOption) => {
        },
        type: 'ACTION',
        actionOptions: ['EDIT', 'DELETE']
      },
    ];
  }
  documentCategoryModalOpen(data: any = null) {
    this.hbErrorHandler.clearErrors()
    if (data) {
      this.getDocument(data);
      this.docCategoryModal = true;
    } else {
      this.document = new MasterOption();
      this.docCategoryModal = true;
    }
  }

  documentTypeModalOpen(data: any = null) {
    this.hbErrorHandler.clearErrors()
    if (data) {
      this.getDocument(data);
      this.docTypeModal = true;
    } else {
      this.document = new MasterOption();
      this.docTypeModal = true;
    }
  }

  ngAfterViewInit() {

  }

  deleteCategory(id: number) {
    this.deleteConfirmationPopup().then(result => {
      if (result.value) {
        HBLoaderService.showLoader();
        this.masterOptionService.deleteMasterOption(id).subscribe(response => {
          this.deletedConfirmationPopup(response.message, 'Document Category', 'category');
          HBLoaderService.hideLoader();
        });
      }
    });
  }

  deleteType(id: number) {
    this.deleteConfirmationPopup().then(result => {
      if (result.value) {
        HBLoaderService.showLoader();
        this.masterOptionService.deleteMasterOption(id).subscribe(response => {
          this.deletedConfirmationPopup(response.message, 'Document Type', 'type');
          HBLoaderService.hideLoader();
        });
      }
    });
  }

  deleteConfirmationPopup() {
    return Swal.fire({
      title: 'Warning',
      text: 'Are you sure that you want to perform this action?',
      icon: 'question',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes',
      cancelButtonText: 'No',
      allowOutsideClick: false,
      allowEscapeKey: false,
    });
  }

  deletedConfirmationPopup(message, title, code) {
    Swal.fire({
      title: title,
      text: message,
      icon: 'success',
      allowOutsideClick: false,
      allowEscapeKey: false,
    }).then(result => {
      if (result.value) {
        switch (code) {
          case 'category':
            this.getCategoryList();
            break;
          case 'type':
            this.getTypeList();
            break;
        }
      }
    });
  }

  onActionCategory(_event: any) {
    if (_event && _event.actionType && _event.data) {
      if (_event.actionType === 'DELETE') {
        this.deleteCategory(_event.data.id);
      }

      if (_event.actionType === 'EDIT') {
        this.documentCategoryModalOpen(_event.data.id);
      }
    }
  }

  onActionType(_event: any) {
    if (_event && _event.actionType && _event.data) {
      if (_event.actionType === 'DELETE') {
        this.deleteType(_event.data.id);
      }

      if (_event.actionType === 'EDIT') {
        this.documentTypeModalOpen(_event.data.id);
      }
    }
  }

  onChangeCategory(_event: any) {
    this.masterSearchRequest.page = _event.page;
    this.masterSearchRequest.limit = _event.limit;
    this.getCategoryList();
  }

  onChangeType(_event: any) {
    this.masterSearchRequest.page = _event.page;
    this.masterSearchRequest.limit = _event.limit;
    this.getTypeList();
  }

  getCategoryList() {
    HBLoaderService.showLoader();
    this.masterSearchRequest.searchFor = this.searchName;
    this.masterSearchRequest.catCode = AppConst.MASTER_CODE.DOCUMENT_CATEGORY;
    this.masterOptionService.getListMasterOption(this.masterSearchRequest).subscribe(response => {
      console.log(response);
      if (response.status === 200 && response.data && response.data.masterOption) {
        this.dataCategory = response.data.masterOption.list;
        this.totalCategory = response.data.masterOption.totalRowCount;
        HBLoaderService.hideLoader();
      } else {
        this.dataCategory = new Array<MasterOption>();
        this.totalCategory = response.data.masterOption.totalRowCount;
        HBLoaderService.hideLoader();
      }
    });

  }

  getTypeList() {
    HBLoaderService.showLoader();
    this.masterSearchRequest.searchFor = this.searchName;
    this.masterSearchRequest.catCode = AppConst.MASTER_CODE.DOCUMENT_TYPE;
    this.masterOptionService.getListMasterOption(this.masterSearchRequest).subscribe(response => {
      console.log(response);
      if (response.status === 200 && response.data && response.data.masterOption) {
        this.dataType = response.data.masterOption.list;
        this.totalType = response.data.masterOption.totalRowCount;
        HBLoaderService.hideLoader();
      } else {
        this.dataType = new Array<MasterOption>();
        this.totalType = response.data.masterOption.totalRowCount;
        HBLoaderService.hideLoader();
      }
    });
  }


  getDocument(id: any) {
    this.masterOptionService.getMasterOptionById(id).subscribe(response => {
      if (response.status === 200 && response.data && response.data.masterOption) {
        this.document = response.data.masterOption;
      }
    });
  }

  validate(): void {
    if (this.docCategoryModal) {
      if (!this.document.name) {
        this.hbErrorHandler.emptyCheck(this.document.name, 'name');
      }
    }
    if (this.docTypeModal) {
      if (!this.document.name && !this.document.parentId) {
        this.hbErrorHandler.emptyCheck(this.document.parentId, 'category')
      }
    }
  }

  confirmationPopup(message: any, title: string, code: string) {
    Swal.fire({
      title,
      html: message,
      icon: 'success',
      allowOutsideClick: false,
      allowEscapeKey: false,
    }).then(result => {
      if (result.value) {
        switch (code) {
          case 'category':
            this.getCategoryList();
            break;
          case 'type':
            this.getTypeList();
            break;
        }
      }
      this.close()
    });
  }

  close() {
    this.docCategoryModal = false;
    this.docTypeModal = false;
  }

  addUpdateDocument(doc: string) {
    this.hbErrorHandler.clearErrors()
    this.validate();
    if (!this.hbErrorHandler.invalid) {
      if (!this.document.id) {
        HBLoaderService.showLoader();
        if (doc === 'documentCategory') {
          this.document.catCode = AppConst.MASTER_CODE.DOCUMENT_CATEGORY;
        } else if (doc === 'documentType') {
          this.document.catCode = AppConst.MASTER_CODE.DOCUMENT_TYPE;
        }
        this.masterOptionService.addMasterOption(this.document).subscribe(response => {
          console.log(response);
          if (response.status === 200 && response.data && response.data.masterOption) {
            if (doc === 'documentCategory') {
              this.confirmationPopup(response.message, 'Document Category', 'category')
            } else if (doc === 'documentType') {
              this.confirmationPopup(response.message, 'Document Type', 'type')
            }
            HBLoaderService.hideLoader();
          }
        });
      } else {
        HBLoaderService.showLoader();
        this.masterOptionService.updateMasterOption(this.document).subscribe(response => {
          console.log(response);
          if (response.status === 200 && response.data && response.data.masterOption) {
            if (doc === 'documentCategory') {
              this.confirmationPopup(response.message, 'Document Category', 'category')
            }
            if (doc === 'documentType') {
              this.confirmationPopup(response.message, 'Document Type', 'type')
            }
            HBLoaderService.hideLoader();
          }
        });
      }
    }
  }

  errorHandler(parentkey: string, childkey?: string, keyIndex?: number): HbErrorHandlerData {
    const hData = this.hbErrorHandler.getErrorHandlerData(parentkey, childkey, keyIndex);
    return hData;
  }
}
