import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import Swal from 'sweetalert2';
import { HbDataTableColumnOption } from '@hostbooks/hb-lib/hb-list-table/src/hb-list-table-columns';
import { HbDateFormatPipe } from '../../../shared/pipes/hb-date-format.pipe';
import { HBLoaderService } from '../../../shared/services/hb-loader.service';
import { MasterOptionService } from 'src/app/payroll/master-rules/common/services/master-option.service';
import { MasterOption } from 'src/app/payroll/master-rules/common/models/masters-options';
import { AppConst } from 'src/app/core/constants/app-const';
import { HbErrorHandler, HbErrorHandlerData } from 'src/app/shared/models/hb-error-handler';
import { MasterSearchRequest } from '../master-search-request';
import { PopupService } from 'src/app/shared/services/popup.service';

@Component({
  selector: 'app-employee-master',
  templateUrl: './employee-master.component.html',
  styleUrls: ['./employee-master.component.scss'],
  providers: [HbDateFormatPipe]
})
export class EmployeeMasterComponent implements OnInit {


  masterSearchRequest = new MasterSearchRequest();

  columnsStatus: HbDataTableColumnOption[] = [];
  dataStatus: MasterOption[] = [];
  totalStatus: number;


  columnsLevel: HbDataTableColumnOption[] = [];
  dataLevel: MasterOption[] = [];
  totalLevel: number;

  empTypeModal = false;
  empStatusModal = false;
  empLevelModal = false;


  columnsType: HbDataTableColumnOption[] = [];
  dataType: MasterOption[] = [];
  totalType: number;
  searchName;
  employee = new MasterOption();
  levelOption: MasterOption[];
  hbErrorHandler = new HbErrorHandler();
  isEdit=false;
  constructor(
    private _location: Location,
    private datePipe: HbDateFormatPipe,
    private masterOptionService: MasterOptionService
  ) { }

  ngOnInit(): void {

    this.getEmployeeStatusList();
    this.getEmployeeLevelList();
    this.getEmployeeTypeList();
    this.masterSearchRequest.page = 1;
    this.masterSearchRequest.limit = 10;
    this.employeeStatusColumns();
    this.employeeLevelColumns();
    this.employeeTypeColumns();
  }

  back() {
    this._location.back();
  }

  ngAfterViewInit() {

  }

  employeeStatusColumns() {
    this.columnsStatus = [
      {
        header: 'S. No.',
        columnData: (inv: MasterOption) => {
        },
        type: 'SR_NO'
      },
      {
        header: 'Employment Status',
        columnData: (inv: MasterOption) => {
          return inv.name;
        },
        type: 'TEXT'
      },
      {
        header: 'Created At',
        columnData: (inv: MasterOption) => {
          return this.datePipe.transform(inv.createdAt);
        },
        type: 'DATE'
      },
      {
        header: 'Created By',
        columnData: (inv: MasterOption) => {
          return inv.createdByName;
        },
        type: 'TEXT'
      },
      {
        header: 'Updated At',
        columnData: (inv: MasterOption) => {
          return this.datePipe.transform(inv.updatedAt);
        },
        type: 'DATE'
      },
      {
        header: 'Updated By',
        columnData: (inv: MasterOption) => {
          return inv.updatedByName;
        },
        type: 'TEXT'
      },
      {
        header: 'Actions',
        columnData: (inv: MasterOption) => {
        },
        type: 'ACTION',
        actionOptions: ['EDIT', 'DELETE']
      },
    ];
  }

  employeeLevelColumns() {
    this.columnsLevel = [
      {
        header: 'S. No.',
        columnData: (inv: MasterOption) => {
        },
        type: 'SR_NO'
      },
      {
        header: 'Employee Level Name',
        columnData: (inv: MasterOption) => {
          return inv.name;
        },
        type: 'TEXT'
      },
      {
        header: 'Employee Level',
        columnData: (inv: MasterOption) => {
          return inv.level;
        },
        type: 'NUMBER'
      },
      {
        header: 'Created At',
        columnData: (inv: MasterOption) => {
          return this.datePipe.transform(inv.createdAt);
        },
        type: 'DATE'
      },
      {
        header: 'Created By',
        columnData: (inv: MasterOption) => {
          return inv.createdByName;
        },
        type: 'TEXT'
      },
      {
        header: 'Updated At',
        columnData: (inv: MasterOption) => {
          return this.datePipe.transform(inv.updatedAt);
        },
        type: 'DATE'
      },
      {
        header: 'Updated By',
        columnData: (inv: MasterOption) => {
          return inv.updatedByName;
        },
        type: 'TEXT'
      },
      {
        header: 'Actions',
        columnData: (inv: MasterOption) => {
        },
        type: 'ACTION',
        actionOptions: ['EDIT', 'DELETE']
      },
    ];
  }

  employeeTypeColumns() {
    this.columnsType = [
      {
        header: 'S. No.',
        columnData: (inv: MasterOption) => {
        },
        type: 'SR_NO'
      },
      {
        header: 'Employee Type',
        columnData: (inv: MasterOption) => {
          return inv.name;
        },
        type: 'TEXT'
      },
      {
        header: 'Created At',
        columnData: (inv: MasterOption) => {
          return this.datePipe.transform(inv.createdAt);
        },
        type: 'DATE'
      },
      {
        header: 'Created By',
        columnData: (inv: MasterOption) => {
          return inv.createdByName;
        },
        type: 'TEXT'
      },
      {
        header: 'Updated At',
        columnData: (inv: MasterOption) => {
          return this.datePipe.transform(inv.updatedAt);
        },
        type: 'DATE'
      },
      {
        header: 'Updated By',
        columnData: (inv: MasterOption) => {
          return inv.updatedByName;
        },
        type: 'TEXT'
      },
      {
        header: 'Actions',
        columnData: (inv: MasterOption) => {
        },
        type: 'ACTION',
        actionOptions: ['EDIT', 'DELETE']
      },
    ];
  }

  deleteEmployeeStatus(id: number) {
    this.deleteConfirmationPopup().then(result => {
      if (result.value) {
        HBLoaderService.showLoader();
        this.masterOptionService.deleteMasterOption(id).subscribe(response => {
          this.deletedConfirmationPopup(response.message, 'Employee Status', 'status');
          HBLoaderService.hideLoader();
        });
      }
    });
  }

  deleteEmployeeLevel(id: number) {
    this.deleteConfirmationPopup().then(result => {
      if (result.value) {
        HBLoaderService.showLoader();
        this.masterOptionService.deleteMasterOption(id).subscribe(response => {
          this.deletedConfirmationPopup(response.message, 'Employee Level', 'level');
          HBLoaderService.hideLoader();
        });
      }
    });
  }

  deleteEmployeeType(id: number) {
    this.deleteConfirmationPopup().then(result => {
      if (result.value) {
        HBLoaderService.showLoader();
        this.masterOptionService.deleteMasterOption(id).subscribe(response => {
          this.deletedConfirmationPopup(response.message, 'Employee Type', 'category');
          HBLoaderService.hideLoader();
        });
      }
    });
  }

  deleteConfirmationPopup() {
    return Swal.fire({
      title: 'Warning',
      text: 'Are you sure that you want to perform this action?',
      icon: 'question',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes',
      cancelButtonText: 'No',
      allowOutsideClick: false,
      allowEscapeKey: false,
    });
  }

  deletedConfirmationPopup(message, title, code) {
    Swal.fire({
      title: title,
      text: message,
      icon: 'success',
      allowOutsideClick: false,
      allowEscapeKey: false,
    }).then(result => {
      if (result.value) {
        switch (code) {
          case 'status':
            this.getEmployeeStatusList();
            break;
          case 'level':
            this.getEmployeeLevelList();
            break;
          case 'category':
            this.getEmployeeTypeList();
            break;
        }
      }
    });
  }

  onActionStatus(_event: any) {
    if (_event && _event.actionType && _event.data) {
      if (_event.actionType === 'DELETE') {
        this.deleteEmployeeStatus(_event.data.id);
      }
      if (_event.actionType === 'EDIT') {
        this.employementStatusModalOpen(_event.data.id);
      }
    }
  }

  onActionLevel(_event: any) {
    if (_event && _event.actionType && _event.data) {
      if (_event.actionType === 'DELETE') {
        this.deleteEmployeeLevel(_event.data.id);
      }

      if (_event.actionType === 'EDIT') {
        this.employementLevelModalOpen(_event.data.id);
      }
    }
  }

  onActionType(_event: any) {
    if (_event && _event.actionType && _event.data && (_event.data.code === 'CONTRACT'|| _event.data.code === 'PERMANENT'||_event.data.code ==='CONSULT') ) {
      if (_event.actionType === 'DELETE') {
        PopupService.infoAlert('Employee Type','Unable to delete default types.');
      }
      if (_event.actionType === 'EDIT') {
        PopupService.infoAlert('Employee Type','Unable to Edit default types.');
      }
    }else{
      if (_event && _event.actionType && _event.data) {
        if (_event.actionType === 'DELETE') {
          this.deleteEmployeeType(_event.data.id);
        }
        if (_event.actionType === 'EDIT') {
          this.employementTypeModalOpen(_event.data.id);
        }
      }
    }
    
  }

  onChangeStatus(_event: any) {
    this.masterSearchRequest.page = _event.page;
    this.masterSearchRequest.limit = _event.limit;
    this.getEmployeeStatusList();
  }

  onChangeLevel(_event: any) {
    this.masterSearchRequest.page = _event.page;
    this.masterSearchRequest.limit = _event.limit;
    this.getEmployeeLevelList();
  }

  onChangeType(_event: any) {
    this.masterSearchRequest.page = _event.page;
    this.masterSearchRequest.limit = _event.limit;
    this.getEmployeeTypeList();
  }

  getEmployeeStatusList() {
    HBLoaderService.showLoader();
    this.masterSearchRequest.searchFor = this.searchName;
    this.masterSearchRequest.catCode = AppConst.MASTER_CODE.EMPLOYEE_STATUS;
    this.masterOptionService.getListMasterOptionWithCode(this.masterSearchRequest).subscribe(response => {
      console.log(response);
      if (response.status === 200 && response.data && response.data.masterOption) {
        this.dataStatus = response.data.masterOption.list;
        this.totalStatus = response.data.masterOption.totalRowCount;
        HBLoaderService.hideLoader();
      } else {
        this.dataStatus = new Array<MasterOption>();
        this.totalStatus = response.data.masterOption.totalRowCount;
        HBLoaderService.hideLoader();
      }
    });
  }

  getEmployeeTypeList() {
    HBLoaderService.showLoader();
    this.masterSearchRequest.searchFor = this.searchName;
    this.masterSearchRequest.catCode = AppConst.MASTER_CODE.EMPLOYEE_TYPE;
    this.masterOptionService.getListMasterOptionWithCode(this.masterSearchRequest).subscribe(response => {
      console.log(response);
      if (response.status === 200 && response.data && response.data.masterOption) {
        this.dataType = response.data.masterOption.list;
        this.totalType = response.data.masterOption.totalRowCount;
        HBLoaderService.hideLoader();
      } else {
        this.dataType = new Array<MasterOption>();
        this.totalType = response.data.masterOption.totalRowCount;
        HBLoaderService.hideLoader();
      }
    });
  }

  getEmployeeLevelList() {
    HBLoaderService.showLoader();
    this.masterSearchRequest.searchFor = this.searchName;
    this.masterSearchRequest.catCode = AppConst.MASTER_CODE.EMPLOYEE_LEVEL;
    this.masterOptionService.getListMasterOptionWithCode(this.masterSearchRequest).subscribe(response => {
      console.log(response);
      if (response.status === 200 && response.data && response.data.masterOption) {
        this.dataLevel = response.data.masterOption.list;
        this.totalLevel = response.data.masterOption.totalRowCount;
        this.levelOption = this.dataLevel;
        HBLoaderService.hideLoader();
      } else {
        this.dataLevel = new Array<MasterOption>();
        this.totalLevel = response.data.masterOption.totalRowCount;
        HBLoaderService.hideLoader();
      }
    });
  }

  employementTypeModalOpen(data: any = null) {
    this.hbErrorHandler.clearErrors()
    if (data) {
      this.getEmployee(data);
      this.empTypeModal = true;

    } else {
      this.employee = new MasterOption();
      this.empTypeModal = true;
    }
  }

  employementStatusModalOpen(data: any = null) {
    this.hbErrorHandler.clearErrors()
    if (data) {
      this.getEmployee(data);
      this.empStatusModal = true;
    } else {
      this.employee = new MasterOption();
      this.empStatusModal = true;
    }
  }

  employementLevelModalOpen(data: any = null) {
    this.hbErrorHandler.clearErrors()
    if (data) {
      this.getEmployee(data);
      this.empLevelModal = true;
    } else {
      this.employee = new MasterOption();
      this.empLevelModal = true;
    }
  }

  getEmployee(id: any) {
    HBLoaderService.showLoader();
    this.masterOptionService.getMasterOptionById(id).subscribe(response => {
      if (response.status === 200 && response.data && response.data.masterOption) {
        this.employee = response.data.masterOption;
        this.isEdit = true;
        HBLoaderService.hideLoader();
      }
    });
  }

  validate(): void {
    if (this.empTypeModal) {
      if (!this.employee.name) {
        this.hbErrorHandler.emptyCheck(this.employee.name, 'name');
      }
    }
    if (this.empLevelModal) {
      if (!this.employee.name) {
        this.hbErrorHandler.emptyCheck(this.employee.name, 'name');
      }
    }
    if (this.empStatusModal) {
      if (!this.employee.name) {
        this.hbErrorHandler.emptyCheck(this.employee.name, 'name');
      }
    }
  }

  confirmationPopup(message: any, title: string, code: string) {
    Swal.fire({
      title,
      html: message,
      icon: 'success',
      allowOutsideClick: false,
      allowEscapeKey: false,
    }).then(result => {
      if (result.value) {
        switch (code) {
          case 'status':
            this.getEmployeeStatusList();
            break;
          case 'type':
            this.getEmployeeTypeList();
            break;
          case 'level':
            this.getEmployeeLevelList();
            break;
        }
      }
      this.close()
    });
  }

  close() {
    this.empStatusModal = false;
    this.empTypeModal = false;
    this.empLevelModal = false;
  }

  addUpdateEmployee(doc: string) {
    this.hbErrorHandler.clearErrors()
    this.validate();
    if (!this.hbErrorHandler.invalid) {
      if (!this.employee.id) {
        HBLoaderService.showLoader();
        if (doc === 'employeeStatus') {
          this.employee.catCode = AppConst.MASTER_CODE.EMPLOYEE_STATUS;
        } else if (doc === 'employeeType') {
          this.employee.catCode = AppConst.MASTER_CODE.EMPLOYEE_TYPE;
        } else if (doc === 'employeeLevel') {
          this.employee.catCode = AppConst.MASTER_CODE.EMPLOYEE_LEVEL;
        }
        if (this.levelOption && this.levelOption.length > 0) {
          const maxLevel = Math.max(...this.levelOption.map(option => option.maxLevel));
          this.employee.level = maxLevel + 1;
        }
        this.masterOptionService.addMasterOption(this.employee).subscribe(response => {
          console.log(response);
          if (response.status === 200 && response.data && response.data.masterOption) {
            if (doc === 'employeeStatus') {
              this.confirmationPopup(response.message, 'Employee Status', 'status')
            } else if (doc === 'employeeType') {
              this.confirmationPopup(response.message, 'Employee Type', 'type')
            } else if (doc === 'employeeLevel') {
              this.confirmationPopup(response.message, 'Employee Level', 'level')
            }
            HBLoaderService.hideLoader();
          }
        });
      } else {
        HBLoaderService.showLoader();
        this.masterOptionService.updateMasterOption(this.employee).subscribe(response => {
          console.log(response);
          if (response.status === 200 && response.data && response.data.masterOption) {
            if (doc === 'employeeStatus') {
              this.confirmationPopup(response.message, 'Employee Status', 'status')
            } else if (doc === 'employeeType') {
              this.confirmationPopup(response.message, 'Employee Type', 'type')
            } else if (doc === 'employeeLevel') {
              this.confirmationPopup(response.message, 'Employee Level', 'level')
            }
            HBLoaderService.hideLoader();
          }
        });
      }
    }
  }

  errorHandler(parentkey: string, childkey?: string, keyIndex?: number): HbErrorHandlerData {
    const hData = this.hbErrorHandler.getErrorHandlerData(parentkey, childkey, keyIndex);
    return hData;
  }
}
