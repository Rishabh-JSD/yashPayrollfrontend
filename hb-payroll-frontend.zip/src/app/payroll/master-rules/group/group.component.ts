import { Component } from '@angular/core';
import { Location } from '@angular/common';
import { HbDataTableColumnOption } from '@hostbooks/hb-lib/hb-list-table/src/hb-list-table-columns';

@Component({
  selector: 'app-group',
  templateUrl: './group.component.html',
  styleUrls: ['./group.component.scss']
})
export class GroupComponent {

  group: HbDataTableColumnOption[] = [];
  groupModal = false;

  constructor(private _location: Location,) {}

  ngOnInit(): void {

    this.group = [
      {
        header: 'S. No.',
        columnData: () => {},
        type: 'SR_NO'
      },
      {
        header: 'Group',
        columnData: () => {},
        type: 'TEXT'
      },
      {
        header: 'Action',
        columnData: () => {},
        type: 'TEXT'
      },
    ];
  }


  back() {
    this._location.back();
  }

  groupModalOpen() {
    this.groupModal = true;
  }

}
