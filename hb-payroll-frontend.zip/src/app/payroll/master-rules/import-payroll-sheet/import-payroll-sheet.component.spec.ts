import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ImportPayrollSheetComponent } from './import-payroll-sheet.component';

describe('ImportPayrollSheetComponent', () => {
  let component: ImportPayrollSheetComponent;
  let fixture: ComponentFixture<ImportPayrollSheetComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ImportPayrollSheetComponent]
    })
      .compileComponents();

    fixture = TestBed.createComponent(ImportPayrollSheetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
