import { Component, Input } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-import-payroll-sheet',
  templateUrl: './import-payroll-sheet.component.html',
  styleUrls: ['./import-payroll-sheet.component.scss']
})
export class ImportPayrollSheetComponent {

  @Input() visible = false;
  dialogRef: MatDialogRef<any>;

  closeDialog(): void {
  }
}
