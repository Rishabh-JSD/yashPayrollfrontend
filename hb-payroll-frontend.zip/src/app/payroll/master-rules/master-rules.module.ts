import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../../shared/shared.module';
import { DeductionsComponent } from './deductions/deductions.component';
import { AllowancesComponent } from './allowances/allowances.component';
import { PayFrequencyComponent } from './pay-frequency/pay-frequency.component';
import { EmployeeMasterComponent } from './employee-master/employee-master.component';
import { ShiftComponent } from './shift/shift.component';
import { DesignationsComponent } from './designations/designations.component';
import { LayoutModule } from '../../layout/layout.module';
import { ReimbursementComponent } from './reimbursement/reimbursement.component';
import { AllowanceDeductionRuleComponent } from './allowance-deduction-rule/allowance-deduction-rule.component';
import { ImportPayrollSheetComponent } from './import-payroll-sheet/import-payroll-sheet.component';
import { GroupComponent } from './group/group.component';
import { AccountComponent } from './account/account.component';
import { DocumentMasterComponent } from './document-master/document-master.component';

const routes: Routes = [
  { path: '', component: DeductionsComponent },
  { path: 'deductions', component: DeductionsComponent },
  { path: 'allowances', component: AllowancesComponent },
  { path: 'pay-frequency', component: PayFrequencyComponent },
  { path: 'reimbursement', component: ReimbursementComponent },
  { path: 'employee-master', component: EmployeeMasterComponent },
  { path: 'shift', component: ShiftComponent },
  { path: 'designation', component: DesignationsComponent },
  { path: 'allowance-deduction-rule', component: AllowanceDeductionRuleComponent },
  { path: 'group', component: GroupComponent },
  { path: 'account', component: AccountComponent },
  { path: 'document-master', component: DocumentMasterComponent },
  { path: '**', redirectTo: '', pathMatch: 'full' },
];

@NgModule({
  declarations: [
    DeductionsComponent,
    AllowancesComponent,
    PayFrequencyComponent,
    EmployeeMasterComponent,
    ShiftComponent,
    DesignationsComponent,
    ReimbursementComponent,
    AllowanceDeductionRuleComponent,
    ImportPayrollSheetComponent,
    GroupComponent,
    AccountComponent,
    DocumentMasterComponent,
  ],
  imports: [CommonModule, SharedModule, LayoutModule, RouterModule.forChild(routes)],
})
export class MasterRulesModule {
}
