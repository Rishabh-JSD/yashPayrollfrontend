import { AfterViewInit, Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import Swal from 'sweetalert2';
import { HbDataTableColumnOption } from '@hostbooks/hb-lib/hb-list-table/src/hb-list-table-columns';
import { HbDateFormatPipe } from '../../../shared/pipes/hb-date-format.pipe';
import { HBLoaderService } from '../../../shared/services/hb-loader.service';
import { MasterOption } from 'src/app/payroll/master-rules/common/models/masters-options';
import { MasterOptionService } from 'src/app/payroll/master-rules/common/services/master-option.service';
import { AppConst } from 'src/app/core/constants/app-const';
import { MasterSearchRequest } from '../master-search-request';
import { HbErrorHandler, HbErrorHandlerData } from 'src/app/shared/models/hb-error-handler';
import { DropDownModel } from 'src/app/shared/models/hb-field-option';

@Component({
  selector: 'app-pay-frequency',
  templateUrl: './pay-frequency.component.html',
  styleUrls: ['./pay-frequency.component.scss'],
  providers: [HbDateFormatPipe]
})
export class PayFrequencyComponent implements OnInit, AfterViewInit {

  masterSearchRequest = new MasterSearchRequest();
  columns: HbDataTableColumnOption[] = [];
  data: MasterOption[] = [];
  total: number;
  searchName: string;
  payFrequencyModal = false;
  hbErrorHandler = new HbErrorHandler();
  payFrequency = new MasterOption();
  payFrequencyOption: DropDownModel[] = [
    { label: 'Monthly', code: 'MONTHLY', id: undefined, value: undefined },
    { label: 'Daily', code: 'DAILY', id: undefined, value: undefined },
    { label: 'Weekly', code: 'WEEKLY', id: undefined, value: undefined },
  ];
  payFrequencyData = {
    code: null,
    selectedOption: null
  };
  isDaillyOrWeeklyPayFrequency: boolean = false;
  isError: boolean = false;
  errorMessage: string;
  isAddPayFrequency: boolean = true


  constructor(private _location: Location, private datePipe: HbDateFormatPipe,
              private masterOptionService: MasterOptionService) {}

  ngOnInit(): void {

    this.getPayFrequencyList();
    this.masterSearchRequest.page = 1;
    this.masterSearchRequest.limit = 10;
    this.columns = [
      {
        header: 'S. No.',
        columnData: (inv: MasterOption) => {
        },
        type: 'SR_NO'
      },
      {
        header: 'Pay Frequency Type',
        columnData: (inv: MasterOption) => {
          return this.capitalizeFirstLetter(inv.name);
        },
        type: 'TEXT'
      },
      {
        header: 'Start Day',
        columnData: (inv: MasterOption) => {
          return inv.startDay;
        },
        type: 'DATE'
      },
      {
        header: 'End Day',
        columnData: (inv: MasterOption) => {
          return inv.endDay;
        },
        type: 'DATE'
      },
      {
        header: 'Code',
        columnData: (inv: MasterOption) => {
          return inv.code;
        },
        type: 'TEXT'
      },
      {
        header: 'Created At',
        columnData: (inv: MasterOption) => {
          return this.datePipe.transform(inv.createdAt);
        },
        type: 'DATE'
      },
      {
        header: 'Created By',
        columnData: (inv: MasterOption) => {
          return inv.createdByName;
        },
        type: 'TEXT'
      },
      {
        header: 'Updated At',
        columnData: (inv: MasterOption) => {
          return this.datePipe.transform(inv.updatedAt);
        },
        type: 'DATE'
      },
      {
        header: 'Updated By',
        columnData: (inv: MasterOption) => {
          return inv.updatedByName;
        },
        type: 'TEXT'
      },
      {
        header: 'Actions',
        columnData: (inv: MasterOption) => {
        },
        type: 'ACTION',
        actionOptions: ['EDIT', 'DELETE']
      },
    ];
  }

  back() {
    this._location.back();
  }

  ngAfterViewInit() {}

  deletePayFrequency(id: number) {
    this.deleteConfirmationPopup().then(result => {
      if (result.value) {
        HBLoaderService.showLoader();
        this.masterOptionService.deleteMasterOption(id).subscribe(response => {
          this.deletedConfirmationPopup(response.message, 'Pay Frequency');
          HBLoaderService.hideLoader();
        });
      }
    });
  }

  payFrequencyModalOpen(id: any = null) {
    this.isError = false;
    this.hbErrorHandler.clearErrors()
    if (id) {
      this.getPayFrequency(id);
      this.payFrequencyModal = true;
      this.isAddPayFrequency = false;
    } else {
      this.payFrequency = new MasterOption();
      this.isDaillyOrWeeklyPayFrequency = false;
      this.payFrequencyModal = true;
      this.isAddPayFrequency = true;
      this.payFrequencyData.selectedOption = null
      this.payFrequencyData.code = null
    }
  }

  getPayFrequency(id: any) {
    HBLoaderService.showLoader();
    this.masterOptionService.getMasterOptionById(id).subscribe(response => {
      if (response.status === 200 && response.data && response.data.masterOption) {
        this.payFrequency = response.data.masterOption;
        this.payFrequencyData.selectedOption = this.payFrequency.name
        if(this.payFrequencyData.selectedOption === "DAILY" || this.payFrequencyData.selectedOption === "WEEKLY"){
          this.isDaillyOrWeeklyPayFrequency = true;
        } else{
          this.isDaillyOrWeeklyPayFrequency = false;
        }
        this.payFrequency.startDay = response.data.masterOption.startDay;
        this.payFrequency.endDay =response.data.masterOption.endDay
        HBLoaderService.hideLoader();
      }
    });
  }

  deleteConfirmationPopup() {
    return Swal.fire({
      title: 'Warning',
      text: 'Are you sure that you want to perform this action?',
      icon: 'question',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes',
      cancelButtonText: 'No',
      allowOutsideClick: false,
      allowEscapeKey: false,
    });
  }

  deletedConfirmationPopup(message, title) {
    Swal.fire({
      title: title,
      text: message,
      icon: 'success',
      allowOutsideClick: false,
      allowEscapeKey: false,
    }).then(result => {
      if (result.value) {
        this.getPayFrequencyList();
      }
    });
  }


  onAction(_event: any) {
    this.isError = false;
    if (_event && _event.actionType && _event.data) {
      if (_event.actionType === 'DELETE') {
        this.deletePayFrequency(_event.data.id);
      }

      if (_event.actionType === 'EDIT') {
        this.payFrequencyModalOpen(_event.data.id);
      }
    }
  }

  onChange(_event: any) {
    this.masterSearchRequest.page = _event.page;
    this.masterSearchRequest.limit = _event.limit;
    this.getPayFrequencyList();
  }

  getPayFrequencyList() {
    HBLoaderService.showLoader();
    this.masterSearchRequest.searchFor = this.searchName;
    this.masterSearchRequest.catCode = AppConst.MASTER_CODE.PAY_FREQUENCY;
    this.masterOptionService.getListMasterOption(this.masterSearchRequest).subscribe(response => {
      console.log(response);
      if (response.status === 200 && response.data && response.data.masterOption) {
        this.data = response.data.masterOption.list;
        this.total = response.data.masterOption.totalRowCount;
        HBLoaderService.hideLoader();
      } else {
        this.data = new Array<MasterOption>();
        this.total = response.data.masterOption.totalRowCount;
        HBLoaderService.hideLoader();
      }
    });
    HBLoaderService.hideLoader();
  }

  validate(): void {
    this.hbErrorHandler.emptyCheck(this.payFrequency.name, 'name');   
    this.hbErrorHandler.emptyCheck(this.payFrequency.code, 'code');
    if(this.payFrequencyData.selectedOption == "MONTHLY"){
      this.hbErrorHandler.emptyCheck(this.payFrequency.startDay, 'startDay');      
    }
  }

  close() {
    this.payFrequencyModal = false;
    this.isError = false;
    this.isAddPayFrequency = true;
  }

  addUpdatePayFrequency() {
    this.hbErrorHandler.clearErrors()
    this.validate();
    this.isError = false
    if (!this.hbErrorHandler.invalid) {
      HBLoaderService.showLoader();
      if (!this.payFrequency.id) {        
        this.payFrequency.catCode = AppConst.MASTER_CODE.PAY_FREQUENCY;        
        this.masterOptionService.addMasterOption(this.payFrequency).subscribe(response => {
          console.log(response);
          if (response.status === 200 && response.data && response.data.masterOption) {
            this.confirmationPopup(response.message);            
          }else if (response.status === 400 && response.fieldErrors.length != 0) {
            this.isError = true;
            this.errorMessage = response.fieldErrors[0].message;
            HBLoaderService.hideLoader();
          }
        });
      } else {
        this.masterOptionService.updateMasterOption(this.payFrequency).subscribe(response => {
          console.log(response);
          if (response.status === 200 && response.data && response.data.masterOption) {
            this.confirmationPopup(response.message);            
          } else if (response.status === 400 && response.fieldErrors.length != 0) {
            this.isError = true;
            this.errorMessage = response.fieldErrors[0].message;
            HBLoaderService.hideLoader();
          }
        });
      }
      HBLoaderService.hideLoader();
    }
  }

  errorHandler(parentkey: string, childkey?: string, keyIndex?: number): HbErrorHandlerData {
    const hData = this.hbErrorHandler.getErrorHandlerData(parentkey, childkey, keyIndex);
    return hData;
  }

  confirmationPopup(message: any) {
    Swal.fire({
      title: 'Pay Frequency',
      html: message,
      icon: 'success',
      allowOutsideClick: false,
      allowEscapeKey: false,
    }).then(() => {
      this.getPayFrequencyList();
      this.close();
    });
  }

  onPayFrequencyChange() {
    if (this.payFrequencyData.selectedOption) {
      if(this.payFrequencyData.selectedOption === "DAILY" || this.payFrequencyData.selectedOption === "WEEKLY"){
        this.isDaillyOrWeeklyPayFrequency = true;
      } else{
        this.isDaillyOrWeeklyPayFrequency = false;
      }
      this.payFrequencyData.code = this.payFrequencyData.selectedOption;
      this.payFrequency.name = this.payFrequencyData.selectedOption
    }
  }

  calculateCompletedMonths() {
    if (this.payFrequency.startDay) {     
      this.payFrequency.startDay = Math.min(31, Math.max(1, this.payFrequency.startDay));          
      this.payFrequency.endDay = this.payFrequency.startDay - 1; 
      if (this.payFrequency.startDay === 1) {
        this.payFrequency.endDay = 31;
      }     
    }
  }

  capitalizeFirstLetter(str: string): string {
    return str.charAt(0).toUpperCase() + str.slice(1).toLowerCase();
  }
}
