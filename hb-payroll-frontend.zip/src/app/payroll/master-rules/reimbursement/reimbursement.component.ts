import { AfterViewInit, Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import Swal from 'sweetalert2';
import { HbDataTableColumnOption } from '@hostbooks/hb-lib/hb-list-table/src/hb-list-table-columns';
import { HbDateFormatPipe } from '../../../shared/pipes/hb-date-format.pipe';
import { HBLoaderService } from '../../../shared/services/hb-loader.service';
import { MasterOption } from 'src/app/payroll/master-rules/common/models/masters-options';
import { MasterOptionService } from 'src/app/payroll/master-rules/common/services/master-option.service';
import { AppConst } from 'src/app/core/constants/app-const';
import { MasterSearchRequest } from '../master-search-request';
import { HbErrorHandler, HbErrorHandlerData } from 'src/app/shared/models/hb-error-handler';

@Component({
  selector: 'app-reimbursement',
  templateUrl: './reimbursement.component.html',
  styleUrls: ['./reimbursement.component.scss'],
  providers: [HbDateFormatPipe]
})
export class ReimbursementComponent implements OnInit, AfterViewInit {

  masterSearchRequest = new MasterSearchRequest();

  columns: HbDataTableColumnOption[] = [];
  data: MasterOption[] = [];
  total: number;
  searchName: string;
  reimbursementModal = false;
  hbErrorHandler = new HbErrorHandler();
  reimbursement = new MasterOption();

  constructor(private _location: Location,
              private datePipe: HbDateFormatPipe, private masterOptionService: MasterOptionService) {}

  ngOnInit(): void {
    this.getReimbursementList();
    this.masterSearchRequest.page = 1;
    this.masterSearchRequest.limit = 10;
    this.reimbursementColumns();
  }

  back() {
    this._location.back();
  }

  ngAfterViewInit() {

  }

reimbursementColumns(){
  this.columns = [
    {
      header: 'S. No.',
      columnData: (inv: MasterOption) => {
      },
      type: 'SR_NO'
    },
    {
      header: 'Reimbursement Name',
      columnData: (inv: MasterOption) => {
        return inv.name;
      },
      type: 'TEXT'
    },
    {
      header: 'Created At',
      columnData: (inv: MasterOption) => {
        return this.datePipe.transform(inv.createdAt);
      },
      type: 'DATE'
    },
    {
      header: 'Created By',
      columnData: (inv: MasterOption) => {
        return inv.createdByName;
      },
      type: 'TEXT'
    },
    {
      header: 'Updated At',
      columnData: (inv: MasterOption) => {
        return this.datePipe.transform(inv.updatedAt);
      },
      type: 'DATE'
    },
    {
      header: 'Updated By',
      columnData: (inv: MasterOption) => {
        return inv.updatedByName;
      },
      type: 'TEXT'
    },
    {
      header: 'Actions',
      columnData: (inv: MasterOption) => {
      },
      type: 'ACTION',
      actionOptions: ['EDIT', 'DELETE']
    },
  ];
}
  deleteReimbursement(id: number) {
    this.deleteConfirmationPopup().then(result => {
      if (result.value) {
        HBLoaderService.showLoader();
        this.masterOptionService.deleteMasterOption(id).subscribe(response => {
          this.deletedConfirmationPopup(response.message, 'Reimbursement');
          HBLoaderService.hideLoader();
        });
      }
    });
  }

  reimbursementModalOpen(id: any = null) {
    this.hbErrorHandler.clearErrors()
    if (id) {
      this.getReimbursement(id);
      this.reimbursementModal = true;
    } else {
      this.reimbursement = new MasterOption();
      this.reimbursementModal = true;
    }
  }

  getReimbursement(id: any) {
    HBLoaderService.showLoader();
    this.masterOptionService.getMasterOptionById(id).subscribe(response => {
      if (response.status === 200 && response.data && response.data.masterOption) {
        this.reimbursement = response.data.masterOption;
        HBLoaderService.hideLoader();
      }
    });
  }

  deleteConfirmationPopup() {
    return Swal.fire({
      title: 'Warning',
      text: 'Are you sure that you want to perform this action?',
      icon: 'question',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes',
      cancelButtonText: 'No',
      allowOutsideClick: false,
      allowEscapeKey: false,
    });
  }

  deletedConfirmationPopup(message, title) {
    Swal.fire({
      title: title,
      text: message,
      icon: 'success',
      allowOutsideClick: false,
      allowEscapeKey: false,
    }).then(result => {
      if (result.value) {
        this.getReimbursementList();
      }
    });
  }

  onAction(_event: any) {
    if (_event && _event.actionType && _event.data) {
      if (_event.actionType === 'DELETE') {
        this.deleteReimbursement(_event.data.id);
      }

      if (_event.actionType === 'EDIT') {
        this.reimbursementModalOpen(_event.data.id);
      }
    }
  }

  onChange(_event: any) {
    this.masterSearchRequest.page = _event.page;
    this.masterSearchRequest.limit = _event.limit;
    this.getReimbursementList();
  }

  getReimbursementList() {
    HBLoaderService.showLoader();
    this.masterSearchRequest.searchFor = this.searchName;
    this.masterSearchRequest.catCode = AppConst.MASTER_CODE.REIMBURSEMENT;
    this.masterOptionService.getListMasterOption(this.masterSearchRequest).subscribe(response => {
      console.log(response);
      if (response.status === 200 && response.data && response.data.masterOption) {
        this.data = response.data.masterOption.list;
        this.total = response.data.masterOption.totalRowCount;
        HBLoaderService.hideLoader();
      } else {
        this.data = new Array<MasterOption>();
        this.total = response.data.masterOption.totalRowCount;
        HBLoaderService.hideLoader();
      }
    });
  }

  validate(): void {
    this.hbErrorHandler.emptyCheck(this.reimbursement.name, 'name');
  }

  close() {
    this.reimbursementModal = false;
  }

  addUpdateReimbursement() {
    this.hbErrorHandler.clearErrors()
    this.validate();
    if (!this.hbErrorHandler.invalid) {
      if (!this.reimbursement.id) {
        HBLoaderService.showLoader();
        this.reimbursement.catCode = AppConst.MASTER_CODE.REIMBURSEMENT;
        this.masterOptionService.addMasterOption(this.reimbursement).subscribe(response => {
          console.log(response);
          if (response.status === 200 && response.data && response.data.masterOption) {
            this.confirmationPopup(response.message);
            HBLoaderService.hideLoader();
          }
        });
      } else {
        HBLoaderService.showLoader();
        this.masterOptionService.updateMasterOption(this.reimbursement).subscribe(response => {
          console.log(response);
          if (response.status === 200 && response.data && response.data.masterOption) {
            this.confirmationPopup(response.message);
            HBLoaderService.hideLoader();
          }
        });
      }
    }
  }

  errorHandler(parentkey: string, childkey?: string, keyIndex?: number): HbErrorHandlerData {
    const hData = this.hbErrorHandler.getErrorHandlerData(parentkey, childkey, keyIndex);
    return hData;
  }

  confirmationPopup(message: any) {
    Swal.fire({
      title: 'Reimbursement',
      html: message,
      icon: 'success',
      allowOutsideClick: false,
      allowEscapeKey: false,
    }).then(() => {
      this.getReimbursementList()
      this.close();
    });
  }
}
