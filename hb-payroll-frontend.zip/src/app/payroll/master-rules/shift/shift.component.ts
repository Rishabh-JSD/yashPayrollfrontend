import { AfterViewInit, Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import Swal from 'sweetalert2';
import { HbDataTableColumnOption } from '@hostbooks/hb-lib/hb-list-table/src/hb-list-table-columns';
import { HbDateFormatPipe } from '../../../shared/pipes/hb-date-format.pipe';
import { TimeFormatPipe } from '../../../shared/pipes/time-format.pipe';
import { HBLoaderService } from '../../../shared/services/hb-loader.service';
import { MasterOption } from 'src/app/payroll/master-rules/common/models/masters-options';
import { MasterOptionService } from 'src/app/payroll/master-rules/common/services/master-option.service';
import { AppConst } from 'src/app/core/constants/app-const';
import { MasterSearchRequest } from '../master-search-request';
import { HbErrorHandler, HbErrorHandlerData } from 'src/app/shared/models/hb-error-handler';

@Component({
  selector: 'app-shift',
  templateUrl: './shift.component.html',
  styleUrls: ['./shift.component.scss'],
  providers: [HbDateFormatPipe,
    TimeFormatPipe]
})
export class ShiftComponent implements OnInit, AfterViewInit {


  masterSearchRequest = new MasterSearchRequest();
  columnsTiming: HbDataTableColumnOption[] = [];
  dataTiming: MasterOption[] = [];
  totalTiming: number;

  columnsType: HbDataTableColumnOption[] = [];

  levels: HbDataTableColumnOption[] = [];
  account: HbDataTableColumnOption[] = [];

  dataType: MasterOption[] = [];
  totalType: number;
  setOpenShiftTimingModal: any;
  setOpenShiftTypeModal: any;
  selectedTab: number = 0;
  searchName: string;
  shiftTypeModal = false;
  shiftTimingModal = false;
  hbErrorHandler = new HbErrorHandler();
  shift = new MasterOption();
  endTime: Date;
  startTime: Date;


  constructor(private _location: Location, private datePipe: HbDateFormatPipe,
    private timePipe: TimeFormatPipe,
    private masterOptionService: MasterOptionService) { }

  ngOnInit(): void {


    this.getShiftTimingList();
    this.getShiftTypeList();
    this.masterSearchRequest.page = 1;
    this.masterSearchRequest.limit = 10;
    this.shiftTypeColumns();
    this.shiftTimingColumns();
  }

  back() {
    this._location.back();
  }

  ngAfterViewInit() {
  }

shiftTimingColumns(){
  this.columnsTiming = [
    {
      header: 'S. No.',
      columnData: (inv: MasterOption) => {
      },
      type: 'SR_NO'
    },
    {
      header: 'Shift Types',
      columnData: (inv: MasterOption) => {
        return inv.shiftTypeName;
      },
      type: 'TEXT'
    },
    {
      header: 'Shift Timing',
      columnData: () => { },
      type: 'TEXT'
    },

    {
      header: 'Start Time',
      columnData: (inv: MasterOption) => {
        return this.timePipe.transform(inv.startTime);
      },
      type: 'TEXT'
    },
    {
      header: 'End Time',
      columnData: (inv: MasterOption) => {
        return this.timePipe.transform(inv.endTime);
      },
      type: 'TEXT'
    },
    {
      header: 'Working Hours',
      columnData: (inv: MasterOption) => {
        return inv.workingHours;
      },
      type: 'NUMBER'
    },
    {
      header: 'Created At',
      columnData: (inv: MasterOption) => {
        return this.datePipe.transform(inv.createdAt);
      },
      type: 'DATE'
    },
    {
      header: 'Created By',
      columnData: (inv: MasterOption) => {
        return inv.createdByName;
      },
      type: 'TEXT'
    },
    {
      header: 'Updated At',
      columnData: (inv: MasterOption) => {
        return this.datePipe.transform(inv.updatedAt);
      },
      type: 'DATE'
    },
    {
      header: 'Updated By',
      columnData: (inv: MasterOption) => {
        return inv.updatedByName;
      },
      type: 'TEXT'
    },
    {
      header: 'Actions',
      columnData: (inv: MasterOption) => {
      },
      type: 'ACTION',
      actionOptions: ['EDIT', 'DELETE']
    },
  ];
}

shiftTypeColumns(){
  this.columnsType = [
    {
      header: 'S. No.',
      columnData: (inv: MasterOption) => {
      },
      type: 'SR_NO'
    },
    {
      header: 'Shift Types',
      columnData: (inv: MasterOption) => {
        return inv.name;
      },
      type: 'TEXT'
    },
    {
      header: 'Created At',
      columnData: (inv: MasterOption) => {
        return this.datePipe.transform(inv.createdAt);
      },
      type: 'DATE'
    },
    {
      header: 'Created By',
      columnData: (inv: MasterOption) => {
        return inv.createdByName;
      },
      type: 'TEXT'
    },
    {
      header: 'Updated At',
      columnData: (inv: MasterOption) => {
        return this.datePipe.transform(inv.updatedAt);
      },
      type: 'DATE'
    },
    {
      header: 'Updated By',
      columnData: (inv: MasterOption) => {
        return inv.updatedByName;
      },
      type: 'TEXT'
    },
    {
      header: 'Actions',
      columnData: () => {
      },
      type: 'ACTION',
      actionOptions: ['EDIT', 'DELETE']
    },
  ];
}

  deleteShiftTiming(id: number) {
    this.deleteConfirmationPopup().then(result => {
      if (result.value) {
        HBLoaderService.showLoader();
        this.masterOptionService.deleteMasterOption(id).subscribe(response => {
          this.deletedConfirmationPopup(response.message, 'ShiftTiming', 'timing');
          HBLoaderService.hideLoader();
        });
      }
    });
  }

  deleteShiftType(id: number) {
    this.deleteConfirmationPopup().then(result => {
      if (result.value) {
        HBLoaderService.showLoader();
        this.masterOptionService.deleteMasterOption(id).subscribe(response => {
          this.deletedConfirmationPopup(response.message, 'ShiftType', 'type');
          HBLoaderService.hideLoader();
        });
      }
    });
  }

  deleteConfirmationPopup() {
    return Swal.fire({
      title: 'Warning',
      text: 'Are you sure that you want to perform this action?',
      icon: 'question',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes',
      cancelButtonText: 'No',
      allowOutsideClick: false,
      allowEscapeKey: false,
    });
  }

  deletedConfirmationPopup(message: any, title: string, code: string) {
    Swal.fire({
      title,
      text: message,
      icon: 'success',
      allowOutsideClick: false,
      allowEscapeKey: false,
    }).then(result => {
      if (result.value) {
        switch (code) {
          case 'timing':
            this.getShiftTimingList();
            break;
          case 'type':
            this.getShiftTypeList();
            break;
        }
      }
    });
  }

  onActionTiming(_event: any) {
    if (_event && _event.actionType && _event.data) {
      if (_event.actionType === 'DELETE') {
        this.deleteShiftTiming(_event.data.id);
      }
      if (_event.actionType === 'EDIT') {
        this.shiftTimingModalOpen(_event.data.id);
      }
    }
  }

  onActionType(_event: any) {
    if (_event && _event.actionType && _event.data) {
      if (_event.actionType === 'DELETE') {
        this.deleteShiftType(_event.data.id);
      }
      if (_event.actionType === 'EDIT') {
        this.shiftTypeModalOpen(_event.data.id);
      }
    }
  }

  onChangeTiming(_event: any) {
    this.masterSearchRequest.page = _event.page;
    this.masterSearchRequest.limit = _event.limit;
    this.getShiftTimingList();
  }

  onChangeType(_event: any) {
    this.masterSearchRequest.page = _event.page;
    this.masterSearchRequest.limit = _event.limit;
    this.getShiftTypeList();
  }

  getShiftTypeList() {
    HBLoaderService.showLoader();
    this.masterSearchRequest.searchFor = this.searchName;
    this.masterSearchRequest.catCode = AppConst.MASTER_CODE.SHIFT_TYPE;
    this.masterOptionService.getListMasterOption(this.masterSearchRequest).subscribe(response => {
      console.log(response);
      if (response.status === 200 && response.data && response.data.masterOption) {
        this.dataType = response.data.masterOption.list;
        this.totalType = response.data.masterOption.totalRowCount;
        HBLoaderService.hideLoader();
      } else {
        this.dataType = new Array<MasterOption>();
        this.totalType = response.data.masterOption.totalRowCount;
        HBLoaderService.hideLoader();
      }
    });
  }

  getShiftTimingList() {
    HBLoaderService.showLoader();
    this.masterSearchRequest.searchFor = this.searchName;
    this.masterSearchRequest.catCode = AppConst.MASTER_CODE.SHIFT_TIMING;
    this.masterOptionService.getListMasterOption(this.masterSearchRequest).subscribe(response => {
      console.log(response);
      if (response.status === 200 && response.data && response.data.masterOption) {
        this.dataTiming = response.data.masterOption.list;
        this.totalTiming = response.data.masterOption.totalRowCount;
        HBLoaderService.hideLoader();
      } else {
        this.dataTiming = new Array<MasterOption>();
        this.totalTiming = response.data.masterOption.totalRowCount;
        HBLoaderService.hideLoader();
      }
    });
    HBLoaderService.hideLoader();
  }


  shiftTimingModalOpen(data: any = null) {
    this.hbErrorHandler.clearErrors()
    if (data) {
      this.getShift(data);
      this.shiftTimingModal = true;
    } else {
      this.shift = new MasterOption();
      this.startTime = null
      this.endTime = null
      this.radioType = 'Fixed'
      this.shiftTimingModal = true;
    }
  }

  shiftTypeModalOpen(data: any = null) {
    this.hbErrorHandler.clearErrors()
    if (data) {
      this.getShift(data);
      this.shiftTypeModal = true;
    } else {
      this.shift = new MasterOption();
      this.shiftTypeModal = true;
    }
  }

  getShift(id: any) {
    HBLoaderService.showLoader();
    this.masterOptionService.getMasterOptionById(id).subscribe(response => {
      if (response.status === 200 && response.data && response.data.masterOption) {
        this.shift = response.data.masterOption;
        this.startTime = new Date(this.shift.startTime);
        this.endTime = new Date(this.shift.endTime);
        if (!this.shift.fixedShiftFlag) {
          this.radioType = 'Flexible'
        } else {
          this.radioType = 'Fixed'
        }
        HBLoaderService.hideLoader();
      }
    });
  }

  validate(): void {
    if (this.shiftTypeModal) {
      if (!this.shift.name) {
        this.hbErrorHandler.emptyCheck(this.shift.name, 'name');
      }
    }
    if (this.shiftTimingModal) {
      // if (!this.shift.parentId && !this.shift.startTime && !this.shift.endTime) {
      //   this.hbErrorHandler.emptyCheemptyCheckck(this.shift.parentId, 'type');
      //   this.hbErrorHandler.(this.startTime, 'startTime')
      //   this.hbErrorHandler.emptyCheck(this.endTime, 'endTime')
      // }
      if (!this.shift.parentId) {
        this.hbErrorHandler.emptyCheck(this.shift.parentId, 'type')
      }
    }
  }

  close() {
    this.shiftTypeModal = false;
    this.shiftTimingModal = false;
  }

  addUpdateShift(doc: string) {
    this.hbErrorHandler.clearErrors()
    this.validate();
    if (!this.hbErrorHandler.invalid) {
      if (!this.shift.id) {
        HBLoaderService.showLoader();
        if (doc === 'shiftTiming') {
          this.shift.catCode = AppConst.MASTER_CODE.SHIFT_TIMING;
          this.calculateWorkingTime()
          this.shift.startTime = this.startTime.getTime().toString()
          this.shift.endTime = this.endTime.getTime().toString()
          if (this.radioType === "Fixed") {
            this.shift.fixedShiftFlag = true
          } else {
            this.shift.shiftStartTolerance = null
            this.shift.shiftEndTolerance = null
          }
        } else if (doc === 'shiftType') {
          this.shift.catCode = AppConst.MASTER_CODE.SHIFT_TYPE;
        }
        this.masterOptionService.addMasterOption(this.shift).subscribe(response => {
          console.log(response);
          if (response.status === 200 && response.data && response.data.masterOption) {
            if (doc === 'shiftTiming') {
              this.confirmationPopup(response.message, 'Shift Timing', 'timing')
            } else if (doc === 'shiftType') {
              this.confirmationPopup(response.message, 'Shift Type', 'type')
            }
            HBLoaderService.hideLoader();
          }
        });
      } else {
        HBLoaderService.showLoader();
        if (doc === 'shiftTiming') {
          this.shift.startTime = this.startTime.getTime().toString()
          this.shift.endTime = this.endTime.getTime().toString()
          this.calculateWorkingTime()
          if (this.radioType === "Fixed") {
            this.shift.fixedShiftFlag = true
          } else {
            this.shift.fixedShiftFlag = false
            this.shift.shiftStartTolerance = null
            this.shift.shiftEndTolerance = null
          }
        }
        this.masterOptionService.updateMasterOption(this.shift).subscribe(response => {
          console.log(response);
          if (response.status === 200 && response.data && response.data.masterOption) {
            if (doc === 'shiftTiming') {
              this.confirmationPopup(response.message, 'Shift Timing', 'timing')
            } else if (doc === 'shiftType') {
              this.confirmationPopup(response.message, 'Shift Type', 'type')
            }
            HBLoaderService.hideLoader();
          }
        });
      }
    }
  }

  errorHandler(parentkey: string, childkey?: string, keyIndex?: number): HbErrorHandlerData {
    const hData = this.hbErrorHandler.getErrorHandlerData(parentkey, childkey, keyIndex);
    return hData;
  }

  confirmationPopup(message: any, title: string, code: string) {
    Swal.fire({
      title,
      html: message,
      icon: 'success',
      allowOutsideClick: false,
      allowEscapeKey: false,
    }).then(result => {
      if (result.value) {
        switch (code) {
          case 'timing':
            this.getShiftTimingList();
            break;
          case 'type':
            this.getShiftTypeList();
            break;
        }
      }
      this.close()
    });
  }

  radioType = 'Fixed';
  radio = [
    { label: 'Fixed', code: 'Fixed', id: undefined, value: undefined },
    { label: 'Flexible', code: 'Flexible', id: undefined, value: undefined },
  ];

  calculateWorkingTime() {
    if (this.endTime < this.startTime) {
      this.endTime.setDate(this.endTime.getDate() + 1);
    }
    this.shift.workingHours = +((this.endTime.getTime() - this.startTime.getTime()) / (1000 * 60 * 60)).toFixed(2);
  }
}
