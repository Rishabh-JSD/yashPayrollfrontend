import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { DashboardComponent } from './dashboard/dashboard.component';
import { LayoutPayrollComponent } from './layout-payroll/layout-payroll.component';
import { SharedModule } from '../shared/shared.module';
import { HeaderPayrollComponent } from './layout-payroll/header-payroll/header-payroll.component';
import { ContentSliderComponent } from './dashboard/content-slider/content-slider.component';


const routing: Routes = [
  {
    path: '',
    component: LayoutPayrollComponent,
    children: [
      { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
      { path: 'dashboard', component: DashboardComponent, pathMatch: 'full' },
      { path: 'company', loadChildren: () => import('./company/company.module').then(mod => mod.CompanyModule), },
      { path: 'employee', loadChildren: () => import('./employee/employee.module').then(mod => mod.EmployeeModule), },
      { path: 'user', loadChildren: () => import('./../users/users.module').then(mod => mod.UsersModule), },
      { path: 'branch', loadChildren: () => import('./company/company.module').then(mod => mod.CompanyModule), },
      { path: 'leave', loadChildren: () => import('./leave/leave.module').then(mod => mod.LeaveModule), },
      { path: 'settings', loadChildren: () => import('./../settings/settings.module').then(mod => mod.SettingsModule), },
      { path: 'master-rules', loadChildren: () => import('./master-rules/master-rules.module').then(mod => mod.MasterRulesModule), },
      { path: 'salary', loadChildren: () => import('./salary/salary.module').then(mod => mod.SalaryModule), },
      { path: 'payrun', loadChildren: () => import('./payrun/payrun.module').then(mod => mod.PayrunModule), },
      { path: 'pending', loadChildren: () => import('./pending-request/pending-request.module').then(mod => mod.PendingRequestModule), },
      { path: 'applied', loadChildren: () => import('./applied/applied.module').then(mod => mod.AppliedModule), },
      { path: 'reports', loadChildren: () => import('./../reports/reports.module').then(mod => mod.ReportsModule), },
      { path: 'attendance-management', loadChildren: () => import('./attendance-management/attendance-management.module').then(mod => mod.AttendanceManagementModule), },
      { path: 'importMaster', loadChildren: () => import('./import/import.module').then(mod => mod.ImportModule), },
    ]
  },
];

@NgModule({
  declarations: [
    DashboardComponent,
    LayoutPayrollComponent,
    ContentSliderComponent,
    HeaderPayrollComponent
  ],
  imports: [
    CommonModule,
    SharedModule,
    RouterModule.forChild(routing)
  ]
})
export class  PayrollModule {
}
