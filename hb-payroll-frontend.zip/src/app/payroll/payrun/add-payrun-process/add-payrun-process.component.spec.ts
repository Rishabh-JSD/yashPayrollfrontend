import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddPayrunProcessComponent } from './add-payrun-process.component';

describe('AddPayrunProcessComponent', () => {
  let component: AddPayrunProcessComponent;
  let fixture: ComponentFixture<AddPayrunProcessComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [AddPayrunProcessComponent]
    })
      .compileComponents();

    fixture = TestBed.createComponent(AddPayrunProcessComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
