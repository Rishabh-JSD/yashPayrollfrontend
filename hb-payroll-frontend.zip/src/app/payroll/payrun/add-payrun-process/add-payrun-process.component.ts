import { Component } from '@angular/core';
import { Location } from '@angular/common';

@Component({
  selector: 'app-add-payrun-process',
  templateUrl: './add-payrun-process.component.html',
  styleUrls: ['./add-payrun-process.component.scss']
})
export class AddPayrunProcessComponent {

  data = [{}];


  constructor(private _location: Location) { }


  back() {
    this._location.back();
  }
}
