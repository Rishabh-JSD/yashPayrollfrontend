import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddPayrunComponent } from './add-payrun.component';

describe('AddPayrunComponent', () => {
  let component: AddPayrunComponent;
  let fixture: ComponentFixture<AddPayrunComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [AddPayrunComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddPayrunComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
