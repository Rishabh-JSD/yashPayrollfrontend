import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';

@Component({
  selector: 'app-add-payrun',
  templateUrl: './add-payrun.component.html',
  styleUrls: ['./add-payrun.component.scss']
})
export class AddPayrunComponent implements OnInit {
  data = [{}];
  dataEdit = [{}];
  editPayrunModal = false;

  constructor(private _location: Location) { }

  ngOnInit(): void {

    this.data = [{}];
    this.dataEdit = [{}];
  }

  back() {
    this._location.back();
  }

  editModalOpen() {
    this.editPayrunModal = !this.editPayrunModal;
  }
}
