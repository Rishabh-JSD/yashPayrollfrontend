import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employee-payment',
  templateUrl: './employee-payment.component.html',
  styleUrls: ['./employee-payment.component.scss']
})
export class EmployeePaymentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
