import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-payroll-setup',
  templateUrl: './payroll-setup.component.html',
  styleUrls: ['./payroll-setup.component.scss']
})
export class PayrollSetupComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
