import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PayrunListingComponent } from './payrun-listing.component';

describe('PayrunListingComponent', () => {
  let component: PayrunListingComponent;
  let fixture: ComponentFixture<PayrunListingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [PayrunListingComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PayrunListingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
