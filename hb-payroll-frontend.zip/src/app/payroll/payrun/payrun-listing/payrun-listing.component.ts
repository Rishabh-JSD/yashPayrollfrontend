import { Component, OnInit } from '@angular/core';
import { HbDataTableColumnOption } from '@hostbooks/hb-lib/hb-list-table/src/hb-list-table-columns';
import { PayrunListing } from './payrun-listing';

@Component({
  selector: 'app-payrun-listing',
  templateUrl: './payrun-listing.component.html',
  styleUrls: ['./payrun-listing.component.scss']
})
export class PayrunListingComponent implements OnInit {

  columns: HbDataTableColumnOption[] = [];
  data: PayrunListing[] = [];
  total: number;
  runPayrunModal = false;
  settingModal = false;

  dataSource = [
    {
      s_no: 1,
      period: 'April 1, 2021 to April 30, 2021',
      refer: 'PR-00002',
      date: 'May 1, 2021',
      noEmp: '150',
      empPay: '3456789',
      otherPay: '9456789',
      total: '456738398000',
      status: 'paid',
      action: ''

    },
  ];

  constructor() { }

  ngOnInit(): void {
    this.data = this.dataSource;
    this.total = this.data.length;
    this.columns = [
      {
        header: 'S. No.',
        columnData: (inv: PayrunListing) => {
          return 's_no';
        },
        type: 'SR_NO'
      },
      {
        header: 'Pay Period',
        columnData: (inv: PayrunListing) => {
          return inv.period;
        },
        type: 'DATE'
      },
      {
        header: 'Reference',
        columnData: (inv: PayrunListing) => {
          return inv.refer;
        },
        type: 'TEXT'
      },
      {
        header: 'Payroll Date',
        columnData: (inv: PayrunListing) => {
          return inv.date;
        },
        type: 'DATE'
      },
      {
        header: 'No of Employee',
        columnData: (inv: PayrunListing) => {
          return inv.noEmp;
        },
        type: 'NUMBER'
      },
      {
        header: 'Employee Payments',
        columnData: (inv: PayrunListing) => {
          return inv.empPay;
        },
        type: 'NUMBER'
      },
      {
        header: 'Other Payments',
        columnData: (inv: PayrunListing) => {
          return inv.otherPay;
        },
        type: 'NUMBER'
      },
      {
        header: 'Total',
        columnData: (inv: PayrunListing) => {
          return inv.total;
        },
        type: 'NUMBER'
      },
      {
        header: 'Status',
        columnData: (inv: PayrunListing) => {
          return inv.status;
        },
        type: 'TEXT'
      },
      {
        header: 'Actions',
        columnData: (inv: PayrunListing) => {
          return 'actions';
        },
        type: 'ACTION',
        actionOptions: ['EDIT', 'DELETE']
      },
    ];
  }


  settingModalOpen() {
    this.settingModal = !this.settingModal;
  }

  runPayrunModalOpen() {
    this.runPayrunModal = !this.runPayrunModal;
  }


}
