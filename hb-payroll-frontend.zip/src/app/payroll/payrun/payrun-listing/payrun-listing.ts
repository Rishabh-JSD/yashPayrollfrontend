export class PayrunListing {
  public s_no: any;
  public period: any;
  public refer: any;
  public date: any;
  public noEmp: any;
  public empPay: any;
  public otherPay: any;
  public total: any;
  public status: any;
  public action: any;
}
