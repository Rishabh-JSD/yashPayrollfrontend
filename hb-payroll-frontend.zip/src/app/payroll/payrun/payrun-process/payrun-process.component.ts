import { Component } from '@angular/core';
import { Location } from '@angular/common';
import { HbDataTableColumnOption } from '@hostbooks/hb-lib/hb-list-table/src/hb-list-table-columns';

@Component({
  selector: 'app-payrun-process',
  templateUrl: './payrun-process.component.html',
  styleUrls: ['./payrun-process.component.scss']
})
export class PayrunProcessComponent {

  columns: HbDataTableColumnOption[] = [];
  data: any[] = [];
  total: number;
  dataSource = [];


  constructor(private _location: Location) { }

  ngOnInit(): void {
    this.data = this.dataSource;
    this.total = this.data.length;
    this.columns = [
      {
        header: 'Year',
        columnData: () => { },
        type: 'TEXT'
      },
      {
        header: 'Month',
        columnData: () => { },
        type: 'TEXT'
      },
      {
        header: 'Start Date',
        columnData: () => { },
        type: 'DATE'
      },
      {
        header: 'End Date',
        columnData: () => { },
        type: 'DATE'
      },
      {
        header: 'Total Employees',
        columnData: () => { },
        type: 'NUMBER'
      },
      {
        header: 'Payroll Cost',
        columnData: () => { },
        type: 'NUMBER'
      },
      {
        header: 'Taxes',
        columnData: () => { },
        type: 'NUMBER'
      },
      {
        header: 'Net Pay',
        columnData: () => { },
        type: 'NUMBER'
      },
    ];
  }


  back() {
    this._location.back();
  }


}
