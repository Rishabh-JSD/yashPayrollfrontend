import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../../shared/shared.module';

import { PayrollSetupComponent } from './payroll-setup/payroll-setup.component';
import { AddPayrunComponent } from './add-payrun/add-payrun.component';
import { PayrunListingComponent } from './payrun-listing/payrun-listing.component';
import { EmployeePaymentComponent } from './employee-payment/employee-payment.component';
import { PayrunProcessComponent } from './payrun-process/payrun-process.component';
import { AddPayrunProcessComponent } from './add-payrun-process/add-payrun-process.component';

const routes: Routes = [

  { path: '', component: PayrunListingComponent },
  { path: 'add-payrun', component: AddPayrunComponent },
  { path: 'payrun', component: PayrunListingComponent },
  { path: 'emp-payment', component: EmployeePaymentComponent },
  { path: 'payrun-process', component: PayrunProcessComponent },
  { path: 'add-payrun-process', component: AddPayrunProcessComponent },

  { path: 'payroll-setup', component: PayrollSetupComponent },


  { path: '**', redirectTo: '', pathMatch: 'full' }
];

@NgModule({
  declarations: [
    PayrollSetupComponent,
    AddPayrunComponent,
    PayrunListingComponent,
    EmployeePaymentComponent,
    PayrunProcessComponent,
    AddPayrunProcessComponent
  ],
  imports: [
    CommonModule,
    SharedModule,

    RouterModule.forChild(routes)
  ]
})
export class PayrunModule {
}
