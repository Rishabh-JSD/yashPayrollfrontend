import { Component, OnInit } from '@angular/core';
import { DropDownModel } from '../../../shared/models/hb-field-option';
import { HbDataTableColumnOption } from '@hostbooks/hb-lib/hb-list-table/src/hb-list-table-columns';
import { LeaveListing } from './leave';
import { HbDateFormatPipe } from '../../../shared/pipes/hb-date-format.pipe';

@Component({
  selector: 'app-leave',
  templateUrl: './leave.component.html',
  styleUrls: ['./leave.component.scss'],
  providers: [HbDateFormatPipe]
})
export class LeaveComponent implements OnInit {


  columns: HbDataTableColumnOption[] = [];
  data: LeaveListing[] = [];
  total: number;

  dataSource = [
    {
      s_no: 1,
      check: '',
      emp_name: 'Jyoti',
      leaveType: 'CL',
      from: '09-08-2021',
      to: '10-08-2021',
      noOfDays: '1',
      reason: 'Not Well',
    },
  ];

  Employee: DropDownModel[] = [
    { label: '1', code: '1', id: undefined, value: undefined },
  ];

  constructor(private datePipe: HbDateFormatPipe) { }

  ngOnInit(): void {
    this.data = this.dataSource;
    this.total = this.data.length;
    this.columns = [
      {
        header: 'S. No.',
        columnData: (inv: LeaveListing) => {
          return 's_no';
        },
        type: 'SR_NO'
      },
      {
        header: 'check',
        columnData: (inv: LeaveListing) => {
          return 'check';
        },
        type: 'CHECK'
      },
      {
        header: 'Employee Name',
        columnData: (inv: LeaveListing) => {
          return inv.emp_name;
        },
        type: 'TEXT'
      },
      {
        header: 'Leave Type',
        columnData: (inv: LeaveListing) => {
          return inv.leaveType;
        },
        type: 'TEXT'
      },
      {
        header: 'From',
        columnData: (inv: LeaveListing) => {
          return this.datePipe.transform(inv.from);
        },
        type: 'DATE'
      },
      {
        header: 'To',
        columnData: (inv: LeaveListing) => {
          return this.datePipe.transform(inv.to);
        },
        type: 'DATE'
      },
      {
        header: 'Number of Days',
        columnData: (inv: LeaveListing) => {
          return inv.noOfDays;
        },
        type: 'NUMBER'
      },
      {
        header: 'Reason',
        columnData: (inv: LeaveListing) => {
          return inv.reason;
        },
        type: 'TEXT'
      },
    ];
  }

}
