export class LeaveListing {
  public s_no: any;
  public check: any;
  public emp_name: any;
  public leaveType: any;
  public from: any;
  public to: any;
  public noOfDays: any;
  public reason: any;
}
