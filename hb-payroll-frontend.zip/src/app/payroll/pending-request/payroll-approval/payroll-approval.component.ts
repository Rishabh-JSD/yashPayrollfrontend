import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-payroll-approval',
  templateUrl: './payroll-approval.component.html',
  styleUrls: ['./payroll-approval.component.scss']
})
export class PayrollApprovalComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
