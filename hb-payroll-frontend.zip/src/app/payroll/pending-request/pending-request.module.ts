import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RegularisationComponent } from './regularisation/regularisation.component';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../../shared/shared.module';
import { LeaveComponent } from './leave/leave.component';
import { PayrollApprovalComponent } from './payroll-approval/payroll-approval.component';


const routes: Routes = [

  { path: 'regularisation', component: RegularisationComponent },
  { path: 'leave', component: LeaveComponent },
  { path: 'payroll-approval', component: PayrollApprovalComponent },


  { path: '**', redirectTo: '', pathMatch: 'full' }
];


@NgModule({
  declarations: [
    RegularisationComponent,
    LeaveComponent,
    PayrollApprovalComponent
  ],
  imports: [
    CommonModule,
    SharedModule,

    RouterModule.forChild(routes)
  ]
})
export class PendingRequestModule {
}
