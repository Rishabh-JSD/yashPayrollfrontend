import { Component, OnInit } from '@angular/core';
import { DropDownModel } from '../../../shared/models/hb-field-option';
import { HbDataTableColumnOption } from '@hostbooks/hb-lib/hb-list-table/src/hb-list-table-columns';
import { RegularisationListing } from './regularisation';
import { HbDateFormatPipe } from '../../../shared/pipes/hb-date-format.pipe';

@Component({
  selector: 'app-regularisation',
  templateUrl: './regularisation.component.html',
  styleUrls: ['./regularisation.component.scss'],
  providers: [HbDateFormatPipe]
})
export class RegularisationComponent implements OnInit {

  total: number;
  columns: HbDataTableColumnOption[] = [];
  data: RegularisationListing[] = [];

  dataSource = [
    {
      s_no: 1,
      check: '',
      emp_name: 'Jyoti',
      date: '09-08-2021',
      regularFor: 'Both',
      checkIn: '10:00',
      checkOut: '08:00',
      reason: 'Not Well',
    },
  ];

  Employee: DropDownModel[] = [
    { label: '1', code: '1', id: undefined, value: undefined },
  ];

  constructor(private datePipe: HbDateFormatPipe) { }

  ngOnInit(): void {
    this.data = this.dataSource;
    this.total = this.data.length;
    this.columns = [
      {
        header: 'S. No.',
        columnData: (inv: RegularisationListing) => {
          return 's_no';
        },
        type: 'SR_NO'
      },
      {
        header: 'check',
        columnData: (inv: RegularisationListing) => {
          return 'check';
        },
        type: 'CHECK'
      },
      {
        header: 'Employee Name',
        columnData: (inv: RegularisationListing) => {
          return inv.emp_name;
        },
        type: 'TEXT'
      },
      {
        header: 'Date',
        columnData: (inv: RegularisationListing) => {
          return this.datePipe.transform(inv.date);
        },
        type: 'DATE'
      },
      {
        header: 'Regularisation For',
        columnData: (inv: RegularisationListing) => {
          return inv.regularFor;
        },
        type: 'TEXT'
      },
      {
        header: 'Check-In',
        columnData: (inv: RegularisationListing) => {
          return inv.checkIn;
        },
        type: 'DATE'
      },
      {
        header: 'Check-Out',
        columnData: (inv: RegularisationListing) => {
          return inv.checkOut;
        },
        type: 'DATE'
      },
      {
        header: 'Reason',
        columnData: (inv: RegularisationListing) => {
          return inv.reason;
        },
        type: 'TEXT'
      },
    ];
  }

}
