export class RegularisationListing {
  public s_no: any;
  public check: any;
  public emp_name: any;
  public date: any;
  public regularFor: any;
  public checkIn: any;
  public checkOut: any;
  public reason: any;
}
