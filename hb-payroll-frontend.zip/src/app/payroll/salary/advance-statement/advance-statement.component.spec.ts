import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdvanceStatementComponent } from './advance-statement.component';

describe('AdvanceStatementComponent', () => {
  let component: AdvanceStatementComponent;
  let fixture: ComponentFixture<AdvanceStatementComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [AdvanceStatementComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdvanceStatementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
