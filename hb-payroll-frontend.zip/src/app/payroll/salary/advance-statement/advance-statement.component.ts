import { Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { HbDataTableColumnOption } from '@hostbooks/hb-lib/hb-list-table/src/hb-list-table-columns';
import { AdvanceStatementListing } from './advance-statement';
import { HbDateFormatPipe } from '../../../shared/pipes/hb-date-format.pipe';

@Component({
  selector: 'app-advance-statement',
  templateUrl: './advance-statement.component.html',
  styleUrls: ['./advance-statement.component.scss'],
  providers: [HbDateFormatPipe]
})
export class AdvanceStatementComponent implements OnInit {

  @ViewChild('avanceRequest') avanceRequest: TemplateRef<any> | undefined;
  dialogRef: MatDialogRef<any> | undefined;


  columns: HbDataTableColumnOption[] = [];
  data: AdvanceStatementListing[] = [];
  total: number;

  dataSource = [
    {
      s_no: 1,
      adAmt: '4000',
      dateOfAd: '03-12-21',
      formDate: '10-12-21',
      toDate: '12-12-21',
      noOfInstall: '6',
      installRecov: '3',
      amount_recov: '8900',
      balance: '7900',
      advanDetail: '',


    },
  ];

  constructor(public dialog: MatDialog, private datePipe: HbDateFormatPipe) { }

  ngOnInit(): void {
    this.data = this.dataSource;
    this.total = this.data.length;
    this.columns = [
      {
        header: 'S. No.',
        columnData: (inv: AdvanceStatementListing) => {
          return 'sno';
        },
        type: 'SR_NO'
      },
      {
        header: 'Advance Amount',
        columnData: (inv: AdvanceStatementListing) => {
          return inv.adAmt;
        },
        type: 'NUMBER'
      },
      {
        header: 'Date of Advance',
        columnData: (inv: AdvanceStatementListing) => {
          return this.datePipe.transform(inv.dateOfAd);
        },
        type: 'DATE'
      },
      {
        header: 'Start Date',
        columnData: (inv: AdvanceStatementListing) => {
          return this.datePipe.transform(inv.formDate);
        },
        type: 'DATE'
      },
      {
        header: 'End Date',
        columnData: (inv: AdvanceStatementListing) => {
          return this.datePipe.transform(inv.toDate);
        },
        type: 'DATE'
      },
      {
        header: 'Number of Installment',
        columnData: (inv: AdvanceStatementListing) => {
          return inv.noOfInstall;
        },
        type: 'NUMBER'
      },
      {
        header: 'Installments Recovered',
        columnData: (inv: AdvanceStatementListing) => {
          return inv.installRecov;
        },
        type: 'NUMBER'
      },
      {
        header: 'Amount Recovered',
        columnData: (inv: AdvanceStatementListing) => {
          return inv.amount_recov;
        },
        type: 'NUMBER'
      },
      {
        header: 'Balance',
        columnData: (inv: AdvanceStatementListing) => {
          return inv.balance;
        },
        type: 'NUMBER'
      },

      {
        header: 'Advance Detail',
        columnData: (inv: AdvanceStatementListing) => {
          return inv.advanDetail;
        },
        type: 'TEXT'
      },
      {
        header: 'Actions',
        columnData: (inv: AdvanceStatementListing) => {
          return 'actions';
        },
        type: 'ACTION',
        actionOptions: ['VIEW']
      },
    ];
  }

  openAdvancePopup(template: TemplateRef<any>): void {
    this.dialogRef = this.dialog.open(template, {
      minHeight: '150px',
      width: '400px',
    });

  }

  closeDialog(data: any = null): void {
    if (this.dialogRef) {
      this.dialogRef.close(data);
    }
  }
}
