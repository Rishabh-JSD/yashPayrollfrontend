export class AdvanceStatementListing {
  public s_no: any;
  public adAmt: any;
  public dateOfAd: any;
  public formDate: any;
  public toDate: any;
  public noOfInstall: any;
  public installRecov: any;
  public amount_recov: any;
  public balance: any;

  public advanDetail: any;
}
