import { Component, OnInit, TemplateRef } from '@angular/core';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { DropDownModel } from '../../../shared/models/hb-field-option';

@Component({
  selector: 'app-investment-proofs',
  templateUrl: './investment-proofs.component.html',
  styleUrls: ['./investment-proofs.component.scss']
})
export class InvestmentProofsComponent implements OnInit {


  dialogRef: MatDialogRef<any> | undefined;

  City: DropDownModel[] = [
    { label: 'option 1', code: 'option 1', id: undefined, value: undefined },
  ];
  Deduction: DropDownModel[] = [
    { label: 'option 1', code: 'option 1', id: undefined, value: undefined },
  ];
  HouseProperty: DropDownModel[] = [
    { label: 'option 1', code: 'option 1', id: undefined, value: undefined },
  ];

  constructor(public dialog: MatDialog) { }

  ngOnInit(): void {
  }

  openPopup(template: TemplateRef<any>): void {
    this.dialogRef = this.dialog.open(template, {
      minHeight: '200px',
      width: '800px',
    });

  }

  closeDialog(data: any = null): void {
    if (this.dialogRef) {
      this.dialogRef.close(data);
    }
  }

}
