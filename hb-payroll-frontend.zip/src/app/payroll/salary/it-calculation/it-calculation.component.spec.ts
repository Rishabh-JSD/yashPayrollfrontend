import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ItCalculationComponent } from './it-calculation.component';

describe('ItCalculationComponent', () => {
  let component: ItCalculationComponent;
  let fixture: ComponentFixture<ItCalculationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ItCalculationComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ItCalculationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
