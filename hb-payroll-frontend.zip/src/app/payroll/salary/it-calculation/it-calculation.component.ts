import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-it-calculation',
  templateUrl: './it-calculation.component.html',
  styleUrls: ['./it-calculation.component.scss']
})
export class ItCalculationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
