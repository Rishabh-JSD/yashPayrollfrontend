export class ReimbursementClaimSearch {
    page: number
    limit: number
    searchFor: string | undefined
    status:string
}