import { AppConst } from "src/app/core/constants/app-const";
import { Reimbursements } from "./remburishment-list";

export class ReimbursementClaim {
    id: number;
    branchId: number
    previousNumber: string
    overrideFlag: boolean;
    employeeId: string;
    claimNumber: string;
    displayStyle: number;
    currentNumber: string;
    claimDate: Date;
    amount: number;
    status: string = AppConst.REIMBURSEMENT_CLAIM_STATUS.DRAFT;
    reimbursements = new Array<Reimbursements>();
}