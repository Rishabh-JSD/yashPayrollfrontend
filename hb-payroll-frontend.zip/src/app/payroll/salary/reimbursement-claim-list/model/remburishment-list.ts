export class Reimbursements {
    id: number;
    reimbursementClaimId: number;
    description: string;
    date: Date;
    billRef: string;
    amount: number;
    approvedAmount: number;
    rejectedAmout: number;
    reimbursementMasterId: number
}