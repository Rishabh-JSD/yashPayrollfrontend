import { Component, OnInit } from '@angular/core';
import { ReimbursementClaim } from '../model/reimbursement-claim';
import { AppConst } from '../../../../core/constants/app-const';
import { Reimbursements } from '../model/remburishment-list';
import { ReimbursementClaimService } from '../service/reimbursement-service';
import { PopupService } from 'src/app/shared/services/popup.service';
import { MenuItem } from 'primeng/api';
import { DocumentSeriesResponse } from 'src/app/shared/models/document-series-response';
import { DocumentSeriesSettingService } from 'src/app/settings/document-series-setting/service/document-series-service';
import { ActivatedRoute, Router } from '@angular/router';
import { Location } from '@angular/common';
@Component({
  selector: 'app-reimbursement-claim',
  templateUrl: './reimbursement-claim.component.html',
  styleUrls: ['./reimbursement-claim.component.scss']
})
export class ReimbursementClaimComponent implements OnInit {

  reimbursementClaim = new ReimbursementClaim();
  REIMBURSEMENT = AppConst.MASTER_CODE.REIMBURSEMENT;
  REIMBURSEMENT_CLAIM_STATUS = AppConst.REIMBURSEMENT_CLAIM_STATUS;
  reimbursementOptions: MenuItem[];
  REIMBURSEMENT_CLAIM = AppConst.DOC_CODE.REIMBURSEMENT_CLAIM
  documentSeriesResponse = new DocumentSeriesResponse()
  reimbursementClaimId: number = 0;
  isEdit = false;

  constructor(private reimbursementClaimService: ReimbursementClaimService, private documentSeries: DocumentSeriesSettingService, private activtedRoute: ActivatedRoute, private location: Location, private router: Router) {
    this.reimbursementOptions = [
      {
        label: 'Save As Draft',
        command: () => {
          this.save(this.REIMBURSEMENT_CLAIM_STATUS.DRAFT);
        },
      },
      {
        label: 'Submit For Approval',
        command: () => {
          this.save(this.REIMBURSEMENT_CLAIM_STATUS.PENDING_APPROVAL);
        },
      },
      {
        label: 'Approve',
        command: () => {
          this.save(this.REIMBURSEMENT_CLAIM_STATUS.APPROVED);
        },
      }
    ];
  }

  ngOnInit() {
    this.activtedRoute.queryParams.subscribe(params => {
      if (params['reimbursementClaimId'] && !params['copy']) {
        this.reimbursementClaimId = +params['reimbursementClaimId'];
        this.getReimbursementClaimById();
      } else if (params['copy']) {
        this.reimbursementClaimId = +params['reimbursementClaimId'];
        this.getReimbursementClaimByCopy();
      } else {
        this.setOptions();
        this.reimbursementClaim.reimbursements.push(new Reimbursements());
      }
    })
  }

  onAdd() {
    this.reimbursementClaim.reimbursements.push(new Reimbursements());
  }

  goBack() {
    this.location.back();
  }

  saveReimbursementClaim() {
    if (!this.reimbursementClaim.id) {
      this.reimbursementClaimService.addReimbursementClaim(this.reimbursementClaim).subscribe(response => {
        if (response && response.status == 200 && response.data.reimbursementClaim) {
          PopupService.successAlert('ReimbursementClaim', 'Added SucessFully').then(result => {
            if (result) {
              this.router.navigateByUrl('/payroll/salary/reimburisement-claim-list')
            }
          });
        } else {
          PopupService.failedAlert('ReimbursementClaim', 'Failed');
        }
      })
    } else {
      this.reimbursementClaimService.updateReimbursementClaim(this.reimbursementClaim).subscribe(response => {
        if (response && response.status == 200 && response.data.reimbursementClaim) {
          PopupService.successAlert('ReimbursementClaim', 'Updated SucessFully').then(result => {
            if (result) {
              this.router.navigateByUrl('/payroll/salary/reimburisement-claim-list')
            }
          });
        } else {
          PopupService.failedAlert('ReimbursementClaim', 'Failed');
        }
      })
    }
  }

  save(type: string) {
    this.reimbursementClaim.status = type;
    this.saveReimbursementClaim();
  }


  getAutoCode() {
    if (this.reimbursementClaim.branchId) {
      this.documentSeries.getAutoSeriesByDocType(this.REIMBURSEMENT_CLAIM.trim(), this.reimbursementClaim.branchId).subscribe(response => {
        if (response && response.status == 200 && response.data.series != null) {
          this.documentSeriesResponse = response.data.series;
          if (this.isEdit && this.reimbursementClaim.claimNumber && this.reimbursementClaim.claimNumber !== response.data.documentSeries) {
            PopupService.confirmationAlert('Voucher Number', 'Voucher Number will be changed, Do you want to change?').then((result) => {
              if (result) {
                this.reimbursementClaim.claimNumber = this.documentSeriesResponse.seriesNumber;
                this.reimbursementClaim.previousNumber = this.reimbursementClaim.claimNumber;
                this.reimbursementClaim.overrideFlag = this.documentSeriesResponse.overrideFlag;
                this.reimbursementClaim.displayStyle = this.documentSeriesResponse.displayStyle;
                this.reimbursementClaim.currentNumber = this.documentSeriesResponse.currentNumber;
              }
            });
          } else {
            this.reimbursementClaim.claimNumber = this.documentSeriesResponse.seriesNumber;
            this.reimbursementClaim.previousNumber = this.reimbursementClaim.claimNumber;
            this.reimbursementClaim.overrideFlag = this.documentSeriesResponse.overrideFlag;
            this.reimbursementClaim.displayStyle = this.documentSeriesResponse.displayStyle;
            this.reimbursementClaim.currentNumber = this.documentSeriesResponse.currentNumber;
          }
        } else {
          this.reimbursementClaim.claimNumber = "";
          this.reimbursementClaim.overrideFlag = false;
          this.reimbursementClaim.displayStyle = null;
          this.reimbursementClaim.currentNumber = null;
        }
      });
    }
  }

  onClaimNumber() {
    if (this.reimbursementClaim.claimNumber === this.reimbursementClaim.previousNumber) {
      this.reimbursementClaim.displayStyle = this.documentSeriesResponse.displayStyle;
      this.reimbursementClaim.currentNumber = this.documentSeriesResponse.currentNumber;
    } else {
      this.reimbursementClaim.displayStyle = null;
      this.reimbursementClaim.currentNumber = null;
    }
  }

  setOptions() {
    if (this.reimbursementClaim.status == this.REIMBURSEMENT_CLAIM_STATUS.DRAFT) {
      this.reimbursementOptions.splice(2, 3);
    } else if (this.reimbursementClaim.status == this.REIMBURSEMENT_CLAIM_STATUS.PENDING_APPROVAL) {
      this.reimbursementOptions.splice(0, 1);
    } else if (this.reimbursementClaim.status == this.REIMBURSEMENT_CLAIM_STATUS.APPROVED) {
      this.reimbursementOptions.splice(0, 2);
    }
  }

  getReimbursementClaimById() {
    this.reimbursementClaimService.getReimbursementClaim(this.reimbursementClaimId).subscribe(response => {
      if (response && response.status == 200 && response.data.reimbursementClaim) {
        this.reimbursementClaim = response.data.reimbursementClaim;
        this.setOptions();
      } else {
        PopupService.failedAlert('ReimbursementClaim', 'Something Went Wrong');
      }
    })
  }

  getReimbursementClaimByCopy() {
    this.reimbursementClaimService.getReimbursementClaim(this.reimbursementClaimId).subscribe(response => {
      if (response && response.status == 200 && response.data.reimbursementClaim) {
        this.reimbursementClaim = response.data.reimbursementClaim;
        this.reimbursementClaim.id = null;
        this.reimbursementClaim.claimNumber = "";
        this.reimbursementClaim.overrideFlag = false;
        this.reimbursementClaim.displayStyle = null;
        this.reimbursementClaim.currentNumber = null;
        this.reimbursementClaim.status = this.REIMBURSEMENT_CLAIM_STATUS.DRAFT;
        if (this.reimbursementClaim.reimbursements) {
          this.reimbursementClaim.reimbursements.forEach(element => {
            element.id = null;
          });
        }
        this.setOptions();
        this.getAutoCode();
      } else {
        PopupService.failedAlert('ReimbursementClaim', 'Something Went Wrong');
      }
    })
  }



}
