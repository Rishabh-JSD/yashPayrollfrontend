import { Component, OnInit } from '@angular/core';
import { HbDataTableColumnOption } from '@hostbooks/hb-lib/hb-list-table/src/hb-list-table-columns';
import { ReimbursementClaim } from './model/reimbursement-claim';
import { ReimbursementClaimSearch } from './model/reimbursement-claim-search';
import { AppConst } from 'src/app/core/constants/app-const';
import { ReimbursementClaimService } from './service/reimbursement-service';
import { PopupService } from 'src/app/shared/services/popup.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-reimbursement-claim-list',
  templateUrl: './reimbursement-claim-list.component.html',
  styleUrls: ['./reimbursement-claim-list.component.scss']
})
export class ReimbursementClaimListComponent implements OnInit {

  total: number = 0;
  activeIndex: number = 0;
  scrollableTabs: any[] = [];
  columns: HbDataTableColumnOption[] = [];
  data = new Array<ReimbursementClaim>();
  searchRequest = new ReimbursementClaimSearch();
  REIMBURSEMENT_CLAIM_STATUS = AppConst.REIMBURSEMENT_CLAIM_STATUS;


  constructor(private reimbursementClaimService: ReimbursementClaimService, private router: Router) {
    this.setHeader();
  }

  ngOnInit() {
    this.columns = [
      {
        header: 'Employee Id',
        columnData: (rc: ReimbursementClaim) => {
          return rc.employeeId;
        },
        type: 'TEXT'
      },
      {
        header: 'Claim Number',
        columnData: (rc: ReimbursementClaim) => {
          return rc.claimNumber;
        },
        type: 'TEXT'
      },
      {
        header: 'Claim Date',
        columnData: (rc: ReimbursementClaim) => {
          return rc.claimDate;
        },
        type: 'DATE'
      },
      {
        header: 'Amount',
        columnData: (rc: ReimbursementClaim) => {
          return rc.amount;
        },
        type: 'NUMBER'
      },
      {
        header: 'Status',
        columnData: (rc: ReimbursementClaim) => {
          return rc.status;
        },
        type: 'TEXT'
      }, {
        header: 'Actions',
        columnData: (rc: ReimbursementClaim) => {
          return 'actions';
        },
        type: 'ACTION',
        actionOptions: ['VIEW', 'EDIT']
      },
    ];
    this.searchRequest.status =  this.REIMBURSEMENT_CLAIM_STATUS.DRAFT;
    this.getList();
  }

  setHeader() {
    let tabs = [];
    tabs.push({ title: "Draft", status: this.REIMBURSEMENT_CLAIM_STATUS.DRAFT });
    tabs.push({ title: "Pending Approval", status: this.REIMBURSEMENT_CLAIM_STATUS.PENDING_APPROVAL });
    tabs.push({ title: "Approved", status: this.REIMBURSEMENT_CLAIM_STATUS.APPROVED });
    tabs.push({ title: "Rejected", status: this.REIMBURSEMENT_CLAIM_STATUS.REJECTED });
    tabs.push({ title: "Withdrawn", status: this.REIMBURSEMENT_CLAIM_STATUS.WITHDRAWN });
    this.scrollableTabs = tabs;
  }

  onTabChange(event: any) {
    if (event && event.index >=0 ) {
      this.searchRequest.status = this.scrollableTabs[event.index].status;
      this.getList();
    }
  }

  getList() {
    this.reimbursementClaimService.getListReimbursementClaim(this.searchRequest).subscribe(response => {
      if (response && response.status == 200 && response.data.reimbursementClaim.list) {
        this.data = response.data.reimbursementClaim.list
      } else {
        PopupService.failedAlert("Reimbursement Claim", "Something Went Wrong");
      }
    })
  }

  onActions(event) {
    if (event && event.actionType == 'EDIT') {
      this.router.navigate(['/payroll/salary/reimburisement-claim-list/reimbursement-claim'], { queryParams: { reimbursementClaimId: event.data.id } });
    } else if (event && event.actionType == 'VIEW') {
      this.router.navigate(['/payroll/salary/reimburisement-claim-list/reimbursement-claim-view'], { queryParams: { reimbursementClaimId: event.data.id } });
    }
  }

}
