import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ReimbursementClaim } from '../model/reimbursement-claim';
import { AppConst } from 'src/app/core/constants/app-const';
import { MenuItem } from 'primeng/api';
import { ReimbursementClaimService } from '../service/reimbursement-service';
import { PopupService } from 'src/app/shared/services/popup.service';
import { Location } from '@angular/common';
import { HbDataTableColumnOption } from '@hostbooks/hb-lib/hb-list-table/src/hb-list-table-columns';
import { Reimbursements } from '../model/remburishment-list';

@Component({
  selector: 'app-reimbursement-claim-view',
  templateUrl: './reimbursement-claim-view.component.html',
  styleUrls: ['./reimbursement-claim-view.component.scss']
})
export class ReimbursementClaimViewComponent implements OnInit {


  reimbursementClaim = new ReimbursementClaim();
  REIMBURSEMENT = AppConst.MASTER_CODE.REIMBURSEMENT;
  REIMBURSEMENT_CLAIM_STATUS = AppConst.REIMBURSEMENT_CLAIM_STATUS;
  reimbursementOptions: MenuItem[];
  REIMBURSEMENT_CLAIM = AppConst.DOC_CODE.REIMBURSEMENT_CLAIM
  reimbursementClaimId: number;
  total: number;
  columns: HbDataTableColumnOption[] = [];
  data = new Array<Reimbursements>();

  constructor(private reimbursementClaimService: ReimbursementClaimService, private activtedRoute: ActivatedRoute, private location: Location, private router: Router) {
    this.reimbursementOptions = [
      {
        label: 'Edit',
        command: () => {
          this.chooseOptions("EDIT");
        },
      },
      {
        label: 'Copy',
        command: () => {
          this.chooseOptions("COPY");
        },
      },
      {
        label: 'Reject',
        command: () => {
          this.chooseOptions(this.REIMBURSEMENT_CLAIM_STATUS.REJECTED);
        },
      },
      {
        label: 'Withdraw',
        command: () => {
          this.chooseOptions(this.REIMBURSEMENT_CLAIM_STATUS.WITHDRAWN);
        },
      },
      {
        label: 'Approve',
        command: () => {
          this.chooseOptions(this.REIMBURSEMENT_CLAIM_STATUS.APPROVED);
        },
      },
      {
        label: 'Delete',
        command: () => {
          this.chooseOptions(this.REIMBURSEMENT_CLAIM_STATUS.DELETE);
        },
      },
    ];
  }
  ngOnInit() {
    this.activtedRoute.queryParams.subscribe(params => {
      if (params['reimbursementClaimId']) {
        this.reimbursementClaimId = +params['reimbursementClaimId'];
        this.getReimbursementClaimById();
      }
    })

    this.columns = [
      {
        header: 'Type of Reimbursement',
        columnData: (rc: Reimbursements) => {
          return rc.reimbursementMasterId;
        },
        type: 'TEXT'
      },
      {
        header: 'Description',
        columnData: (rc: Reimbursements) => {
          return rc.description;
        },
        type: 'TEXT'
      },
      {
        header: 'Date',
        columnData: (rc: Reimbursements) => {
          return rc.date;
        },
        type: 'DATE'
      },
      {
        header: 'Bill Ref',
        columnData: (rc: Reimbursements) => {
          return rc.billRef;
        },
        type: 'NUMBER'
      }
    ]
  }

  chooseOptions(status: string) {
    if (status === "EDIT") {
      this.router.navigate(['/payroll/salary/reimburisement-claim-list/reimbursement-claim'], { queryParams: { reimbursementClaimId: this.reimbursementClaim.id } });
    } else if (status === "COPY") {
      this.router.navigate(['/payroll/salary/reimburisement-claim-list/reimbursement-claim'], { queryParams: { copy: true, reimbursementClaimId: this.reimbursementClaim.id } });
    } else {
      this.reimbursementClaim.status = status;
      this.updateReimbursementClaim();
    }

  }

  goBack() {
    this.location.back();
  }


  setOptions() {
    if (this.reimbursementClaim.status == this.REIMBURSEMENT_CLAIM_STATUS.DRAFT) {
      this.reimbursementOptions.splice(2, 3);
    } else if (this.reimbursementClaim.status == this.REIMBURSEMENT_CLAIM_STATUS.APPROVED) {
      this.reimbursementOptions.splice(4, 4);
    } else if (this.reimbursementClaim.status == this.REIMBURSEMENT_CLAIM_STATUS.REJECTED) {
      this.reimbursementOptions.splice(4, 4);
    } else if (this.reimbursementClaim.status == this.REIMBURSEMENT_CLAIM_STATUS.WITHDRAWN) {
      this.reimbursementOptions.splice(4, 4);
    }
  }

  getReimbursementClaimById() {
    this.reimbursementClaimService.getReimbursementClaim(this.reimbursementClaimId).subscribe(response => {
      if (response && response.status == 200 && response.data.reimbursementClaim) {
        this.reimbursementClaim = response.data.reimbursementClaim;
        this.data = this.reimbursementClaim.reimbursements;
        this.setOptions();
      } else {
        PopupService.failedAlert('ReimbursementClaim', 'Something Went Wrong');
      }
    })
  }

  updateReimbursementClaim() {
    if (this.reimbursementClaim.id) {
      this.reimbursementClaimService.updateReimbursementClaim(this.reimbursementClaim).subscribe(response => {
        if (response && response.status == 200 && response.data.reimbursementClaim) {
          PopupService.successAlert('ReimbursementClaim', 'Updated SucessFully').then(result => {
            if (result) {
              this.router.navigateByUrl('/payroll/salary/reimburisement-claim-list');
            }
          });
        } else {
          PopupService.failedAlert('ReimbursementClaim', 'Failed');
        }
      })
    }
  }

}
