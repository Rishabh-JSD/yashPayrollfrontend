import { NgModule } from "@angular/core";
import { ReimbursementClaimListComponent } from "./reimbursement-claim-list.component";
import { RouterModule, Routes } from "@angular/router";
import { SharedModule } from "src/app/shared/shared.module";
import { CommonModule } from "@angular/common";
import { ReimbursementClaimComponent } from "./reimbursement-claim-edit/reimbursement-claim.component";
import { ReimbursementClaimViewComponent } from './reimbursement-claim-view/reimbursement-claim-view.component';

const routes: Routes = [

    { path: '', component: ReimbursementClaimListComponent },
    { path: 'reimbursement-claim-list', component: ReimbursementClaimListComponent },
    { path: 'reimbursement-claim', component: ReimbursementClaimComponent },
    { path: 'reimbursement-claim-view', component: ReimbursementClaimViewComponent },
    { path: '**', redirectTo: '', pathMatch: 'full' }
];

@NgModule({
    declarations: [
        ReimbursementClaimListComponent,
        ReimbursementClaimComponent,
        ReimbursementClaimViewComponent
    ],
    imports: [
        SharedModule,
        CommonModule,
        RouterModule.forChild(routes)
    ]
})
export class ReimbursementClaimModule {
}
