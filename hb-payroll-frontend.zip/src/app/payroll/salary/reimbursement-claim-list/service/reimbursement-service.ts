import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HBHttpService } from 'src/app/core/services/hb-http-service.service';

@Injectable({
  providedIn: 'root',
})
export class ReimbursementClaimService {
  constructor(private hbHttpClient: HBHttpService) {}

  addReimbursementClaim(data: any): Observable<any> {
    return this.hbHttpClient.getResponse('reimbursement-claim/add', this.hbHttpClient.POST, data);
  }

  updateReimbursementClaim(data: any): Observable<any> {
    return this.hbHttpClient.getResponse('reimbursement-claim/update', this.hbHttpClient.POST, data);
  }

  getListReimbursementClaim(data: any): Observable<any> {
    return this.hbHttpClient.getResponse('reimbursement-claim/list', this.hbHttpClient.POST, data);
  }

  getReimbursementClaim(id: any): Observable<any> {
    return this.hbHttpClient.getResponse(`reimbursement-claim/${ id }`, this.hbHttpClient.GET);
  }

  deleteReimbursementClaim(id: any): Observable<any> {
    return this.hbHttpClient.getResponse('reimbursement-claim/delete?reimbursementId=' + id, this.hbHttpClient.DELETE);
  }
}
