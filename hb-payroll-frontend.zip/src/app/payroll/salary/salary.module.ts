import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../../shared/shared.module';
import { ItCalculationComponent } from './it-calculation/it-calculation.component';
import { InvestmentProofsComponent } from './investment-proofs/investment-proofs.component';
import { AdvanceStatementComponent } from './advance-statement/advance-statement.component';

const routes: Routes = [

  { path: '', component: ItCalculationComponent },
  { path: 'it-calc', component: ItCalculationComponent },
  { path: 'inves-proof', component: InvestmentProofsComponent },
  { path: 'advance-statement', component: AdvanceStatementComponent },
  { path: 'reimburisement-claim-list', loadChildren: () => import('./reimbursement-claim-list/reimbursement-claim.module').then(mod => mod.ReimbursementClaimModule), },
  { path: '**', redirectTo: '', pathMatch: 'full' }
];

@NgModule({
  declarations: [
    ItCalculationComponent,
    InvestmentProofsComponent,
    AdvanceStatementComponent
  ],
  imports: [
    CommonModule,
    SharedModule,

    RouterModule.forChild(routes)
  ]
})
export class SalaryModule {
}
