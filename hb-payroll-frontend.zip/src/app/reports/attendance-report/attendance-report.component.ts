import { Component, OnInit } from '@angular/core';
import { DropDownModel } from '../../shared/models/hb-field-option';

@Component({
  selector: 'app-attendance-report',
  templateUrl: './attendance-report.component.html',
  styleUrls: ['./attendance-report.component.scss']
})
export class AttendanceReportComponent implements OnInit {

  Reports: DropDownModel[] = [
    { label: 'option 1', code: '1', id: undefined, value: undefined },
  ];
  Employee: DropDownModel[] = [
    { label: 'option 1', code: '1', id: undefined, value: undefined },
  ];

  constructor() { }

  ngOnInit(): void {
  }

}
