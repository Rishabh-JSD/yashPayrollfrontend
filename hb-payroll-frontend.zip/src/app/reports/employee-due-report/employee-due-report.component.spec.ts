import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployeeDueReportComponent } from './employee-due-report.component';

describe('EmployeeDueReportComponent', () => {
  let component: EmployeeDueReportComponent;
  let fixture: ComponentFixture<EmployeeDueReportComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [EmployeeDueReportComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EmployeeDueReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
