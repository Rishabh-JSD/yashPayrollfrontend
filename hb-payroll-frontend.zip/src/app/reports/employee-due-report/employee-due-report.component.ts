import { Component, OnInit } from '@angular/core';
import { DropDownModel } from '../../shared/models/hb-field-option';

@Component({
  selector: 'app-employee-due-report',
  templateUrl: './employee-due-report.component.html',
  styleUrls: ['./employee-due-report.component.scss']
})
export class EmployeeDueReportComponent implements OnInit {
  Reports: DropDownModel[] = [
    { label: 'option 1', code: '1', id: undefined, value: undefined },
  ];
  Employee: DropDownModel[] = [
    { label: 'option 1', code: '1', id: undefined, value: undefined },
  ];
  Amount: DropDownModel[] = [
    { label: 'Chocolate', code: 'Chocolate', id: undefined, value: undefined },
    { label: 'Coconut', code: 'Coconut', id: undefined, value: undefined },
    { label: 'Mint', code: 'Mint', id: undefined, value: undefined },
    { label: 'Strawberry', code: 'Strawberry', id: undefined, value: undefined },
    { label: 'Vanilla', code: 'Vanilla', id: undefined, value: undefined },
  ];

  constructor() { }

  ngOnInit(): void {
  }

}
