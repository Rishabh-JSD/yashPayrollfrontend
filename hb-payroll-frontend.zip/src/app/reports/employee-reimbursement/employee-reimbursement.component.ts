import { Component, OnInit } from '@angular/core';
import { DropDownModel } from '../../shared/models/hb-field-option';

@Component({
  selector: 'app-employee-reimbursement',
  templateUrl: './employee-reimbursement.component.html',
  styleUrls: ['./employee-reimbursement.component.scss']
})
export class EmployeeReimbursementComponent implements OnInit {
  Reports: DropDownModel[] = [
    { label: 'option 1', code: '1', id: undefined, value: undefined },
  ];
  Employee: DropDownModel[] = [
    { label: 'option 1', code: '1', id: undefined, value: undefined },
  ];
  Amount: DropDownModel[] = [
    { label: '1000', code: '1000', id: undefined, value: undefined },
    { label: '20000', code: '20000', id: undefined, value: undefined },
    { label: '678788', code: '678788', id: undefined, value: undefined },
    { label: '12343', code: '12343', id: undefined, value: undefined },
    { label: '432', code: '432', id: undefined, value: undefined },
  ];

  constructor() { }

  ngOnInit(): void {
  }

}
