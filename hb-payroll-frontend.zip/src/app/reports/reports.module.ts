import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../shared/shared.module';

import { AttendanceReportComponent } from './attendance-report/attendance-report.component';
import { EmployeeDueReportComponent } from './employee-due-report/employee-due-report.component';
import { TaxesDueComponent } from './taxes-due/taxes-due.component';
import { EmployeeAdvancesComponent } from './employee-advances/employee-advances.component';
import { EmployeeReimbursementComponent } from './employee-reimbursement/employee-reimbursement.component';

const routes: Routes = [

  { path: 'attendance', component: AttendanceReportComponent },
  { path: 'emp-due', component: EmployeeDueReportComponent },
  { path: 'tax-due', component: TaxesDueComponent },

  { path: 'emp-advances', component: EmployeeAdvancesComponent },

  { path: 'emp-reimburse', component: EmployeeReimbursementComponent },


  { path: '**', redirectTo: '', pathMatch: 'full' }
];

@NgModule({
  declarations: [
    AttendanceReportComponent,
    EmployeeDueReportComponent,
    TaxesDueComponent,
    EmployeeAdvancesComponent,
    EmployeeReimbursementComponent
  ],
  imports: [
    CommonModule,
    SharedModule,
    RouterModule.forChild(routes)
  ]
})
export class ReportsModule {
}
