import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TaxesDueComponent } from './taxes-due.component';

describe('TaxesDueComponent', () => {
  let component: TaxesDueComponent;
  let fixture: ComponentFixture<TaxesDueComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [TaxesDueComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TaxesDueComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
