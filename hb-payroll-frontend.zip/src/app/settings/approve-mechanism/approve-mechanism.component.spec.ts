import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ApproveMechanismComponent } from './approve-mechanism.component';

describe('ApproveMechanismComponent', () => {
  let component: ApproveMechanismComponent;
  let fixture: ComponentFixture<ApproveMechanismComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ApproveMechanismComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ApproveMechanismComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
