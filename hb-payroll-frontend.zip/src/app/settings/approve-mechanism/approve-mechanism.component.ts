import { Component, OnInit } from '@angular/core';
import { HbDataTableColumnOption } from '@hostbooks/hb-lib/hb-list-table/src/hb-list-table-columns';
import { ApproveListing } from './approve-mechanism';

@Component({
  selector: 'app-approve-mechanism',
  templateUrl: './approve-mechanism.component.html',
  styleUrls: ['./approve-mechanism.component.scss']
})
export class ApproveMechanismComponent implements OnInit {

  columns: HbDataTableColumnOption[] = [];
  data: ApproveListing[] = [];
  total: number;
  dataSource = [
    {
      s_no: 1,
      check: '',
      type: 'Advance',
      enterBy: 'Director',
      level1: '3',
      level2: '3',
      level3: '3',

      actions: '',
    },
    {
      s_no: 2,
      check: '',
      type: 'Pay Run',
      enterBy: 'Director',
      level1: '3',
      level2: '3',
      level3: '3',

      actions: '',
    },
  ];

  constructor() { }

  ngOnInit(): void {
    this.data = this.dataSource;
    this.total = this.data.length;
    this.columns = [
      {
        header: 'S. No.',
        columnData: (inv: ApproveListing) => {
          return 's_no';
        },
        type: 'SR_NO'
      },
      {
        header: 'check',
        columnData: (inv: ApproveListing) => {
          return 'check';
        },
        type: 'CHECK'
      },
      {
        header: 'Type',
        columnData: (inv: ApproveListing) => {
          return inv.type;
        },
        type: 'TEXT'
      },
      {
        header: 'To Be Enter By',
        columnData: (inv: ApproveListing) => {
          return inv.enterBy;
        },
        type: 'TEXT'
      },
      {
        header: 'Level 1 Approval',
        columnData: (inv: ApproveListing) => {
          return inv.level1;
        },
        type: 'NUMBER'
      },
      {
        header: 'Level 2 Approval',
        columnData: (inv: ApproveListing) => {
          return inv.level2;
        },
        type: 'NUMBER'
      },
      {
        header: 'Level 3 Approval',
        columnData: (inv: ApproveListing) => {
          return inv.level3;
        },
        type: 'NUMBER'
      },
      {
        header: 'Actions',
        columnData: (inv: ApproveListing) => {
          return 'actions';
        },
        type: 'ACTION',
        actionOptions: ['EDIT', 'DELETE']
      },
    ];
  }

}
