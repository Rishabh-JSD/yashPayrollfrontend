export class ApproveListing {
  public s_no: any;
  public type: any;
  public enterBy: any;
  public level1: any;
  public level2: any;
  public level3: any;
  public actions: any;
}
