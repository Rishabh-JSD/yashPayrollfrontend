import { Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { DocumentSeriesSetting } from 'src/app/shared/models/document-series-setting';
import { DocumentSeriesSettingService } from './service/document-series-service';
import { DropDownModel, DropDownOption } from 'src/app/shared/models/hb-field-option';
import { Router } from '@angular/router';
import { PopupService } from 'src/app/shared/services/popup.service';
import { HbErrorHandler, HbErrorHandlerData } from 'src/app/shared/models/hb-error-handler';
import { forkJoin } from 'rxjs';
import { Branch } from 'src/app/payroll/company/models/branch';
import { BranchService } from 'src/app/payroll/company/services/branch.service';
import { PaginationCriteria } from 'src/app/core/models/pagination-criteria';
@Component({
  selector: 'app-document-series-setting',
  templateUrl: './document-series-setting.component.html',
  styleUrls: ['./document-series-setting.component.scss']
})
export class DocumentSeriesSettingComponent implements OnInit {



  constructor(private location: Location, private documentSeriesSettingService: DocumentSeriesSettingService, private router: Router, private branchService: BranchService) { }
  documentSeries = new DocumentSeriesSetting();
  statusDropdownOptions: DropDownModel[] = [];
  docTypeOptions: DropDownModel[] = [];
  hbErrorHandler: HbErrorHandler = new HbErrorHandler();
  docType = "EMP";
  displayStyles: any[] = new Array<any>();
  branchList = new Array<Branch>();
  paginationCriteriaBranch = new PaginationCriteria();
  branchDropDownOptions: DropDownModel[] = [];
  overrideFlag: boolean = false;

  ngOnInit() {
    this.paginationCriteriaBranch.searchFor = "";
    this.getAllData();
    this.setStatus();
    this.setDocType();
  }

  back() {
    this.location.back();
  }

  saveDocumentSeries() {
    this.documentSeries.seriesId = null;
    this.documentSeries.docType = this.docType;
    this.validateData();
    if (!this.hbErrorHandler.invalid) {
      this.documentSeriesSettingService.addDocumentSeries(this.documentSeries).subscribe(response => {
        if (response && response.status == 200 && response.data.documentSeries) {
          this.documentSeries = response.data.documentSeries;
          PopupService.successAlert("Document Series", "Added SuccessFully").then(result => {
            if (result) {
              this.router.navigateByUrl('/company/department');
            }
          });
        } else {
          PopupService.failedAlert("Document Series", 'Imported Failed');
        }
      });
    }
  }

  setStatus() {
    this.statusDropdownOptions = this.statusDropdownOptions.concat(DropDownOption.fetchDropDownOptionByType('DOCUMENT_SERIES_STATUS'));
  }

  setDocType() {
    this.docTypeOptions = this.docTypeOptions.concat(DropDownOption.fetchDropDownOptionByType('DOC_TYPE'));
  }

  getDocumentSeries(response: any) {
    if (response && response.status == 200 && response.data.series) {
      this.documentSeries = response.data.series[0];
      this.overrideFlag = this.documentSeries.overrideFlag;
    } else {
      this.documentSeries = new DocumentSeriesSetting();
    }
  }

  errorHandler(parentkey: string, childkey?: string, keyIndex?: number): HbErrorHandlerData {
    const hData = this.hbErrorHandler.getErrorHandlerData(parentkey, childkey, keyIndex);
    return hData;
  }

  validateData() {
    this.hbErrorHandler.clearErrors();
    this.hbErrorHandler.emptyCheck(this.docType, 'docType');
    this.hbErrorHandler.emptyCheck(this.documentSeries.startDate, 'startDate');
    this.hbErrorHandler.emptyCheck(this.documentSeries.status, 'status');
    this.hbErrorHandler.emptyCheck(this.documentSeries.displayStyle, 'displayStyle');
    this.hbErrorHandler.emptyCheck(this.documentSeries.endNumber, 'endNumber');
    this.hbErrorHandler.emptyCheck(this.documentSeries.startNumber, 'startNumber');
    this.hbErrorHandler.emptyCheck(this.documentSeries.docType, 'docType');
    if (this.documentSeries.branchList.length == 0) {
      this.hbErrorHandler.addError('Please Select Branch', 'branchError');
    }
  }

  getDisplayStyleList(response: any) {
    this.displayStyles = []
    if (response && response.status == 200 && response.data.displayStyle) {
      response.data.displayStyle.forEach(element => {
        if (element) {
          let dropDown = {};
          // if(this.documentSeries.prefix){
          dropDown["id"] = element.id;
          dropDown["code"] = element.symbol;
          dropDown["displayStyle"] = element.name;
          if ((this.documentSeries.prefix == null || this.documentSeries.prefix === "") && element != null) {
            switch (dropDown["code"]) {
              case "/":
                dropDown["label"] = element.name.replace("prefix/", this.documentSeries.prefix);
                break;
              case "-":
                dropDown["label"] = element.name.replace("prefix-", this.documentSeries.prefix);
                break;
              default:
                dropDown["label"] = element.name.replace("prefix", this.documentSeries.prefix);
                break;
            }
          } else {
            dropDown["label"] = element.name.replace("prefix", this.documentSeries.prefix);
          }

          if ((this.documentSeries.suffix == null || this.documentSeries.suffix === "") && element != null) {
            switch (dropDown["code"]) {
              case "/":
                dropDown["label"] = dropDown["label"].replace("/suffix", this.documentSeries.suffix);
                dropDown["label"] = dropDown["label"].replace("suffix/", this.documentSeries.suffix);
                break;
              case "-":
                dropDown["label"] = dropDown["label"].replace("-suffix", this.documentSeries.suffix);
                dropDown["label"] = dropDown["label"].replace("suffix-", this.documentSeries.suffix);
                break;
              default:
                dropDown["label"] = dropDown["label"].replace("suffix", this.documentSeries.suffix);
                break;
            }
          } else {
            dropDown["label"] = dropDown["label"].replace("suffix", this.documentSeries.suffix);
          }
          dropDown["label"] = dropDown["label"].replace("startNum", this.documentSeries.startNumber);
          // }
          this.displayStyles.push(dropDown);
        }
      })
    }
  }

  getAllData() {
    forkJoin({
      documentSeries: this.documentSeriesSettingService.getDocumentSeriesList(this.docType),
      displayStyle: this.documentSeriesSettingService.getDisplayStyleList(),
      branchList: this.branchService.getListBranch(this.paginationCriteriaBranch)
    }).subscribe(
      ({
        documentSeries,
        displayStyle,
        branchList,
      }) => {
        this.getDocumentSeries(documentSeries);
        this.getDisplayStyleList(displayStyle);
        this.getBranchList(branchList);

      }
    );
  }

  onChange() {
    if (this.documentSeries.prefix && this.documentSeries.suffix && this.documentSeries.startNumber) {
      this.documentSeries.displayStyle = null;
      this.displayStyles.forEach(element => {
        if ((this.documentSeries.prefix == null || this.documentSeries.prefix === "") && element != null) {
          switch (element.code) {
            case "/":
              element.label = element.displayStyle.replace("prefix/", this.documentSeries.prefix);
              break;
            case "-":
              element.label = element.displayStyle.replace("prefix-", this.documentSeries.prefix);
              break;
            default:
              element.label = element.displayStyle.replace("prefix", this.documentSeries.prefix);
              break;
          }
        } else {
          element.label = element.displayStyle.replace("prefix", this.documentSeries.prefix);
        }

        if ((this.documentSeries.suffix == null || this.documentSeries.suffix === "") && element != null) {
          switch (element.code) {
            case "/":
              element.label = element.label.replace("/suffix", this.documentSeries.suffix);
              element.label = element.label.replace("suffix/", this.documentSeries.suffix);
              break;
            case "-":
              element.label = element.label.replace("-suffix", this.documentSeries.suffix);
              element.label = element.label.replace("suffix-", this.documentSeries.suffix);
              break;
            default:
              element.label = element.label.replace("suffix", this.documentSeries.suffix);
              break;
          }
        } else {
          element.label = element.label.replace("suffix", this.documentSeries.suffix);
        }
        element.label = element.label.replace("startNum", this.documentSeries.startNumber);

      })
    } else if (this.documentSeries.prefix && this.documentSeries.suffix && !this.documentSeries.startNumber) {
      this.documentSeries.displayStyle = null;
      this.displayStyles.forEach(element => {
        if ((this.documentSeries.prefix == null || this.documentSeries.prefix === "") && element != null) {
          switch (element.code) {
            case "/":
              element.label = element.displayStyle.replace("prefix/", this.documentSeries.prefix);
              break;
            case "-":
              element.label = element.displayStyle.replace("prefix-", this.documentSeries.prefix);
              break;
            default:
              element.label = element.displayStyle.replace("prefix", this.documentSeries.prefix);
              break;
          }
        } else {
          element.label = element.displayStyle.replace("prefix", this.documentSeries.prefix);
        }

        if ((this.documentSeries.suffix == null || this.documentSeries.suffix === "") && element != null) {
          switch (element.code) {
            case "/":
              element.label = element.label.replace("/suffix", this.documentSeries.suffix);
              element.label = element.label.replace("suffix/", this.documentSeries.suffix);
              break;
            case "-":
              element.label = element.label.replace("-suffix", this.documentSeries.suffix);
              element.label = element.label.replace("suffix-", this.documentSeries.suffix);
              break;
            default:
              element.label = element.label.replace("suffix", this.documentSeries.suffix);
              break;
          }
        } else {
          element.label = element.label.replace("suffix", this.documentSeries.suffix);
        }
        element.label = element.label.replace("startNum", "");
      })
    } else if (this.documentSeries.prefix && !this.documentSeries.suffix && this.documentSeries.startNumber) {
      this.documentSeries.displayStyle = null;
      this.displayStyles.forEach(element => {
        if ((this.documentSeries.prefix == null || this.documentSeries.prefix === "") && element != null) {
          switch (element.code) {
            case "/":
              element.label = element.displayStyle.replace("prefix/", this.documentSeries.prefix);
              break;
            case "-":
              element.label = element.displayStyle.replace("prefix-", this.documentSeries.prefix);
              break;
            default:
              element.label = element.displayStyle.replace("prefix", this.documentSeries.prefix);
              break;
          }
        } else {
          element.label = element.displayStyle.replace("prefix", this.documentSeries.prefix);
        }
        if ((this.documentSeries.suffix == null || this.documentSeries.suffix === "") && element != null) {
          switch (element.code) {
            case "/":
              element.label = element.label.replace("/suffix", this.documentSeries.suffix);
              element.label = element.label.replace("suffix/", this.documentSeries.suffix);
              break;
            case "-":
              element.label = element.label.replace("-suffix", this.documentSeries.suffix);
              element.label = element.label.replace("suffix-", this.documentSeries.suffix);
              break;
            default:
              element.label = element.label.replace("suffix", this.documentSeries.suffix);
              break;
          }
        } else {
          element.label = element.label.replace("suffix", this.documentSeries.suffix);
        }
        element.label = element.label.replace("startNum", this.documentSeries.startNumber);
      })
    } else if (!this.documentSeries.prefix && this.documentSeries.suffix && this.documentSeries.startNumber) {
      this.documentSeries.displayStyle = null;
      this.displayStyles.forEach(element => {
        if ((this.documentSeries.prefix == null || this.documentSeries.prefix === "") && element != null) {
          switch (element.code) {
            case "/":
              element.label = element.displayStyle.replace("prefix/", this.documentSeries.prefix);
              break;
            case "-":
              element.label = element.displayStyle.replace("prefix-", this.documentSeries.prefix);
              break;
            default:
              element.label = element.displayStyle.replace("prefix", this.documentSeries.prefix);
              break;
          }
        }
        if ((this.documentSeries.suffix == null || this.documentSeries.suffix === "") && element != null) {
          switch (element.code) {
            case "/":
              element.label = element.label.replace("/suffix", this.documentSeries.suffix);
              element.label = element.label.replace("suffix/", this.documentSeries.suffix);
              break;
            case "-":
              element.label = element.label.replace("-suffix", this.documentSeries.suffix);
              element.label = element.label.replace("suffix-", this.documentSeries.suffix);
              break;
            default:
              element.label = element.label.replace("suffix", this.documentSeries.suffix);
              break;
          }
        }
        element.label = element.label.replace("startNum", this.documentSeries.startNumber);
      })
    } else if (!this.documentSeries.prefix && !this.documentSeries.suffix && !this.documentSeries.startNumber) {
      this.documentSeries.displayStyle = null;
      this.displayStyles.forEach(element => {
        if ((this.documentSeries.prefix == null || this.documentSeries.prefix === "") && element != null) {
          switch (element.code) {
            case "/":
              element.label = element.displayStyle.replace("prefix/", this.documentSeries.prefix);
              break;
            case "-":
              element.label = element.displayStyle.replace("prefix-", this.documentSeries.prefix);
              break;
            default:
              element.label = element.displayStyle.replace("prefix", this.documentSeries.prefix);
              break;
          }
        }
        if ((this.documentSeries.suffix == null || this.documentSeries.suffix === "") && element != null) {
          switch (element.code) {
            case "/":
              element.label = element.label.replace("/suffix", this.documentSeries.suffix);
              element.label = element.label.replace("suffix/", this.documentSeries.suffix);
              break;
            case "-":
              element.label = element.label.replace("-suffix", this.documentSeries.suffix);
              element.label = element.label.replace("suffix-", this.documentSeries.suffix);
              break;
            default:
              element.label = element.label.replace("suffix", this.documentSeries.suffix);
              break;
          }
        }
        element.label = element.label.replace("startNum", "");
      })
    }
  }

  getBranchList(response: any) {
    this.branchList = [];
    this.branchDropDownOptions=[];
    if (response && response.status == 200 && response.data && response.data.branch) {
      this.branchList = response.data.branch.list;
      this.branchList.forEach(element => {
        let branchOption = new DropDownModel(element.name, element.id);
        this.branchDropDownOptions.push(branchOption);
      })
    }
  }

  onOverRideChange() {
    this.documentSeries.overrideFlag = this.overrideFlag;
  }

}
