import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { HBHttpService } from "src/app/core/services/hb-http-service.service";

@Injectable({
  providedIn: 'root'
})
export class DocumentSeriesSettingService {

  constructor(private hbHttpClient: HBHttpService) { }

  addDocumentSeries(data: any): Observable<any> {
    return this.hbHttpClient.getResponse('documentSeries/add', this.hbHttpClient.POST, data);
  }

  getDocumentSeriesList(data: any): Observable<any> {
    return this.hbHttpClient.getResponse('documentSeries/list?docType=' + data, this.hbHttpClient.GET);
  }

  getAutoSeriesByDocType(docType: any, branchId: any): Observable<any> {
    return this.hbHttpClient.getResponse('documentSeries/auto-code?docType=' + docType + " &branchId=" + branchId, this.hbHttpClient.GET);
  }

  getDisplayStyleList(): Observable<any> {
    return this.hbHttpClient.getResponse('documentSeries/display-style-list', this.hbHttpClient.GET);
  }
}