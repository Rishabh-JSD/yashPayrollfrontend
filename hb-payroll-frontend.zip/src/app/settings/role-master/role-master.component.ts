import { Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { HbDataTableColumnOption } from '@hostbooks/hb-lib/hb-list-table/src/hb-list-table-columns';
import { RoleListing } from './role-master';

import { DropDownModel } from '../../shared/models/hb-field-option';

@Component({
  selector: 'app-role-master',
  templateUrl: './role-master.component.html',
  styleUrls: ['./role-master.component.scss']
})
export class RoleMasterComponent implements OnInit {

  @ViewChild('addRole') addRole: TemplateRef<any> | undefined;
  dialogRef: MatDialogRef<any> | undefined;


  columns: HbDataTableColumnOption[] = [];
  data: RoleListing[] = [];
  total: number;
  Department: DropDownModel[] = [
    { label: 'option 1', code: 'option 1', id: undefined, value: undefined },
  ];
  Level: DropDownModel[] = [
    { label: 'option 1', code: 'option 1', id: undefined, value: undefined },
  ];
  dataSource = [
    {
      s_no: 1,
      check: '',
      role_name: 'Director',
      department: 'Quality',
      level: '3',
      actions: '',
    },
    {
      s_no: 2,
      check: '',
      role_name: 'Director',
      department: 'Quality',
      level: '3',
      actions: '',
    },
    {
      s_no: 3,
      check: '',
      role_name: 'Director',
      department: 'Quality',
      level: '3',
      actions: '',
    },
    {
      s_no: 4,
      check: '',
      role_name: 'Director',
      department: 'Quality',
      level: '3',
      actions: '',
    },
  ];

  constructor(public dialog: MatDialog) { }

  ngOnInit(): void {
    this.data = this.dataSource;
    this.total = this.data.length;
    this.columns = [
      {
        header: 'S. No.',
        columnData: (inv: RoleListing) => {
          return 's_no';
        },
        type: 'SR_NO'
      },
      {
        header: 'Check',
        columnData: (inv: RoleListing) => {
          return 'check';
        },
        type: 'CHECK'
      },
      {
        header: 'Role name',
        columnData: (inv: RoleListing) => {
          return inv.role_name;
        },
        type: 'TEXT'
      },
      {
        header: 'Department',
        columnData: (inv: RoleListing) => {
          return inv.department;
        },
        type: 'TEXT'
      },
      {
        header: 'Level',
        columnData: (inv: RoleListing) => {
          return inv.level;
        },
        type: 'NUMBER'
      },
      {
        header: 'Actions',
        columnData: (inv: RoleListing) => {
          return inv.actions;
        },
        type: 'ACTION',
        actionOptions: ['EDIT']
      },
    ];
  }

  openAddRolePopup(template: TemplateRef<any>): void {
    this.dialogRef = this.dialog.open(template, {
      minHeight: '150px',
      width: '400px',
    });

  }

  closeDialog(data: any = null): void {
    if (this.dialogRef) {
      this.dialogRef.close(data);
    }
  }

}
