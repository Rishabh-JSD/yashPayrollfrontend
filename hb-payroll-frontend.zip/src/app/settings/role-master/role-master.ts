export class RoleListing {
  public s_no: any;
  public check: any;
  public role_name: any;
  public department: any;
  public level: any;
  public actions: any;
}
