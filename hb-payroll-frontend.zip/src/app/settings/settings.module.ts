import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../shared/shared.module';
import { RoleMasterComponent } from './role-master/role-master.component';
import { ApproveMechanismComponent } from './approve-mechanism/approve-mechanism.component';
import { DocumentSeriesSettingComponent } from './document-series-setting/document-series-setting.component';

const routes: Routes = [

  { path: '', component: RoleMasterComponent },
  { path: 'role-master', component: RoleMasterComponent },
  { path: 'approve-mechanism', component: ApproveMechanismComponent },
  { path: 'document-series', component: DocumentSeriesSettingComponent },

  { path: '**', redirectTo: '', pathMatch: 'full' }
];

@NgModule({
  declarations: [
    RoleMasterComponent,
    ApproveMechanismComponent,
    DocumentSeriesSettingComponent
  ],
  imports: [
    CommonModule,
    SharedModule,

    RouterModule.forChild(routes)
  ]
})
export class SettingsModule {
}
