import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Address } from '../models/address';
import { HbErrorHandler, HbErrorHandlerData } from '../models/hb-error-handler';

@Component({
  selector: 'app-address',
  templateUrl: './address.component.html',
  styleUrls: ['./address.component.scss'],
})
export class AddressComponent implements OnInit {
  @Output() sameAsEvent = new EventEmitter();
  @Input() viewFlag: boolean = false;
  @Input() addressType: string = '';
  @Input() sameAsField: boolean = false;
  @Input() sameAsFlag: boolean;
  @Input() sameAsName: string = '';
  @Input() address: Address = new Address();
  @Input() hbErrorHandler: HbErrorHandler;

  constructor() {}

  ngOnInit(): void {
  }


  // setCity(city: Cities) {
  //   this.address.cityId = city.id;
  //   console.log(this.address);
  // }

  // setPincode(pincode: Pincode) {
  //   this.address.pincodeId = pincode.id;
  //   console.log(this.address);
  // }

  // setCountry(country: Countries) {
  //   this.address.countryId = country.id;
  //   console.log(this.address);
  // }

  emitSameAsEvent() {
    this.sameAsEvent.emit(this.sameAsFlag);
  }

  errorHandler(parentkey: string, childkey?: string, keyIndex?: number): HbErrorHandlerData {
    const hData = this.hbErrorHandler.getErrorHandlerData(parentkey, childkey, keyIndex);
    return hData;
  }
}
