import { Component, EventEmitter, forwardRef, Input, OnInit, Output } from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';
import { AutoCompleteOptionCode, AutoCompleteOptionType, DropDownModel } from '../models/hb-field-option';
import { HbErrorHandlerData } from '../models/hb-error-handler';
import { DropDownReqRes, HbAutoCompleteDropdownApiService } from '../services/hb-auto-complete-dropdown-api.service';
import { ApiResponse } from '../../core/models/api-response';

@Component({
  selector: 'hb-auto-complete',
  template: `
      <div class="p-field" [ngClass]="{'error': errorHandler?.invalid}">
        <span class="p-float-label">
          <p-autoComplete [(ngModel)]="autoCompleteValue"
          [showEmptyMessage]="emptyMessage"
          [suggestions]="dropdownOptions"
          (completeMethod)="autoCompleteChange($event)"
          (onSelect) = "setValue(autoCompleteValue)"
          (onClear) = "setValue(autoCompleteValue)"
          [completeOnFocus]="true"
          immutable="false"
          field="label"
          [minLength]="0"
          appendTo="body"
          [disabled]="disabled"
          [required]="required"
          inputId="float-autoComplete"
          (keydown.ArrowRight)="doNothing($event)"
          (keydown.ArrowLeft)="doNothing($event)"
          [ngClass]="tooltipContent ? 'tooltipWidth' : ''"
          autocomplete="nofill">
          </p-autoComplete>
          <label for="float-autoComplete" *ngIf="floatLabel">{{placeHolder}}<sup *ngIf="required">*</sup></label>

          <div class="tooltip-container" *ngIf="tooltipContent">
            <i class="fa fa-info-circle tooltip-trigger" aria-hidden="true"></i>
            <div class="dropdown-menu placeSupplyPopup tooltip icon-tooltip" role="menu">
              <div class="file-grp">
                <p class="popUpData">
                {{tooltipContent}}
                </p>
              </div>
            </div>
          </div>
        </span>
        <p *ngIf="errorHandler?.invalid" class="validation-message">{{errorHandler?.errorMsg}}</p>
      </div>
  `,
  styles: [
    `
    .tooltipWidth{
      width: calc(100% - 12px);
      display: inline-block;
    }
    .p-field ::ng-deep .p-autocomplete{
      width: 100%;
    }
    `
  ],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => HbAutoCompleteComponent),
      multi: true
    },
    HbAutoCompleteDropdownApiService
  ]
})
export class HbAutoCompleteComponent implements OnInit, ControlValueAccessor {
  @Input() required = false;
  @Input() disabled = false;
  @Input() placeHolder = '';
  @Input() tooltipContent = '';
  @Input() autoCompleteType: AutoCompleteOptionType | undefined;
  @Input() errorHandler: HbErrorHandlerData | undefined;
  @Input() codeAsValue = false;
  @Input() valueAsId = false;
  @Input() codeAsLabel = false;
  @Input() noneOption = false;
  @Input() subAccCode = '';
  @Input() valueChangeFlag: boolean = false;
  @Input() newOption: boolean = false;
  @Input() floatLabel: boolean = true;
  @Input() storageType: string | undefined;
  @Input() isNone: boolean = true;
  @Input() searchType: string | undefined;
  @Input() searchField: string | undefined;
  @Input() extraId: number | undefined;
  @Input() selectedId: any | undefined;
  @Input() pincode: any | undefined;
  @Input() onlyBranch: boolean;  // required for getting only lowest level branches
  @Input() idList: number[] | undefined;
  @Input() catCode: AutoCompleteOptionCode | undefined;
  @Input() parentId: any | undefined
  emptyMessage: boolean = false;

  dropdownOptions: DropDownModel[] = [];
  autoCompleteValue: any = '';
  loading = false;

  @Output() onChange: EventEmitter<any> = new EventEmitter();
  @Output() valueDataChange = new EventEmitter<any>();
  @Output() onNewSelection: EventEmitter<any> = new EventEmitter();
  actionEvent = null;
  private innerValue: any = '';

  constructor(private hbAutoCompleteDropdownApiService: HbAutoCompleteDropdownApiService) { }

  get value(): any {
    return this.innerValue;
  }

  set value(v: any) {
    if (v !== this.innerValue) {
      this.innerValue = v;
      this.onChangeCallback(v);
    }
  }

  ngOnInit(): void {

  }

  doNothing(e: any) {
    e.stopPropagation();
    return;
  }

  // Set touched on blur
  onBlur(): void {
    this.onTouchedCallback();
  }

  // From ControlValueAccessor interface
  registerOnChange(fn: any): void {
    this.onChangeCallback = fn;
  }

  // From ControlValueAccessor interface
  registerOnTouched(fn: any): void {
    this.onTouchedCallback = fn;
  }

  onKeyUp(event: KeyboardEvent) {
    if (event.key == 'Enter') {
      let tokenInput = event.srcElement as any;
      console.log(tokenInput.value, '----');
      if (tokenInput.value) {
        // this.texts.push(tokenInput.value);
        tokenInput.value = '';
      }
    }
  }

  // From ControlValueAccessor interface
  writeValue(value: any): void {
    let valueChanged = false;
    if (value !== this.innerValue) {
      this.innerValue = value;
      valueChanged = true;
      if (!this.innerValue) {
        this.autoCompleteValue = null;
      }
    }
    if (value && this.autoCompleteType && (!this.autoCompleteValue || valueChanged)) {
      if (this.codeAsValue) {
        this.hbAutoCompleteDropdownApiService.labelDataByCode(value, this.autoCompleteType).subscribe(response => {
          this.handleAutoCompleteRes(response);
        });
      } else if (+value) {
        this.hbAutoCompleteDropdownApiService.labelDataById(value, this.autoCompleteType, this.codeAsLabel, this.storageType, this.valueAsId).subscribe(response => {
          this.handleAutoCompleteRes(response);
        });
      }
    }
  }

  handleAutoCompleteRes(response: ApiResponse): void {
    if (response && response.status === 200 && response.data && response.data.list) {
      this.dropdownOptions = [response.data.list];
      if (this.codeAsLabel) {
        for (let i = 0; i < this.dropdownOptions.length; i++) {
          let temp = this.dropdownOptions[i].code;
          this.dropdownOptions[i].code = this.dropdownOptions[i].label;
          this.dropdownOptions[i].label = temp;
        }
      }
      if (this.dropdownOptions[0].label) {
        this.autoCompleteValue = this.dropdownOptions[0];
      }
    } else {
      this.dropdownOptions = [];
    }
  }

  autoCompleteChange(event, isReset = false): void {
    if (isReset) {
      this.value = undefined;
      this.onValueChange();
    }
    if (!this.autoCompleteValue) {
      this.autoCompleteValue = '';
    }
    if (this.autoCompleteType) {
      // this.loading = true;
      const dropDownReqRes = new DropDownReqRes();
      if (typeof (this.autoCompleteValue) == 'string') {
        dropDownReqRes.searchFor = this.autoCompleteValue;
      } else {
        dropDownReqRes.searchFor = this.autoCompleteValue.label;
      }

      this.setDropdownValues(dropDownReqRes);
      dropDownReqRes.codeAsLabel = this.codeAsLabel;

      this.hbAutoCompleteDropdownApiService.autoCompleteSearchDropdown(dropDownReqRes).subscribe(response => {
        if (response && response.status === 200 && response.data && response.data.dropdown) {
          this.dropdownOptions = [];
          this.addStaticOptions();
          this.dropdownOptions = this.dropdownOptions.concat(response.data.dropdown.list);
          if (this.codeAsLabel) {
            for (let i = 0; i < this.dropdownOptions.length; i++) {
              let temp = this.dropdownOptions[i].code;
              this.dropdownOptions[i].code = this.dropdownOptions[i].label;
              this.dropdownOptions[i].label = temp;
            }
          }
          if (response.data.dropdown.list.length == 0) {
            this.emptyMessage = true;
          }
        } else {
          this.dropdownOptions = [];
          if (response.data.list == null) {
            this.emptyMessage = true;
          }
          this.addStaticOptions();
        }
      });
    }
  }

  onValueChange(dropdownOption: DropDownModel = null): void {
    if (dropdownOption) {
      this.onChange.emit(dropdownOption);
      if (this.valueChangeFlag) {
        this.onNewSelection.emit(dropdownOption);
      }
    } else {
      this.onChange.emit(this.value);
      if (this.valueChangeFlag) {
        this.onNewSelection.emit(this.value);
      }
    }
  }

  addStaticOptions(): void {
    if (this.noneOption) {
      const option = new DropDownModel('(none)', null);
      this.dropdownOptions.push(option);
    }
  }

  setDropdownValues(dropDownReqRes: DropDownReqRes) {
    if (typeof (this.autoCompleteValue) == 'string') {
      dropDownReqRes.name = this.autoCompleteValue;
    } else {
      dropDownReqRes.name = this.autoCompleteValue.label;
    }
    dropDownReqRes.catCode = this.catCode;
    dropDownReqRes.parentId = this.parentId;
    dropDownReqRes.page = 1;
    dropDownReqRes.limit = 10;
    dropDownReqRes.type = this.autoCompleteType;
    dropDownReqRes.searchType = this.searchType;
    dropDownReqRes.searchField = this.searchField;
    dropDownReqRes.id = this.extraId;
    dropDownReqRes.selectedId = this.selectedId;
    dropDownReqRes.onlyBranch = this.onlyBranch;
    dropDownReqRes.idList = this.idList;
    dropDownReqRes.pincode = this.pincode;
    dropDownReqRes.subAccCode = this.subAccCode;
  }

  setValue(dropdownOption: DropDownModel): void {
    let isAddNew = false;
    if (this.codeAsValue) {
      if (!dropdownOption.code) {
        setTimeout(() => {
          this.autoCompleteValue = null;
        });
      }
      this.value = dropdownOption.code;
    } else if (this.valueAsId) {
      if (!dropdownOption.value) {
        setTimeout(() => {
          this.autoCompleteValue = null;
        });
      }
      this.value = dropdownOption.value;
    } else {
      if (dropdownOption.id === 0) {
        isAddNew = true;
        setTimeout(() => {
          this.autoCompleteValue = null;
          this.value = null;
        });
      } else {
        if (!dropdownOption.id) {
          setTimeout(() => {
            this.autoCompleteValue = null;
          });
        }
        this.value = dropdownOption.id;
      }
    }
    if (isAddNew) {

    } else {
      this.valueDataChange.emit(dropdownOption);
      this.onValueChange(dropdownOption);
    }
  }

  private onTouchedCallback: () => void = () => { };

  private onChangeCallback: (_: any) => void = () => { };
}
