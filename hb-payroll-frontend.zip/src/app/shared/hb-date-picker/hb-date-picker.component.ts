import { DateHelperService } from '../services/date-helper.service';
import { Component, EventEmitter, forwardRef, Input, OnInit, Output, ViewChild } from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';
import { FloatLabelType } from '@angular/material/form-field';
import { Calendar } from 'primeng/calendar';
import { HbErrorHandlerData } from '../models/hb-error-handler';


@Component({
  selector: 'hb-date-picker',
  template: `
    <div class="p-field" [ngClass]="{'error': errorHandler?.invalid}">
      <span class="p-float-label" [ngClass]="tooltipContent ? 'with-tooltip' : ''">
        <p-calendar
          [(ngModel)]="dateUI"
          [required]="required"
          [disabled]="disabled"
          [minDate]="_minDate"
          [maxDate]="_maxDate"
          (key.enter)="onBlurChange($event)"
          (onClose)="onBlurChange($event)"
          (onBlur)="onBlurChange($event)"
          (onTodayClick)="onDateChange()"
          (onClearClick)="onDateChange()"
          (onSelect)="onDateChange()"
          [showIcon]="true"
          [showButtonBar]="true"
          [timeOnly]="timeOnly"
          [showSeconds]="showSeconds"
          inputId="float-calendar"
          dateFormat="dd/mm/yy"
          dataType="string"
          (keydown.ArrowRight)="doNothing($event)"
          (keydown.ArrowLeft)="doNothing($event)"
          appendTo="body">
        </p-calendar>
        <label for="float-calendar">{{placeHolder}} <small *ngIf="required">*</small></label>
      </span>
        <!-- <i *ngIf="tooltipContent" class="pi pi-exclamation-circle" [pTooltip]="tooltipContent"></i> -->
      <p *ngIf="errorHandler?.invalid" class="validation-message">{{errorHandler?.errorMsg}}</p>
    </div>
  `,
  styles: [
    `
      .p-field ::ng-deep .p-calendar{
        width: 100%;
      }
      .p-field ::ng-deep .p-datepicker-trigger,
      .p-field ::ng-deep .p-button:enabled:hover,
      .p-field ::ng-deep .p-button:enabled:active,
      .p-field ::ng-deep .p-button:enabled:target{
        background: var(--white);
        color: var(--black-text) !important;
      }
      .p-field ::ng-deep .p-calendar-w-btn .p-inputtext{
        border-right: 0;
      }
      .p-field ::ng-deep .p-datepicker table td,
      .p-field ::ng-deep .p-datepicker .p-datepicker-header{
        padding: 0;
      }
      .p-field ::ng-deep .p-datepicker:not(.p-datepicker-inline) .p-datepicker-header{
        background: var(--white) !important;
      }
      .p-field ::ng-deep .p-datepicker .p-datepicker-buttonbar .p-button,
      .p-field ::ng-deep .p-datepicker .p-datepicker-buttonbar .p-button:hover{
        background: var(--white);
        color: var(--anchor-color) !important;
        border-color: rgb(var(--blue)) !important;
        padding: 0.2rem 0.5rem;
        border-radius: 5px;
      }
      .p-field ::ng-deep .p-datepicker .p-datepicker-buttonbar {
        padding: 1rem 0 3px;
      }
      .tooltipWidth{
        width: calc(100% - 12px);
        display: inline-block;
      }
      .p-field ::ng-deep .p-button-icon-only{
        border: 1px solid var(--input-border);
        margin-left: 0 !important;
      }
      .p-field ::ng-deep .p-calendar-w-btn .p-inputtext {
        border-right: 0 !important;
        border-radius: 4px 0 0 4px !important;
      }
    `
  ],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => HbDatePickerComponent),
      multi: true
    }
  ]
})
export class HbDatePickerComponent implements OnInit, ControlValueAccessor {
  dateUI: string | undefined | null;
  _preDate: string;
  @Input() required = false;
  @Input() disabled = false;
  @Input() placeHolder = '';
  @Input() tooltipContent = '';
  @Input() errorHandler: HbErrorHandlerData | undefined;
  @Input() isLockDate = false;
  @Input() floatLabel: FloatLabelType = 'auto';
  @Input() timeOnly = false;
  @Input() showSeconds = false;
  @Output() onChange: EventEmitter<any> = new EventEmitter();
  @Output() onPreChange: EventEmitter<any> = new EventEmitter();
  @ViewChild(Calendar, { static: false }) datePicker: Calendar;
  private innerValue: any = '';

  constructor() { }

  _minDate: Date | null;

  @Input() set minDate(_date: string | null) {
    this._minDate = _date ? new Date(_date) : null;
  };

  _maxDate: Date | null;

  @Input() set maxDate(_date: string | null) {
    this._maxDate = _date ? new Date(_date) : null;
  };

  get value(): any {
    return this.innerValue;
  }

  set value(v: any) {
    if (v !== this.innerValue) {
      this.innerValue = v;
      this.onChangeCallback(v);
    }
  }

  ngOnInit(): void { }

  doNothing(e: any) {
    e.stopPropagation();
    return;
  }

  // Set touched on blur
  onBlur(): void {
    this.onTouchedCallback();
  }

  // From ControlValueAccessor interface
  registerOnChange(fn: any): void {
    this.onChangeCallback = fn;
  }

  // From ControlValueAccessor interface
  registerOnTouched(fn: any): void {
    this.onTouchedCallback = fn;
  }

  // From ControlValueAccessor interface
  writeValue(value: any): void {
    this.innerValue = undefined;
    this.dateUI = DateHelperService.convertUiDate(value);
    value = DateHelperService.convertUiToApiDate(this.dateUI);
    if (value !== this.innerValue) {
      this.value = value;
      this._preDate = this.value;
    }
  }

  onBlurChange(_event): void {
    let newVal = null;
    if (this.datePicker?.inputfieldViewChild?.nativeElement?.value) {
      newVal = DateHelperService.convertUiDate(this.datePicker.inputfieldViewChild.nativeElement.value, this.isLockDate);
    } else {
      newVal = null;
    }
    const value = DateHelperService.convertUiToApiDate(this.dateUI);
    if (this.dateUI != newVal || value !== this.innerValue) {
      this.dateUI = newVal;
      this.onDateChange();
    }
  }

  onDateChange(): void {
    this.value = DateHelperService.convertUiToApiDate(this.dateUI);
    this.onChange.emit(this.value);
    if (this._preDate != this.value) {
      this.onPreChange.emit(this._preDate);
      this._preDate = this.value;
    }
  }

  private onTouchedCallback: () => void = () => { };

  private onChangeCallback: (_: any) => void = () => { };
}
