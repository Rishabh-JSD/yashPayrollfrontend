import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HbFieldComponent } from './hb-field.component';

describe('HbFieldComponent', () => {
  let component: HbFieldComponent;
  let fixture: ComponentFixture<HbFieldComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [HbFieldComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HbFieldComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
