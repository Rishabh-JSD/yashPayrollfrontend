import { Component, ElementRef, EventEmitter, forwardRef, Input, OnInit, Output, ViewChild } from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';
import { HbErrorHandlerData } from '../models/hb-error-handler';
import { DropDownModel, DropDownOption, DropDownOptionType, FieldOptionType } from '../models/hb-field-option';
import * as moment from 'moment';
import { HelperService } from 'src/app/helper/helper.service';

@Component({
  selector: 'hb-field',
  templateUrl: './hb-field.component.html',
  styleUrls: ['./hb-field.component.scss'],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => HbFieldComponent),
      multi: true,
    },
  ],
})
export class HbFieldComponent implements OnInit, ControlValueAccessor {
  @Output() valueChange = new EventEmitter<any>();
  @ViewChild('datePicker') datePickerInput: ElementRef | undefined;

  @Input() fieldType: FieldOptionType;
  @Input() required = false;
  @Input() disabled = false;
  @Input() minlength = '0';
  @Input() maxlength = '200';
  @Input() placeHolder = '';
  @Input() min: string;
  @Input() max: string;
  @Input() dropdownOptions: DropDownModel[] = [];
  @Input() radioOptions: DropDownModel[] = [];
  @Input() codeAsValue = false;
  @Input() minDate: any | undefined;
  @Input() errorHandler: HbErrorHandlerData;
  dateMapMonth = new Map();
  dateUI: string | undefined;
  autoCompleteValue: any = '';
  private innerValue: any = '';

  constructor() {}

  @Input() set dropdownType(type: DropDownOptionType) {
    if (type) {
      this.dropdownOptions = DropDownOption.fetchDropDownOptionByType(type);
    }
  }

  // get accessor
  get value(): any {
    return this.innerValue;
  }

  // set accessor including call the onchange callback
  set value(v: any) {
    if (v !== this.innerValue) {
      this.innerValue = v;
      this.onChange(v);
    }
  }

  // Invoked when the model has been changed
  onChange: (_: any) => void = (_: any) => {};

  // Invoked when the model has been touched
  onTouched: () => void = () => {};

  ngOnInit(): void {}

  // Method that is invoked on an update of a model.
  updateChanges() {
    this.onChange(this.value);
  }

  // Set touched on blur
  onBlur(): void {
    this.onTouched();
  }

  /**
   * Writes a new item to the element.
   * @param value the value
   */
  writeValue(value: any): void {
    this.value = value;
    this.updateChanges();

    if (value !== this.innerValue) {
      this.innerValue = value;
      if (!this.innerValue) {
        this.autoCompleteValue = null;
      }
    }
    if (this.fieldType) {
      switch (this.fieldType) {
        case 'date-picker': {
          this.dateUI = this.convertTimeStampToDate(value);
          break;
        }
      }
    }
  }

  /**
   * Registers a callback function that should be called when the control's value changes in the UI.
   * @param fn
   */
  registerOnChange(fn: any): void {
    this.onChange = fn;
  }

  /**
   * Registers a callback function that should be called when the control receives a blur event.
   * @param fn
   */
  registerOnTouched(fn: any): void {
    this.onTouched = fn;
  }

  onValueChange(): void {
    if (this.fieldType) {
      switch (this.fieldType) {
        case 'date-picker': {
          if (this.datePickerInput && this.datePickerInput.nativeElement && this.datePickerInput.nativeElement.value) {
            const dateTemp = this.updateDate(this.datePickerInput.nativeElement.value);
            this.dateUI = dateTemp;
            this.value = this.dateUI;
          } else {
            this.value = undefined;
          }
          break;
        }
        case 'number': {
          if (this.value) {
            this.value = HelperService.mathRound(this.value);
          } else {
            this.value = 0;
          }
          break;
        }
      }
    }
    this.valueChange.emit(this.value);
  }

  convertTimeStampToDate(dateOrTimeStamp: string): string {
    if (dateOrTimeStamp && +dateOrTimeStamp) {
      const curDate = new Date();
      curDate.setTime(+dateOrTimeStamp);
      return moment(curDate).format('YYYY-MM-DD');
    } else {
      return dateOrTimeStamp;
    }
  }

  updateDate(value: string): string | undefined {
    let date: string | undefined;
    if (value) {
      value = value.toString().replace(/[^a-zA-Z0-9]/g, '/');
      const data = value.split('/');
      const curDate = new Date();
      if (this.checkDate(data)) {
        curDate.setMonth(0);
        if (data[2]) {
          if (data[2].length === 2) {
            let subYear = +curDate.getFullYear().toString().substr(0, 2);
            if (+data[2] > subYear + 1) {
              curDate.setFullYear(+((--subYear).toString() + data[2].toString()));
            }
            curDate.setFullYear(+(subYear.toString() + data[2].toString()));
          } else {
            curDate.setFullYear(+data[2]);
          }
        }
        curDate.setDate(+data[0]);
        curDate.setMonth(+data[1] - 1);
        date = moment(curDate).format('YYYY-MM-DD');
      } else {
        if (moment(value, 'ddd/MMM/DD/YYYY', true).isValid()) {
          date = moment(value, 'ddd/MMM/DD/YYYY', true).format('YYYY-MM-DD');
        } else if (moment(value, 'YYYY/MM/DD', true).isValid()) {
          date = moment(value, 'YYYY/MM/DD', true).format('YYYY-MM-DD');
        } else if (moment(value, 'M/DD/YYYY', true).isValid()) {
          date = moment(value, 'M/DD/YYYY', true).format('YYYY-MM-DD');
        } else {
          date = moment(curDate).format('YYYY-MM-DD');
        }
      }
    } else {
      date = undefined;
    }
    return date;
  }

  checkDate(arr: any[]): boolean {
    let bFlag = true;
    if (arr[1] && arr[1].toString().length > 2) {
      const monthValue = this.dateMapMonth.get(arr[1].toString().toLowerCase().substr(0, 3));
      if (monthValue) {
        arr[1] = monthValue;
      }
    }
    if (
      (arr.length === 3 || arr.length === 2) &&
      (arr[0].toString().length === 2 || arr[0].toString().length === 1) &&
      (arr[1].toString().length === 2 || arr[1].toString().length === 1) &&
      arr[1] <= 12 &&
      (!arr[2] || arr[2].toString().length === 4 || arr[2].toString().length === 2)
    ) {
      arr.forEach(element => {
        if (!Number(element)) {
          bFlag = false;
        }
      });
    } else {
      bFlag = false;
    }
    return bFlag;
  }
}
