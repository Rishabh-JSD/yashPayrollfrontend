import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'hb-app-loader',
  templateUrl: './hb-loader.component.html',
  styleUrls: ['./hb-loader.component.scss']
})
export class HbLoaderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
