import { Component, EventEmitter, forwardRef, Input, OnInit, Output } from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';
import { AutoCompleteOptionType, DropDownModel } from '../models/hb-field-option';
import { DropDownReqRes, HbAutoCompleteDropdownApiService } from '../services/hb-auto-complete-dropdown-api.service';
import { HbErrorHandlerData } from '../models/hb-error-handler';
import { ApiResponse } from 'src/app/core/models/api-response';

@Component({
  selector: 'hb-auto-complete-multi-select',
  template: `
    <div class="p-field"
      [ngClass]="{'error': errorHandler?.invalid, 'form-group': fromGroupClass, 'position-relative': true}">
      <span class="p-float-label">
      <p-autoComplete #autoComp [(ngModel)]="autoCompleteValue"
      [suggestions]="dropdownOptions"
      (onFocus)="getDropdownOptions($event)"
      (keyup.enter)="getDropdownOptions($event)"
      [multiple]="true"
      field="label"
      [showEmptyMessage]="emptyMessage"
      (onSelect) = "setValue(autoCompleteValue)"
      (onUnselect) = "setValue(autoCompleteValue)"
      [completeOnFocus]="true"
      [minLength] = "0"
      [required]="required"
      id="autoComp"
      [dropdown]="true"
      [disabled]="disabled"
      [lazy]= "true"
      appendTo="body"
      dropdownIcon="fa fa-search"
      (click)="getDropdownOptions(autoComp)"
      (keydown.ArrowRight)="doNothing($event)"
      (keydown.ArrowLeft)="doNothing($event)"
      [ngClass]="tooltipContent ? 'tooltipWidth' : ''">
      </p-autoComplete>
      <label for="autoComp" class="d-block">{{placeHolder}}</label>
      <div class="tooltip-container" *ngIf="tooltipContent">
        <i class="fa fa-info-circle tooltip-trigger" aria-hidden="true"></i>
        <div class="dropdown-menu placeSupplyPopup tooltip icon-tooltip" role="menu">
          <div class="file-grp">
            <p class="popUpData">
            {{tooltipContent}}
            </p>
          </div>
        </div>
      </div>
      </span>
      <p *ngIf="errorHandler?.invalid" class="validation-message">{{errorHandler?.errorMsg}}</p>
    </div>
  `,
  styles: [
    `
    .p-field ::ng-deep .p-autocomplete{
      width: 100%;
    }
    .p-field ::ng-deep .p-autocomplete .p-inputtext{
      padding-right: 94px;
    }
    .p-field ::ng-deep .p-autocomplete .p-autocomplete-multiple-container .p-autocomplete-token {
      padding: 0.2rem 0.5rem;
      margin-right: 0.5rem;
      border-radius: 6px;
    }
    .p-field ::ng-deep .p-autocomplete .p-autocomplete-multiple-container .p-autocomplete-input-token {
      padding: 0.15rem 0;
    }
    .p-field ::ng-deep .p-autocomplete .p-autocomplete-multiple-container {
      padding: 0.14rem 5px;
      width: 100%;
      border-radius: 6px;
    }
    .p-field ::ng-deep .p-autocomplete .p-autocomplete-multiple-container .p-autocomplete-token .p-autocomplete-token-icon {
      margin-left: 0.5rem;
    }
    .p-field ::ng-deep .p-autocomplete-items{
      border: 0 !important
    }
    .p-field ::ng-deep .p-autocomplete-panel{
      box-shadow: 0 2px 12px 0 rgb(0 0 0 / 10%);
    }
    .p-field ::ng-deep .p-autocomplete-items .p-autocomplete-item {
      padding: 7px 10px;
    }
    .p-field ::ng-deep .p-float-label label{
      padding: 2px 8px;
      transition: 0.2s all ease-in-out;
    }
    .p-field ::ng-deep .p-float-label input:focus ~ label, .p-field ::ng-deep .p-float-label input.p-filled ~ label, .p-field ::ng-deep .p-float-label textarea:focus ~ label, .p-field ::ng-deep .p-float-label textarea.p-filled ~ label, .p-field ::ng-deep .p-float-label .p-inputwrapper-focus ~ label, .p-field ::ng-deep .p-float-label .p-inputwrapper-filled ~ label {
      top: 2px;
      left: 5px;
      font-size: 10px;
      display: inline-block !important;
      width: auto !important;
      height: auto !important;
      padding: 0 6px !important;
      font-weight: 500;
      border-radius: 4px;
      letter-spacing: 0.4px;
    }
    .p-field ::ng-deep .p-autocomplete-loader {
      display: none;
      top: calc(50% - -2px);
      right: 26px;
      z-index: 1;
    }
    .p-field ::ng-deep .p-autocomplete-loader.showLoader {
      display:block;
    }
    .p-field ::ng-deep .fa.fa-search{
      font-size: 14px;
    }
    .p-field ::ng-deep .p-float-label:after{
      content: 'Press Enter';
      position: absolute;
      right: 32px;
      top: calc(50% - 7px);
      text-transform: uppercase;
      font-size: 10px;
    }
    .p-field ::ng-deep .p-autocomplete .p-autocomplete-multiple-container:not(.p-disabled).p-focus,
    .p-field ::ng-deep .p-autocomplete .p-autocomplete-multiple-container:not(.p-disabled).p-focus + .p-autocomplete-dropdown,
    .p-field ::ng-deep .p-autocomplete .p-autocomplete-multiple-container:not(.p-disabled).p-focus:hover,
    .p-field ::ng-deep .p-autocomplete .p-autocomplete-multiple-container:not(.p-disabled).p-focus + .p-autocomplete-dropdown:hover{
      box-shadow: none;
    }
    .tooltipWidth{
      width: calc(100% - 12px);
      display: inline-block;
    }
    `
  ],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => HbAutoCompleteMultiSelectComponent),
      multi: true
    },
    HbAutoCompleteDropdownApiService,
  ]
})
export class HbAutoCompleteMultiSelectComponent implements OnInit, ControlValueAccessor {
  @Input() required = false;
  @Input() disabled = false;
  @Input() placeHolder = '';
  @Input() tooltipContent = '';
  @Input() autoCompleteType: AutoCompleteOptionType | undefined;
  @Input() errorKey: string | undefined;
  @Input() errorHandler: HbErrorHandlerData | undefined;
  @Input() codeAsValue = false;
  @Input() codeAsLabel = false;
  @Input() inventoryId: number | undefined;
  @Input() inventoryType: string | undefined;
  @Input() idsInclude: number[] | undefined;
  @Input() excludeIdList: number[] | undefined;
  @Input() contactId: number | undefined;
  @Input() attributeId: number | undefined;
  @Input() showCode = false;
  @Input() noneOption = false;
  @Input() withValuation = false;
  @Input() companyGstin: string;
  @Input() nature: string;
  @Input() fromGroupClass = true;
  @Input() isManufactured = false;
  @Input() employeeCheck = false;
  @Input() vendorCheck = false;
  @Input() customerCheck = false;
  @Input() projectId: number;

  emptyMessage: boolean = false;

  dropdownOptions: DropDownModel[] = [];
  autoCompleteValue: any = '';
  loading = false;

  @Output() onChange: EventEmitter<any> = new EventEmitter();
  @Output() valueDataChange = new EventEmitter<any>();
  private innerValue: any = '';
  actionEvent = null;

  constructor(private hbAutoCompleteDropdownApiService: HbAutoCompleteDropdownApiService) { }

  ngOnInit(): void {

  }

  private onTouchedCallback: () => void = () => { };
  private onChangeCallback: (_: any) => void = () => { };

  get value(): any {
    return this.innerValue;
  }

  set value(v: any) {
    if (v !== this.innerValue) {
      this.innerValue = v;
      this.onChangeCallback(v);
    }
  }

  doNothing(e: any) {
    e.stopPropagation();
    return;
  }

  // Set touched on blur
  onBlur(): void {
    this.onTouchedCallback();
  }

  // From ControlValueAccessor interface
  registerOnChange(fn: any): void {
    this.onChangeCallback = fn;
  }

  // From ControlValueAccessor interface
  registerOnTouched(fn: any): void {
    this.onTouchedCallback = fn;
  }

  // From ControlValueAccessor interface
  writeValue(value: any): void {
    let valueChanged = false;
    if (value !== this.innerValue) {
      this.innerValue = value;
      valueChanged = true;
      if (!this.innerValue) {
        this.autoCompleteValue = [];
      }
    }
    if (value && Array.isArray(value) && this.autoCompleteType && (!this.autoCompleteValue || valueChanged)) {
      if (!this.codeAsValue) {
        this.hbAutoCompleteDropdownApiService.labelListByIdList(value, this.autoCompleteType).subscribe(response => {
          this.handleMultiAutoCompleteRes(response);
        });
      }
    }
  }

  setLoader() {
    document.getElementsByClassName("p-autocomplete-loader")[0]?.classList.add('showLoader');
  }

  handleMultiAutoCompleteRes(response: ApiResponse): void {
    if (response && response.status === 200 && response.data && response.data.list) {
      this.dropdownOptions = response.data.list;
      if (this.dropdownOptions[0]?.label) {
        this.autoCompleteValue = this.dropdownOptions;
      }
    } else {
      this.dropdownOptions = [];
    }
  }

  getDropdownOptions(event: any) {
    if (event.keyCode === 13 || (event.target?.value?.length == 0 && this.autoCompleteValue == null || this.autoCompleteValue?.length === 0) || event.inputValue) {
      if (event.inputValue) {
        this.autoCompleteChange(event.inputValue);
      } else {
        this.autoCompleteChange(event.target?.value);
      }
    }
  }

  autoCompleteChange(event): void {
    if (!event) {
      event = '';
    }
    if (this.autoCompleteType) {
      this.setLoader();
      const dropDownReqRes = new DropDownReqRes();
      dropDownReqRes.searchFor = event;
      this.setDropdownValues(dropDownReqRes);
      dropDownReqRes.codeAsLabel = this.codeAsLabel;

      this.hbAutoCompleteDropdownApiService.autoCompleteSearchDropdown(dropDownReqRes).subscribe(response => {
        if (response && response.status === 200 && response.data && response.data.dropdown.list) {
          this.dropdownOptions = [];
          this.addStaticOptions();
          this.dropdownOptions = this.dropdownOptions.concat(response.data.dropdown.list);
          if (response.data.dropdown.list.length == 0) {
            this.emptyMessage = true;
          }
        } else {
           this.dropdownOptions = [];
          if (response.data.dropdown.list == null) {
            this.emptyMessage = true;
          }
          this.addStaticOptions();
        }
      });
    }
  }

  onValueChange(dropdownOption: DropDownModel = null): void {
    if (dropdownOption) {
      this.onChange.emit(dropdownOption);
    } else {
      this.onChange.emit(this.value);
    }
  }

  setDropdownValues(dropDownReqRes: DropDownReqRes) {
    dropDownReqRes.type = this.autoCompleteType;
    dropDownReqRes.id = this.inventoryId;
  }

  addStaticOptions(): void {
    if (this.noneOption) {
      const option = new DropDownModel('(none)', null);
      this.dropdownOptions.push(option);
    }
  }

  setValue(dropdownOption): void {
    let tempValue = [];
    if (this.codeAsValue) {
      dropdownOption.forEach(element => {
        tempValue.push(element.code);
      });
      this.value = tempValue;
    } else {
      dropdownOption.forEach(element => {
        tempValue.push(element.id);
      });
      this.value = tempValue;
    }
    this.valueDataChange.emit(dropdownOption);
    this.onValueChange(dropdownOption);
  }

}
