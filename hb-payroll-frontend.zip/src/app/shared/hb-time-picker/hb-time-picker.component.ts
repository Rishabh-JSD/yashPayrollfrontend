import { Component, EventEmitter, forwardRef, Input, OnInit, Output, ViewChild } from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';
import { Calendar } from 'primeng/calendar';
import { HbErrorHandlerData } from '../models/hb-error-handler';

@Component({
  selector: 'hb-time-picker',
  template: `
    <div class="p-field" [ngClass]="{'error': errorHandler?.invalid}">
      <span class="p-float-label" [ngClass]="tooltipContent ? 'with-tooltip' : ''">
      <p-calendar
          [(ngModel)]="timeUI"
          [required]="required"
          [disabled]="disabled"
          [showTime]="true"
          [timeOnly]="timeOnly"
          [showSeconds]="showSeconds"
          [hourFormat]="hourFormat"
          (keydown.ArrowRight)="preventDefaultKeys($event)"
          (keydown.ArrowLeft)="preventDefaultKeys($event)"
          (onClose)="onBlurChange()"
          (onBlur)="onBlurChange()"
          (onSelect)="onTimeChange()"
          inputId="float-time"
          dataType="string"
          appendTo="body">
        </p-calendar>
        <label for="float-time">{{ placeHolder }} <small *ngIf="required">*</small></label>
      </span>
      <p *ngIf="errorHandler?.invalid" class="validation-message">{{ errorHandler?.errorMsg }}</p>
    </div>
  `,
  styles: [
    // Styles similar to HbDatePickerComponent
  ],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => HbTimePickerComponent),
      multi: true,
    },
  ],
})
export class HbTimePickerComponent implements OnInit, ControlValueAccessor {
  // Input properties
  @Input() required = false;
  @Input() disabled = false;
  @Input() placeHolder = '';
  @Input() tooltipContent = '';
  @Input() errorHandler: HbErrorHandlerData | undefined;
  @Input() showSeconds = false;
  @Input() timeOnly = false;
  @Input() hourFormat: string = '24';

  // Output event
  @Output() onChange: EventEmitter<any> = new EventEmitter();

  // Accessing child component
  @ViewChild(Calendar, { static: false }) timePicker: Calendar;

  // Internal property to bind ngModel
  timeUI: string | undefined | null;

  // Holds the inner value
  private innerValue: any = '';

  constructor() { }

  ngOnInit(): void { }

  // Prevent default behavior of arrow keys
  preventDefaultKeys(event: any): void {
    event.stopPropagation();
  }

  // Update timeUI on input blur/change
  onBlurChange(): void {
    const newTime = this.timePicker?.inputfieldViewChild?.nativeElement?.value || null;
    if (this.timeUI !== newTime) {
      this.timeUI = newTime;
      this.onTimeChange();
    }
  }

  //Process time change
  onTimeChange(): void {
    if (this.innerValue !== this.timeUI) {
      this.innerValue = this.timeUI;
      this.onChange.emit(this.innerValue);
      this.onTouchedCallback();
    }
  }

  // Set touched on blur
  onBlur(): void {
    this.onTouchedCallback();
  }

  // ControlValueAccessor interface methods
  get value(): any {
    return this.innerValue;
  }

  set value(v: any) {
    if (v !== this.innerValue) {
      this.innerValue = v;
      this.onChangeCallback(v);
      console.log("set", this.innerValue)
    }
  }

  // Write value to the component
  writeValue(value: any): void {
    this.innerValue = undefined;
    this.timeUI = value;
  }

  // Register change events
  registerOnChange(fn: any): void {
    this.onChangeCallback = fn;
  }

  // Register touch events
  registerOnTouched(fn: any): void {
    this.onTouchedCallback = fn;
  }

  // Private callbacks for touched and changed
  private onTouchedCallback: () => void = () => { };
  private onChangeCallback: (_: any) => void = () => { };
}
