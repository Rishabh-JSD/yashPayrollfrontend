export class Address {
  public id: number = null;
  public addressOne: string = null;
  public addressTwo: string = null;
  public cityName: string = null;
  public pincode: string = null;
  public stateName: string = null;
  public countryName: string = null;
}
