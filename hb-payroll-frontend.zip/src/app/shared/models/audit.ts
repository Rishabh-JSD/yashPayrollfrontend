export class Audit {
  public createdAt: Date;
  public createdBy: number;
  public updatedAt: Date;
  public updatedBy: number;
  public createdByName: string;
  public updatedByName: string;
}
