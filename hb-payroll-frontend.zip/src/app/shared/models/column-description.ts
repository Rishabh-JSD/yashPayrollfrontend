
export class ColumnDescription{

    columnName:string;
    description: string;
    mandatory:string;
    validation:string;

}

export interface ImportField {
    apiName: string;
    displayName: string;
    inputType: string;
    isMandatory: boolean;
    unique: boolean;
    listValidValues: SelectValidValue[];
    importFileColumnIndex: number;
    fieldValue: string;
    headerValue?: string;
    extraObject?:string;
    parent?:string,
    isList?:boolean,
    isStatic?:boolean,
    moduleTypeList?: string[]
}

interface SelectValidValue {
    apiId: string;
    displayName: string 
}

export interface Field {
    apiName: string;
    displayName: string;
    inputType: string;
    isMandatory: boolean;
    unique: boolean;
    listValidValues: SelectValidValue[];
    importFileColumnIndex: number;
    // importType : string,
    moduleTypeList?: string[]
}

interface SelectValidValue {
    apiId: string;
    displayName: string 
}

export class TemplateDropDown {
    public value: any;
    public templatelist: any[];
    public label: string;
    public txn_Type: string;
    public standard_templateFlag: boolean;
    public flipkart_templateFlag: boolean;
    public amazon_templateFlag: boolean;
    public marutiDms_templateFlag: boolean;
    public branch_assign: boolean;
    public opening_account: boolean;
  }

  export class MasterImportResponse{
    public rowData: any[];
    public errorList: any[];
  }
