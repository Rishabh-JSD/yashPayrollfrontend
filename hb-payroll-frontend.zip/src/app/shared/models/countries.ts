export class Countries {
  public id: number;
  public shortName: string;
  public name: string;
  public phoneCode: number;
}
