export class DocumentSeriesResponse{
    overrideFlag: boolean = null;
    seriesNumber: string = null;
    displayStyle:number ;
    currentNumber: string = null;
}