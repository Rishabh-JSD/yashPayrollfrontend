export class DocumentSeriesSetting {
    seriesId: number = null;
    docType: string = null;
    prefix: string = null;
    startNumber: string = null;
    endNumber: number = null;
    suffix: string = null;
    startDate: Date = null;
    displayStyle: number = null;
    status: boolean = null;
    branchList = new Array<number>();
    overrideFlag:boolean = false;
}