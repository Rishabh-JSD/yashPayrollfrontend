export class HbErrorHandler {
  invalid = false;
  errorFieldData: any = {};

  clearErrors(): void {
    this.invalid = false;
    this.errorFieldData = {};
  }

  addError(msg: string, key: string): void {
    this.invalid = true;
    this.errorFieldData[key] = new HbErrorHandlerData(true, msg);
  }

  removeError(key: string): void {
    this.errorFieldData[key] = undefined;
  }

  emptyCheck(value: string | number | undefined | any, parentkey: string, childkey?: string, keyIndex?: number): void {
    let isEmpty = false;
    if (value) {
      if (typeof value === 'number') {
        if (value === 0) {
          isEmpty = true;
        }
      } else if (typeof value === 'string') {
        if (!value.trim()) {
          isEmpty = true;
        }
      } else if (typeof value === 'object') {
        const len = 'length';
        if (Array.isArray(value) && value[len] === 0) {
          isEmpty = true;
        }
      }
    } else {
      isEmpty = true;
    }
    if (isEmpty) {
      if ((keyIndex || keyIndex === 0) && childkey) {
        this.addError('Required', parentkey + '[' + keyIndex + '].' + childkey);
      } else if (parentkey && childkey) {
        this.addError('Required', parentkey + '.' + childkey);
      } else {
        this.addError('Required', parentkey);
      }
    }
  }

  emptyCheckList(list: any[], parentkey: string, arrayErrorList: HbArrayError[]): void {
    if (list) {
      let index1 = 0;
      list.forEach(element1 => {
        arrayErrorList.forEach(arrayError => {
          this.emptyCheck(element1[arrayError.key], parentkey, arrayError.key, index1);
          if (arrayError.duplicateCheck && element1[arrayError.key] && index1 > 0) {
            let index2 = 0;
            list.forEach(element2 => {
              if (element1[arrayError.key] === element2[arrayError.key] && index1 !== index2) {
                this.addError('Duplicate', parentkey + '[' + index1 + '].' + arrayError.key);
              }
              index2++;
            });
          }
        });
        index1++;
      });
    }
  }

  getErrorHandlerData(parentkey: string, childkey?: string, keyIndex?: number): HbErrorHandlerData {
    if ((keyIndex || keyIndex === 0) && childkey) {
      return this.errorFieldData[parentkey + '[' + keyIndex + '].' + childkey];
    } else if (parentkey && childkey) {
      return this.errorFieldData[parentkey + '.' + childkey];
    } else {
      return this.errorFieldData[parentkey];
    }
  }
}

export class HbErrorHandlerData {
  invalid: boolean;
  errorMsg: string;

  constructor(invalid: boolean, errorMsg: string) {
    this.invalid = invalid;
    this.errorMsg = errorMsg;
  }
}

export interface HbArrayError {
  key: string;
  duplicateCheck: boolean;
}
