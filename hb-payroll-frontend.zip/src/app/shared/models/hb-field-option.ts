
export type FieldOptionType = 'text' | 'number' | 'textarea' | 'checkbox' | 'radio' | 'dropdown' | 'multi-select' | 'date-picker';

export type AutoCompleteOptionType = 'PINCODE' | 'CITY' | 'COUNTRY' | 'MASTER_OPTION' | 'BRANCH' | 'COST_CENTER' | 'DEPARTMENT' | 'FIXED_MASTERS' | 'EMPLOYEE' | 'INDUSTRY' | 'DISPLAY_STYLE' | 'STATE' | 'LEAVE_TYPE' | 'HOLIDAY_TYPE';

export type AutoCompleteOptionCode = 'EMPS' | 'DES' | 'DED' | 'EMPT' | 'EMPL' | 'SHIFTTYPE' | 'SHIFTTIME' | 'PAYF' | 'ALW' | 'REIM' | 'DOCTYPE' | 'DOCCAT';

export type DropDownOptionType = 'SHIFT_TYPE' | 'Employee' | 'DOCUMENT_SERIES_STATUS' | 'DOC_TYPE';

export class DropDownModel {
  label: string | undefined;
  code: any | undefined;
  id: number | undefined;
  value: number | undefined;
  isNew?= false;
  isNewitem?= 0;

  constructor(label?: string, id?: number) {
    this.label = label;
    this.id = id;
  }
}

export class DropDownOption {
  static fetchDropDownOptionByType(type: DropDownOptionType): DropDownModel[] {
    switch (type) {
      case 'SHIFT_TYPE': {
        return [
          { label: 'Day', code: undefined, id: undefined, value: undefined },
          { label: 'Night', code: undefined, id: undefined, value: undefined },
        ];
      }
      case 'Employee': {
        return [
          { label: 'From SO', code: 'FSO', id: undefined, value: undefined },
          { label: 'Manual', code: 'MNL', id: undefined, value: undefined }
        ];
      }
      case 'DOCUMENT_SERIES_STATUS': {
        return [
          { label: 'Active', code: true, id: undefined, value: undefined },
          { label: 'In-Active', code: false, id: undefined, value: undefined }
        ];
      }
      case 'DOC_TYPE': {
        return [
          { label: 'Employee', code: 'EMP', id: undefined, value: undefined },
          { label: 'Remburisement Claim', code: 'RECLAIM', id: undefined, value: undefined },
        ];
      }
      default: {
        return [];
      }
    }
  }
}
