export class ImportMasterTemplate{
    public id: number;
    public templateName: string;
    public txnType: string;
    public standard_templateFlag : boolean;
    public flipkart_templateFlag: boolean;
    public amazon_templateFlag: boolean;
    public marutiDms_templateFlag: boolean;
    public opening_accountFlag: boolean;
    public branch_assigntFlag: boolean;
    public key: string[];
    public fieldDisplay: string[];

    constructor() { }
}