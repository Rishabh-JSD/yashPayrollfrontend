import { ImportField } from "./column-description";

export class ImportMaster {
    public rowCellsList:any[];
    public importType: string;
    constructor() { }
}