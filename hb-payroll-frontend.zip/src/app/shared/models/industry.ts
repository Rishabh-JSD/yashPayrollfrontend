export class Industry {
  public industryId: number;
  public code: string;
  public name: string;
  public description: string;
}
