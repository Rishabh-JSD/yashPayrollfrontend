export class Pincode {
  public id: number;
  public pincode: string;
  public cityId: number;
}
