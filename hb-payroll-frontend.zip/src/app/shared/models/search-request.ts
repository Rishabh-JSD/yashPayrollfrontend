export class SearchRequest {
  page: number;
  limit: number;
  firstLimit: number;
  endLimit: number;
  sortType: number;
  sortField: string;
}
