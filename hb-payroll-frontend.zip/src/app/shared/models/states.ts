export class States {
  public id: number;
  public countryId: number;
  public countryCode: string;
  public name: string;
  public stateAbbrevCode: string;
  public gstinPrefix: string;
  public stateCode: number;
}
