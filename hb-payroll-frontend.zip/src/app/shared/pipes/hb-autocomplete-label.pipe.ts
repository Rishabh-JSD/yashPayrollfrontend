import { Pipe, PipeTransform } from "@angular/core";
import { AutoCompleteOptionType, DropDownModel, DropDownOptionType } from "../models/hb-field-option";
import { HbAutoCompleteDropdownApiService } from "../services/hb-auto-complete-dropdown-api.service";
import { ApiResponse } from "src/app/core/models/api-response";

@Pipe({
  name: 'HblabelPipe',
})
export class HblabelPipe implements PipeTransform {
  autoCompleteType: AutoCompleteOptionType | undefined;
  dropdownOptions: DropDownModel[] = [];

  constructor(private hbAutoCompleteDropdownApiService: HbAutoCompleteDropdownApiService) { }

  //code as label is used if we want to show code using this label pipe
  transform(value: any, type?: DropDownOptionType | DropDownModel[] | any | AutoCompleteOptionType, codeAsLabel: boolean = false): any {
    if (value && Array.isArray(value) && value.every(element => typeof element === 'number')) {
      return new Promise<string>((resolve, rejects) => {
        this.hbAutoCompleteDropdownApiService.labelListByIdList(value, type).subscribe(response => {
          resolve(this.handleAutoCompleteRes(response, true));
        });
      });
    } else if (+value) {
      return new Promise<string>((resolve, reject) => {
        this.hbAutoCompleteDropdownApiService.labelDataById(value, type).subscribe(response => {
          resolve(this.handleAutoCompleteRes(response, false, codeAsLabel));
        });
      });
    }
  }

  handleAutoCompleteRes(response: ApiResponse, isArray: boolean, codeAsLabel: boolean = false): string {
    let str = '';
    if (isArray) {
      if (response?.status === 200 && response.data?.list) {
        response.data?.list?.forEach((element, index) => {
          str += element.label;
          if (index != response.data?.list.length - 1) {
            str += ', ';
          }
        });

      }
    } else {
      if (response?.status === 200 && response.data?.list) {
        if (codeAsLabel) {
          str += response.data?.list?.code;
        } else {
          str += response.data?.list?.label;
        }
      }
    }
    return str;
  }
}
