import { DatePipe } from '@angular/common';
import { Injectable, Pipe, PipeTransform } from '@angular/core';
import { AppConst } from '../../core/constants/app-const';

@Pipe({ name: 'hbDateFormat' })
@Injectable({ providedIn: 'root' })
export class HbDateFormatPipe implements PipeTransform {
  constructor() { }

  transform(value: any, type?: string): any {
    if (!type || type === 'withTime') {
      let formatter = 'dd/MM/yyyy';
      if (type === 'withTime') {
        formatter = 'dd/MM/yyyy h:mm:ss a';
      }
      if (!value || value === '') {
        return '';
      }
      return new DatePipe('en-IN').transform(value, formatter);
    } else if (value && type === 'mothYear') {
      const str = value + '';
      if (str.length === 5) {
        return (
          AppConst.MONTH_LIST[+str.substring(0, 1)] +
          '-' +
          str.substring(1, 5)
        );
      } else if (str.length === 6) {
        return (
          AppConst.MONTH_LIST[+str.substring(0, 2)] +
          '-' +
          str.substring(2, 6)
        );
      }
    }
  }

  transformDate(dateString: string): string {
    const date = new Date(dateString);
    const day = date.getDate().toString().padStart(2, '0');
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const year = date.getFullYear();
    return `${ day }-${ month }-${ year }`;
  }
}
