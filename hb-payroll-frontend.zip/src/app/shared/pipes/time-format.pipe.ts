import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'timeFormat'
})
export class TimeFormatPipe implements PipeTransform {
  transform(time: string): string {
    // Parse the input time string
    const parsedTime = new Date(time);

    // Extract hours, minutes, and AM/PM
    const hours = parsedTime.getHours();
    const minutes = parsedTime.getMinutes();
    const period = hours >= 12 ? 'PM' : 'AM';

    // Convert to 12-hour format
    const formattedHour = (hours % 12) || 12;

    // Pad minutes with leading zero if needed
    const formattedMinutes = minutes < 10 ? `0${ minutes }` : minutes;

    // Construct the formatted time string
    const formattedTime = `${ formattedHour }:${ formattedMinutes } ${ period }`;

    return formattedTime;
  }
}
