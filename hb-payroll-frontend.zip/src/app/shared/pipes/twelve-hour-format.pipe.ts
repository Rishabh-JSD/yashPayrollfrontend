import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'twelveHourFormat',
})
export class TwelveHourFormatPipe implements PipeTransform {
  transform(time: any): any {
    let hour = time.split(':')[0];
    let min = time.split(':')[1];
    const part = hour >= 12 ? 'PM' : 'AM';
    if (+hour === 0) {
      hour = 12;
    }
    min = min.toString().length === 1 ? `0${ min }` : min;
    hour = hour > 12 ? hour - 12 : hour;
    hour = hour.toString().length === 1 ? `0${ hour }` : hour;
    return `${ hour }:${ min } ${ part }`;
  }
}
