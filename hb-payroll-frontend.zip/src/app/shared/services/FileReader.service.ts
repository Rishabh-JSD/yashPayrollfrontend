import * as XLSX from 'xlsx';
import { AlphabetService } from './alphabet.service';
import { Injectable } from "@angular/core";
type AOA =any [][];

@Injectable()
export class FileReaderService{
    data: any[][];
    getDataFromWorkSheet(e:any, index = 0):any[][]{
       
       const bstr: string = e.target.result;
       const wb: XLSX.WorkBook = XLSX.read(bstr, {type: 'binary',cellDates: true, dateNF: 'dd/mm/yyyy', });
       
       /* grab first sheet */
       const wsname: string = wb.SheetNames[index];
       const ws: XLSX.WorkSheet = wb.Sheets[wsname];
 
       /* save data */
       this.data = <AOA>(XLSX.utils.sheet_to_json(ws, {header: 1,  raw: false}));
       return this.data;
    }  
    calculateMaximum(data: any[][]) {
        let i=0;
        let maximum = data[i].length;
        for(i =1; i<data.length;i++){
            if(maximum < data[i].length){
                maximum = data[i].length;
            }
        }
        return maximum;
    }

    fetchDisplayedColumns(data: any[][], checkboxValue:boolean, maximum): any[] {
        let displayedColumns=[];
        if(checkboxValue){
            let i ;
            for(i=0;i<data[0].length; i++){
                displayedColumns.push(data[0][i]);                
            }           
        }
        else{
            let i ;
            for(i=0;i<maximum; i++){
                displayedColumns.push( AlphabetService.Alaphabet(i));
            }
        }
        return displayedColumns;
    }

   dropValue(displayedColumns, dropDownImport, checkboxValue: boolean): any[]{
    let dropValue =[],i,j;
    
    if(checkboxValue){
        for(i =0;i<displayedColumns.length;i++){
            let checker =0;
           for(j=0;j<dropDownImport.length;j++){
             if(displayedColumns[i] != undefined){               
                if(displayedColumns[i].toString().replace(/\s/g, "").toLowerCase() === dropDownImport[j].label.toString().replace(/\s/g, "").toLowerCase()){
                    checker++;
                    const practice = {
                        value: dropDownImport[j].value,
                        label: dropDownImport[j].label
                    }
                    dropValue.push(practice);
                    j= dropDownImport.length;
                    }
                }
            }
           if(checker === 0){
            const practice = {
                value: "noImport",
                label: "--No Import Match--"
              }
              dropValue.push(practice);
           }            
        }
    }
    else{
        for(i =0;i<displayedColumns.length;i++){
            const practice = {
                value: "noImport",
                label: "--No Import Match--"
              }
              dropValue.push(practice);
        }
    }
    return dropValue;
   }
}