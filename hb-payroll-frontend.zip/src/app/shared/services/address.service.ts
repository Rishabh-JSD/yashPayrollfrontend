import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HBHttpService } from 'src/app/core/services/hb-http-service.service';

@Injectable({
  providedIn: 'root',
})
export class AddressService {
  constructor(private hbHttpClient: HBHttpService) {}

  addAddress(data: any): Observable<any> {
    return this.hbHttpClient.getResponse('address/add', this.hbHttpClient.POST, data);
  }

  updateAddress(data: any): Observable<any> {
    return this.hbHttpClient.getResponse('address/update', this.hbHttpClient.POST, data);
  }

  getListAddress(data: any): Observable<any> {
    return this.hbHttpClient.getResponse('address/list', this.hbHttpClient.POST, data);
  }

  getAddress(id: any): Observable<any> {
    return this.hbHttpClient.getResponse(`address/${ id }`, this.hbHttpClient.GET);
  }

  deleteAddress(id: any): Observable<any> {
    return this.hbHttpClient.getResponse('address/delete?addressId=' + id, this.hbHttpClient.DELETE);
  }

  getPincodeDetail(data:any): Observable<any> {
    return this.hbHttpClient.getResponse('address/pinCodeDetail?pinCode=' + data, this.hbHttpClient.GET);
  }
  
}
