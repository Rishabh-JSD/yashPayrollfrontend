import { Injectable } from '@angular/core';

@Injectable()
export class AlphabetService {

  constructor() { }
  public static Alaphabet(i){
    const index1 = Math.floor(i/26);
    const index2 = i%26;
    const alaphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    if(i<26){
      return alaphabet[i]
    }
    else{
      return alaphabet[index1-1]+ alaphabet[index2];
    }
  }
}
