import { Injectable } from "@angular/core";
import { ColumnDescription, ImportField } from "../models/column-description";


@Injectable()
export class ColumnDescriptionWritingService {

  constructor() { }

  write(fields: ImportField[]): ColumnDescription[] {
    let result = new Array<ColumnDescription>();
    for (let i = 0; i < fields.length; i++) {
      if (fields[i].displayName != 'Sub Type') {
        let obj = new ColumnDescription();
        obj.columnName = fields[i].displayName;
        obj.description = `It is ${fields[i].displayName}.`;

        if (fields[i].isMandatory) {
          obj.mandatory = "Yes";
        }
        else {
          obj.mandatory = "No";
        }

        obj.validation = "";
        let counter = 1;
        if (fields[i].inputType != "text") {
          obj.validation = `It must be a ${fields[i].inputType}`;
          if (fields[i].inputType == "date") {
            obj.validation = ` ${obj.validation} format should be DD/MM/YYYY. `;
          }
        }

        if (fields[i].unique) {
          // obj.validation = `${obj.validation}${(counter++).toString()}. It must not already exist. `;
          // obj.validation = `${obj.validation}${(counter++).toString()}.  It must not exist more than once inside file to be imported.`
          obj.validation = `${obj.validation} ${fields[i].displayName} should be unique. `;
        }

        if (fields[i].listValidValues) {
          obj.validation = `${obj.validation} ${(counter++).toString()}. ` +
            'It must exist in the database. ' +
            'If not provided in file, you can select valid value from dropdown menu after loading file.'
        }

        if (fields[i].moduleTypeList.includes('Sales Order') || fields[i].moduleTypeList.includes('Quote') || fields[i].moduleTypeList.includes('Sales')
          || fields[i].moduleTypeList.includes('Bill') || fields[i].moduleTypeList.includes('Debit Note') || fields[i].moduleTypeList.includes('Credit Note')
          || fields[i].moduleTypeList.includes('Purchase Order') || fields[i].moduleTypeList.includes('Delivery Challan') || fields[i].moduleTypeList.includes('Chart of Accounts')
          || fields[i].moduleTypeList.includes('Account Group') || fields[i].moduleTypeList.includes('Contacts') || fields[i].moduleTypeList.includes('Receive Money')
          || fields[i].moduleTypeList.includes('Spend Money') || fields[i].moduleTypeList.includes('Transfer Order')) {
          if (fields[i].displayName == 'Number' && fields[i].moduleTypeList?.[0] === 'Purchase Order') {
            obj.description = 'Enter Order Number';
            obj.validation = `Order number not required if ‘Automatic’ selected in the Order Number’ dropdown given above. It should be unique, two lines having same Order number consider one Purchase Order. `;
          } else if (fields[i].displayName == 'Number') {
            obj.description = 'Enter Invoice Number';
            obj.validation = `Invoice number not required if ‘Automatic’ selected in the ‘Invoice Number’ dropdown given above. It should be unique, two lines having same invoice number consider one invoice. `;
          } else if (fields[i].displayName == 'Document Index' && fields[i].moduleTypeList?.[0] === 'Purchase Order') {
            obj.description = 'Enter Document Index Number';
            obj.validation = `'This function is available only if ‘Automatic’ selected in the Order Number’ dropdown given above and must have document series setting done. Specify the sequencing of data in the excel file which is to be imported. [For Example, there is 10 rows in the excel pertaining to 2 Purchase Order (where first 7 for Purchase Order 1 and next 3 for Purchase Order 2) in that case user can specify 1 to the first 7 rows and 2 to the next 3 rows].`;
          }  else if (fields[i].displayName == 'Document Index') {
            obj.description = 'Enter Document Index Number';
            obj.validation = `'This function is available only if ‘Automatic’ selected in the ‘Invoice Number’ dropdown given above and must have document series setting done. Specify the sequencing of data in the excel file which is to be imported. [For Example, there is 10 rows in the excel pertaining to 2 invoices (where first 7 for Invoice 1 and next 3 for Invoice 2) in that case user can specify 1 to the first 7 rows and 2 to the next 3 rows].`;
          } else if (fields[i].displayName == 'Billing Pincode') {
            obj.description = 'Billing Pin Code in which data to be imported';
            obj.validation = `If Billing Pin Code is there, then Billing Address should be there.`;
          } else if (fields[i].displayName == 'Billing address') {
            obj.description = 'Billing Address in which data to be imported';
            obj.validation = `${obj.validation} If Billing Address is there, then Billing Pin Code should be there.`;
          } else if (fields[i].displayName == 'Shipping address') {
            obj.description = 'Shipping Address in which data to be imported';
            obj.validation = `${obj.validation} If Shipping Address is there, then Shipping Pin Code should be there.`;
          } else if (fields[i].displayName == 'Shipping Pincode') {
            obj.description = 'Shipping Pin Code in which data to be imported';
            obj.validation = `If Shipping Pin Code is there, then Shipping Address should be there.`;
          } else if (fields[i].displayName == 'Branch') {
            obj.description = 'Branch of company in which data to imported';
            obj.validation = `${obj.validation} Select Branch as per requirement, mandatory in case of branch accounting.`;
          } else if (fields[i].displayName == 'Company GSTIN') {
            obj.description = 'GSTIN of Company in data to be imported';
            obj.validation = `${obj.validation} Select Company GSTIN as per requirement.`;
          } else if (fields[i].displayName == 'Category') {
            obj.description = 'Category in which data to be imported';
            obj.validation = `${obj.validation} Select Category as per requirement.`;
          } else if (fields[i].displayName == 'Account Name') {
            obj.description = 'Account in which data to be imported';
            obj.validation = `${obj.validation} If sales account entered in the excel sheet as well as under common field above then data import in common Sales Account.`;
            if (fields[i].moduleTypeList.includes("Bill")) {
              obj.validation = `If purchase account entered in the excel sheet as well as under common field above then data import in common Purchase Account.`;
            }
          } else if (fields[i].displayName == 'Customer Code') {
            obj.description = 'Customer code as master';
          } else if (fields[i].displayName == 'Customer Name') {
            obj.description = 'Customer Name as master';
          } else if (fields[i].displayName == 'Item') {
            obj.description = 'Item Name as per master';
          } else if (fields[i].displayName == 'Item Code') {
            obj.description = 'Item Code as per master';
          } else if (fields[i].displayName == 'Unit Price' || fields[i].displayName == 'Quantity') {
            obj.description = `Enter ${fields[i].displayName}`;
            obj.validation = 'It should not be empty';
          } else if (fields[i].displayName == 'Currency') {
            if (fields[i].moduleTypeList.includes('Bill')) {
              obj.description = 'Enter or Select Bill Type as per master';
            } else {
              obj.description = 'Enter or Select Invoice Type as per master';
            }
            obj.validation = `${obj.validation} If not entered, by default 'INR' selected.`;
          } else if (fields[i].displayName == 'Tax Rate') {
            obj.description = 'Select or Enter Tax Rate as per master';
          } else if (fields[i].displayName == 'GST rate') {
            obj.description = 'Select or Enter GST Rate as per master';
            if (fields[i].moduleTypeList.includes('Bill')) {
              obj.validation = 'Refer tax setting';
            }
          } else if (fields[i].displayName == 'Discount' || fields[i].displayName == 'Add Discount'
            || fields[i].displayName == 'Additional Discount' || fields[i].displayName == 'Add cess'
            || fields[i].displayName == 'Additional Cess' || fields[i].displayName == 'Cess'
            || fields[i].displayName == 'Freight charge') {
            obj.description = `Enter ${fields[i].displayName} Amount`;
          } else if (fields[i].displayName == 'Reverse Charge') {
            obj.description = 'Select Yes/No for applying and removing reverse charge';
          } else if (fields[i].displayName == 'place of supply') {
            obj.description = 'Provide option to add Place of supply in the import, if place of supply not entered while import, then place of supply will be taken as per business GSTIN';
          } else if (fields[i].displayName == 'Service Charge' || fields[i].displayName == 'Packing Charge'
            || fields[i].displayName == 'Making Charge') {
            obj.description = `${fields[i].displayName} on the item`;
          } else if (fields[i].displayName == 'NIL/Exempt Rate') {
            obj.description = "This field is only required when taxable and exempt both supplies are under one invoice and supplied to Unregistered Person; Item which is exempt, select this field as applicable GST rate not required to be selected; in case transaction has only exempt supply then use Bill of Supply import; if details not been provided  then default is 'None'";
          } else if (fields[i].displayName == 'Cost Centre') {
            obj.description = 'Select or Enter cost centre as per master';
          } else if (fields[i].displayName == 'Date' && fields[i].moduleTypeList?.[0] === 'Purchase Order') {
            obj.description = 'Enter Order Date ';
            obj.validation = 'Order Date format should be DD/MM/YYYY';
          } else if (fields[i].displayName == 'Date') {
            obj.description = 'Enter Invoice Date ';
            obj.validation = 'Invoice Date format should be DD/MM/YYYY';
          } else if (fields[i].displayName == 'Expiry Date') {
            obj.description = 'Enter Expiry Date';
            obj.validation = 'Due Date format should be DD/MM/YYYY, If not given in excel than Invoice Date set as Due Date.';
          } else if (fields[i].displayName == 'Description') {
            obj.description = 'Enter Description of Item sold';
            obj.validation = 'Description is mandatory if Item is not given';
          } else if (fields[i].displayName == 'Conversion Type') {
            obj.description = 'Conversion type dropdown i.e. Full conversion, Partial conversion';
            // obj.validation = 'By default ‘Partial conversion’ is selected';
            obj.validation = 'Take Conversion type i.e. Full conversion, Partial conversion';
          } else if (fields[i].fieldValue == 'orderType') {
            obj.description = 'Order type dropdown i.e. Standard SO and Open SO';
            obj.validation = 'By default ‘Standard SO’ is selected';
          } else if (fields[i].fieldValue == 'orderTypePO') {
            obj.description = 'Order type dropdown i.e. Standard PO and Open PO';
            obj.validation = 'By default ‘Standard PO’ is selected';
          } else if (fields[i].fieldValue == 'orderTypeTO') {
            obj.description = 'Order type dropdown i.e. Standard TO and Open TO';
            obj.validation = 'By default ‘Standard TO’ is selected';
          } else if (fields[i].displayName == 'Voucher Number') {
            obj.description = 'Enter Voucher Number';
            obj.validation = 'It should be unique, two line items having same voucher number considered one Bill.';
          } else if (fields[i].displayName == 'Voucher Date') {
            obj.description = 'Enter Voucher Date';
            obj.validation = 'Voucher Date format should be DD/MM/YYYY.';
          } else if (fields[i].displayName == 'Bill Number') {
            obj.description = 'Enter Bill Number';
            obj.validation = 'It should be unique, two line items having same Bill number considered one Bill.';
          } else if (fields[i].displayName == 'Bill Date') {
            obj.description = 'Enter Bill Date';
            obj.validation = 'Bill Date format should be DD/MM/YYYY.';
          } else if (fields[i].displayName == 'Transaction Date') {
            obj.description = 'Enter the transaction date, it will be considered for ITC availment in the GST return';
            obj.validation = 'Transaction Date format should be DD/MM/YYYY.';
          } else if (fields[i].displayName == 'Due Date') {
            obj.description = 'Enter Due Date';
            obj.validation = 'Due Date format should be DD/MM/YYYY.';
          } else if (fields[i].displayName == 'Bill Type') {
            obj.description = 'Enter or Select Bill Type as per list';
            obj.validation = 'If not entered, by default `Regular` selected in case of Vendor having GSTIN otherwise default is NA, refer purchase Bill for other options in the list.';
          } else if (fields[i].displayName == 'Vendor Name') {
            obj.description = 'Vendor Name as Master';
            obj.validation = 'If two different Vendor having same name, user must specify the Vendor code to differentiate otherwise entry will be post on first Vendor.';
          } else if (fields[i].displayName == 'Vendor Code') {
            obj.description = 'Vendor Code as Master';
            obj.validation = '';
          } else if (fields[i].displayName == 'Amounts are') {
            obj.description = 'It is Amounts Are';
            obj.validation = 'Not mention we are taking Tax Exclusive by default';
          } else if (fields[i].displayName == 'Item Type') {
            obj.description = 'Select or Enter Item as per master ';
            obj.validation = 'If not entered, by default `Services` is selected';
          } else if (fields[i].displayName == 'Account') {
            obj.description = 'Select or Enter Purchase Account as per master';
            obj.validation = `If purchase account entered in the excel sheet as well as under common field above then data import in common Purchase Account.`;
          } else if (fields[i].displayName == 'Freight Charges' || fields[i].displayName == 'Delivery Charges') {
            obj.description = `Enter ${fields[i].displayName} Amount`;
          } else if (fields[i].displayName == 'Terms & Condition') {
            obj.description = 'Enter Terms & Conditions';
            obj.validation = `Terms & Conditions will be entered Bill wise i.e. if an Bill having multiple line items then enter Terms & condition in first line item, no need to entered in every line items`;
          } else if (fields[i].displayName == 'Vendor Notes') {
            obj.description = 'Enter Vendor Notes';
            obj.validation = `Vendor Notes will be entered Bill wise i.e. if an Bill having multiple line items then enter Vendor Notes in first line item, no need to entered in every line items`;
          } else if (fields[i].displayName == 'ITC Eligibility') {
            obj.description = 'Enter ITC Eligibility option as per the list';
            obj.validation = `By default it is taking Input Goods, refer a purchase invoice for other options in the list`;
          } else if (fields[i].displayName == 'ITC Claim') {
            obj.description = 'Enter % of ITC to be claimed for the line item to be imported';
          } else if (fields[i].displayName == 'TDS Rate') {
            obj.description = 'Enter TDS Rate';
            obj.validation = `TDS Rate as per master, refer Chart of accounts or tax setting`;
          } else if (fields[i].displayName == 'TDS') {
            obj.description = 'Enter TDS Amount as per TDS Rate';
            obj.validation = `TDS Amount as per TDS rate`;
          } else if (fields[i].displayName == 'Type of Import') {
            obj.description = 'Choose type of import transaction';
            obj.validation = `Choose from these- Import of Goods, Import of Goods from SEZ, Import of Services, Import of Services from SEZ`;
          } else if (fields[i].displayName == 'Bill of Entry Port Code') {
            obj.description = 'Enter the Port Code from where goods are cleared';
          } else if (fields[i].displayName == 'Bill of Entry Date') {
            obj.description = 'Enter the Bill of Entry Date';
          } else if (fields[i].displayName == 'Bill of Entry Number') {
            obj.description = 'Enter the Bill of Entry Number';
          } else if (fields[i].displayName == 'Status') {
            obj.description = 'Select document save option';
            obj.validation = `Choose from these- Save as Draft, Approve and submit for approval`;
          } else if (fields[i].displayName == 'Invoice Type') {
            obj.description = 'Enter or Select Invoice Type as per master';
            obj.validation = `${obj.validation} If not entered, by default 'Regular' selected in case of Customer having GSTIN otherwise default is 'NA'.`;
          } else if (fields[i].displayName == 'Order Item ID') {
            obj.description = 'It is Order Item ID';
          } else if (fields[i].displayName == 'Taxable Value (Final Invoice Amount -Taxes)') {
            obj.description = 'It is Taxable Value';
          } else if (fields[i].displayName == 'Final Invoice Amount (Price after discount+Shipping Charges)') {
            obj.description = 'It is Final Invoice Amount (Price after discount+Shipping Charges)';
            obj.validation = `${obj.validation} Should not be empty.`;
          } else if (fields[i].displayName == 'Buyer Invoice Amount') {
            obj.description = 'It is Buyer Invoice Amount';
            obj.validation = `${obj.validation} Should not be empty.`;
          } else if (fields[i].displayName == 'Delivery Challan Type') {
            obj.description = 'Enter or Select Delivery Challan Type as per list';
            obj.validation = `${obj.validation} If not entered, by default 'Job Work' selected.`;
          } else if (fields[i].fieldValue == 'accountType') {
            obj.description = 'Enter Account Type as per the Chart of account structure';
            obj.validation = `${obj.validation} Refer Chart of accounts.`;
          } else if (fields[i].fieldValue == 'parentGroup') {
            obj.description = 'Enter the immediate parent group of the account';
            obj.validation = `${obj.validation} Default selected is primary group i.e. account will be created under the account type if parent group for the account not selected.`;
          } else if (fields[i].fieldValue == 'parentGroupCode') {
            obj.description = 'Enter the immediate parent group code of the account';
            obj.validation = `${obj.validation} if parent group is selected then Parent Group Code is mandatory.`;
          } else if (fields[i].fieldValue == 'accountCode') {
            obj.description = 'Enter the account code';
          } else if (fields[i].fieldValue == 'chartAccountName') {
            obj.description = 'Enter the account name';
          } else if (fields[i].fieldValue == 'accountDescription') {
            obj.description = 'Enter the account description';
          } else if (fields[i].fieldValue == 'openingBalance') {
            obj.description = 'Enter opening balance of accounts, if any';
          } else if (fields[i].fieldValue == 'dashboard') {
            obj.description = 'User can add any accounts under its watchlist, which will be available at dashboard';
            obj.validation = `${obj.validation} By default No, Yes to show on Dashboard.`;
          } else if (fields[i].fieldValue == 'expenseClaimFlag') {
            obj.description = 'Allow to pass expense entries for this account';
            obj.validation = `${obj.validation} By default No, Yes to show the account on Expense.`;
          } else if (fields[i].fieldValue == 'paymentFlag') {
            obj.description = 'Allow to enable payment to this account';
            obj.validation = `${obj.validation} By default No, Yes to show on Payment.`;
          } else if (fields[i].fieldValue == 'subParentAccountGroupCode') {
            obj.description = 'Enter the sub parent account group code of the account';
            obj.validation = `${obj.validation} If sub parent account group is not empty then it should not be empty.`;
          } else if (fields[i].fieldValue == 'aDescription') {
            obj.description = 'Enter the description';
            obj.validation = `${obj.validation} description.`;
          } else if (fields[i].fieldValue == 'contactName') {
            obj.validation = `${obj.validation} Shouldn't be empty.`;
          } else if (fields[i].fieldValue == 'contactCode') {
            obj.validation = `${obj.validation} 1. If not provide we will give our own 2.  Should be unique.`;
          } else if (fields[i].fieldValue == 'ledgerCode') {
            obj.validation = `${obj.validation} 1. If not provide we will give our own 2.  Should be unique.`;
          } else if (fields[i].fieldValue == 'ledgerGroupCode') {
            obj.validation = `${obj.validation} 1. If not provide we will give our own 2.  Should be available.`;
          } else if (fields[i].fieldValue == 'firstName') {
            obj.validation = `${obj.validation} If last Name is not empty then it should not be empty.`;
          } else if (fields[i].fieldValue == 'mobileNumber') {
            obj.validation = `${obj.validation} Accepting the  Mobile Numbers 1. 9999999999.`;
          } else if (fields[i].fieldValue == 'phoneNumber') {
            obj.validation = `${obj.validation} Accepting the  Phone Number -011-2342345.`;
          } else if (fields[i].fieldValue == 'zip') {
            obj.validation = `${obj.validation} Shouldn't be empty if address for that contact is there.`;
          } else if (fields[i].fieldValue == 'gstin') {
            obj.validation = `${obj.validation} Accepting the following formats -11AAAAA1111A1Z1.`;
          } else if (fields[i].fieldValue == 'pan') {
            obj.validation = `${obj.validation} Accepting the following formats - AAAAA1111A.`;
          } else if (fields[i].fieldValue == 'primaryType') {
            obj.validation = `${obj.validation} Shouldn't be empty.`;
          } else if (fields[i].fieldValue == 'designation') {
            obj.validation = `${obj.validation} If Primary type is Employee then Designation is mandatory.`;
          } else if (fields[i].fieldValue == 'priceTrackingName1' || fields[i].fieldValue == 'priceTrackingName2' ||
            fields[i].fieldValue == 'priceTrackingName2') {
            obj.validation = `${obj.validation} If Price Tracking List is given then Price Tracking Name is mandatory.`;
          } else if (fields[i].fieldValue == 'receiptNumber') {
            obj.description = 'Enter Receipt Number';
            obj.validation = `${obj.validation} It should be unique, two line items having same voucher number considered one Bill.`;
          } else if (fields[i].fieldValue == 'receiptDate') {
            obj.description = 'Enter Receipt Date';
            obj.validation = `${obj.validation} Receipt Date format should be DD/MM/YYYY.`;
          } else if (fields[i].fieldValue == 'customerName') {
            obj.description = 'Customer Name as master';
            obj.validation = `${obj.validation} If two different Customer having same name, user must specify the Customer code to differentiate otherwise entry will be post on first Customer.`;
          } else if (fields[i].fieldValue == 'customerCode') {
            obj.description = 'Customer Code as master';
          } else if (fields[i].fieldValue == 'currency') {
            obj.description = 'Please enter or select currency as per master';
            obj.validation = `${obj.validation} If not entered, by default 'INR' selected`;
          } else if (fields[i].fieldValue == 'currency') {
            obj.description = 'Please enter or select currency as per master';
            obj.validation = `${obj.validation} If not entered, by default 'INR' selected`;
          } else if (fields[i].fieldValue == 'paymentAdjAmount') {
            obj.description = 'Enter Adjustment Amount';
            obj.validation = `${obj.validation} Mandatory if adjustment type is given`;
          } else if (fields[i].fieldValue == 'customerNotes') {
            obj.description = 'Enter Customer Notes';
            obj.validation = `${obj.validation} Customer Notes will be entered Receive Money wise i.e. if an invoice having multiple line items then enter Customer Notes in first line item, no need to entered in every line items`;
          } else if (fields[i].fieldValue == 'reverseCharge_9_5') {
            obj.description = 'Select Yes/No for applying reverse Charge9(5)';
            obj.validation = `${obj.validation} If applying reverse Charge9(5) then reverse charge by default yes'`;
          } else if (fields[i].fieldValue == 'contactsGroups') {
            obj.description = 'Enter Groups';
            obj.validation = `${obj.validation} Enter the groups with comma seperated value eg. group1, group2, group3 etc`;
          } else if (fields[i].fieldValue == 'accountCodeUpdate') {
            obj.validation = `${obj.validation} Enter Name is not selected than Code is mandatory`;
          } else if (fields[i].fieldValue == 'chartAccountNameUpdate') {
            obj.validation = `${obj.validation} Enter Code is not selected than Name is mandatory`;
          } else if (fields[i].fieldValue == 'natureType') {
            obj.validation = `${obj.validation} By default ‘Quantity Fixed’ is selected if Order type is Open`;
          } else if (fields[i].fieldValue == 'tolerancePercentage') {
            obj.validation = `${obj.validation} , If you want to Set Tolerance for Goods Receipt`;
          } else if (fields[i].displayName == '---No Import---') {
            obj.description = "Use this field on the column which don't want to import";
            obj.validation = `${obj.validation} --`;
          }
        }

        result.push(obj)
      }
    }

    return result;
  }

}
