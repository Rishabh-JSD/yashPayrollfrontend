import Swal from 'sweetalert2';
import moment from 'moment';
import { AppConst } from '../../core/constants/app-const';

export class DateHelperService {
  static convertUiDate(value, isLockDate = false) {
    let date;
    if (value && +value) {
      const curDate = new Date();
      curDate.setTime(+value);
      date = moment(curDate).format('DD/MM/YYYY');
    } else if (value) {
      value = value.toString().replace(/[^a-zA-Z0-9]/g, '/');
      const data = value.split('/');
      let curDate = new Date();
      if (this.checkDate(data)) {
        curDate.setMonth(0);
        if (data[2] && data[2].trim()) {
          if (data[2].length == 2) {
            let subYear = +curDate.getFullYear().toString().substr(0, 2);
            curDate.setFullYear(+(subYear.toString() + data[2].toString()));
          } else if (data[2].length == 4) {
            curDate.setFullYear(+data[2]);
          }
        }
        curDate.setDate(+data[0]);
        curDate.setMonth((+data[1] - 1));
        if (!isLockDate && AppConst.LOCK_DATE) {
          const lockDate = new Date(AppConst.LOCK_DATE);
          if (curDate.getTime() <= lockDate.getTime()) {
            curDate = lockDate;
            curDate.setDate(curDate.getDate() + 1);
            Swal.fire({
              title: 'Lock Date',
              html: 'Date you have entered is not allowed.<br> Lock Date: <b>' + moment(AppConst.LOCK_DATE).format('DD/MM/YYYY') + '</b>',
              icon: 'warning',
              allowOutsideClick: false,
            });
          }
        }
        date = moment(curDate).format('DD/MM/YYYY');
      } else {
        if (moment(value, 'ddd/MMM/DD/YYYY', true).isValid()) {
          date = moment(value, 'ddd/MMM/DD/YYYY', true).format('DD/MM/YYYY');
        } else if (moment(value, 'YYYY/MM/DD', true).isValid()) {
          date = moment(value, 'YYYY/MM/DD', true).format('DD/MM/YYYY');
        } else if (moment(value, 'M/DD/YYYY', true).isValid()) {
          date = moment(value, 'M/DD/YYYY', true).format('DD/MM/YYYY');
        } else {
          date = moment(curDate).format('DD/MM/YYYY');
        }
      }
    } else {
      date = null;
    }
    return date;
  }

  static convertUiToApiDate(dateUI: string | undefined | null): string | undefined | null {
    if (dateUI) {
      return moment(dateUI, 'DD/MM/YYYY', true).format('YYYY-MM-DD');
    }
    return dateUI;
  }

  static convertApiDate(value) {
    let date;
    if (value && +value) {
      const curDate = new Date();
      curDate.setTime(+value);
      date = moment(curDate).format('YYYY-MM-DD');
    } else if (value) {
      value = value.toString().replace(/[^a-zA-Z0-9]/g, '/');
      const data = value.split('/');
      let curDate = new Date();
      if (this.checkDate(data)) {
        curDate.setMonth(0);
        if (data[2] && data[2].trim()) {
          if (data[2].length == 2) {
            let subYear = +curDate.getFullYear().toString().substr(0, 2);
            curDate.setFullYear(+(subYear.toString() + data[2].toString()));
          } else if (data[2].length == 4) {
            curDate.setFullYear(+data[2]);
          }
        }
        curDate.setDate(+data[0]);
        curDate.setMonth((+data[1] - 1));
        date = moment(curDate).format('YYYY-MM-DD');
      } else {
        if (moment(value, 'ddd/MMM/DD/YYYY', true).isValid()) {
          date = moment(value, 'ddd/MMM/DD/YYYY', true).format('YYYY-MM-DD');
        } else if (moment(value, 'YYYY/MM/DD', true).isValid()) {
          date = moment(value, 'YYYY/MM/DD', true).format('YYYY-MM-DD');
        } else if (moment(value, 'M/DD/YYYY', true).isValid()) {
          date = moment(value, 'M/DD/YYYY', true).format('YYYY-MM-DD');
        } else {
          date = moment(curDate).format('YYYY-MM-DD');
        }
      }
    } else {
      date = null;
    }
    return date;
  }

  private static checkDate(arr: any[]): boolean {
    const dateMapMonth = new Map();
    dateMapMonth.set('jan', 1);
    dateMapMonth.set('feb', 2);
    dateMapMonth.set('mar', 3);
    dateMapMonth.set('apr', 4);
    dateMapMonth.set('may', 5);
    dateMapMonth.set('jun', 6);
    dateMapMonth.set('jul', 7);
    dateMapMonth.set('aug', 8);
    dateMapMonth.set('sep', 9);
    dateMapMonth.set('oct', 10);
    dateMapMonth.set('nov', 11);
    dateMapMonth.set('dec', 12);
    let bFlag = true;
    if (arr[1] && arr[1].toString().length > 2) {
      const monthValue = dateMapMonth.get(arr[1].toString().toLowerCase().substr(0, 3));
      if (monthValue) {
        arr[1] = monthValue;
      }
    }
    if ((arr.length === 3 || arr.length === 2) && (arr[0].toString().length === 2 || arr[0].toString().length === 1)
        && ((arr[1].toString().length === 2 || arr[1].toString().length === 1) && arr[1] <= 12) && (!arr[2] || (arr[2].toString().length === 4
                                                                                                    || arr[2].toString().length === 2))) {
      arr.forEach(element => {
        if (!Number(element)) {
          bFlag = false;
        }
      });
    } else {
      bFlag = false;
    }
    return bFlag;
  }
}
