import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ApiResponse } from '../../core/models/api-response';
import { AutoCompleteOptionType } from '../models/hb-field-option';
import { HBHttpService } from '../../core/services/hb-http-service.service';

@Injectable({
  providedIn: 'root',
})
export class HbAutoCompleteDropdownApiService {

  private apiPath = 'auto-complete';

  constructor(private hbHttpClient: HBHttpService) { }

  autoCompleteSearchDropdown(dropDownReqRes: DropDownReqRes): Observable<ApiResponse> {
    const masterFlag = (dropDownReqRes.type === ('INDUSTRY') || dropDownReqRes.type === ('PINCODE') || dropDownReqRes.type === ('CITY') || dropDownReqRes.type === ('STATE') || dropDownReqRes.type === ('COUNTRY'));
    console.log();
    return this.hbHttpClient.getResponse(this.apiPath + '/dropdown', this.hbHttpClient.POST, dropDownReqRes, masterFlag);
  }

  labelDataById(selectedId: number, typeValue: AutoCompleteOptionType, codeAsLabel: boolean = false, storageType?: string, valueAsId: boolean = false): Observable<ApiResponse> {
    const masterFlag = (typeValue === ('INDUSTRY') || typeValue === ('PINCODE') || typeValue === ('CITY') || typeValue === ('STATE') || typeValue === ('COUNTRY'));
    return this.hbHttpClient.getResponse(this.apiPath + '/labelById', 'POST', {
      id: selectedId,
      type: typeValue,
      codeAsLabel: codeAsLabel,
      storageType: storageType,
      valueAsId: valueAsId
    }, masterFlag);
  }

  labelDatasById(selectedId: number, typeValue: AutoCompleteOptionType, codeAsLabel: boolean = false, storageType?: string, valueAsId: boolean = false): Observable<ApiResponse> {
    const masterFlag = (typeValue === ('INDUSTRY') || typeValue === ('PINCODE') || typeValue === ('CITY') || typeValue === ('STATE') || typeValue === ('COUNTRY'));
    return this.hbHttpClient.getResponse(this.apiPath + '/labelById', 'POST', {
      id: selectedId,
      type: typeValue,
      codeAsLabel: codeAsLabel,
      storageType: storageType,
      valueAsId: valueAsId
    },masterFlag);
  }

  labelDataByCode(code: string, typeValue: AutoCompleteOptionType): Observable<ApiResponse> {
    const masterFlag = (typeValue === ('INDUSTRY') || typeValue === ('PINCODE') || typeValue === ('CITY') || typeValue === ('STATE') || typeValue === ('COUNTRY'));
    return this.hbHttpClient.getResponse(this.apiPath + '/labelByCode', this.hbHttpClient.POST, { name: code, type: typeValue }, masterFlag);
  }

  labelListByIdList(selectedIdList: number[], typeValue: AutoCompleteOptionType): Observable<ApiResponse> {
    return this.hbHttpClient.getResponse(this.apiPath + '/labelByIdList', this.hbHttpClient.POST,
      { idList: selectedIdList, type: typeValue });
  }

}

export class DropDownReqRes {
  name: string | undefined;
  type: AutoCompleteOptionType | undefined;
  searchType: string | undefined;
  searchField: string | undefined;
  pincode: string | undefined;
  id: number | undefined;
  selectedId: any | undefined;
  onlyBranch: boolean;// used for getting low level branches
  idList: number[] | undefined;
  subAccCode: string | undefined;
  codeAsLabel: boolean;
  catCode: string
  page: number
  limit: number
  parentId: number
  searchFor: string | undefined
}
