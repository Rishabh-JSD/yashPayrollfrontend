import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class HBLoaderService {
  private static isLoading = new BehaviorSubject<boolean>(false);
  public static loader$: Observable<boolean> = HBLoaderService.isLoading.asObservable();

  constructor() { }

  public static showLoader(): void {
    setTimeout(() => {
      HBLoaderService.isLoading.next(true);
    });
  }

  public static hideLoader(): void {
    if (HBLoaderService.isLoading) {
      setTimeout(() => {
        HBLoaderService.isLoading.next(false);
      });
    }
  }
}
