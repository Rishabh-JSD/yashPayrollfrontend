import { Router } from '@angular/router';
import { HttpClient, HttpErrorResponse, HttpHeaders, HttpResponse } from '@angular/common/http';
import { catchError, map } from 'rxjs/operators';
import { Observable, of } from 'rxjs';
import { Injectable } from '@angular/core';
import { ApiResponse } from '../../core/models/api-response';

@Injectable()
export class HBServiceHttp {

  readonly GET = 'GET';
  readonly POST = 'POST';
  readonly PUT = 'PUT';
  readonly DELETE = 'DELETE';

  apiUrl = '';

  constructor(private httpClient: HttpClient, private router: Router) { }

  static get checkInternetConnection(): boolean {
    if (navigator.onLine) {
      return true;
    } else {
      return false;
    }
  }

  getResponse(secondUrl: string, method: string, data: any = null): Observable<ApiResponse> | any {
    if (HBServiceHttp.checkInternetConnection) {
      let headers = new HttpHeaders();
      headers = headers.append('Content-Type', 'application/json; charset=utf-8');


      const url = secondUrl.toString().split('?');
      if (url && url[1]) {
        const j = url[1].split('&');
        j.forEach(element => {
          if (element.includes('status')) {
            const statusVal = element.split('=');
            headers = headers.append('status', statusVal[1]);
          }
        });
      }
      if (data?.status) {
        headers = headers.append('status', data.status);
      }
      if ((data && data.searchFieldsObj && data.searchFieldsObj.status)
          || (data && data.searchFieldsObj && data.searchFieldsObj.status === '')) {
        headers = headers.append('status', data.searchFieldsObj.status);
      }
      console.log('URL >>>>', url);
      const controller = '/' + url[0] + '|' + headers.get('status');
      headers = headers.append('Access-Control-Allow-Origin', '*');

      const options = { headers };
      console.log('API At ', this.apiUrl);
      switch (method) {
        case this.GET: {
          console.log('>>>>', this.apiUrl, options);
          return this.httpClient.get(this.apiUrl, options).pipe(map((res: any) => {
            return this.extractData(res, controller);
          }), catchError(this.handleError));
        }
        case this.POST: {
          console.log('>>>>', this.apiUrl, data, options);
          return this.httpClient.post(this.apiUrl, data, options).pipe(map((res: any) => {
            return this.extractData(res, controller);
          }), catchError(this.handleError));
        }
        case this.PUT: {
          return this.httpClient.put(this.apiUrl, data, options).pipe(map((res: any) => {
            return this.extractData(res, controller);
          }), catchError(this.handleError));
        }
        case this.DELETE: {
          return this.httpClient.delete(this.apiUrl, options).pipe(map((res: any) => {
            return this.extractData(res, controller);
          }), catchError(this.handleError));
        }
      }
    } else {
      return new Observable();
    }
  }

  private extractData(res: any, headerUrl: string): any {
    return res;
  }

  private handleError(error: any) {
    console.log('error', error);
    let errMsg = '';
    if (error instanceof HttpErrorResponse) {
      if (error.status === 0 || error.status === -1) {
        // errMsg = 'Internet is may be slow, You can try again or Contact Support ';
        errMsg = 'Something went wrong, Please contact Support or Try Again';
      } else {
        errMsg = error.message;
      }
    } else if (error instanceof ProgressEvent) {
      if (error.type === 'error') {
        // errMsg = 'Internet is may be slow, You can try again or Contact Support ';
        // if (error && error.url.includes('gstfiling/syncing')) {
        //   errMsg = 'Data sync process is started in back ground. Please refresh GST Application after some time to verify data for GST Filing.';
        // } else {
        errMsg = 'Something went wrong, Please contact Support or Try Again';
        // }
      } else {
        errMsg = error.type;
      }
    } else if (error instanceof HttpResponse) {
      errMsg = 'Something went wrong, Please contact Support or Try Again';
    } else {
      errMsg = error.message ? error.message : error.toString();
    }
    return of(error);
  }
}
