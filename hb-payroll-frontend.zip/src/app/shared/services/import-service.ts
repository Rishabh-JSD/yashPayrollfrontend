import { Injectable } from "@angular/core";
import { HBServiceHttp } from "./hb-service-http.service";
import { Observable } from "rxjs";
import { HBHttpService } from "src/app/core/services/hb-http-service.service";

@Injectable({
    providedIn: 'root'
})
export class ImportService {
    constructor(private hbServiceHttp: HBHttpService) {

    }

    validImportOption(data): Observable<any> {
        return this.hbServiceHttp.getResponse('masterImport/valid', 'POST', data);
    }

    addImportData(data): Observable<any> {
        return this.hbServiceHttp.getResponse('masterImport/addImport', 'POST', data);
    }

    addImportTemplate(data): Observable<any> {
        return this.hbServiceHttp.getResponse('master/template/add', 'POST', data);
    }

    fetchImportTemplate(data: string): Observable<any> {
        return this.hbServiceHttp.getResponse('master/template/get?txn=' + data, 'GET');
    }

    getTemplateList(): Observable<any> {
        return this.hbServiceHttp.getResponse('master/template/list', 'GET');
    }

    updateImportTemplate(data): Observable<any> {
        return this.hbServiceHttp.getResponse('master/template/update', 'PUT', data);
    }

    deleteTemplateById(id: number): Observable<any> {
        return this.hbServiceHttp.getResponse('master/delete/' + id, 'DELETE', null);
    }



}