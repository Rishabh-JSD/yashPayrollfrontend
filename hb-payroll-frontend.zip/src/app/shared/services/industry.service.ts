import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HBHttpService } from 'src/app/core/services/hb-http-service.service';

@Injectable({
  providedIn: 'root',
})
export class IndustryService {
  constructor(private hbHttpClient: HBHttpService) {}

  getListIndustry(): Observable<any> {
    return this.hbHttpClient.getResponse('industry/list', this.hbHttpClient.GET, null, true);
  }

  getIndustryById(id): Observable<any> {
    return this.hbHttpClient.getResponse(`industry/${ id }`, this.hbHttpClient.GET, null, true);
  }
}
