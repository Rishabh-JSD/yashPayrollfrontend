import { Injectable } from '@angular/core';
import Swal, { SweetAlertIcon, SweetAlertInput } from 'sweetalert2';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class PopupService {

  constructor() { }

  public static successAlert(alertTitle: string, alertText: string): Promise<any> {
    return new Promise((resolve) => {
      Swal.fire({
        title: alertTitle, text: alertText, icon: 'success', allowOutsideClick: false, allowEscapeKey: false,
      }).then((result) => {
        resolve(result.value);
      });
    });
  }

  public static failedAlert(alertTitle: string, alertText: string): Promise<any> {
    return new Promise((resolve) => {
      Swal.fire({
        title: alertTitle, text: alertText, icon: 'error', allowOutsideClick: false, allowEscapeKey: false,
      }).then((result) => {
        resolve(result.value);
      });
    });
  }

  public static confirmationAlert(alertTitle: string, alertText: string, confirmBtnText = 'OK'): Promise<any> {
    return new Promise((resolve) => {
      Swal.fire({
        title: alertTitle, text: alertText, icon: 'warning', showCancelButton: true, allowOutsideClick: false, confirmButtonText: confirmBtnText, allowEscapeKey: false,
      }).then((result) => {
        resolve(result.value);
      });
    });
  }

  public static infoAlert(alertTitle: string, alertText: string): Promise<any> {
    return new Promise((resolve) => {
      Swal.fire({
        title: alertTitle, text: alertText, icon: 'info', allowOutsideClick: false, allowEscapeKey: false,
      }).then((result) => {
        resolve(result.value);
      });
    });
  }

  public static questionAlert(alertTitle: string, alertText: string): Promise<any> {
    return new Promise((resolve) => {
      Swal.fire({
        title: alertTitle,
        text: alertText,
        icon: 'question',
        allowOutsideClick: false,
        allowEscapeKey: false,
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes',
        cancelButtonText: 'No',
      }).then((result) => {
        resolve(result.value);
      });
    });
  }

  public static htmlAlert(alertTitle: string, alertHtml: string | HTMLElement, alertIcon: SweetAlertIcon = 'warning', alertShowCancelButton: boolean = false, alertConfirmButtonText: string = 'OK', alertCancelButtonText: string = 'Cancel'): Promise<any> {
    return new Promise((resolve) => {
      Swal.fire({
        title: alertTitle,
        html: alertHtml,
        icon: alertIcon,
        showCancelButton: alertShowCancelButton,
        allowOutsideClick: false,
        allowEscapeKey: false,
        confirmButtonText: alertConfirmButtonText,
        cancelButtonText: alertCancelButtonText
      }).then((result) => {
        resolve(result.value);
      });
    });
  }

  public static alertWithInput(alertTitle: string, alertHtml: string | HTMLElement, alertInput: SweetAlertInput, alertInputOptions: Map<string, string>, alertIcon: SweetAlertIcon, alertConfirmButtonText: string = 'OK'): Promise<any> {
    return new Promise((resolve) => {
      Swal.fire({
        title: alertTitle,
        html: alertHtml,
        input: alertInput,
        icon: alertIcon,
        confirmButtonText: alertConfirmButtonText,
        allowOutsideClick: false,
        allowEscapeKey: false,
        showCloseButton: true,
        inputOptions: alertInputOptions,
        inputPlaceholder: '--None--',
        inputValidator: result => !result && 'You need to select type!',
        customClass: 'label-block'
      }).then((result) => {
        resolve(result);
      });
    });
  }


  public static alertWithUrl(router: Router, alertTitle: string, alertText: string, url: string, alertIcon: SweetAlertIcon = 'warning'): Promise<any> {
    return new Promise((resolve) => {
      Swal.fire({
        title: alertTitle, text: alertText, icon: alertIcon, allowOutsideClick: false
      }).then((result) => {
        if (result.value) {
          router.navigate([url]);
        }
      });
    });
  }

  public static selectAlert(alertHtml: string | HTMLElement, alertInputOptions: Map<string, string> | any, alertInput: SweetAlertInput = 'select'): Promise<any> {
    return new Promise((resolve) => {
      Swal.fire({
        html: alertHtml, input: alertInput, allowOutsideClick: false, allowEscapeKey: false, showCloseButton: true, inputOptions: alertInputOptions, inputPlaceholder: '--None--',
      }).then((result) => {
        resolve(result);
      });
    });
  }

  public static selectAlertWithDisableButton(alertHtml: string | HTMLElement, alertInputOptions: Map<string, string> | any, alertInput: SweetAlertInput = 'select'): Promise<any> {
    return new Promise((resolve) => {
      Swal.fire({
        html: alertHtml,
        input: alertInput,
        allowOutsideClick: false,
        allowEscapeKey: false,
        showCloseButton: true,
        inputOptions: alertInputOptions,
        inputPlaceholder: '--None--',
        willOpen() {
          Swal.disableButtons();
          const inputElement = Swal.getInput();
          inputElement.addEventListener('input', () => {
            Swal.enableButtons();
          });
        }
      }).then((result) => {
        Swal.enableButtons();
        resolve(result);
      });
    });
  }

  public static textAlert(alertTitle: string, alertText: string, alertShowCancelButton: boolean = false, alertConfirmButtonText: string = 'OK', alertCancelButtonText: string = 'Cancel'): Promise<any> {
    return new Promise((resolve) => {
      Swal.fire({
        title: alertTitle,
        text: alertText,
        allowOutsideClick: false,
        allowEscapeKey: false,
        showCancelButton: alertShowCancelButton,
        confirmButtonText: alertConfirmButtonText,
        cancelButtonText: alertCancelButtonText,
      }).then((result) => {
        resolve(result.value);
      });
    });
  }


  public static alertCronLoading(alertTitle: string, alertHtml: string | HTMLElement): Promise<any> {
    return new Promise((resolve) => {
      Swal.fire({
        title: alertTitle, html: alertHtml, allowOutsideClick: false, allowEscapeKey: false, didOpen: () => {
          Swal.showLoading();
        }
      }).then((result) => {
        resolve(result.value);
      });
    });
  }

  public static closePopup() {
    Swal.close();
  }


  public static preConfirmAlert1(alertTitle: string, alertHtml: string | HTMLElement): Promise<any> {
    return new Promise((resolve) => {
      Swal.fire({
        title: alertTitle,
        showCancelButton: true,
        confirmButtonText: 'Confirm',
        html: alertHtml + '<input id="input2" class="swal2-input" value="" placeholder="Cancel Remarks" maxLength="100">',
        focusConfirm: false,
        preConfirm: () => {
          return [(document.getElementById('input1') as HTMLInputElement).value, (document.getElementById('input2') as HTMLInputElement).value];
        }
      }).then((result) => {
        resolve(result);
      });
    });
  }

  public static preConfirmAlert2(alertTitle: string): Promise<any> {
    return new Promise((resolve) => {
      Swal.fire({
        title: alertTitle, input: 'text', inputAttributes: {
          autocapitalize: 'off'
        }, showCancelButton: true, confirmButtonText: 'Save', showLoaderOnConfirm: true, preConfirm: (val) => {
          if ((!val || !+val) && +val !== 0) {
            Swal.showValidationMessage(`Invalid %`);
          } else if (+val < 0) {
            Swal.showValidationMessage(`Invalid % Less than 0`);
          } else if (+val > 100) {
            Swal.showValidationMessage(`Invalid % More than 100`);
          } else {
            return val;
          }
        }, allowOutsideClick: () => !Swal.isLoading()
      }).then((result) => {
        resolve(result);
      });
    });
  }

  public static showBusinessWarning(): void {
    Swal.fire({
      title: 'Business Changed', text: 'You have opened a different Business Tab', icon: 'error', allowOutsideClick: false, // showCancelButton: true,
      confirmButtonText: 'Refresh Tab', // cancelButtonText: 'Close Tab'
      backdrop: `var(--main-bgcolor)`
    }).then((result) => {
      if (result.isConfirmed) {
        location.reload();
      } else if (result.isDismissed) {
        window.close();
      }
    });
  }

}
