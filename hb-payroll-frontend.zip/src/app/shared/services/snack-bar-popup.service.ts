import { Injectable } from '@angular/core';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';

@Injectable({
  providedIn: 'root'
})
export class SnackBarPopupService {

  constructor(private _snackBar: MatSnackBar) { }

  snackBar(message: string, horizontalPosition: MatSnackBarHorizontalPosition = 'center', verticalPosition: MatSnackBarVerticalPosition = 'bottom', duration: number = 3000) {
    this._snackBar.open(message, 'OK', {
      duration,
      horizontalPosition,
      verticalPosition,
    });
  }
}
