import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class TimeHelperService {
  constructor() { }

//  // Convert UI time format to 'hh:mm:ss'
// static convertUiTime(uiTime: string | null): string {
//   if (uiTime) {
//     const timeParts = uiTime.split(':');
//     // // Check if the time has at least hours and minutes
//     // if (timeParts.length >= 2) {
//     //   // Ensure each part of the time has two digits (pad with '0' if necessary)
//     //   const formattedTime = timeParts.map(part => {
//     //     const parsedPart = parseInt(part, 10);
//     //     return parsedPart >= 0 && parsedPart <= 59 ? ('0' + parsedPart).slice(-2) : '00';
//     //   });

//       // Check if it's already in 'hh:mm:ss' format
//       if (timeParts.length === 3) {
//         return uiTime; // Return as is if already in 'hh:mm:ss'
//       }

//       // Ensure the formatted time has all parts (hours, minutes, seconds)
//       // while (formattedTime.length < 3) {
//       //   formattedTime.push('00');
//       // }

//       // return formattedTime.slice(0, 3).join(':'); // Return 'hh:mm:ss'
//     }
//   }
//   // Return the original time or an empty string if no valid time is provided
//   return uiTime || '';
// }

// Convert UI time format to 'hh:mm:ss'
static convertUiTime(uiTime: string | null): string {
  if (uiTime) {
    const timeParts = uiTime.split(':');

    if (timeParts.length === 3) {
      return uiTime; // Return as is if already in 'hh:mm:ss'
    }

    // If the input is not in 'hh:mm:ss' format, return it as is or handle edge cases as needed
  }
  // Return the original time or an empty string if no valid time is provided
  return uiTime || '';
}

}
