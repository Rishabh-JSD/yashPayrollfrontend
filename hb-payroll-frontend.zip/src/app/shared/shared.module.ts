import { AddressComponent } from './address/address.component';
import { NgModule } from '@angular/core';
import { CommonModule, NgOptimizedImage } from '@angular/common';
import { SharedMaterialModule } from './shared-material.module';
import { HighchartsChartModule } from 'highcharts-angular';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FullCalendarModule } from '@fullcalendar/angular';
import { HbFieldComponent } from './hb-field/hb-field.component';
import { AlertModule } from 'ngx-bootstrap/alert';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { CollapseModule } from 'ngx-bootstrap/collapse';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { TabsModule } from 'ngx-bootstrap/tabs';
import { AccordionModule } from 'ngx-bootstrap/accordion';
import { TooltipModule } from 'ngx-bootstrap/tooltip';
import { ModalModule } from 'ngx-bootstrap/modal';
import { DocumentComponent } from './document/document.component';
import { TwelveHourFormatPipe } from './pipes/twelve-hour-format.pipe';
import { HbDropdownModule } from '@hostbooks/hb-lib/hb-dropdown';
import { HbInputFieldModule } from '@hostbooks/hb-lib/hb-input-field';
import { HbButtonModule } from '@hostbooks/hb-lib/hb-button';
import { HbCheckboxModule } from '@hostbooks/hb-lib/hb-checkbox';
import { HbListTableModule } from '@hostbooks/hb-lib/hb-list-table';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { HbMonthPickerModule } from '@hostbooks/hb-lib/hb-month-picker';
import { HbMultiSelectModule } from '@hostbooks/hb-lib/hb-multi-select';
import { HbRadioButtonModule } from '@hostbooks/hb-lib/hb-radio-button';
import { HbSplitButtonModule } from '@hostbooks/hb-lib/hb-split-button';
import { HbToggleButtonModule } from '@hostbooks/hb-lib/hb-toggle-button';
import { HbDatePickerComponent } from './hb-date-picker/hb-date-picker.component';
import { CalendarModule } from 'primeng/calendar';
import { HbAutoCompleteComponent } from './hb-auto-complete/hb-auto-complete';
import { HBServiceHttp } from './services/hb-service-http.service';
import { TabViewModule } from 'primeng/tabview';
import { InputSwitchModule } from 'primeng/inputswitch';
import { ProgressBarModule } from 'primeng/progressbar';
import { StepsModule } from 'primeng/steps';
import { PaginatorModule } from 'primeng/paginator';
import { MenuModule } from 'primeng/menu';
import { DialogModule } from 'primeng/dialog';
import { TableModule } from 'primeng/table';
import { HbTimePickerComponent } from './hb-time-picker/hb-time-picker.component';
import { HbLoaderComponent } from './hb-loader/hb-loader.component';
import { HbDateFormatPipe } from './pipes/hb-date-format.pipe';
import { HblabelPipe } from './pipes/hb-autocomplete-label.pipe';
import { HbAutoCompleteMultiSelectComponent } from './hb-multi-select/hb-auto-complete-multi-select';

@NgModule({
  declarations: [HbFieldComponent, AddressComponent, DocumentComponent, TwelveHourFormatPipe, HbDatePickerComponent,
    HbAutoCompleteComponent, HbTimePickerComponent, HbLoaderComponent, HbDateFormatPipe, HbAutoCompleteMultiSelectComponent,HblabelPipe],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    SharedMaterialModule,
    HighchartsChartModule,
    FullCalendarModule,
    BsDropdownModule.forRoot(),
    BsDatepickerModule.forRoot(),
    AlertModule.forRoot(),
    TabsModule.forRoot(),
    AccordionModule.forRoot(),
    CollapseModule.forRoot(),
    TooltipModule.forRoot(),
    ModalModule.forRoot(),
    HbDropdownModule,
    HbInputFieldModule,
    HbButtonModule,
    HbCheckboxModule,
    HbListTableModule,
    HbMonthPickerModule,
    HbMultiSelectModule,
    HbRadioButtonModule,
    HbSplitButtonModule,
    HbToggleButtonModule,
    CalendarModule,
    AutoCompleteModule,
    TabViewModule,
    InputSwitchModule,
    ProgressBarModule,
    StepsModule,
    PaginatorModule,
    MenuModule,
    DialogModule,
    TableModule,
    NgOptimizedImage,
  ],
  exports: [
    FormsModule,
    ReactiveFormsModule,
    HbDatePickerComponent,
    HbAutoCompleteComponent,
    HighchartsChartModule,
    SharedMaterialModule,
    FullCalendarModule,
    HbFieldComponent,
    BsDropdownModule,
    BsDatepickerModule,
    AlertModule,
    TabsModule,
    AccordionModule,
    CollapseModule,
    TooltipModule,
    ModalModule,
    AddressComponent,
    DocumentComponent,
    TwelveHourFormatPipe,
    HbDropdownModule,
    HbInputFieldModule,
    HbButtonModule,
    HbCheckboxModule,
    HbListTableModule,
    HbMonthPickerModule,
    HbMultiSelectModule,
    HbRadioButtonModule,
    HbSplitButtonModule,
    HbToggleButtonModule,
    CalendarModule,
    AutoCompleteModule,
    TabViewModule,
    InputSwitchModule,
    ProgressBarModule,
    StepsModule,
    PaginatorModule,
    MenuModule,
    DialogModule,
    TableModule,
    HbTimePickerComponent,
    HbLoaderComponent,
    HbDateFormatPipe,
    HblabelPipe,
    NgOptimizedImage,
    HbAutoCompleteMultiSelectComponent
  ],
  providers: [HBServiceHttp]
})
export class SharedModule {
}
