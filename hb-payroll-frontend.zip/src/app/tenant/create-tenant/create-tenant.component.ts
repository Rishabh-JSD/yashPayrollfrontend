import { Component, OnDestroy, OnInit } from '@angular/core';
import { MenuItem } from 'primeng/api';
import { Location } from '@angular/common';
import { TenantService } from '../service/tenant.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Tenant } from '../model/tenant';
import { AddressService } from '../../shared/services/address.service';
import { PopupService } from '../../shared/services/popup.service';
import { HBLoaderService } from '../../shared/services/hb-loader.service';
import { HbErrorHandler, HbErrorHandlerData } from '../../shared/models/hb-error-handler';
import { HelperService } from '../../helper/helper.service';

interface City {
  name: string;
  code: string;
}

@Component({
  selector: 'app-create-tenant', templateUrl: './create-tenant.component.html', styleUrls: ['./create-tenant.component.scss']
})

export class CreateTenantComponent implements OnInit, OnDestroy {
  items: MenuItem[] = [];
  activeIndex: number = 0;
  currentIndex: number | undefined;
  body = document.getElementsByTagName('body')[0];
  tenant = new Tenant();
  hbErrorHandler = new HbErrorHandler();
  hbErrorHandlerPageOne = new HbErrorHandler();
  hbErrorHandlerPageTwo = new HbErrorHandler();
  hbErrorHandlerPageThree = new HbErrorHandler();


  constructor(private location: Location, private businessService: TenantService, private router: Router, private route: ActivatedRoute, private addressService: AddressService) {
    if (parseInt(this.route.snapshot.params.id, null)) {
      this.getBusinessById(parseInt(this.route.snapshot.params.id, null));
    }
  }

  ngOnInit(): void {
    this.items = [{
      label: 'Basic Info', command: (event: any) => {
      }
    }, {
      label: 'Address', command: (event: any) => {
      }
    }, {
      label: 'Contact Details', command: (event: any) => {
      }
    },];
    this.body.classList.add('onlyHeader');
    this.currentIndex = this.activeIndex;
    this.tenant.version = 'IND';

  }

  onActiveIndexChange(event: any) {
    if (event > this.currentIndex) {
      this.activeIndex = this.currentIndex;
    }
  }

  ngOnDestroy(): void {
    this.body.classList.remove('onlyHeader');
  }

  getBusinessById(id: number): void {
  }

  allow_numbers(event) {
    let k: number;
    k = event.charCode;
    return (k >= 48 && k <= 57);
  }

  saveBusiness() {
    this.validateThree();
    if (!this.hbErrorHandlerPageThree.invalid) {
      HBLoaderService.showLoader();
      this.businessService.addTenant(this.tenant).subscribe(response => {
        if (response && response.status === 200 && response.data.tenant) {
          PopupService.successAlert('Company', 'Added Successfully').then(result => {
            if (result) {
              this.router.navigate(['/tenant/list']);
            }
          });
        } else {
          this.codeValidation(response);
        }
        HBLoaderService.hideLoader();
      });
    }
  }

  goBack(event): void {
    this.activeIndex = event;
  }

  changeIndex(event: number) {
    if (event === 1) {
      this.validateOne();
      if (!this.hbErrorHandlerPageOne.invalid) {
        this.activeIndex = event;
      }
    } else if (event === 2) {
      this.validateTwo();
      if (!this.hbErrorHandlerPageTwo.invalid) {
        this.activeIndex = event;
      }
    }
  }

  changeCheckBoxValue() {

  }


  errorHandlerOne(parentkey: string, childkey?: string, keyIndex?: number): HbErrorHandlerData {
    const hData = this.hbErrorHandlerPageOne.getErrorHandlerData(parentkey, childkey, keyIndex);
    return hData;
  }

  validateOne() {
    this.hbErrorHandlerPageOne.clearErrors();
    this.hbErrorHandlerPageOne.emptyCheck(this.tenant.name, 'name');
    this.hbErrorHandlerPageOne.emptyCheck(this.tenant.industryId, 'industryId');
    this.hbErrorHandlerPageOne.emptyCheck(this.tenant.tenantDetail.legalName, 'tenantDetail', 'legalName');
  }

  validateTwo() {
    this.hbErrorHandlerPageTwo.clearErrors();
    this.hbErrorHandlerPageTwo.emptyCheck(this.tenant.tenantDetail.address.addressOne, 'address', 'addressOne');
    this.hbErrorHandlerPageTwo.emptyCheck(this.tenant.tenantDetail.address.cityName, 'address', 'cityName');
    this.hbErrorHandlerPageTwo.emptyCheck(this.tenant.tenantDetail.address.stateName, 'address', 'stateName');
    this.hbErrorHandlerPageTwo.emptyCheck(this.tenant.tenantDetail.address.countryName, 'address', 'countryName');
    this.hbErrorHandlerPageTwo.emptyCheck(this.tenant.tenantDetail.address.pincode, 'address', 'pincode');
  }

  validateThree() {
    this.hbErrorHandlerPageThree.clearErrors();
    this.hbErrorHandlerPageThree.emptyCheck(this.tenant.tenantDetail.email, 'tenantDetail', 'email');
    if(this.tenant.tenantDetail.email){
      if (this.tenant.tenantDetail.email && !HelperService.emailValidator(this.tenant.tenantDetail.email)) {
        this.hbErrorHandlerPageThree.addError('Invalid Email', 'tenantDetail.email');
      }
    }
    this.hbErrorHandlerPageThree.emptyCheck(this.tenant.tenantDetail.phone, 'tenantDetail', 'phone');
    if (this.tenant.tenantDetail.phone && !HelperService.validateMobile(this.tenant.tenantDetail.phone)) {
      this.hbErrorHandlerPageThree.addError('Invalid Mobile', 'tenantDetail.phone');
    }
  }


  errorHandlerTwo(parentkey: string, childkey?: string, keyIndex?: number): HbErrorHandlerData {
    const hData = this.hbErrorHandlerPageTwo.getErrorHandlerData(parentkey, childkey, keyIndex);
    return hData;
  }

  errorHandlerThree(parentkey: string, childkey?: string, keyIndex?: number): HbErrorHandlerData {
    const hData = this.hbErrorHandlerPageThree.getErrorHandlerData(parentkey, childkey, keyIndex);
    return hData;
  }

  setZipCode(event: any) {
    if (event) {
      this.addressService.getPincodeDetail(event.id).subscribe(response => {
        if (response && response.status === 200 && response.data.pinCodeDetail) {
          this.tenant.tenantDetail.address.cityName = response.data.pinCodeDetail.city;
          this.tenant.tenantDetail.address.pincode = response.data.pinCodeDetail.pinCode;
          this.tenant.tenantDetail.address.stateName = response.data.pinCodeDetail.state;
          this.tenant.tenantDetail.address.countryName = response.data.pinCodeDetail.country;
        }
      });
    }
  }

  codeValidation(response) {
    if (response.status == 400) {
      if (response.fieldErrors) {
        response.fieldErrors.forEach(error => {
          this.hbErrorHandlerPageOne.addError(error.message, error.fieldName);
          this.activeIndex = 0;
        });
      }
      window.scrollTo(0, 0);
    }else{
      PopupService.failedAlert('Company', 'Something Went Wrong').then(result => {
        if (result) {
          this.router.navigate(['/tenant/list']);
        }
      });
    }
  }
}
