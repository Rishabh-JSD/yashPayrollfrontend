import { Component, OnInit } from '@angular/core';
import { MenuItem } from 'primeng/api';
import { Router } from '@angular/router';
import { TenantService } from '../service/tenant.service';
import { TenantSearchRequest } from '../model/tenant-search-request';
import { Tenant } from '../model/tenant';
import { LocalStorageService } from '../../core/services/local-storage-service';
import { HBLoaderService } from '../../shared/services/hb-loader.service';

@Component({
  selector: 'app-tenant-listing',
  templateUrl: './tenant-listing.component.html',
  styleUrls: ['./tenant-listing.component.scss']
})
export class TenantListingComponent implements OnInit {
  display: boolean = false;
  items: MenuItem[];
  activeItem: MenuItem;
  tenants = new Array<Tenant>();
  totalRecords: number = 0;
  step: boolean = true;
  pageSizeOptions: number[] = [10, 20, 30, 50];

  constructor(private router: Router, private tenantService: TenantService) {
    this.items = [];
  }

  ngOnInit() {
    this.items = [{
      label: 'View'
    }, {
      label: 'Edit'
    },
      {
        label: 'Mark as Inactive'
      }];

    this.fixupItems(this.items);
    this.tenantList();
  }

  businessDialog() {
    this.display = true;
  }

  tenantList() {
    HBLoaderService.showLoader();
    this.tenantService.getTenantListByUser(new TenantSearchRequest()).subscribe(response => {
      if (response.status === 200 && response.data && response.data.tenant) {
        this.tenants = response.data.tenant.list;
        this.totalRecords = response.data.tenant.totalRowCount;
      }
      HBLoaderService.hideLoader();
    });
  }

  redirectToTenantPayroll(dbUuid) {
    LocalStorageService.setTenant(dbUuid);
    this.router.navigate(['payroll']).then(r => console.log(r));
  }

  onPageChange(event: any): void {
    this.tenantList();
  }

  searchTenant() {
    this.tenantList();
  }

  actionEvent(tenant: any): void {
    if (this.activeItem && tenant) {
      let routerData = null;
      switch (this.activeItem.label) {
        case 'View': {
          break;
        }
        case 'Edit': {
          routerData = ['add-tenant', tenant.id];
          break;
        }
        case 'Mark as Inactive': {

          break;
        }
      }
      console.log(tenant);
      this.router.navigate(routerData).then(r => console.log(r));
    }
  }

  private fixupItems(items: MenuItem[]): void {
    items?.forEach((item) => {
      item.command = (e) => (this.activeItem = e.item);
      this.fixupItems(item.items);
    });
  }
}
