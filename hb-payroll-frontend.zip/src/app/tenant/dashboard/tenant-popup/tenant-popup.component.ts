import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-tenant-popup',
  templateUrl: './tenant-popup.component.html',
  styleUrls: ['./tenant-popup.component.scss']
})
export class TenantPopupComponent implements OnInit {
  @Input() display = false;

  replica: boolean = true;

  constructor(private router: Router) {
  }

  ngOnInit(): void {
  }

  businessCloseDialog() {
    this.display = false;
  }

  toggleBusiness() {
    if (this.replica) {
      this.replica = false;
    } else {
      this.replica = true;
    }
  }

  createBusiness() {
    if (!this.replica) {
      this.router.navigate(['/tenant/add-tenant']);
    } else {
      this.router.navigate(['/tenant/replica-tenant']);
    }
  }

}
