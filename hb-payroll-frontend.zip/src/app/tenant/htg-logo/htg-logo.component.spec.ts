import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HtgLogoComponent } from './htg-logo.component';

describe('HtgLogoComponent', () => {
  let component: HtgLogoComponent;
  let fixture: ComponentFixture<HtgLogoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [HtgLogoComponent]
    })
      .compileComponents();

    fixture = TestBed.createComponent(HtgLogoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
