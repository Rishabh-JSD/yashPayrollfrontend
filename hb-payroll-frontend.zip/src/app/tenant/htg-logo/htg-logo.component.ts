import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'htg-logo',
  templateUrl: './htg-logo.component.html',
  styleUrls: ['./htg-logo.component.scss']
})
export class HtgLogoComponent implements OnInit {

  @Input() image: undefined;
  @Input() disabled = false;

  constructor() {
  }

  ngOnInit(): void {

  }


  fileChange(event: any): void {
    const files = event.target.files;
    const tempFiles = Array.from(files);
    if (this.validateFileUpload(tempFiles[0], 1, 'logo')) {
      // this.getFileData(tempFiles[0]);
    }
  }

  validateFileUpload(file: any, limit = 10, ext = 'txn'): boolean {
    let re = /(\.jpg|\.jpeg|\.png|\.pdf|\.txt|\.gif|\.doc|\.docx|\.ppt|\.pptx|\.xls|\.xlsx|\.csv|\.zip|\.ods|)$/i;
    if (ext === 'logo') {
      re = /(\.jpg|\.jpeg|\.png)$/i;
    }
    const fileSize = file.size / (1024 * 1024);
    return true;
  }

  // getFileData(file: any): void {
  //   const reader = new FileReader();
  //   reader.readAsDataURL(file);
  //   reader.onloadend = e => {
  //     if (!this.image) {
  //       this.image = new ImageClass();
  //     }
  //     this.image!.logoName = file.name;
  //     this.image!.logo = reader.result + '';
  //     this.image!.updateLogoFlag = true;
  //   };
  // }


}
