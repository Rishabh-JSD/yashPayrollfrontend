import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { LocalStorageService } from '../../../core/services/local-storage-service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header-tenant',
  templateUrl: './header-tenant.component.html',
  styleUrls: ['./header-tenant.component.scss']
})
export class HeaderTenantComponent implements OnInit {
  sidebarVisible: boolean = false;
  @Output() open: EventEmitter<any> = new EventEmitter();
  @Output() close: EventEmitter<any> = new EventEmitter();

  constructor(private router: Router) {
  }

  ngOnInit() {

  }

  logout() {
    LocalStorageService.clearEveryThing();
    this.router.navigate(['auth']).then(r => console.log(r));
  }

  public sidebarToggle() {
    this.sidebarVisible = !this.sidebarVisible;
    if (this.sidebarVisible) {
      this.open.emit(true);
    } else {
      this.close.emit(false);
    }
  }

}
