import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-sidebar-tenant',
  templateUrl: './sidebar-tenant.component.html',
  styleUrls: ['./sidebar-tenant.component.scss']
})
export class SidebarTenantComponent implements OnInit {
  // set true to make sidebar-tenant visible on load
  @Input() sidebarVisible: boolean = false;
  role: string = '';
  sideIndex: number = 0;

  constructor() {}

  ngOnInit() {}

  sideNav(index: number) {
    this.sideIndex = index;
  }
}
