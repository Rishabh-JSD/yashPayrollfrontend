import { Address } from "src/app/shared/models/address";

export class TenantDetail {
    id: number = null;
    alias: string | null = null;
    legalName: string | null = null;
    businessType: string | null = null;
    logo: string | null = null;
    phone: string | null = null;
    email: string | null = null;
    addressId: number = 0;
    address: Address = new Address();
}