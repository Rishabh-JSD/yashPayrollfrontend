import { SearchRequest } from '../../shared/models/search-request';

export class TenantSearchRequest extends SearchRequest{
  name: string;
}
