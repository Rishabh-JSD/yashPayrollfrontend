import { Audit } from '../../shared/models/audit';
import { TenantDetail } from './tenant-detail';

export class Tenant extends Audit {
  id: number;
  ownerId: number;
  industryId: number;
  name: string;
  dbName: string;
  dbUuid: string;
  tenantDetail:TenantDetail = new TenantDetail();
  version:string
}
