import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from 'src/app/core/services/user.service';
import { LocalStorageService } from 'src/app/core/services/local-storage-service';
import { User } from 'src/app/auth/models/user';
import { Address } from 'src/app/shared/models/address';
import { PopupService } from 'src/app/shared/services/popup.service';
import { AddressService } from 'src/app/shared/services/address.service';
import { HbErrorHandler, HbErrorHandlerData } from 'src/app/shared/models/hb-error-handler';
import { HelperService } from 'src/app/helper/helper.service';
import { UserDetail } from 'src/app/auth/models/user-detail';

@Component({
  selector: 'app-user-profile',
  templateUrl: './user-profile.component.html',
  styleUrls: ['./user-profile.component.scss']
})
export class UserProfileComponent implements OnInit {

  
  hbErrorHandler = new HbErrorHandler();
  userId: number;
  user: User;
  genderList1 = [
    { label: 'Male', code: 'Male', id: undefined, value: undefined },
    { label: 'Female', code: 'Female', id: undefined, value: undefined },
    { label: 'Other', code: 'Other', id: undefined, value: undefined },
    { label: 'Not willing to specify', code: 'Not wiiling to specify', id: undefined, value: undefined },
  ];

  constructor(private location: Location, private router: Router, public activatedRoute: ActivatedRoute, private userService: UserService, private addressService: AddressService) {

  }


  ngOnInit() {
    this.userId = Number(LocalStorageService.getUser());
    this.user = new User();
    this.user.userDetail.address = new Address();
    this.getUserById();

  }

  goBack(): void {
    this.location.back();
  }

  getUserById() {
    this.userService.getUserById(this.userId).subscribe(response => {
      if (response && response.status === 200 && response.data.user) {
        this.user = response.data.user;
        if (!this.user.userDetail) {
          this.user.userDetail = new UserDetail()
        }
        if (this.user.userDetail && !this.user.userDetail.address) {
          this.user.userDetail.address = new Address();
        }
      } else {
        PopupService.failedAlert("Profile", "Something Went Wrong");
      }
    })
  }

  setZipCode(event: any) {
    if (event) {
      this.addressService.getPincodeDetail(event.id).subscribe(response => {
        if (response && response.status === 200 && response.data.pinCodeDetail) {
          this.user.userDetail.address.cityName = response.data.pinCodeDetail.city;
          this.user.userDetail.address.pincode = response.data.pinCodeDetail.pinCode;
          this.user.userDetail.address.stateName = response.data.pinCodeDetail.state;
          this.user.userDetail.address.countryName = response.data.pinCodeDetail.country;
        }
      });
    }
  }

  updateUser() {
    this.validateUser();
    if(!this.hbErrorHandler.invalid){
      this.userService.updateUser(this.user).subscribe(response => {
        if (response && response.status == 200 && response.data.user) {
          this.user = response.data.user;
          PopupService.successAlert('Profile', 'Profile Updated SucessFully').then(result => {
            if (result) {
              this.router.navigate(['/tenant/list']);
            }
          });
        } else {
          this.codeValidation(response);
        }
      })
    }
  }

  validateUser(){
    this.hbErrorHandler.clearErrors();
    this.hbErrorHandler.emptyCheck(this.user.name, 'name');
    this.hbErrorHandler.emptyCheck(this.user.username, 'username');
    this.hbErrorHandler.emptyCheck(this.user.email, 'email');
    if (this.user.email && !HelperService.emailValidator(this.user.email)) {
      this.hbErrorHandler.addError('Invalid Email', 'email');
    }

    if (this.user.oldPassword && !HelperService.passwordValidator(this.user.oldPassword)) {
      this.hbErrorHandler.addError('Password should have min 8 characters, 1 uppercase letter, 1 lowercase letter & 1 numeric', 'oldPassword');
    }

    if (this.user.newPassword && !HelperService.passwordValidator(this.user.newPassword)) {
      this.hbErrorHandler.addError('Password should have min 8 characters, 1 uppercase letter, 1 lowercase letter & 1 numeric', 'newPassword');
    }
    if (this.user.newPassword && this.user.confirmPassword && this.user.newPassword !== this.user.confirmPassword) {
      this.hbErrorHandler.addError('Password mismatch', 'confirmPassword');
    }
    this.hbErrorHandler.emptyCheck(this.user.userDetail.address.addressOne,'addressOne');
    this.hbErrorHandler.emptyCheck(this.user.userDetail.address.cityName,'cityName');
    this.hbErrorHandler.emptyCheck(this.user.userDetail.address.stateName,'stateName');
    this.hbErrorHandler.emptyCheck(this.user.userDetail.address.pincode,'pincode');
    this.hbErrorHandler.emptyCheck(this.user.userDetail.address.countryName,'countryName');


  }

  errorHandler(parentKey: string, childKey?: string, keyIndex?: number): HbErrorHandlerData {
    return this.hbErrorHandler.getErrorHandlerData(parentKey, childKey, keyIndex);
  }

  codeValidation(response) {
    if (response.status == 400) {
      if (response.fieldErrors) {
        response.fieldErrors.forEach(error => {
          this.hbErrorHandler.addError(error.message, error.fieldName);
        });
      }
      window.scrollTo(0, 0);
    }else{
      PopupService.failedAlert('Profile', 'Something Went Wrong').then(result => {
        if (result) {
          this.router.navigate(['/tenant/list']);
        }
      });
    }
  }
}
