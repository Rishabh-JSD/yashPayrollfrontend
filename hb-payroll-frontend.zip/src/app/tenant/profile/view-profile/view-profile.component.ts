import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { User } from 'src/app/auth/models/user';
import { LocalStorageService } from 'src/app/core/services/local-storage-service';
import { Address } from 'src/app/shared/models/address';
import { UserService } from 'src/app/core/services/user.service';
import { PopupService } from 'src/app/shared/services/popup.service';

@Component({
  selector: 'app-view-profile',
  templateUrl: './view-profile.component.html',
  styleUrls: ['./view-profile.component.scss']
})
export class ViewProfileComponent implements OnInit{


  userId: number;
  user: User;
  constructor(private location: Location, private router: Router, public activatedRoute: ActivatedRoute,private userService: UserService,) {
    
  }
  ngOnInit(): void {
    this.userId = Number(LocalStorageService.getUser());
    this.user = new User();
    this.user.userDetail.address = new Address();
    this.getUserById();
  }

  goBack(): void {
    this.location.back();
  }

  getUserById() {
    this.userService.getUserById(this.userId).subscribe(response => {
      if (response && response.status === 200 && response.data.user) {
        this.user = response.data.user;
        if (this.user.userDetail && !this.user.userDetail.address) {
          this.user.userDetail.address = new Address();
        }
      } else {
        PopupService.failedAlert("Profile", "Something Went Wrong");
      }
    })
  }

}
