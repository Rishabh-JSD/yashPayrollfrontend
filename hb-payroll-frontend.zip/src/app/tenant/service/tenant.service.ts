import { Injectable } from '@angular/core';
import { HBHttpService } from '../../core/services/hb-http-service.service';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class TenantService {
  constructor(private hbHttpClient: HBHttpService) {}

  getListTenant(data: any): Observable<any> {
    return this.hbHttpClient.getResponse('tenant/list', this.hbHttpClient.POST, data, true);
  }

  getTenant(id: any): Observable<any> {
    return this.hbHttpClient.getResponse(`tenant/${ id }`, this.hbHttpClient.GET, null, true);
  }

  getTenantListByUser(data: any): Observable<any> {
    return this.hbHttpClient.getResponse('tenant/list', this.hbHttpClient.POST, data, true);
  }

  addTenant(data): Observable<any> {
    return this.hbHttpClient.getResponse('tenant/add', this.hbHttpClient.POST, data, true);
  }
}
