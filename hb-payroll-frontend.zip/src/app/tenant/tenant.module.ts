import { NgModule } from '@angular/core';
import { CommonModule, NgOptimizedImage } from '@angular/common';
import { ViewProfileComponent } from './profile/view-profile/view-profile.component';
import { TenantListingComponent } from './dashboard/tenant-listing.component';
import { TenantPopupComponent } from './dashboard/tenant-popup/tenant-popup.component';
import { CreateTenantComponent } from './create-tenant/create-tenant.component';
import { UserProfileComponent } from './profile/user-profile.component';
import { SharedModule } from '../shared/shared.module';
import { HtgLogoComponent } from './htg-logo/htg-logo.component';
import { RouterModule, Routes } from '@angular/router';
import { LayoutTenantComponent } from './layout-tenant/layout-tenant.component';
import { HeaderTenantComponent } from './layout-tenant/header-tenant/header-tenant.component';
import { SidebarTenantComponent } from './layout-tenant/sidebar-tenant/sidebar-tenant.component';

const routing: Routes = [
  {
    path: '',
    component: LayoutTenantComponent,
    children: [
      { path: '', redirectTo: 'list', pathMatch: 'full', },
      { path: 'list', component: TenantListingComponent, pathMatch: 'full', },
      { path: 'user-profile', component: UserProfileComponent },
      { path: 'add-tenant', component: CreateTenantComponent },
      { path: 'add-tenant/:id', component: CreateTenantComponent },
      { path: 'view-profile', component: ViewProfileComponent },
      { path: 'sidebar-tenat', component: SidebarTenantComponent },
    ]
  },
];

@NgModule({
  declarations: [
    TenantListingComponent,
    TenantPopupComponent,
    CreateTenantComponent,
    UserProfileComponent,
    ViewProfileComponent,
    HtgLogoComponent,
    HeaderTenantComponent,
    LayoutTenantComponent,
    SidebarTenantComponent
  ],
  imports: [
    CommonModule,
    SharedModule,
    RouterModule.forChild(routing),
    NgOptimizedImage,
  ]
})
export class TenantModule {
}
