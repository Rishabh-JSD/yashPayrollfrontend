import { Component, OnInit } from '@angular/core';
import { DropDownModel } from '../../shared/models/hb-field-option';

@Component({
  selector: 'app-admin-add',
  templateUrl: './add-admin.component.html',
  styleUrls: ['./add-admin.component.scss']
})
export class AddAdminComponent implements OnInit {
  HierarchyLevel: DropDownModel[] = [
    { label: ' 1', code: ' 1', id: undefined, value: undefined },
  ];
  Select: DropDownModel[] = [
    { label: ' 1', code: ' 1', id: undefined, value: undefined },
  ];
  User: DropDownModel[] = [
    { label: ' 1', code: ' 1', id: undefined, value: undefined },
  ];

  constructor() { }

  ngOnInit(): void {
  }

}
