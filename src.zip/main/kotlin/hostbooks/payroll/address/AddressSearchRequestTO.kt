package hostbooks.payroll.address

import hostbooks.payroll.shared.utility.model.SearchRequestTO

class AddressSearchRequestTO : SearchRequestTO() {
}