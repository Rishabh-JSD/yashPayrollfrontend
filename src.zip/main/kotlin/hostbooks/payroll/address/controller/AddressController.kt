package hostbooks.payroll.address.controller

import hostbooks.payroll.address.AddressSearchRequestTO
import hostbooks.payroll.address.dto.*
import hostbooks.payroll.address.service.AddressService
import hostbooks.payroll.shared.utility.ValidationError
import hostbooks.payroll.shared.utility.model.ResponseTO
import hostbooks.payroll.shared.utility.model.SearchResponseTO
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.validation.Errors
import org.springframework.validation.Validator
import org.springframework.web.bind.WebDataBinder
import org.springframework.web.bind.annotation.*
import javax.validation.Valid

@RestController
@RequestMapping("/address")
class AddressController(private val addressService: AddressService, private val addressValidator: Validator) {

    @InitBinder
    private fun initBinder(binder: WebDataBinder) {
        binder.validator = this.addressValidator
    }

    @RequestMapping(value = ["/add"], method = [RequestMethod.POST])
    fun addAddress(@RequestBody addressTO: @Valid AddressTO, errors: Errors): ResponseEntity<*> {
        if (errors.hasErrors()) {
            val validationError: ValidationError = ValidationError.fromBindingErrors(errors)
            return ResponseEntity<Any>(validationError, HttpStatus.OK)
        }
        val addressTO_return: AddressTO = addressService.addAddress(addressTO)
        val responseDTO = ResponseTO.responseBuilder(200, "COM01", "/address", "address", addressTO_return)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }

    @RequestMapping(value = ["/update"], method = [RequestMethod.POST])
    fun updateAddress(@RequestBody addressTO: @Valid AddressTO, errors: Errors): ResponseEntity<*> {
        if (errors.hasErrors()) {
            val validationError: ValidationError = ValidationError.fromBindingErrors(errors)
            return ResponseEntity<Any>(validationError, HttpStatus.OK)
        }
        val addressTO_return: AddressTO = addressService.updateAddress(addressTO)
        val responseDTO = ResponseTO.responseBuilder(200, "COM02", "/address", "address", addressTO_return)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }

    @RequestMapping(value = ["/list"], method = [RequestMethod.POST])
    fun getAddressList(@RequestBody addressSearchRequestTO: AddressSearchRequestTO): ResponseEntity<*> {
        val searchResponseTO: SearchResponseTO<AddressTO> = addressService.getAddressList(addressSearchRequestTO)
        if (searchResponseTO.list == null || searchResponseTO.list!!.isEmpty()) {
            val responseDTO = ResponseTO.responseBuilder(200, "COM03E", "/address", "address", searchResponseTO)
            return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
        }
        val responseDTO = ResponseTO.responseBuilder(200, "COM11", "/address", "address", searchResponseTO)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }

    @RequestMapping(value = ["/{id}"], method = [RequestMethod.GET])
    fun getAddressById(@PathVariable id: Int): ResponseEntity<*> {
        val addressTO: AddressTO? = addressService.getAddressById(id)
        if (addressTO == null) {
            val responseDTO = ResponseTO.responseBuilder(200, "COM03E", "/address", "address", 0)
            return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
        }
        val responseDTO = ResponseTO.responseBuilder(200, "COM11", "/address", "address", addressTO)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }

    @RequestMapping(value = ["/delete"], method = [RequestMethod.DELETE])
    fun deleteAddress(@RequestParam(name = "addressId") addressId: List<Int>): ResponseEntity<*> {
        addressService.deleteAddress(addressId)
        val responseDTO = ResponseTO.responseBuilder(200, "COM05", "/address", "address", addressId)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }

//  @RequestMapping(value = "/pincode-details/{pincode}", method = RequestMethod.GET, name = "Pincode Details(Dependency)->ADDCR")
//  public ResponseEntity<?> getPincodeDetails(@PathVariable("pincode") int pincode) {
//   val responseDTO = ResponseTO.responseBuilder(200, "COM11", "/address", "address", addressService.getPincodeRelatedData(pincode));
//    return new ResponseEntity<>(responseDTO, HttpStatus.OK);
//  }

    @RequestMapping(value = ["/city-list"], method = [RequestMethod.POST])
    fun getCityList(@RequestBody(required = false) sortField: String): ResponseEntity<*> {
        val citiesTOList: List<CitiesTO> = addressService.getCityList(sortField)
        if (citiesTOList.isEmpty()) {
            val responseDTO = ResponseTO.responseBuilder(200, "COM03E", "/address/city-list", "city", citiesTOList)
            return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
        }
        val responseDTO = ResponseTO.responseBuilder(200, "COM11", "/address/city-list", "city", citiesTOList)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }

    @RequestMapping(value = ["/city/{id}"], method = [RequestMethod.GET])
    fun getCityById(@PathVariable id: Long): ResponseEntity<*> {
        val citiesTO: CitiesTO? = addressService.getCityById(id)
        if (citiesTO == null) {
            val responseDTO = ResponseTO.responseBuilder(200, "COM03E", "/address/city", "city", 0)
            return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
        }
        val responseDTO = ResponseTO.responseBuilder(200, "COM11", "/address/city", "city", citiesTO)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }

    @RequestMapping(value = ["/country-list"], method = [RequestMethod.POST])
    fun getCountryList(@RequestBody(required = false) sortField: String): ResponseEntity<*> {
        val countriesTOList: List<CountriesTO> = addressService.getCountryList(sortField)
        if (countriesTOList.isEmpty()) {
            val responseDTO =
                ResponseTO.responseBuilder(200, "COM03E", "/address/country-list", "country", countriesTOList)
            return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
        }
        val responseDTO = ResponseTO.responseBuilder(200, "COM11", "/address/country-list", "country", countriesTOList)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }

    @RequestMapping(value = ["/country/{id}"], method = [RequestMethod.GET])
    fun getCountryById(@PathVariable id: Long): ResponseEntity<*> {
        val countriesTO: CountriesTO? = addressService.getCountryById(id)
        if (countriesTO == null) {
            val responseDTO = ResponseTO.responseBuilder(200, "COM03E", "/address/country", "country", 0)
            return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
        }
        val responseDTO = ResponseTO.responseBuilder(200, "COM11", "/address/country", "country", countriesTO)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }

    @RequestMapping(value = ["/pincode-list"], method = [RequestMethod.POST])
    fun getPincodeList(@RequestBody(required = false) sortField: String): ResponseEntity<*> {
        val pincodeTOList: List<PincodeTO> = addressService.getPincodeList(sortField)
        if (pincodeTOList.isEmpty()) {
            val responseDTO =
                ResponseTO.responseBuilder(200, "COM03E", "/address/pincode-list", "pincode", pincodeTOList)
            return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
        }
        val responseDTO = ResponseTO.responseBuilder(200, "COM11", "/address/pincode-list", "pincode", pincodeTOList)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }

    @RequestMapping(value = ["/pincode/{id}"], method = [RequestMethod.GET])
    fun getPincodeById(@PathVariable id: Long): ResponseEntity<*> {
        val pincodeTO: PincodeTO? = addressService.getPincodeById(id)
        if (pincodeTO == null) {
            val responseDTO = ResponseTO.responseBuilder(200, "COM03E", "/address/pincode", "pincode", 0)
            return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
        }
        val responseDTO = ResponseTO.responseBuilder(200, "COM11", "/address/pincode", "pincode", pincodeTO)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }

    @RequestMapping(value = ["/state-list"], method = [RequestMethod.GET])
    fun getStateList(): ResponseEntity<*> {
        val statesTOList: List<StatesTO> = addressService.getStateList()
        if (statesTOList.isEmpty()) {
            val responseDTO = ResponseTO.responseBuilder(200, "COM03E", "/address/state-list", "state", statesTOList)
            return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
        }
        val responseDTO = ResponseTO.responseBuilder(200, "COM11", "/address/state-list", "state", statesTOList)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }

    @RequestMapping(value = ["/state/{id}"], method = [RequestMethod.GET])
    fun getStateById(@PathVariable id: Long): ResponseEntity<*> {
        val statesTO: StatesTO? = addressService.getStateById(id)
        if (statesTO == null) {
            val responseDTO = ResponseTO.responseBuilder(200, "COM03E", "/address/state", "state", 0)
            return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
        }
        val responseDTO = ResponseTO.responseBuilder(200, "COM11", "/address/state", "state", statesTO)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }

    @RequestMapping(value = ["/pinCodeDetail"], method = [RequestMethod.GET])
    fun getPinCodeDetail(@RequestParam(name = "pinCode") pinCode: Int): ResponseEntity<*> {
        val pinCodeDetail: PincodeRelatedTO = addressService.getPinCodeDetails(pinCode)
        val responseDTO = ResponseTO.responseBuilder(200, "COM11", "/address/pinCodeDetail", "pinCodeDetail", pinCodeDetail)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK);
    }
}
