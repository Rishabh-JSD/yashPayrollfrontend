package hostbooks.payroll.address.dto

class AddressTO {

    var id: Long? = null
    var addressOne: String? = null
    var addressTwo: String? = null
    var cityId: Long? = null
    var cityName: String? = null
    var pincodeId: Long? = null
    var pincode: String? = null
    var stateId: Long? = null
    var stateName: String? = null
    var countryId: Long? = null
    var countryName: String? = null
}
