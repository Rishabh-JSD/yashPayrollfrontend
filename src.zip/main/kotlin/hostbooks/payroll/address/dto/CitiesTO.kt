package hostbooks.payroll.address.dto

class CitiesTO {
    var id: Long? = null
    var stateId: Long? = null
    var name: String? = null
    var countryCode: String? = null
}