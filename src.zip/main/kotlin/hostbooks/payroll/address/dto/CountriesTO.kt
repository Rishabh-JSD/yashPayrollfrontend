package hostbooks.payroll.address.dto

class CountriesTO {

    var id: Long? = null
    var shortName: String? = null
    var name: String? = null
    var phoneCode = 0
}