package hostbooks.payroll.address.dto

class PincodeRelatedTO {
     var pinCode: String? = null
     var city: String? = null
     var state: String? = null
     var country: String? = null
}