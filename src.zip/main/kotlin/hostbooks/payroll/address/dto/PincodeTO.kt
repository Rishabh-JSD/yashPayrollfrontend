package hostbooks.payroll.address.dto

class PincodeTO {
    var id: Long? = null
    var pincode: String? = null
    var cityId: Long? = null
}