package hostbooks.payroll.address.dto

class StatesTO {
    var id: Long? = null
    var countryId: Long? = null
    var countryCode: String? = null
    var name: String? = null
    var stateAbbrevCode: String? = null
    var gstinPrefix: String? = null
    var stateCode = 0
}