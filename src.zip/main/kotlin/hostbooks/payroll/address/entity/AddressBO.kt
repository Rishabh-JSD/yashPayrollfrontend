package hostbooks.payroll.address.entity

import hostbooks.payroll.shared.constant.Tables
import jakarta.persistence.*

@Entity
@Table(name = Tables.ADDRESS)
class AddressBO {

    companion object {
        private const val serialVersionUID = 3935672606438086598L
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", updatable = false)
    var id: Long? = null

    @Column(name = "address_one")
    var addressOne: String? = null

    @Column(name = "address_two")
    var addressTwo: String? = null

    @Column(name = "city_name")
    var cityName: String? = null

    @Column(name = "pincode")
    var pincode: String? = null

    @Column(name = "state_name")
    var stateName: String? = null

    @Column(name = "country_name")
    var countryName: String? = null
}
