package hostbooks.payroll.address.entity

import hostbooks.payroll.shared.constant.Tables
import jakarta.persistence.*
import java.io.Serializable

@Entity
@Table(name = Tables.MasterDb.CITIES)
class CitiesBO : Serializable {

    companion object {
        private const val serialVersionUID = -6384072555216311690L
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", updatable = false)
    var id: Long? = null

    @Column(name = "state_id")
    var stateId: Long? = null

    @Column(name = "name")
    var name: String? = null

    @Column(name = "country_code")
    var countryCode: String? = null
}