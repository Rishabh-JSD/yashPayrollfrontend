package hostbooks.payroll.address.entity

import hostbooks.payroll.shared.constant.Tables
import jakarta.persistence.*
import java.io.Serializable

@Entity
@Table(name = Tables.MasterDb.COUNTRIES)
class CountriesBO : Serializable {

    companion object {
        private const val serialVersionUID = -6099715771312350615L
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", updatable = false)
    var id: Long? = null

    @Column(name = "short_name")
    var shortName: String? = null

    @Column(name = "name")
    var name: String? = null

    @Column(name = "phone_code")
    var phoneCode = 0
}