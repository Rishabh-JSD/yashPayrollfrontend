package hostbooks.payroll.address.entity

import hostbooks.payroll.shared.constant.Tables
import jakarta.persistence.*
import java.io.Serializable

@Entity
@Table(name = Tables.MasterDb.PINCODE)
class PincodeBO : Serializable {

    companion object {
        private const val serialVersionUID = 3092237520452423249L
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", updatable = false)
    var id: Long? = null

    @Column(name = "pincode")
    var pincode: String? = null

    @Column(name = "city_id")
    var cityId: Long? = null
}