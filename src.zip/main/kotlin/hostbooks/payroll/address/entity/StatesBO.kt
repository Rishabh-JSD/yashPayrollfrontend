package hostbooks.payroll.address.entity

import hostbooks.payroll.shared.constant.Tables
import jakarta.persistence.*
import java.io.Serializable

@Entity
@Table(name = Tables.MasterDb.STATES)
class StatesBO : Serializable {

    companion object {
        private const val serialVersionUID = -7191989511770737307L
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", updatable = false)
    var id: Long? = null

    @Column(name = "country_id")
    var countryId: Long? = null

    @Column(name = "country_code")
    var countryCode: String? = null

    @Column(name = "name")
    var name: String? = null

    @Column(name = "state_abbrev_code")
    var stateAbbrevCode: String? = null

    @Column(name = "gstin_prefix")
    var gstinPrefix: String? = null

    @Column(name = "state_code")
    var stateCode = 0
}