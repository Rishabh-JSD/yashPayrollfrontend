package hostbooks.payroll.address.service

import hostbooks.payroll.address.AddressSearchRequestTO
import hostbooks.payroll.address.dto.*
import hostbooks.payroll.shared.utility.model.SearchResponseTO

interface AddressService {
    fun addAddress(addressTO: AddressTO): AddressTO

    fun updateAddress(addressTO: AddressTO): AddressTO

    fun getAddressList(addressSearchRequestTO: AddressSearchRequestTO): SearchResponseTO<AddressTO>

    fun getAddressById(id: Int): AddressTO?

    fun deleteAddress(addressId: List<Int>)

    fun getCityList(sortField: String): List<CitiesTO>

    fun getCityById(id: Long): CitiesTO?

    fun getCountryList(sortField: String): List<CountriesTO>

    fun getCountryById(id: Long): CountriesTO?

    fun getPincodeList(sortField: String): List<PincodeTO>

    fun getPincodeById(id: Long): PincodeTO?

    fun getStateList(): List<StatesTO>

    fun getStateById(id: Long): StatesTO?

    fun getPinCodeDetails(pinCode:Int):PincodeRelatedTO
}