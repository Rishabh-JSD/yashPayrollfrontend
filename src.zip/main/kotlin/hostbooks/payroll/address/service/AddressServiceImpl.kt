package hostbooks.payroll.address.service

import hostbooks.payroll.address.AddressSearchRequestTO
import hostbooks.payroll.address.dto.*
import hostbooks.payroll.address.entity.*
import hostbooks.payroll.core.commonDao.CommonDao
import hostbooks.payroll.core.dto.FilterInfo
import hostbooks.payroll.core.dto.HbSort
import hostbooks.payroll.shared.constant.AppEnum
import hostbooks.payroll.shared.utility.CommonUtil
import hostbooks.payroll.shared.utility.MapHandler
import hostbooks.payroll.shared.utility.model.SearchResponseTO
import jakarta.transaction.Transactional
import org.springframework.data.domain.Page
import org.springframework.data.domain.PageRequest
import org.springframework.data.domain.Pageable
import org.springframework.stereotype.Service
import java.util.*

@Service
@Transactional
open class AddressServiceImpl(
    private val commonDao: CommonDao,
    private val mapHandler: MapHandler
) : AddressService {

    override fun addAddress(addressTO: AddressTO): AddressTO {
        val entity = mapHandler.mapObject(addressTO, AddressBO::class.java)
        val persistedEntity = commonDao.persistWithFlush(entity)
        return mapHandler.mapObject(persistedEntity, AddressTO::class.java) ?: addressTO
    }

    override fun updateAddress(addressTO: AddressTO): AddressTO {
        val entity = mapHandler.mapObject(addressTO, AddressBO::class.java)
        val updatedEntity = commonDao.updateWithFlush(entity)
        return mapHandler.mapObject(updatedEntity, AddressTO::class.java) ?: addressTO
    }

    override fun getAddressList(addressSearchRequestTO: AddressSearchRequestTO): SearchResponseTO<AddressTO> {
        val searchResponseTO = SearchResponseTO<AddressTO>()
        val discriminatorMap: WeakHashMap<String, FilterInfo<*>> = WeakHashMap()
        discriminatorMap["status"] = FilterInfo(AppEnum.FilterType.EQ, AppEnum.Status.ACTIVE.toString())
        val sorts: List<HbSort> = listOf(HbSort("addressOne", AppEnum.SortDirection.DESC))
        val pageable: Pageable = PageRequest.of(addressSearchRequestTO.page - 1, addressSearchRequestTO.limit)
        val data: Page<AddressBO> =
            commonDao.listByFilterPagination(AddressBO::class.java, discriminatorMap, pageable, sorts)

        val addressList = ArrayList<AddressTO>()

        data.content.forEach { addressBO ->
            val addressTO: AddressTO? = mapHandler.mapObject(addressBO, AddressTO::class.java)
            if (addressTO != null) {
                addressList.add(addressTO)
            }
        }

        searchResponseTO.list = addressList
        searchResponseTO.pageCount = data.totalPages.toLong()
        searchResponseTO.totalRowCount = data.totalElements
        return searchResponseTO
    }

    override fun getAddressById(id: Int): AddressTO? {
        val addressBO: AddressBO? = commonDao.findByPrimaryKey(AddressBO::class.java, id)
        return mapHandler.mapObject(addressBO, AddressTO::class.java)
    }

    override fun deleteAddress(addressId: List<Int>) {
        for (id in addressId) {
            val address: AddressBO? = commonDao.findByPrimaryKey(AddressBO::class.java, id)
//            if (address != null) {
//                address.status = AppEnum.Status.INACTIVE.toString()
//            }
            commonDao.merge(address);
        }
    }

    override fun getCityList(sortField: String): List<CitiesTO> {
//        val searchResponseTO = SearchResponseTO()
        val discriminatorMap: WeakHashMap<String, FilterInfo<*>> = WeakHashMap()
        val sorts: List<HbSort> = listOf(HbSort("name", AppEnum.SortDirection.DESC))
        val pageable: Pageable = PageRequest.of(1, 10)
        val data: Page<CitiesBO> =
            commonDao.listByFilterPagination(CitiesBO::class.java, discriminatorMap, pageable, sorts)

        val citiesList = ArrayList<CitiesTO>()

        data.content.forEach { citiesBO ->
            val citiesTO: CitiesTO? = mapHandler.mapObject(citiesBO, CitiesTO::class.java)
            if (citiesTO != null) {
                citiesList.add(citiesTO)
            }
        }

//        searchResponseTO.list = citiesList
//        searchResponseTO.pageCount = data.totalPages.toLong()
//        searchResponseTO.totalRowCount = data.totalElements
        return citiesList
    }

    override fun getCityById(id: Long): CitiesTO? {
        val citiesBO: CitiesBO? = commonDao.findByPrimaryKey(CitiesBO::class.java, id)
        return mapHandler.mapObject(citiesBO, CitiesTO::class.java)
    }

    override fun getCountryList(sortField: String): List<CountriesTO> {
//        val searchResponseTO = SearchResponseTO()
        val discriminatorMap: WeakHashMap<String, FilterInfo<*>> = WeakHashMap()
        val sorts: List<HbSort> = listOf(HbSort("name", AppEnum.SortDirection.DESC))
        val pageable: Pageable = PageRequest.of(1, 10)
        val data: Page<CountriesBO> =
            commonDao.listByFilterPagination(CountriesBO::class.java, discriminatorMap, pageable, sorts)

        val countriesList = ArrayList<CountriesTO>()

        data.content.forEach { countriesBO ->
            val countriesTO: CountriesTO? = mapHandler.mapObject(countriesBO, CountriesTO::class.java)
            if (countriesTO != null) {
                countriesList.add(countriesTO)
            }
        }

//        searchResponseTO.list = branchList
//        searchResponseTO.pageCount = data.totalPages.toLong()
//        searchResponseTO.totalRowCount = data.totalElements
        return countriesList
    }

    override fun getCountryById(id: Long): CountriesTO? {
        val countriesBO: CountriesBO? = commonDao.findByPrimaryKey(CountriesBO::class.java, id)
        return mapHandler.mapObject(countriesBO, CountriesTO::class.java)
    }

    override fun getPincodeList(sortField: String): List<PincodeTO> {
//        val searchResponseTO = SearchResponseTO()
        val discriminatorMap: WeakHashMap<String, FilterInfo<*>> = WeakHashMap()
        val sorts: List<HbSort> = listOf(HbSort("name", AppEnum.SortDirection.DESC))
        val pageable: Pageable = PageRequest.of(1, 10)
        val data: Page<PincodeBO> =
            commonDao.listByFilterPagination(PincodeBO::class.java, discriminatorMap, pageable, sorts)

        val pincodeList = ArrayList<PincodeTO>()

        data.content.forEach { pincodeBO ->
            val pincodeTO: PincodeTO? = mapHandler.mapObject(pincodeBO, PincodeTO::class.java)
            if (pincodeTO != null) {
                pincodeList.add(pincodeTO)
            }
        }

//        searchResponseTO.list = branchList
//        searchResponseTO.pageCount = data.totalPages.toLong()
//        searchResponseTO.totalRowCount = data.totalElements
        return pincodeList
    }

    override fun getPincodeById(id: Long): PincodeTO? {
        val pincodeBO: PincodeBO? = commonDao.findByPrimaryKey(PincodeBO::class.java, id)
        return mapHandler.mapObject(pincodeBO, PincodeTO::class.java)
    }

    override fun getStateList(): List<StatesTO> {
//        val searchResponseTO = SearchResponseTO()
        val discriminatorMap: WeakHashMap<String, FilterInfo<*>> = WeakHashMap()
        val sorts: List<HbSort> = listOf(HbSort("name", AppEnum.SortDirection.DESC))
        val pageable: Pageable = PageRequest.of(1, 10)
        val data: Page<StatesBO> =
            commonDao.listByFilterPagination(StatesBO::class.java, discriminatorMap, pageable, sorts)

        val statesList = ArrayList<StatesTO>()

        data.content.forEach { statesBO ->
            val statesTO: StatesTO? = mapHandler.mapObject(statesBO, StatesTO::class.java)
            if (statesTO != null) {
                statesList.add(statesTO)
            }
        }

//        searchResponseTO.list = branchList
//        searchResponseTO.pageCount = data.totalPages.toLong()
//        searchResponseTO.totalRowCount = data.totalElements
        return statesList
    }

    override fun getStateById(id: Long): StatesTO? {
        val statesBO: StatesBO? = commonDao.findByPrimaryKey(StatesBO::class.java, id)
        return mapHandler.mapObject(statesBO, StatesTO::class.java)
    }

    override fun getPinCodeDetails(pinCode: Int): PincodeRelatedTO {
        val returnData:PincodeRelatedTO = PincodeRelatedTO()
        val pinData: PincodeBO? = commonDao.selectSingleByDiscriminator(PincodeBO::class.java,pinCode,"id");
        if(CommonUtil.checkNullEmpty(pinData)){
            if (pinData != null) {
                returnData.pinCode = pinData.pincode
            }
            val cityData: CitiesBO? = commonDao.selectSingleByDiscriminator(CitiesBO::class.java, pinData?.cityId,"id");
            if (cityData != null) {
                returnData.city = cityData.name
            };
            val stateData: StatesBO? = commonDao.selectSingleByDiscriminator(StatesBO::class.java, cityData?.stateId,"id");
            if (stateData != null) {
                returnData.state =stateData.name
            };
            val countryData: CountriesBO? = commonDao.selectSingleByDiscriminator(CountriesBO::class.java, stateData?.countryId,"id");
            if (countryData != null) {
                returnData.country =countryData.name
            }
        }
        return returnData;
    }
}