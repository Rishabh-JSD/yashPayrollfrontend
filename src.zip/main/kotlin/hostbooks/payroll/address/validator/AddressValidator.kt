package hostbooks.payroll.address.validator

import hostbooks.payroll.address.AddressSearchRequestTO
import hostbooks.payroll.address.controller.AddressController
import hostbooks.payroll.address.dto.AddressTO
import org.springframework.validation.Errors
import org.springframework.validation.Validator
import org.springframework.web.bind.annotation.ControllerAdvice

@ControllerAdvice(assignableTypes = [AddressController::class])
class AddressValidator : Validator {

    override fun supports(clazz: Class<*>): Boolean {
        return (clazz == AddressTO::class.java || clazz == AddressSearchRequestTO::class.java)
    }

    override fun validate(target: Any, errors: Errors) {
        if (target is AddressTO) {
            // validation logic for DepartmentTO
        }
    }
}