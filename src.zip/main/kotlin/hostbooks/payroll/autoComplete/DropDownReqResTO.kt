package hostbooks.payroll.autoComplete;


import hostbooks.payroll.shared.utility.model.SearchRequestTO
import lombok.Getter
import lombok.Setter
import lombok.ToString

@Setter
@Getter
@ToString
public class DropDownReqResTO : SearchRequestTO() {
        var name: String? = null
    var type: String? = null
    var catCode: String? = null
    var searchFor: String? = null
    var parentId: Long? = null
    var code: String? = null
    var id: Int? = null
    var idList: ArrayList<Int>? = null
}
