package hostbooks.payroll.autoComplete.controller

import hostbooks.payroll.autoComplete.DropDownReqResTO
import hostbooks.payroll.autoComplete.dto.AutoCompleteDropdownTO
import hostbooks.payroll.autoComplete.service.AutoCompleteDropdownService
import hostbooks.payroll.shared.utility.model.ResponseTO
import hostbooks.payroll.shared.utility.model.SearchResponseTO
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestMethod
import org.springframework.web.bind.annotation.RestController


@RestController
@RequestMapping("/auto-complete")
class AutoCompleteDropdownController(private val autoCompleteDropdownService: AutoCompleteDropdownService) {
    @RequestMapping(value = ["/dropdown"], method = [RequestMethod.POST])
    @Throws(Exception::class)
    fun searchList(@RequestBody dropDownReqResTO: DropDownReqResTO): ResponseEntity<*> {
        val responseTO: SearchResponseTO<AutoCompleteDropdownTO> = autoCompleteDropdownService.searchList(dropDownReqResTO)
        val response: ResponseTO = ResponseTO.responseBuilder(200, "COM11", "/auto-complete", "dropdown", responseTO)
        return ResponseEntity<ResponseTO>(response, HttpStatus.OK)
    }

    @RequestMapping(value = ["/labelById"], method = [RequestMethod.POST])
    @Throws(java.lang.Exception::class)
    fun labelById(@RequestBody dropDownReqRes: DropDownReqResTO): ResponseEntity<*> {
        val labelData: AutoCompleteDropdownTO? = autoCompleteDropdownService.labelById(dropDownReqRes)
        val response: ResponseTO = ResponseTO.responseBuilder(200, "COM11", "/auto-complete", "list", labelData)
        return ResponseEntity<ResponseTO>(response, HttpStatus.OK)
    }

    @RequestMapping(value = ["/labelByCode"], method = [RequestMethod.POST])
    @Throws(java.lang.Exception::class)
    fun labelByCode(@RequestBody dropDownReqRes: DropDownReqResTO): ResponseEntity<*> {
        val labelData: AutoCompleteDropdownTO? = autoCompleteDropdownService.labelByCode(dropDownReqRes)
        val response: ResponseTO = ResponseTO.responseBuilder(200, "COM11", "/auto-complete", "list", labelData)
        return ResponseEntity<ResponseTO>(response, HttpStatus.OK)
    }

    @RequestMapping(value = ["/labelByIdList"], method = [RequestMethod.POST],)
    @Throws(java.lang.Exception::class)
    fun labelByIdList(@RequestBody dropDownReqRes: DropDownReqResTO): ResponseEntity<*> {
        val list: List<AutoCompleteDropdownTO>? = autoCompleteDropdownService.labelByIdList(dropDownReqRes)
        val response: ResponseTO = ResponseTO.responseBuilder(200, "COM11", "/auto-complete", "list", list)
        return ResponseEntity<ResponseTO>(response, HttpStatus.OK)
    }
}