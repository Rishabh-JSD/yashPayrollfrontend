package hostbooks.payroll.autoComplete.dto;


import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
open class AutoCompleteDropdownTO {
    var id: Int? = null
    var catCode: String? = null
    var label: String? = null
    var parentId: Int? = null
    var code: String? = null

}
