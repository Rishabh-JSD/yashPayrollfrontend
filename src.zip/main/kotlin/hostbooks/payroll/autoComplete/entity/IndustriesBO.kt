package hostbooks.payroll.autoComplete.entity

import hostbooks.payroll.shared.constant.Tables
import hostbooks.payroll.shared.utility.model.Audit
import jakarta.persistence.*

@Entity
@Table(name = Tables.MasterDb.INDUSTRIES)
class IndustriesBO : Audit() {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "industry_id", updatable = false, nullable = false)
    var id: Int? = null

    @Column(name = "code", length = 200, nullable = false)
    var code: String? = null

    @Column(name = "name", length = 256, nullable = false)
    var name: String? = null

    @Column(name = "description")
    var description: String? = null

}