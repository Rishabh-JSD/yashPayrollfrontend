package hostbooks.payroll.autoComplete.service;

import hostbooks.payroll.autoComplete.DropDownReqResTO
import hostbooks.payroll.autoComplete.dto.AutoCompleteDropdownTO
import hostbooks.payroll.shared.utility.model.SearchResponseTO


interface AutoCompleteDropdownService
{
	fun searchList(dropDownReqRes: DropDownReqResTO): SearchResponseTO<AutoCompleteDropdownTO>

	fun labelById(dropDownReqRes: DropDownReqResTO): AutoCompleteDropdownTO?

	fun labelByCode(dropDownReqRes: DropDownReqResTO): AutoCompleteDropdownTO?

	fun labelByIdList(dropDownReqRes: DropDownReqResTO): List<AutoCompleteDropdownTO>?
}
