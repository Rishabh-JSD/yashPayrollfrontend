package hostbooks.payroll.autoComplete.service;


import hostbooks.payroll.address.entity.CitiesBO
import hostbooks.payroll.address.entity.CountriesBO
import hostbooks.payroll.address.entity.PincodeBO
import hostbooks.payroll.address.entity.StatesBO
import hostbooks.payroll.autoComplete.DropDownReqResTO
import hostbooks.payroll.autoComplete.dto.AutoCompleteDropdownTO
import hostbooks.payroll.autoComplete.entity.IndustriesBO
import hostbooks.payroll.companyDetail.branch.entity.BranchBO
import hostbooks.payroll.companyDetail.costCenter.entity.CostCenterBO
import hostbooks.payroll.companyDetail.department.entity.DepartmentBO
import hostbooks.payroll.core.commonDao.CommonDao
import hostbooks.payroll.core.dto.FilterInfo
import hostbooks.payroll.documentSeries.entity.DisplayStyleBO
import hostbooks.payroll.employee.entity.EmployeeBO
import hostbooks.payroll.leave.leaveRule.creditCarry.dto.LeaveRuleCreditCarryTO
import hostbooks.payroll.leave.leaveType.dto.LeaveTypeTO
import hostbooks.payroll.leave.leaveType.entity.LeaveTypeBO
import hostbooks.payroll.masters.fixedMasters.entity.FixedMastersBO
import hostbooks.payroll.masters.holiday.typeMaster.entity.HolidayTypeMasterBO
import hostbooks.payroll.masters.option.entity.MasterOptionBO
import hostbooks.payroll.shared.constant.AppConst
import hostbooks.payroll.shared.constant.AppEnum
import hostbooks.payroll.shared.utility.MapHandler
import hostbooks.payroll.shared.utility.model.SearchResponseTO
import jakarta.transaction.Transactional
import org.springframework.data.domain.Page
import org.springframework.data.domain.PageRequest
import org.springframework.stereotype.Service
import java.text.SimpleDateFormat
import java.util.*

@Service
@Transactional
open class AutoCompleteDropdownServiceImpl
    (
    private val mapHandler: MapHandler,
    private val commonDao: CommonDao
) : AutoCompleteDropdownService {

    override fun searchList(dropDownReqRes: DropDownReqResTO): SearchResponseTO<AutoCompleteDropdownTO> {
        val searchResponseTO = SearchResponseTO<AutoCompleteDropdownTO>()
        val discriminatorMap = WeakHashMap<String, FilterInfo<*>>()
        if (dropDownReqRes.type == AppConst.AutoCompleteType.MASTER_OPTION ||
            dropDownReqRes.type == AppConst.AutoCompleteType.BRANCH ||
            dropDownReqRes.type == AppConst.AutoCompleteType.COST_CENTER ||
            dropDownReqRes.type == AppConst.AutoCompleteType.DEPARTMENT ||
            dropDownReqRes.type == AppConst.AutoCompleteType.FIXED_MASTERS ||
            dropDownReqRes.type == AppConst.AutoCompleteType.EMPLOYEE ||
            dropDownReqRes.type == AppConst.AutoCompleteType.LEAVE_TYPE ||
            dropDownReqRes.type == AppConst.AutoCompleteType.HOLIDAY_TYPE
        ) {
            discriminatorMap["status"] = FilterInfo(AppEnum.FilterType.EQ, AppEnum.Status.ACTIVE.toString())
        }
        if (dropDownReqRes.searchFor != null) {
            if (dropDownReqRes.type == AppConst.AutoCompleteType.PINCODE) {
                discriminatorMap["pincode"] = FilterInfo(AppEnum.FilterType.LIKE, dropDownReqRes.searchFor)
            } else if (dropDownReqRes.catCode == AppConst.MasterOption.SHIFT_TIMING) {
                discriminatorMap["parentId"] = FilterInfo(AppEnum.FilterType.LIKE, dropDownReqRes.searchFor)
            } else {
                discriminatorMap["name"] = FilterInfo(AppEnum.FilterType.LIKE, dropDownReqRes.searchFor)
            }
        }
        if (dropDownReqRes.catCode != null) {
            discriminatorMap["catCode"] = FilterInfo(AppEnum.FilterType.EQ, dropDownReqRes.catCode)
        }
        if (dropDownReqRes.parentId != null) {
            discriminatorMap["parentId"] = FilterInfo(AppEnum.FilterType.EQ, dropDownReqRes.parentId)
        }
        val pageable = PageRequest.of(dropDownReqRes.page - 1, dropDownReqRes.limit)

        val data: Page<*> = when (dropDownReqRes.type) {
            AppConst.AutoCompleteType.MASTER_OPTION -> {
                commonDao.listByFilterPagination(MasterOptionBO::class.java, discriminatorMap, pageable, null)
            }

            AppConst.AutoCompleteType.COUNTRY -> {
                commonDao.listByFilterPagination(CountriesBO::class.java, discriminatorMap, pageable, null)
            }

            AppConst.AutoCompleteType.CITY -> {
                commonDao.listByFilterPagination(CitiesBO::class.java, discriminatorMap, pageable, null)
            }

            AppConst.AutoCompleteType.PINCODE -> {
                commonDao.listByFilterPagination(PincodeBO::class.java, discriminatorMap, pageable, null)
            }

            AppConst.AutoCompleteType.STATE -> {
                commonDao.listByFilterPagination(StatesBO::class.java, discriminatorMap, pageable, null)
            }

            AppConst.AutoCompleteType.DISPLAY_STYLE -> {
                commonDao.listByFilterPagination(DisplayStyleBO::class.java, discriminatorMap, pageable, null)
            }

            AppConst.AutoCompleteType.BRANCH -> {
                commonDao.listByFilterPagination(BranchBO::class.java, discriminatorMap, pageable, null)
            }

            AppConst.AutoCompleteType.COST_CENTER -> {
                commonDao.listByFilterPagination(CostCenterBO::class.java, discriminatorMap, pageable, null)
            }

            AppConst.AutoCompleteType.DEPARTMENT -> {
                commonDao.listByFilterPagination(DepartmentBO::class.java, discriminatorMap, pageable, null)
            }

            AppConst.AutoCompleteType.FIXED_MASTERS -> {
                commonDao.listByFilterPagination(FixedMastersBO::class.java, discriminatorMap, pageable, null)
            }

            AppConst.AutoCompleteType.EMPLOYEE -> {
                commonDao.listByFilterPagination(EmployeeBO::class.java, discriminatorMap, pageable, null)
            }

            AppConst.AutoCompleteType.INDUSTRY -> {
                commonDao.listByFilterPagination(IndustriesBO::class.java, discriminatorMap, pageable, null)
            }

            AppConst.AutoCompleteType.LEAVE_TYPE -> {
                commonDao.listByFilterPagination(LeaveTypeBO::class.java, discriminatorMap, pageable, null)
            }

            AppConst.AutoCompleteType.HOLIDAY_TYPE -> {
                commonDao.listByFilterPagination(HolidayTypeMasterBO::class.java, discriminatorMap, pageable, null)
            }

            else -> throw IllegalArgumentException("Unsupported type: ${dropDownReqRes.type}")
        }

        val dropdownOptionList = ArrayList<AutoCompleteDropdownTO>()

        data.content.forEach { entity ->

            when (entity) {

                is MasterOptionBO -> {
                    val autoCompleteDropdownTO = mapHandler.mapObject(entity, AutoCompleteDropdownTO::class.java)
                    if (autoCompleteDropdownTO != null) {
                        if (autoCompleteDropdownTO.catCode != null) {
                            autoCompleteDropdownTO.label = entity.name
                            if (autoCompleteDropdownTO.catCode == AppConst.MasterOption.SHIFT_TIMING) {
                                autoCompleteDropdownTO.label =
                                    "" + formatTime(entity.startTime) + "-" + formatTime(entity.endTime)
                            }
                        }
                        dropdownOptionList.add(autoCompleteDropdownTO)
                    }
                }

                is CountriesBO -> {
                    val autoCompleteDropdownTO = mapHandler.mapObject(entity, AutoCompleteDropdownTO::class.java)
                    if (autoCompleteDropdownTO != null) {
                        autoCompleteDropdownTO.label = entity.name
                        autoCompleteDropdownTO.code = entity.name
                        dropdownOptionList.add(autoCompleteDropdownTO)
                    }
                }

                is CitiesBO -> {
                    val autoCompleteDropdownTO = mapHandler.mapObject(entity, AutoCompleteDropdownTO::class.java)
                    if (autoCompleteDropdownTO != null) {
                        autoCompleteDropdownTO.label = entity.name
                        autoCompleteDropdownTO.code = entity.name;
                        dropdownOptionList.add(autoCompleteDropdownTO)
                    }
                }

                is PincodeBO -> {
                    val autoCompleteDropdownTO = mapHandler.mapObject(entity, AutoCompleteDropdownTO::class.java)
                    if (autoCompleteDropdownTO != null) {
                        autoCompleteDropdownTO.label = entity.pincode
                        autoCompleteDropdownTO.code = entity.pincode
                        dropdownOptionList.add(autoCompleteDropdownTO)
                    }
                }

                is StatesBO -> {
                    val autoCompleteDropdownTO = mapHandler.mapObject(entity, AutoCompleteDropdownTO::class.java)
                    if (autoCompleteDropdownTO != null) {
                        autoCompleteDropdownTO.label = entity.name
                        autoCompleteDropdownTO.code = entity.name;
                        dropdownOptionList.add(autoCompleteDropdownTO)
                    }
                }

                is BranchBO -> {
                    val autoCompleteDropdownTO = mapHandler.mapObject(entity, AutoCompleteDropdownTO::class.java)
                    if (autoCompleteDropdownTO != null) {
                        autoCompleteDropdownTO.label = entity.name
                        dropdownOptionList.add(autoCompleteDropdownTO)
                    }
                }

                is CostCenterBO -> {
                    val autoCompleteDropdownTO = mapHandler.mapObject(entity, AutoCompleteDropdownTO::class.java)
                    if (autoCompleteDropdownTO != null) {
                        autoCompleteDropdownTO.label = entity.name
                        dropdownOptionList.add(autoCompleteDropdownTO)
                    }
                }

                is DepartmentBO -> {
                    val autoCompleteDropdownTO = mapHandler.mapObject(entity, AutoCompleteDropdownTO::class.java)
                    if (autoCompleteDropdownTO != null) {
                        autoCompleteDropdownTO.label = entity.name
                        dropdownOptionList.add(autoCompleteDropdownTO)
                    }
                }

                is FixedMastersBO -> {
                    val autoCompleteDropdownTO = mapHandler.mapObject(entity, AutoCompleteDropdownTO::class.java)
                    if (autoCompleteDropdownTO != null) {
                        autoCompleteDropdownTO.label = entity.name
                        autoCompleteDropdownTO.code = entity.code
                        dropdownOptionList.add(autoCompleteDropdownTO)
                    }
                }

                is EmployeeBO -> {
                    val autoCompleteDropdownTO = mapHandler.mapObject(entity, AutoCompleteDropdownTO::class.java)
                    if (autoCompleteDropdownTO != null) {
                        autoCompleteDropdownTO.label = entity.name
                        dropdownOptionList.add(autoCompleteDropdownTO)
                    }
                }

                is IndustriesBO -> {
                    val autoCompleteDropdownTO = mapHandler.mapObject(entity, AutoCompleteDropdownTO::class.java)
                    if (autoCompleteDropdownTO != null) {
                        autoCompleteDropdownTO.label = entity.name
                        dropdownOptionList.add(autoCompleteDropdownTO)
                    }
                }

                is DisplayStyleBO -> {
                    val autoCompleteDropdownTO = mapHandler.mapObject(entity, AutoCompleteDropdownTO::class.java)
                    if (autoCompleteDropdownTO != null) {
                        autoCompleteDropdownTO.label = entity.name
                        autoCompleteDropdownTO.id = entity.id
                        dropdownOptionList.add(autoCompleteDropdownTO)
                    }
                }

                is LeaveTypeBO -> {
                    val autoCompleteDropdownTO = mapHandler.mapObject(entity, AutoCompleteDropdownTO::class.java)
                    if (autoCompleteDropdownTO != null) {
                        autoCompleteDropdownTO.label = entity.name
                        dropdownOptionList.add(autoCompleteDropdownTO)
                    }
                }

                is HolidayTypeMasterBO -> {
                    val autoCompleteDropdownTO = mapHandler.mapObject(entity, AutoCompleteDropdownTO::class.java)
                    if (autoCompleteDropdownTO != null) {
                        autoCompleteDropdownTO.label = entity.name
                        dropdownOptionList.add(autoCompleteDropdownTO)
                    }
                }

            }
        }

        searchResponseTO.list = dropdownOptionList
        return searchResponseTO
    }

    fun formatTime(time: Date?): String {
        val outputFormat = SimpleDateFormat("hh:mm:ss a")
        return outputFormat.format(time)
    }

    override fun labelById(dropDownReqRes: DropDownReqResTO): AutoCompleteDropdownTO? {
        var labelData: AutoCompleteDropdownTO? = null
        if (dropDownReqRes.type != null && dropDownReqRes.type!!.isNotEmpty()) {
            when (dropDownReqRes.type) {
                AppConst.AutoCompleteType.COUNTRY -> {
                    val countriesBO = commonDao.findByPrimaryKey(CountriesBO::class.java, dropDownReqRes.id!!)
                    if (countriesBO != null) {
                        labelData = mapHandler.mapObject(countriesBO, AutoCompleteDropdownTO::class.java)
                        if (labelData != null) {
                            labelData.label = countriesBO.name
                            labelData.code = countriesBO.name
                        }
                    }
                }

                AppConst.AutoCompleteType.CITY -> {
                    val citiesBO = commonDao.findByPrimaryKey(CitiesBO::class.java, dropDownReqRes.id!!)
                    if (citiesBO != null) {
                        labelData = mapHandler.mapObject(citiesBO, AutoCompleteDropdownTO::class.java)
                        if (labelData != null) {
                            labelData.label = citiesBO.name
                        }
                    }
                }

                AppConst.AutoCompleteType.STATE -> {
                    val statesBO = commonDao.findByPrimaryKey(StatesBO::class.java, dropDownReqRes.id!!)
                    if (statesBO != null) {
                        labelData = mapHandler.mapObject(statesBO, AutoCompleteDropdownTO::class.java)
                        if (labelData != null) {
                            labelData.label = statesBO.name
                        }
                    }
                }

                AppConst.AutoCompleteType.COST_CENTER -> {
                    val costCenterBO = commonDao.findByPrimaryKey(CostCenterBO::class.java, dropDownReqRes.id!!)
                    if (costCenterBO != null) {
                        labelData = mapHandler.mapObject(costCenterBO, AutoCompleteDropdownTO::class.java)
                        if (labelData != null) {
                            labelData.label = costCenterBO.name
                        }
                    }
                }

                AppConst.AutoCompleteType.BRANCH -> {
                    val branchBO = commonDao.findByPrimaryKey(BranchBO::class.java, dropDownReqRes.id!!)
                    if (branchBO != null) {
                        labelData = mapHandler.mapObject(branchBO, AutoCompleteDropdownTO::class.java)
                        if (labelData != null) {
                            labelData.label = branchBO.name
                        }
                    }
                }

                AppConst.AutoCompleteType.DEPARTMENT -> {
                    val departmentBO = commonDao.findByPrimaryKey(DepartmentBO::class.java, dropDownReqRes.id!!)
                    if (departmentBO != null) {
                        labelData = mapHandler.mapObject(departmentBO, AutoCompleteDropdownTO::class.java)
                        if (labelData != null) {
                            labelData.label = departmentBO.name
                        }
                    }
                }

                AppConst.AutoCompleteType.PINCODE -> {
                    val pincodeBO = commonDao.findByPrimaryKey(PincodeBO::class.java, dropDownReqRes.id!!)
                    if (pincodeBO != null) {
                        labelData = mapHandler.mapObject(pincodeBO, AutoCompleteDropdownTO::class.java)
                        if (labelData != null) {
                            labelData.label = pincodeBO.pincode
                        }
                    }
                }

                AppConst.AutoCompleteType.MASTER_OPTION -> {
                    val masterOptionBO = commonDao.findByPrimaryKey(MasterOptionBO::class.java, dropDownReqRes.id!!)
                    if (masterOptionBO != null) {
                        labelData = mapHandler.mapObject(masterOptionBO, AutoCompleteDropdownTO::class.java)
                        if (labelData != null) {
                            labelData.label = masterOptionBO.name
                            if (labelData.catCode == AppConst.MasterOption.SHIFT_TIMING) {
                                labelData.label = "" + formatTime(masterOptionBO.startTime) + "-" + formatTime(masterOptionBO.endTime)
                            }
                        }
                    }
                }

                AppConst.AutoCompleteType.FIXED_MASTERS -> {
                    val fixedMastersBO = commonDao.findByPrimaryKey(FixedMastersBO::class.java, dropDownReqRes.id!!)
                    if (fixedMastersBO != null) {
                        labelData = mapHandler.mapObject(fixedMastersBO, AutoCompleteDropdownTO::class.java)
                        if (labelData != null) {
                            labelData.label = fixedMastersBO.name
                            labelData.code = fixedMastersBO.code
                        }
                    }
                }

                AppConst.AutoCompleteType.EMPLOYEE -> {
                    val employeeBO = commonDao.findByPrimaryKey(EmployeeBO::class.java, dropDownReqRes.id!!)
                    if (employeeBO != null) {
                        labelData = mapHandler.mapObject(employeeBO, AutoCompleteDropdownTO::class.java)
                        if (labelData != null) {
                            labelData.label = employeeBO.name
                        }
                    }
                }

                AppConst.AutoCompleteType.DISPLAY_STYLE -> {
                    val employeeBO = commonDao.findByPrimaryKey(DisplayStyleBO::class.java, dropDownReqRes.id!!)
                    if (employeeBO != null) {
                        labelData = mapHandler.mapObject(employeeBO, AutoCompleteDropdownTO::class.java)
                        if (labelData != null) {
                            labelData.label = employeeBO.name
                        }
                    }
                }

                AppConst.AutoCompleteType.INDUSTRY -> {
                    val industriesBO = commonDao.findByPrimaryKey(IndustriesBO::class.java, dropDownReqRes.id!!)
                    if (industriesBO != null) {
                        labelData = mapHandler.mapObject(industriesBO, AutoCompleteDropdownTO::class.java)
                        if (labelData != null) {
                            labelData.label = industriesBO.name
                        }
                    }
                }

                AppConst.AutoCompleteType.LEAVE_TYPE -> {
                    val leaveTypeBO = commonDao.findByPrimaryKey(LeaveTypeBO::class.java, dropDownReqRes.id!!)
                    if (leaveTypeBO != null) {
                        labelData = mapHandler.mapObject(leaveTypeBO, AutoCompleteDropdownTO::class.java)
                        if (labelData != null) {
                            labelData.label = leaveTypeBO.name
                        }
                    }
                }

                AppConst.AutoCompleteType.HOLIDAY_TYPE -> {
                    val holidayTypeBO = commonDao.findByPrimaryKey(HolidayTypeMasterBO::class.java, dropDownReqRes.id!!)
                    if (holidayTypeBO != null) {
                        labelData = mapHandler.mapObject(holidayTypeBO, AutoCompleteDropdownTO::class.java)
                        if (labelData != null) {
                            labelData.label = holidayTypeBO.name
                        }
                    }
                }
            }
        }
        return labelData
    }

    override fun labelByCode(dropDownReqRes: DropDownReqResTO): AutoCompleteDropdownTO? {
        var labelData: AutoCompleteDropdownTO? = null
        if (dropDownReqRes.type != null && dropDownReqRes.type!!.isNotEmpty() && dropDownReqRes.name != null
        ) {
            when (dropDownReqRes.type) {

                AppConst.AutoCompleteType.COUNTRY -> {
                    val discriminatorMap = WeakHashMap<String, FilterInfo<*>>()
                    discriminatorMap["name"] = FilterInfo(AppEnum.FilterType.EQ, dropDownReqRes.name)
                    val pageable = PageRequest.of(0, 10)
                    val data: Page<CountriesBO> = commonDao.listByFilterPagination(CountriesBO::class.java, discriminatorMap, pageable, null)
                    data.content.forEach { countriesBO ->
                        labelData = mapHandler.mapObject(countriesBO, AutoCompleteDropdownTO::class.java)
                        if (labelData != null) {
                            labelData!!.label = countriesBO.name
                            labelData!!.code = countriesBO.name
                        }
                    }
                }

                AppConst.AutoCompleteType.FIXED_MASTERS -> {
                    val discriminatorMap = WeakHashMap<String, FilterInfo<*>>()
                    discriminatorMap["code"] = FilterInfo(AppEnum.FilterType.EQ, dropDownReqRes.name)
                    val pageable = PageRequest.of(0, 10)
                    val data: Page<FixedMastersBO> = commonDao.listByFilterPagination(FixedMastersBO::class.java, discriminatorMap, pageable, null)
                    data.content.forEach { fixedMastersBO ->
                        labelData = mapHandler.mapObject(fixedMastersBO, AutoCompleteDropdownTO::class.java)
                        if (labelData != null) {
                            labelData!!.label = fixedMastersBO.name
                            labelData!!.code = fixedMastersBO.code
                        }
                    }
                }

                AppConst.AutoCompleteType.PINCODE -> {
                    val pincodeBO:PincodeBO? = commonDao.selectSingleByDiscriminator(PincodeBO::class.java, dropDownReqRes.name!!,"pincode")
                    if (pincodeBO != null) {
                        labelData = mapHandler.mapObject(pincodeBO, AutoCompleteDropdownTO::class.java)
                        if (labelData != null) {
                            labelData!!.label = pincodeBO.pincode
                            labelData!!.code = pincodeBO.pincode
                        }
                    }
                }

                AppConst.AutoCompleteType.CITY -> {
                    val citiesBO:CitiesBO? = commonDao.selectSingleByDiscriminator(CitiesBO::class.java, dropDownReqRes.name!!,"name")
                    if (citiesBO != null) {
                        labelData = mapHandler.mapObject(citiesBO, AutoCompleteDropdownTO::class.java)
                        if (labelData != null) {
                            labelData!!.label = citiesBO.name
                            labelData!!.code = citiesBO.name
                        }
                    }
                }


                AppConst.AutoCompleteType.STATE -> {
                    val statesBO:StatesBO? = commonDao.selectSingleByDiscriminator(StatesBO::class.java, dropDownReqRes.name!!,"name")
                    if (statesBO != null) {
                        labelData = mapHandler.mapObject(statesBO, AutoCompleteDropdownTO::class.java)
                        if (labelData != null) {
                            labelData!!.label = statesBO.name
                            labelData!!.code = statesBO.name
                        }
                    }
                }

            }
        }
        return labelData
    }

    override fun labelByIdList(dropDownReqRes: DropDownReqResTO): List<AutoCompleteDropdownTO>? {
        val arrayList = ArrayList<AutoCompleteDropdownTO>()
        if (dropDownReqRes.idList != null && dropDownReqRes.idList!!.size > 0) {
            when (dropDownReqRes.type) {
                AppConst.AutoCompleteType.LEAVE_TYPE -> {
                    val discriminatorMap = WeakHashMap<String, FilterInfo<*>>()
                    val filterInfo:FilterInfo<Any> = FilterInfo(AppEnum.FilterType.IN, dropDownReqRes.idList)
                    discriminatorMap["id"] = filterInfo;
                    val pageable = PageRequest.of(0, 10)
                    val data: Page<LeaveTypeBO> =
                        commonDao.listByFilterPagination(LeaveTypeBO::class.java, discriminatorMap, pageable, null)
                    data.content.forEach { leaveTypeBO ->
                        val leaveTypeTO = mapHandler.mapObject(leaveTypeBO, AutoCompleteDropdownTO::class.java)
                        if (leaveTypeTO != null) {
                            leaveTypeTO.label = leaveTypeBO.name
                            arrayList.add(leaveTypeTO)
                        }
                    }
                }
            }
        }
        return arrayList
    }

}
