package hostbooks.payroll.companyDetail

import hostbooks.payroll.shared.utility.model.SearchRequestTO

class CompanyDetailSearchRequestTO : SearchRequestTO() {
    val searchFor: String? = null
    val departmentFlag: Boolean? = null
}