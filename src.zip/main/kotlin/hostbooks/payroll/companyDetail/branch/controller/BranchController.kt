package hostbooks.payroll.companyDetail.branch.controller

import hostbooks.payroll.companyDetail.CompanyDetailSearchRequestTO
import hostbooks.payroll.shared.utility.ValidationError
import hostbooks.payroll.shared.utility.model.ResponseTO
import hostbooks.payroll.shared.utility.model.SearchResponseTO
import hostbooks.payroll.companyDetail.branch.dto.BranchTO
import hostbooks.payroll.companyDetail.branch.service.BranchService
import hostbooks.payroll.employee.service.EmployeeService
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.validation.Errors
import org.springframework.validation.Validator
import org.springframework.web.bind.WebDataBinder
import org.springframework.web.bind.annotation.*
import javax.validation.Valid

@RestController
@RequestMapping("/branch")
class BranchController(private val branchService: BranchService, private val branchValidator: Validator) {

    @InitBinder
    private fun initBinder(binder: WebDataBinder) {
        binder.validator = this.branchValidator
    }

    @RequestMapping(value = ["/add"], method = [RequestMethod.POST])
    fun addBranch(@RequestBody branchTO: @Valid BranchTO, errors: Errors): ResponseEntity<*> {
        if (errors.hasErrors()) {
            val validationError: ValidationError = ValidationError.fromBindingErrors(errors)
            return ResponseEntity<Any>(validationError, HttpStatus.OK)
        }
        val branchTO_return: BranchTO = branchService.addBranch(branchTO)
        val responseDTO = ResponseTO.responseBuilder(200, "COM01", "/branch", "branch", branchTO_return)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }

    @RequestMapping(value = ["/update"], method = [RequestMethod.POST])
    fun updateBranch(@RequestBody branchTO: @Valid BranchTO, errors: Errors): ResponseEntity<*> {
        if (errors.hasErrors()) {
            val validationError: ValidationError = ValidationError.fromBindingErrors(errors)
            return ResponseEntity<Any>(validationError, HttpStatus.OK)
        }
        val branchTO_return: BranchTO = branchService.updateBranch(branchTO)
        val responseDTO = ResponseTO.responseBuilder(200, "COM02", "/branch", "branch", branchTO_return)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }

    @RequestMapping(value = ["/list"], method = [RequestMethod.POST])
    fun getBranchList(@RequestBody companyDetailSearchRequestTO: CompanyDetailSearchRequestTO): ResponseEntity<*> {
        val searchResponseTO: SearchResponseTO<BranchTO> = branchService.getBranchList(companyDetailSearchRequestTO)
        if (searchResponseTO.list == null || searchResponseTO.list!!.isEmpty()) {
            val responseDTO = ResponseTO.responseBuilder(200, "COM03E", "/branch", "branch", searchResponseTO)
            return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
        }
        val responseDTO = ResponseTO.responseBuilder(200, "COM11", "/branch", "branch", searchResponseTO)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }

    @RequestMapping(value = ["/{id}"], method = [RequestMethod.GET])
    fun getBranchById(@PathVariable id: Long): ResponseEntity<*> {
        val branchTO: BranchTO? = branchService.getBranchById(id)
        if (branchTO == null) {
            val responseDTO = ResponseTO.responseBuilder(200, "COM03E", "/branch", "branch", null)
            return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
        }
        val responseDTO = ResponseTO.responseBuilder(200, "COM11", "/branch", "branch", branchTO)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }

    @RequestMapping(value = ["/delete"], method = [RequestMethod.DELETE])
    fun deleteBranch(@RequestParam(name = "branchId") branchId: List<Long>): ResponseEntity<*> {
        branchService.deleteBranch(branchId)
        val responseDTO = ResponseTO.responseBuilder(200, "COM05", "/branch", "branch", branchId)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }
}