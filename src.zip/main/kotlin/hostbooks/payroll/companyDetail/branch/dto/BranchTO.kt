package hostbooks.payroll.companyDetail.branch.dto

import hostbooks.payroll.address.dto.AddressTO
import hostbooks.payroll.shared.utility.model.AuditTO
import java.math.BigDecimal

class BranchTO : AuditTO() {

    var id: Long? = null
    var name: String? = null
    var code: String? = null
    var gstin: String? = null
    var addressId: Long? = null
    var headId: Long? = null
    var headName: String? = null
    var phoneNo: Long? = null
    var email: String? = null
    var shiftTypeId: Long? = null
    var shiftTimingId: Long? = null
    var workingHours: BigDecimal? = null
    var status: String = "ACTIVE"
    var address: AddressTO? = null
    var totalEmployees: Long? = null
}