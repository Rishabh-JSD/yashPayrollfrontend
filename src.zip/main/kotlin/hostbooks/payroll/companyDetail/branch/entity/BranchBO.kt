package hostbooks.payroll.companyDetail.branch.entity

import hostbooks.payroll.address.entity.AddressBO
import hostbooks.payroll.shared.constant.Tables
import hostbooks.payroll.shared.utility.model.Audit
import jakarta.persistence.*
import java.math.BigDecimal

@Entity
@Table(name = Tables.BRANCH)
class BranchBO : Audit() {

    companion object {
        private const val serialVersionUID = -8594968278434644290L
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", updatable = false)
    var id: Long? = null

    @Column(name = "name")
    var name: String? = null

    @Column(name = "code")
    var code: String? = null

    @Column(name = "gstin")
    var gstin: String? = null

    @Column(name = "address_id", insertable = false, updatable = false)
    var addressId: Long? = null

    @Column(name = "head_id")
    var headId: Long? = null

    @Column(name = "phone_no")
    var phoneNo: Long? = null

    @Column(name = "email")
    var email: String? = null

    @Column(name = "shift_type_id")
    var shiftTypeId: Long? = null

    @Column(name = "shift_timing_id")
    var shiftTimingId: Long? = null

    @Column(name = "working_hours")
    var workingHours: BigDecimal? = null

    @Column(name = "status", nullable = false)
    var status: String? = null

    @OneToOne(cascade = [CascadeType.ALL], orphanRemoval = true)
    @JoinColumn(name = "address_id")
    var address: AddressBO? = null
}