package hostbooks.payroll.companyDetail.branch.service

import hostbooks.payroll.companyDetail.CompanyDetailSearchRequestTO
import hostbooks.payroll.shared.utility.model.SearchResponseTO
import hostbooks.payroll.companyDetail.branch.dto.BranchTO

interface BranchService {
    fun addBranch(branchTO: BranchTO): BranchTO

    fun updateBranch(branchTO: BranchTO): BranchTO

    fun getBranchList(companyDetailSearchRequestTO: CompanyDetailSearchRequestTO): SearchResponseTO<BranchTO>

    fun deleteBranch(branchId: List<Long>)

    fun getBranchById(id: Long): BranchTO?
}