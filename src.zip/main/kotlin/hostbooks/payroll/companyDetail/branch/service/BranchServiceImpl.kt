package hostbooks.payroll.companyDetail.branch.service

import hostbooks.payroll.companyDetail.CompanyDetailSearchRequestTO
import hostbooks.payroll.companyDetail.branch.dto.BranchTO
import hostbooks.payroll.companyDetail.branch.entity.BranchBO
import hostbooks.payroll.core.commonDao.CommonDao
import hostbooks.payroll.core.dto.FilterInfo
import hostbooks.payroll.core.dto.HbSort
import hostbooks.payroll.employee.entity.EmployeeBO
import hostbooks.payroll.employee.entity.EmployeeCompanyDetailsBO
import hostbooks.payroll.shared.constant.AppEnum
import hostbooks.payroll.shared.utility.CommonUtil
import hostbooks.payroll.shared.utility.MapHandler
import hostbooks.payroll.shared.utility.model.SearchResponseTO
import jakarta.transaction.Transactional
import org.springframework.data.domain.Page
import org.springframework.data.domain.PageRequest
import org.springframework.data.domain.Pageable
import org.springframework.stereotype.Service
import java.util.*

@Service
@Transactional
open class BranchServiceImpl(
    private val commonDao: CommonDao,
    private val mapHandler: MapHandler,
) : BranchService {

    override fun addBranch(branchTO: BranchTO): BranchTO {
        val entity = mapHandler.mapObject(branchTO, BranchBO::class.java)
        val persistedEntity = commonDao.persistWithFlush(entity)
        return mapHandler.mapObject(persistedEntity, BranchTO::class.java) ?: branchTO
    }

    override fun updateBranch(branchTO: BranchTO): BranchTO {
        val entity = mapHandler.mapObject(branchTO, BranchBO::class.java)
        val updatedEntity = commonDao.updateWithFlush(entity)
        return mapHandler.mapObject(updatedEntity, BranchTO::class.java) ?: branchTO
    }

    override fun deleteBranch(branchId: List<Long>) {
        for (id in branchId) {
            val branch: BranchBO? = commonDao.findByPrimaryKey(BranchBO::class.java, id)
            if (branch != null) {
                branch.status = AppEnum.Status.INACTIVE.toString()
            }
            commonDao.merge(branch);
        }
    }

    override fun getBranchList(companyDetailSearchRequestTO: CompanyDetailSearchRequestTO): SearchResponseTO<BranchTO> {
        val searchResponseTO = SearchResponseTO<BranchTO>()
        val discriminatorMap: WeakHashMap<String, FilterInfo<*>> = WeakHashMap()
        discriminatorMap["status"] = FilterInfo(AppEnum.FilterType.EQ, AppEnum.Status.ACTIVE.toString())
        if (companyDetailSearchRequestTO.searchFor != null) {
            discriminatorMap["name"] = FilterInfo(AppEnum.FilterType.LIKE, companyDetailSearchRequestTO.searchFor)
        }
        val sorts: List<HbSort> = listOf(HbSort("name", AppEnum.SortDirection.DESC))
        val pageable: Pageable =
            PageRequest.of(companyDetailSearchRequestTO.page - 1, companyDetailSearchRequestTO.limit)
        val data: Page<BranchBO> =
            commonDao.listByFilterPagination(BranchBO::class.java, discriminatorMap, pageable, sorts)

        val branchList = ArrayList<BranchTO>()

        data.content.forEach { branchBO ->
            val branchTO: BranchTO? = mapHandler.mapObject(branchBO, BranchTO::class.java)
            if (CommonUtil.checkNullEmpty(branchTO)) {

                if (CommonUtil.checkNullEmpty(branchTO!!.headId)) {
                    branchTO.headName = branchTO.headId?.let {
                        commonDao.selectSinglePropertyByDiscriminator(
                            EmployeeBO::class.java, it, "id", "name", String::class.java
                        )
                    }
                }

                if(branchTO.id != null) {
                    discriminatorMap.remove("status")
                    discriminatorMap.remove("name")
                    discriminatorMap["departmentId"] = FilterInfo(AppEnum.FilterType.EQ, branchTO.id)
                    branchTO.totalEmployees = commonDao.count(EmployeeCompanyDetailsBO::class.java, discriminatorMap)
                }

                branchList.add(branchTO)
            }
        }

        searchResponseTO.list = branchList
        searchResponseTO.pageCount = data.totalPages.toLong()
        searchResponseTO.totalRowCount = data.totalElements
        return searchResponseTO
    }

    override fun getBranchById(id: Long): BranchTO? {
        val branchBO: BranchBO? = commonDao.findByPrimaryKey(BranchBO::class.java, id)
        return mapHandler.mapObject(branchBO, BranchTO::class.java)
    }
}