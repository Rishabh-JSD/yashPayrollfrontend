package hostbooks.payroll.companyDetail.branch.validator

import hostbooks.payroll.companyDetail.CompanyDetailSearchRequestTO
import hostbooks.payroll.companyDetail.branch.controller.BranchController
import hostbooks.payroll.companyDetail.branch.dto.BranchTO
import org.springframework.validation.Errors
import org.springframework.validation.Validator
import org.springframework.web.bind.annotation.ControllerAdvice

@ControllerAdvice(assignableTypes = [BranchController::class])
class BranchValidator : Validator {

    override fun supports(clazz: Class<*>): Boolean {
        return (clazz == BranchTO::class.java || clazz == CompanyDetailSearchRequestTO::class.java)
    }

    override fun validate(target: Any, errors: Errors) {
        if (target is BranchTO) {
            // validation logic for DepartmentTO
        }
    }
}