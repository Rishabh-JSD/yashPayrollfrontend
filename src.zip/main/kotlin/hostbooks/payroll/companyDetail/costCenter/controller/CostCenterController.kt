package hostbooks.payroll.companyDetail.costCenter.controller

import hostbooks.payroll.companyDetail.CompanyDetailSearchRequestTO
import hostbooks.payroll.shared.utility.ValidationError
import hostbooks.payroll.shared.utility.model.ResponseTO
import hostbooks.payroll.shared.utility.model.SearchResponseTO
import hostbooks.payroll.companyDetail.costCenter.dto.CostCenterTO
import hostbooks.payroll.companyDetail.costCenter.service.CostCenterService
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.validation.Errors
import org.springframework.validation.Validator
import org.springframework.web.bind.WebDataBinder
import org.springframework.web.bind.annotation.*
import javax.validation.Valid

@RestController
@RequestMapping("/cost-center")
class CostCenterController(
    private val costCenterService: CostCenterService,
    private val costCenterValidator: Validator
) {

    @InitBinder
    private fun initBinder(binder: WebDataBinder) {
        binder.validator = this.costCenterValidator
    }

    @RequestMapping(value = ["/add"], method = [RequestMethod.POST])
    fun addCostCenter(@RequestBody costCenterTO: @Valid CostCenterTO, errors: Errors): ResponseEntity<*> {
        if (errors.hasErrors()) {
            val validationError: ValidationError = ValidationError.fromBindingErrors(errors)
            return ResponseEntity<Any>(validationError, HttpStatus.OK)
        }
        val costCenterTO_return: CostCenterTO = costCenterService.addCostCenter(costCenterTO)
        val responseDTO = ResponseTO.responseBuilder(200, "COM01", "/cost-center", "costCenter", costCenterTO_return)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }

    @RequestMapping(value = ["/update"], method = [RequestMethod.POST])
    fun updateCostCenter(@RequestBody costCenterTO: @Valid CostCenterTO, errors: Errors): ResponseEntity<*> {
        if (errors.hasErrors()) {
            val validationError: ValidationError = ValidationError.fromBindingErrors(errors)
            return ResponseEntity<Any>(validationError, HttpStatus.OK)
        }
        val costCenterTO_return: CostCenterTO = costCenterService.updateCostCenter(costCenterTO)
        val responseDTO = ResponseTO.responseBuilder(200, "COM02", "/cost-center", "costCenter", costCenterTO_return)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }

    @RequestMapping(value = ["/list"], method = [RequestMethod.POST])
    fun getCostCenterList(@RequestBody companyDetailSearchRequestTO: CompanyDetailSearchRequestTO): ResponseEntity<*> {
        val searchResponseTO: SearchResponseTO<CostCenterTO> = costCenterService.getCostCenterList(companyDetailSearchRequestTO)
        if (searchResponseTO.list == null || searchResponseTO.list!!.isEmpty()) {
            val responseDTO = ResponseTO.responseBuilder(200, "COM03E", "/cost-center", "costCenter", searchResponseTO)
            return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
        }
        val responseDTO = ResponseTO.responseBuilder(200, "COM11", "/cost-center", "costCenter", searchResponseTO)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }

    @RequestMapping(value = ["/{id}"], method = [RequestMethod.GET])
    fun getCostCenterById(@PathVariable id: Long): ResponseEntity<*> {
        val costCenterTO: CostCenterTO? = costCenterService.getCostCenterById(id)
        if (costCenterTO == null) {
            val responseDTO = ResponseTO.responseBuilder(200, "COM03E", "/cost-center", "costCenter", null)
            return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
        }
        val responseDTO = ResponseTO.responseBuilder(200, "COM11", "/cost-center", "costCenter", costCenterTO)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }

    @RequestMapping(value = ["/delete"], method = [RequestMethod.DELETE])
    fun deleteCostCenter(@RequestParam(name = "costCenterId") costCenterId: List<Long>): ResponseEntity<*> {
        costCenterService.deleteCostCenter(costCenterId)
        val responseDTO = ResponseTO.responseBuilder(200, "COM05", "/cost-center", "costCenter", costCenterId)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }


}