package hostbooks.payroll.companyDetail.costCenter.dto

import hostbooks.payroll.address.dto.AddressTO
import hostbooks.payroll.shared.utility.model.AuditTO
import jakarta.persistence.Column
import java.math.BigDecimal

class CostCenterTO : AuditTO() {

    var id: Long? = null
    var name: String? = null
    var branchId: Long? = null
    var branchName: String? = null
    var sameAsBranchFlag = false
    var addressId: Long? = null
    var headId: Long? = null
    var departmentId: Long? = null
    var departmentName: String? = null
    var headName: String? = null
    var phoneNo: Long? = null
    var email: String? = null
    var shiftTypeId: Long? = null
    var shiftTimingId: Long? = null
    var workingHours: BigDecimal? = null
    var status: String = "ACTIVE"
    var address: AddressTO? = null
    var totalEmployees: Long? = null
}