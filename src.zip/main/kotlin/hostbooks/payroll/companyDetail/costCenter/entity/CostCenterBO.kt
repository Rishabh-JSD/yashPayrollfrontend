package hostbooks.payroll.companyDetail.costCenter.entity

import hostbooks.payroll.address.entity.AddressBO
import hostbooks.payroll.shared.constant.Tables
import hostbooks.payroll.shared.utility.model.Audit
import jakarta.persistence.*
import java.math.BigDecimal

@Entity
@Table(name = Tables.COST_CENTER)
class CostCenterBO : Audit() {

    companion object {
        private const val serialVersionUID = -1567094078264786807L
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", updatable = false)
    var id: Long? = null

    @Column(name = "name")
    var name: String? = null

    @Column(name = "branch_id")
    var branchId: Long? = null

    @Column(name = "same_as_branch_flag")
    var sameAsBranchFlag = false

    @Column(name = "address_id", insertable = false, updatable = false)
    var addressId: Long? = null

    @Column(name = "head_id")
    var headId: Long? = null

    @Column(name = "department_id")
    var departmentId: Long? = null

    @Column(name = "phone_no")
    var phoneNo: Long? = null

    @Column(name = "email")
    var email: String? = null

    @Column(name = "shift_type_id")
    var shiftTypeId: Long? = null

    @Column(name = "shift_timing_id")
    var shiftTimingId: Long? = null

    @Column(name = "working_hours")
    var workingHours: BigDecimal? = null

    @Column(name = "status", nullable = false)
    var status: String? = null

    @OneToOne(cascade = [CascadeType.ALL], orphanRemoval = true)
    @JoinColumn(name = "address_id")
    var address: AddressBO? = null
}