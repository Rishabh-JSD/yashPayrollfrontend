package hostbooks.payroll.companyDetail.costCenter.service

import hostbooks.payroll.companyDetail.CompanyDetailSearchRequestTO
import hostbooks.payroll.shared.utility.model.SearchResponseTO
import hostbooks.payroll.companyDetail.costCenter.dto.CostCenterTO

interface CostCenterService {

    fun addCostCenter(costCenterTO: CostCenterTO): CostCenterTO

    fun updateCostCenter(costCenterTO: CostCenterTO): CostCenterTO

    fun getCostCenterList(companyDetailSearchRequestTO: CompanyDetailSearchRequestTO): SearchResponseTO<CostCenterTO>

    fun deleteCostCenter(costCenterId: List<Long>)

    fun getCostCenterById(id: Long): CostCenterTO?
}