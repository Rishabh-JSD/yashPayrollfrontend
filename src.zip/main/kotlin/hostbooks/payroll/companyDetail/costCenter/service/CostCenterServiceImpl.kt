package hostbooks.payroll.companyDetail.costCenter.service

import hostbooks.payroll.companyDetail.CompanyDetailSearchRequestTO
import hostbooks.payroll.companyDetail.branch.service.BranchService
import hostbooks.payroll.companyDetail.costCenter.dto.CostCenterTO
import hostbooks.payroll.companyDetail.costCenter.entity.CostCenterBO
import hostbooks.payroll.core.commonDao.CommonDao
import hostbooks.payroll.core.dto.FilterInfo
import hostbooks.payroll.core.dto.HbSort
import hostbooks.payroll.employee.entity.EmployeeCompanyDetailsBO
import hostbooks.payroll.shared.constant.AppEnum
import hostbooks.payroll.shared.utility.CommonUtil
import hostbooks.payroll.shared.utility.MapHandler
import hostbooks.payroll.shared.utility.model.SearchResponseTO
import jakarta.transaction.Transactional
import org.springframework.data.domain.Page
import org.springframework.data.domain.PageRequest
import org.springframework.data.domain.Pageable
import org.springframework.stereotype.Service
import java.util.*

@Service
@Transactional
open class CostCenterServiceImpl(
    private val commonDao: CommonDao,
    private val mapHandler: MapHandler,
    private val branchService: BranchService
) : CostCenterService {

    override fun addCostCenter(costCenterTO: CostCenterTO): CostCenterTO {
        val entity = mapHandler.mapObject(costCenterTO, CostCenterBO::class.java)
        val persistedEntity = commonDao.persistWithFlush(entity)
        return mapHandler.mapObject(persistedEntity, CostCenterTO::class.java) ?: costCenterTO
    }

    override fun updateCostCenter(costCenterTO: CostCenterTO): CostCenterTO {
        val entity = mapHandler.mapObject(costCenterTO, CostCenterBO::class.java)
        val updatedEntity = commonDao.updateWithFlush(entity)
        return mapHandler.mapObject(updatedEntity, CostCenterTO::class.java) ?: costCenterTO
    }

    override fun deleteCostCenter(costCenterId: List<Long>) {
        for (id in costCenterId) {
            val costCenter: CostCenterBO? = commonDao.findByPrimaryKey(CostCenterBO::class.java, id)
            if (costCenter != null) {
                costCenter.status = AppEnum.Status.INACTIVE.toString()
            }
            commonDao.merge(costCenter);
        }
    }

    override fun getCostCenterList(companyDetailSearchRequestTO: CompanyDetailSearchRequestTO): SearchResponseTO<CostCenterTO> {
        val searchResponseTO = SearchResponseTO<CostCenterTO>()
        val discriminatorMap: WeakHashMap<String, FilterInfo<*>> = WeakHashMap()
        discriminatorMap["status"] = FilterInfo(AppEnum.FilterType.EQ, AppEnum.Status.ACTIVE.toString())
        if (companyDetailSearchRequestTO.searchFor != null) {
            discriminatorMap["name"] = FilterInfo(AppEnum.FilterType.LIKE, companyDetailSearchRequestTO.searchFor)
        }
        val sorts: List<HbSort> = listOf(HbSort("name", AppEnum.SortDirection.DESC))
        val pageable: Pageable =
            PageRequest.of(companyDetailSearchRequestTO.page - 1, companyDetailSearchRequestTO.limit)
        val data: Page<CostCenterBO> =
            commonDao.listByFilterPagination(CostCenterBO::class.java, discriminatorMap, pageable, sorts)

        val costCenterList = ArrayList<CostCenterTO>()

        data.content.forEach { costCenterBO ->
            val costCenterTO: CostCenterTO? = mapHandler.mapObject(costCenterBO, CostCenterTO::class.java)
            if (CommonUtil.checkNullEmpty(costCenterTO)) {
//                if (CommonUtil.checkNullEmpty(costCenterTO!!.address)) {
//                    costCenterTO.address!!.cityName =
//                        costCenterTO.address!!.cityId?.let {
//                            commonDao.findByPrimaryKey(
//                                CitiesBO::class.java, it
//                            )?.name
//                        }
//
//                    costCenterTO.address!!.stateName =
//                        costCenterTO.address!!.stateId?.let {
//                            commonDao.findByPrimaryKey(
//                                StatesBO::class.java, it
//                            )?.name
//                        }
//
//                    costCenterTO.address!!.countryName =
//                        costCenterTO.address!!.countryId?.let {
//                            commonDao.findByPrimaryKey(
//                                CountriesBO::class.java, it
//                            )?.name
//                        }
//                }

                if (CommonUtil.checkNullEmpty(costCenterTO!!.branchId)) {
                    costCenterTO.branchName = branchService.getBranchById(costCenterTO.branchId!!.toLong())?.name
                }

                if(costCenterTO.id != null) {
                    discriminatorMap.remove("status")
                    discriminatorMap.remove("name")
                    discriminatorMap["departmentId"] = FilterInfo(AppEnum.FilterType.EQ, costCenterTO.id)
                    costCenterTO.totalEmployees = commonDao.count(EmployeeCompanyDetailsBO::class.java, discriminatorMap)
                }
                costCenterList.add(costCenterTO)
            }
        }

        searchResponseTO.list = costCenterList
        searchResponseTO.pageCount = data.totalPages.toLong()
        searchResponseTO.totalRowCount = data.totalElements
        return searchResponseTO
    }

    override fun getCostCenterById(id: Long): CostCenterTO? {
        val costCenterBO: CostCenterBO? = commonDao.findByPrimaryKey(CostCenterBO::class.java, id)
        return mapHandler.mapObject(costCenterBO, CostCenterTO::class.java)
    }
}