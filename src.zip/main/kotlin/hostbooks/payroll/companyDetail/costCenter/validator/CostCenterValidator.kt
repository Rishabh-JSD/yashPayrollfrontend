package hostbooks.payroll.companyDetail.costCenter.validator

import hostbooks.payroll.companyDetail.CompanyDetailSearchRequestTO
import hostbooks.payroll.companyDetail.costCenter.controller.CostCenterController
import hostbooks.payroll.companyDetail.costCenter.dto.CostCenterTO
import org.springframework.validation.Errors
import org.springframework.validation.Validator
import org.springframework.web.bind.annotation.ControllerAdvice

@ControllerAdvice(assignableTypes = [CostCenterController::class])
class CostCenterValidator : Validator {

    override fun supports(clazz: Class<*>): Boolean {
        return (clazz == CostCenterTO::class.java || clazz == CompanyDetailSearchRequestTO::class.java)
    }

    override fun validate(target: Any, errors: Errors) {
        if (target is CostCenterTO) {
            // validation logic for DepartmentTO
        }
    }
}