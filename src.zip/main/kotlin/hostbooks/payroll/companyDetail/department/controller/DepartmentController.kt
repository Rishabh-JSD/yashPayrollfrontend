package hostbooks.payroll.companyDetail.department.controller

import hostbooks.payroll.companyDetail.CompanyDetailSearchRequestTO
import hostbooks.payroll.shared.utility.ValidationError
import hostbooks.payroll.shared.utility.model.ResponseTO
import hostbooks.payroll.shared.utility.model.SearchResponseTO
import hostbooks.payroll.companyDetail.department.dto.DepartmentTO
import hostbooks.payroll.companyDetail.department.service.DepartmentService
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.validation.Errors
import org.springframework.validation.Validator
import org.springframework.web.bind.WebDataBinder
import org.springframework.web.bind.annotation.*
import javax.validation.Valid

@RestController
@RequestMapping("/department")
class DepartmentController(
    private val departmentService: DepartmentService,
    private val departmentValidator: Validator
) {

    @InitBinder
    private fun initBinder(binder: WebDataBinder) {
        binder.validator = this.departmentValidator
    }

    @RequestMapping(value = ["/add"], method = [RequestMethod.POST])
    fun addDepartment(@Valid @RequestBody departmentTO: DepartmentTO, errors: Errors): ResponseEntity<*> {
        if (errors.hasErrors()) {
            val validationError: ValidationError = ValidationError.fromBindingErrors(errors)
            return ResponseEntity<Any>(validationError, HttpStatus.OK)
        }
        val departmentTO_return: DepartmentTO = departmentService.addDepartment(departmentTO)
        val responseDTO = ResponseTO.responseBuilder(200, "COM01", "/department", "department", departmentTO_return)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }

    @RequestMapping(value = ["/update"], method = [RequestMethod.POST])
    fun updateDepartment(@Valid @RequestBody departmentTO: DepartmentTO, errors: Errors): ResponseEntity<*> {
        if (errors.hasErrors()) {
            val validationError: ValidationError = ValidationError.fromBindingErrors(errors)
            return ResponseEntity<Any>(validationError, HttpStatus.OK)
        }
        val departmentTO_return: DepartmentTO = departmentService.updateDepartment(departmentTO)
        val responseDTO = ResponseTO.responseBuilder(200, "COM02", "/department", "department", departmentTO_return)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }

    @RequestMapping(value = ["/list"], method = [RequestMethod.POST])
    fun getDepartmentList(@RequestBody companyDetailSearchRequestTO: CompanyDetailSearchRequestTO): ResponseEntity<*> {
        val responseTO: SearchResponseTO<DepartmentTO> = departmentService.getDepartmentList(companyDetailSearchRequestTO)
        if (responseTO.list == null || responseTO.list!!.isEmpty()) {
            val responseDTO = ResponseTO.responseBuilder(200, "COM03E", "/department", "department", responseTO)
            return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
        }
        val responseDTO = ResponseTO.responseBuilder(200, "COM11", "/department", "department", responseTO)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }

    @RequestMapping(value = ["/{id}"], method = [RequestMethod.GET])
    fun getDepartmentById(@PathVariable id: Long): ResponseEntity<*> {
        val departmentTO: DepartmentTO? = departmentService.getDepartmentById(id)
        if (departmentTO == null) {
            val responseDTO = ResponseTO.responseBuilder(200, "COM03E", "/department", "department", null)
            return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
        }
        val responseDTO = ResponseTO.responseBuilder(200, "COM11", "/department", "department", departmentTO)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }

    @RequestMapping(value = ["/delete"], method = [RequestMethod.DELETE])
    fun deleteDepartment(@RequestParam(name = "departmentId") departmentId: List<Long>): ResponseEntity<*> {
        departmentService.deleteDepartment(departmentId)
        val responseDTO = ResponseTO.responseBuilder(200, "COM05", "/department", "department", departmentId)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }
}