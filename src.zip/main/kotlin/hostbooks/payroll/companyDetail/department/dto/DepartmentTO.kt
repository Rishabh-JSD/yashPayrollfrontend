package hostbooks.payroll.companyDetail.department.dto

import hostbooks.payroll.shared.utility.model.AuditTO
import java.math.BigDecimal

class DepartmentTO : AuditTO() {

    var id: Long? = null
    var departmentFlag = false
    var departmentId: Long? = null
    var departmentName: String?= null
    var name: String? = null
    var branchId: Long? = null
    var branchName: String? = null
    var costCenterId: Long? = null
    var costCenterName: String? = null
    var headId: Long? = null
    var headName: String? = null
    var phoneNo: Long? = null
    var email: String? = null
    var shiftTypeId: Long? = null
    var shiftTimingId: Long? = null
    var workingHours: BigDecimal? = null
    var description: String? = null
    var status: String = "ACTIVE"
    var totalEmployees: Long? = null

}