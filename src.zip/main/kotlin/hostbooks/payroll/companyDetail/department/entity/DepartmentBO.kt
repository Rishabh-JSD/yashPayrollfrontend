package hostbooks.payroll.companyDetail.department.entity

import hostbooks.payroll.shared.constant.Tables
import hostbooks.payroll.shared.utility.model.Audit
import jakarta.persistence.*
import java.math.BigDecimal

@Entity
@Table(name = Tables.DEPARTMENT)
class DepartmentBO : Audit() {

    companion object {
        private const val serialVersionUID = -3015801901350337816L
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", updatable = false)
    var id: Long? = null

    @Column(name = "department_flag")
    var departmentFlag = false

    @Column(name = "department_id")
    var departmentId: Long? = null

    @Column(name = "name")
    var name: String? = null

    @Column(name = "branch_id")
    var branchId: Long? = null

    @Column(name = "cost_center_id")
    var costCenterId: Long? = null

    @Column(name = "head_id")
    var headId: Long? = null

    @Column(name = "phone_no")
    var phoneNo: Long? = null

    @Column(name = "email")
    var email: String? = null

    @Column(name = "shift_type_id")
    var shiftTypeId: Long? = null

    @Column(name = "shift_timing_id")
    var shiftTimingId: Long? = null

    @Column(name = "working_hours")
    var workingHours: BigDecimal? = null

    @Column(name = "description")
    var description: String? = null

    @Column(name = "status", nullable = false)
    var status: String? = null
}