package hostbooks.payroll.companyDetail.department.service

import hostbooks.payroll.companyDetail.CompanyDetailSearchRequestTO
import hostbooks.payroll.shared.utility.model.SearchResponseTO
import hostbooks.payroll.companyDetail.department.dto.DepartmentTO

interface DepartmentService {

    fun addDepartment(departmentTO: DepartmentTO): DepartmentTO

    fun updateDepartment(departmentTO: DepartmentTO): DepartmentTO

    fun getDepartmentList(companyDetailSearchRequestTO: CompanyDetailSearchRequestTO): SearchResponseTO<DepartmentTO>

    fun deleteDepartment(departmentId: List<Long>)

    fun getDepartmentById(id: Long): DepartmentTO?

}