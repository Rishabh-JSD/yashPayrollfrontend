package hostbooks.payroll.companyDetail.department.service

import hostbooks.payroll.companyDetail.CompanyDetailSearchRequestTO
import hostbooks.payroll.companyDetail.branch.entity.BranchBO
import hostbooks.payroll.companyDetail.costCenter.entity.CostCenterBO
import hostbooks.payroll.shared.constant.AppEnum
import hostbooks.payroll.shared.utility.MapHandler
import hostbooks.payroll.shared.utility.model.SearchResponseTO
import hostbooks.payroll.companyDetail.department.dto.DepartmentTO
import hostbooks.payroll.companyDetail.department.entity.DepartmentBO
import hostbooks.payroll.core.commonDao.CommonDao
import hostbooks.payroll.core.dto.FilterInfo
import hostbooks.payroll.core.dto.HbSort
import hostbooks.payroll.employee.entity.EmployeeBO
import hostbooks.payroll.employee.entity.EmployeeCompanyDetailsBO
import jakarta.transaction.Transactional
import org.springframework.data.domain.Page
import org.springframework.data.domain.PageRequest
import org.springframework.data.domain.Pageable
import org.springframework.stereotype.Service
import java.util.*

@Service
@Transactional
open class DepartmentServiceImpl(
    private val commonDao: CommonDao,
    private val mapHandler: MapHandler
) : DepartmentService {

    override fun addDepartment(departmentTO: DepartmentTO): DepartmentTO {
        val entity = mapHandler.mapObject(departmentTO, DepartmentBO::class.java)
        val persistedEntity = commonDao.persistWithFlush(entity)
        return mapHandler.mapObject(persistedEntity, DepartmentTO::class.java) ?: departmentTO
    }

    override fun updateDepartment(departmentTO: DepartmentTO): DepartmentTO {
        val entity = mapHandler.mapObject(departmentTO, DepartmentBO::class.java)
        val updatedEntity = commonDao.updateWithFlush(entity)
        return mapHandler.mapObject(updatedEntity, DepartmentTO::class.java) ?: departmentTO
    }

    override fun deleteDepartment(departmentId: List<Long>) {
        for (id in departmentId) {
            val department: DepartmentBO? = commonDao.findByPrimaryKey(DepartmentBO::class.java, id)
            if (department != null) {
                department.status = AppEnum.Status.INACTIVE.toString()
            }
            commonDao.merge(department);
        }
    }

    override fun getDepartmentList(companyDetailSearchRequestTO: CompanyDetailSearchRequestTO): SearchResponseTO<DepartmentTO> {
        val searchResponseTO = SearchResponseTO<DepartmentTO>()
        val discriminatorMap: WeakHashMap<String, FilterInfo<*>> = WeakHashMap()
        discriminatorMap["status"] = FilterInfo(AppEnum.FilterType.EQ, AppEnum.Status.ACTIVE.toString())
        if(companyDetailSearchRequestTO.departmentFlag != null){
            if(companyDetailSearchRequestTO.departmentFlag) {
                discriminatorMap["departmentFlag"] = FilterInfo(AppEnum.FilterType.EQ, true)
            } else {
                discriminatorMap["departmentFlag"] = FilterInfo(AppEnum.FilterType.EQ, false)
            }
        }

        if (companyDetailSearchRequestTO.searchFor != null) {
            discriminatorMap["name"] = FilterInfo(AppEnum.FilterType.LIKE, companyDetailSearchRequestTO.searchFor)
        }

        val sorts: List<HbSort> = listOf(HbSort("name", AppEnum.SortDirection.DESC))
        val pageable: Pageable =
            PageRequest.of(companyDetailSearchRequestTO.page - 1, companyDetailSearchRequestTO.limit)
        val data: Page<DepartmentBO> =
            commonDao.listByFilterPagination(DepartmentBO::class.java, discriminatorMap, pageable, sorts)

        val departmentList = ArrayList<DepartmentTO>()

        data.content.forEach { departmentBO ->
            val departmentTO: DepartmentTO? = mapHandler.mapObject(departmentBO, DepartmentTO::class.java)
            if (departmentTO != null) {
                if (departmentTO.branchId != null) {
                    departmentTO.branchName = departmentTO.branchId?.let {
                        commonDao.selectSinglePropertyByDiscriminator(
                            BranchBO::class.java, it, "id", "name", String::class.java
                        )
                    }
                }

                if (departmentTO.costCenterId != null) {
                    departmentTO.costCenterName = departmentTO.costCenterId?.let {
                        commonDao.selectSinglePropertyByDiscriminator(
                            CostCenterBO::class.java, it, "id", "name", String::class.java
                        )
                    }
                }

                if (departmentTO.headId != null) {
                    departmentTO.headName = departmentTO.headId?.let {
                        commonDao.selectSinglePropertyByDiscriminator(
                            EmployeeBO::class.java, it, "id", "name", String::class.java
                        )
                    }
                }

                if(departmentTO.id != null) {
                    discriminatorMap.remove("status")
                    discriminatorMap.remove("departmentFlag")
                    discriminatorMap.remove("name")
                    discriminatorMap["departmentId"] = FilterInfo(AppEnum.FilterType.EQ, departmentTO.id)
                    departmentTO.totalEmployees = commonDao.count(EmployeeCompanyDetailsBO::class.java, discriminatorMap)
                }

                if(departmentTO.departmentId != null) {
                    departmentTO.departmentName = departmentTO.departmentId?.let {
                        commonDao.selectSinglePropertyByDiscriminator(
                            DepartmentBO::class.java, it, "id", "name", String::class.java
                        )
                    }
                }
                    departmentList.add(departmentTO)
            }
        }

        searchResponseTO.list = departmentList
        searchResponseTO.pageCount = data.totalPages.toLong()
        searchResponseTO.totalRowCount = data.totalElements
        return searchResponseTO
    }

    override fun getDepartmentById(id: Long): DepartmentTO? {
        val departmentBO: DepartmentBO? = commonDao.findByPrimaryKey(DepartmentBO::class.java, id)
        return mapHandler.mapObject(departmentBO, DepartmentTO::class.java)
    }
}