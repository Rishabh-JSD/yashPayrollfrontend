package hostbooks.payroll.companyDetail.department.validator

import hostbooks.payroll.companyDetail.CompanyDetailSearchRequestTO
import hostbooks.payroll.companyDetail.department.controller.DepartmentController
import hostbooks.payroll.companyDetail.department.dto.DepartmentTO
import org.springframework.validation.Errors
import org.springframework.validation.Validator
import org.springframework.web.bind.annotation.ControllerAdvice

@ControllerAdvice(assignableTypes = [DepartmentController::class])
class DepartmentValidator : Validator {
    override fun supports(clazz: Class<*>): Boolean {
        return (clazz == DepartmentTO::class.java || clazz == CompanyDetailSearchRequestTO::class.java)
    }

    override fun validate(target: Any, errors: Errors) {
        if (target is DepartmentTO) {
            // validation logic for DepartmentTO
        }
    }
}