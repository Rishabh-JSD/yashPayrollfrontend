package hostbooks.payroll.companyDetail.location.controller

import hostbooks.payroll.companyDetail.CompanyDetailSearchRequestTO
import hostbooks.payroll.companyDetail.location.dto.LocationTO
import hostbooks.payroll.companyDetail.location.service.LocationService
import hostbooks.payroll.shared.utility.ValidationError
import hostbooks.payroll.shared.utility.model.ResponseTO
import hostbooks.payroll.shared.utility.model.SearchResponseTO
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.validation.Errors
import org.springframework.validation.Validator
import org.springframework.web.bind.WebDataBinder
import org.springframework.web.bind.annotation.*
import javax.validation.Valid

@RestController
@RequestMapping("/location")
class LocationController(
    private val locationService: LocationService,
    private val locationValidator: Validator
) {

    @InitBinder
    private fun initBinder(binder: WebDataBinder) {
        binder.validator = this.locationValidator
    }

    @RequestMapping(value = ["/add"], method = [RequestMethod.POST])
    fun addLocation(@Valid @RequestBody locationTO: LocationTO, errors: Errors): ResponseEntity<*> {
        if (errors.hasErrors()) {
            val validationError: ValidationError = ValidationError.fromBindingErrors(errors)
            return ResponseEntity<Any>(validationError, HttpStatus.OK)
        }
        val locationTO_return: LocationTO = locationService.addLocation(locationTO)
        val responseDTO = ResponseTO.responseBuilder(200, "COM01", "/location", "location", locationTO_return)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }

    @RequestMapping(value = ["/update"], method = [RequestMethod.POST])
    fun updateLocation(@Valid @RequestBody locationTO: LocationTO, errors: Errors): ResponseEntity<*> {
        if (errors.hasErrors()) {
            val validationError: ValidationError = ValidationError.fromBindingErrors(errors)
            return ResponseEntity<Any>(validationError, HttpStatus.OK)
        }
        val locationTO_return: LocationTO = locationService.updateLocation(locationTO)
        val responseDTO = ResponseTO.responseBuilder(200, "COM02", "/location", "location", locationTO_return)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }

    @RequestMapping(value = ["/list"], method = [RequestMethod.POST])
    fun getLocationList(@RequestBody companyDetailSearchRequestTO: CompanyDetailSearchRequestTO): ResponseEntity<*> {
        val responseTO: SearchResponseTO<LocationTO> = locationService.getLocationList(companyDetailSearchRequestTO)
        if (responseTO.list == null || responseTO.list!!.isEmpty()) {
            val responseDTO = ResponseTO.responseBuilder(200, "COM03E", "/location", "location", responseTO)
            return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
        }
        val responseDTO = ResponseTO.responseBuilder(200, "COM11", "/location", "location", responseTO)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }

    @RequestMapping(value = ["/{id}"], method = [RequestMethod.GET])
    fun getLocationById(@PathVariable id: Long): ResponseEntity<*> {
        val locationTO: LocationTO? = locationService.getLocationById(id)
        if (locationTO == null) {
            val responseDTO = ResponseTO.responseBuilder(200, "COM03E", "/location", "location", null)
            return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
        }
        val responseDTO = ResponseTO.responseBuilder(200, "COM11", "/location", "location", locationTO)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }

    @RequestMapping(value = ["/delete"], method = [RequestMethod.DELETE])
    fun deleteLocation(@RequestParam(name = "locationId") locationId: List<Long>): ResponseEntity<*> {
        locationService.deleteLocation(locationId)
        val responseDTO = ResponseTO.responseBuilder(200, "COM05", "/location", "location", locationId)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }
}