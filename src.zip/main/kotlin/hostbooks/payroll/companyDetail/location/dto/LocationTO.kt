package hostbooks.payroll.companyDetail.location.dto

import hostbooks.payroll.address.dto.AddressTO
import hostbooks.payroll.shared.utility.model.AuditTO

class LocationTO : AuditTO() {
    var id: Long? = null
    var name: String? = null
    var costCenterId: Long? = null
    var costCenterName: String? = null
    var addressId: Long? = null
    var headId: Long? = null
    var headName: String? = null
    var phoneNo: Long? = null
    var email: String? = null
    var shiftTypeId: Long? = null
    var shiftTimingId: Long? = null
    var deleteFlag = false
    var status: String = "ACTIVE"
    var address: AddressTO? = null
}