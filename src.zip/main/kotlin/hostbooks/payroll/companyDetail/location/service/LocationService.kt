package hostbooks.payroll.companyDetail.location.service

import hostbooks.payroll.companyDetail.CompanyDetailSearchRequestTO
import hostbooks.payroll.companyDetail.location.dto.LocationTO
import hostbooks.payroll.shared.utility.model.SearchResponseTO

interface LocationService {
    fun addLocation(locationTO: LocationTO): LocationTO

    fun updateLocation(locationTO: LocationTO): LocationTO

    fun getLocationList(companyDetailSearchRequestTO: CompanyDetailSearchRequestTO): SearchResponseTO<LocationTO>

    fun deleteLocation(locationId: List<Long>)

    fun getLocationById(id: Long): LocationTO?
}