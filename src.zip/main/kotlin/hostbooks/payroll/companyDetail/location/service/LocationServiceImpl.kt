package hostbooks.payroll.companyDetail.location.service

import hostbooks.payroll.companyDetail.CompanyDetailSearchRequestTO
import hostbooks.payroll.companyDetail.costCenter.entity.CostCenterBO
import hostbooks.payroll.companyDetail.location.dto.LocationTO
import hostbooks.payroll.companyDetail.location.entity.LocationBO
import hostbooks.payroll.core.commonDao.CommonDao
import hostbooks.payroll.core.dto.FilterInfo
import hostbooks.payroll.core.dto.HbSort
import hostbooks.payroll.employee.entity.EmployeeBO
import hostbooks.payroll.shared.constant.AppEnum
import hostbooks.payroll.shared.utility.MapHandler
import hostbooks.payroll.shared.utility.model.SearchResponseTO
import jakarta.transaction.Transactional
import org.springframework.data.domain.Page
import org.springframework.data.domain.PageRequest
import org.springframework.data.domain.Pageable
import org.springframework.stereotype.Service
import java.util.*

@Service
@Transactional
open class LocationServiceImpl(
    private val commonDao: CommonDao,
    private val mapHandler: MapHandler
) : LocationService {
    override fun addLocation(locationTO: LocationTO): LocationTO {
        val entity = mapHandler.mapObject(locationTO, LocationBO::class.java)
        val persistedEntity = commonDao.persistWithFlush(entity)
        return mapHandler.mapObject(persistedEntity, LocationTO::class.java) ?: locationTO
    }

    override fun updateLocation(locationTO: LocationTO): LocationTO {
        val entity = mapHandler.mapObject(locationTO, LocationBO::class.java)
        val updatedEntity = commonDao.updateWithFlush(entity)
        return mapHandler.mapObject(updatedEntity, LocationTO::class.java) ?: locationTO
    }

    override fun deleteLocation(locationId: List<Long>) {
        for (id in locationId) {
            val location: LocationBO? = commonDao.findByPrimaryKey(LocationBO::class.java, id)
            if (location != null) {
                location.status = AppEnum.Status.INACTIVE.toString()
            }
            commonDao.merge(location);
        }
    }

    override fun getLocationList(companyDetailSearchRequestTO: CompanyDetailSearchRequestTO): SearchResponseTO<LocationTO> {
        val searchResponseTO = SearchResponseTO<LocationTO>()
        val discriminatorMap: WeakHashMap<String, FilterInfo<*>> = WeakHashMap()
        discriminatorMap["status"] = FilterInfo(AppEnum.FilterType.EQ, AppEnum.Status.ACTIVE.toString())
        if (companyDetailSearchRequestTO.searchFor != null) {
            discriminatorMap["name"] = FilterInfo(AppEnum.FilterType.LIKE, companyDetailSearchRequestTO.searchFor)
        }

        val sorts: List<HbSort> = listOf(HbSort("name", AppEnum.SortDirection.DESC))
        val pageable: Pageable =
            PageRequest.of(companyDetailSearchRequestTO.page - 1, companyDetailSearchRequestTO.limit)
        val data: Page<LocationBO> =
            commonDao.listByFilterPagination(LocationBO::class.java, discriminatorMap, pageable, sorts)

        val locationList = ArrayList<LocationTO>()

        data.content.forEach { locationBO ->
            val locationTO: LocationTO? = mapHandler.mapObject(locationBO, LocationTO::class.java)
            if (locationTO != null) {
                if (locationTO.costCenterId != null) {
                    locationTO.costCenterName = locationTO.costCenterId?.let {
                        commonDao.selectSinglePropertyByDiscriminator(
                            CostCenterBO::class.java, it, "id", "name", String::class.java
                        )
                    }
                }

                if (locationTO.headId != null) {
                    locationTO.headName = locationTO.headId?.let {
                        commonDao.selectSinglePropertyByDiscriminator(
                            EmployeeBO::class.java, it, "id", "name", String::class.java
                        )
                    }
                }
                locationList.add(locationTO)
            }
        }

        searchResponseTO.list = locationList
        searchResponseTO.pageCount = data.totalPages.toLong()
        searchResponseTO.totalRowCount = data.totalElements
        return searchResponseTO
    }

    override fun getLocationById(id: Long): LocationTO? {
        val locationBO: LocationBO? = commonDao.findByPrimaryKey(LocationBO::class.java, id)
        return mapHandler.mapObject(locationBO, LocationTO::class.java)
    }
}