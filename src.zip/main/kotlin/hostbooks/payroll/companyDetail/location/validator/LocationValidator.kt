package hostbooks.payroll.companyDetail.location.validator

import hostbooks.payroll.companyDetail.CompanyDetailSearchRequestTO
import hostbooks.payroll.companyDetail.location.controller.LocationController
import hostbooks.payroll.companyDetail.location.dto.LocationTO
import org.springframework.validation.Errors
import org.springframework.validation.Validator
import org.springframework.web.bind.annotation.ControllerAdvice

@ControllerAdvice(assignableTypes = [LocationController::class])
class LocationValidator: Validator {
    override fun supports(clazz: Class<*>): Boolean {
        return (clazz == LocationTO::class.java || clazz == CompanyDetailSearchRequestTO::class.java)
    }

    override fun validate(target: Any, errors: Errors) {
        if (target is LocationTO) {
            // validation logic for LocationTO
        }
    }
}