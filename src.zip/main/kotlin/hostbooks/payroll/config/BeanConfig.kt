package hostbooks.payroll.config

import graphql.scalars.ExtendedScalars
import graphql.schema.idl.RuntimeWiring
import hostbooks.payroll.config.redis.entity.RedisBlacklistedJwt
import org.apache.commons.logging.LogFactory
import org.modelmapper.ModelMapper
import org.modelmapper.convention.MatchingStrategies
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration
import org.springframework.data.redis.connection.RedisConnectionFactory
import org.springframework.data.redis.core.RedisTemplate
import org.springframework.graphql.execution.RuntimeWiringConfigurer
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder
import org.springframework.security.crypto.password.PasswordEncoder


@Configuration
open class BeanConfig() {

    private val log = LogFactory.getLog(this.javaClass)

    @Bean
    open fun modelMapper(): ModelMapper? {
        val modelMapper = ModelMapper()
        modelMapper.configuration.matchingStrategy = MatchingStrategies.STRICT
        return modelMapper
    }

    @Bean
    open fun passwordEncoder(): PasswordEncoder? {
        return BCryptPasswordEncoder()
    }

    @Bean
    open fun runtimeWiringConfigurer(): RuntimeWiringConfigurer {
        return RuntimeWiringConfigurer { wiringBuilder: RuntimeWiring.Builder ->
            wiringBuilder
                .scalar(ExtendedScalars.Json)
                .scalar(ExtendedScalars.GraphQLLong)
                .scalar(ExtendedScalars.Date)
                .scalar(ExtendedScalars.DateTime)
        }
    }

    @Bean
    open fun redisTemplate(connectionFactory: RedisConnectionFactory?): RedisTemplate<String, RedisBlacklistedJwt> {
        val template = RedisTemplate<String, RedisBlacklistedJwt>()
        template.connectionFactory = connectionFactory
        // Add some specific configuration here. Key serializers, etc.
        return template
    }
}