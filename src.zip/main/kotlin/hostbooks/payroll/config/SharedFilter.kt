package hostbooks.payroll.config

import hostbooks.payroll.config.mutlitenancy.TenantDBContext
import hostbooks.payroll.core.constant.CoreConst
import hostbooks.payroll.core.constant.CoreEnum
import hostbooks.payroll.core.constant.VarLocalThread
import jakarta.servlet.FilterChain
import jakarta.servlet.http.HttpServletRequest
import jakarta.servlet.http.HttpServletResponse
import org.springframework.core.Ordered
import org.springframework.core.annotation.Order
import org.springframework.stereotype.Component
import org.springframework.web.cors.*
import org.springframework.web.filter.OncePerRequestFilter

@Order(Ordered.HIGHEST_PRECEDENCE)
@Component
class SharedFilter : OncePerRequestFilter() {
    override fun doFilterInternal(
        request: HttpServletRequest,
        response: HttpServletResponse,
        filterChain: FilterChain
    ) {
        val source = UrlBasedCorsConfigurationSource()
        val configuration = CorsConfiguration()
        configuration.allowedOrigins = listOf(request.getHeader("Origin"))
        configuration.allowedMethods = CoreConst.HTTP_ALLOWED_METHODS
        configuration.allowedHeaders = CoreConst.HTTP_ALLOWED_HEADERS
        configuration.allowCredentials = true
        source.registerCorsConfiguration("/**", configuration)
        val corsConfiguration = source.getCorsConfiguration(request)
        this.setTenantDataPoolConfig(request)
        val corsProcessor: CorsProcessor = DefaultCorsProcessor()
        val isValid = corsProcessor.processRequest(corsConfiguration, request, response)
        if (isValid && !CorsUtils.isPreFlightRequest(request)) {
            filterChain.doFilter(request, response)
        }
    }

    private fun setTenantDataPoolConfig(request: HttpServletRequest) {
        val tenant = request.getHeader(CoreConst.TENANT_CODE)
        if (!tenant.isNullOrBlank() && TenantDBContext.dbMap.containsKey(tenant)) {
            if (setOf(CoreConst.HttpMethod.GET, CoreConst.HttpMethod.GET_VIA_POST).contains(request.method)) {
                VarLocalThread.setRequestType(CoreEnum.RequestType.READ.name)
            } else {
                VarLocalThread.setRequestType(CoreEnum.RequestType.WRITE.name)
            }
        }
    }
}
