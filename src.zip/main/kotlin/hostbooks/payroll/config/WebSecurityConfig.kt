package hostbooks.payroll.config

import hostbooks.payroll.config.jwt.JwtAuthenticationFilter
import hostbooks.payroll.config.jwt.JwtUtils
import hostbooks.payroll.core.constant.CoreConst
import hostbooks.payroll.core.user.service.UserService
import lombok.RequiredArgsConstructor
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration
import org.springframework.security.authentication.AuthenticationManager
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder
import org.springframework.security.config.annotation.web.builders.HttpSecurity
import org.springframework.security.config.annotation.web.builders.WebSecurity
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity
import org.springframework.security.config.annotation.web.configuration.WebSecurityCustomizer
import org.springframework.security.config.http.SessionCreationPolicy
import org.springframework.security.core.userdetails.UserDetailsService
import org.springframework.security.web.SecurityFilterChain
import org.springframework.web.servlet.HandlerExceptionResolver


@Configuration
@EnableWebSecurity
@RequiredArgsConstructor
open class WebSecurityConfig(
    private val jwtUtils: JwtUtils,
    private val userDetailsService: UserDetailsService,
    private val handlerExceptionResolver: HandlerExceptionResolver,
    private val userService: UserService
) {
    private fun authManager(http: HttpSecurity): AuthenticationManager {
        val authenticationManagerBuilder = http.getSharedObject(
            AuthenticationManagerBuilder::class.java
        )
        authenticationManagerBuilder.userDetailsService(userDetailsService)
        return authenticationManagerBuilder.build()
    }

    @Bean
    open fun filterChain(http: HttpSecurity): SecurityFilterChain {
        val authenticationManager = this.authManager(http)
        // * Authentication
        http.authenticationManager(authenticationManager)
            .addFilter(JwtAuthenticationFilter(this.jwtUtils, userDetailsService, handlerExceptionResolver, authenticationManager, userService))

        // * Other configuration
        http.csrf { it.disable() }
            .cors { it.disable() }
            .sessionManagement { it.sessionCreationPolicy(SessionCreationPolicy.STATELESS) }
            .headers { header ->
                header.frameOptions { it.disable() }
                header.xssProtection { it.disable() }
            }

        return http.build()
    }

    @Bean
    open fun webSecurityCustomizer(): WebSecurityCustomizer {
        // * Define public and private routes
        return WebSecurityCustomizer { web: WebSecurity ->
            web.ignoring()
                .requestMatchers(*CoreConst.PermittedRequestPath.PUBLIC_PATHS.toTypedArray())
                .requestMatchers(*CoreConst.PermittedRequestPath.GRAPHQL_PATHS.toTypedArray())
        }
    }
}
