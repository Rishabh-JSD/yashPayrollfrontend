package hostbooks.payroll.config.jwt

import hostbooks.payroll.shared.utility.UserSessionContext
import hostbooks.payroll.config.mutlitenancy.TenantContext
import hostbooks.payroll.core.constant.CoreConst
import hostbooks.payroll.core.exception.InvalidRequestHeaderException
import hostbooks.payroll.core.user.service.UserService
import io.jsonwebtoken.ExpiredJwtException
import io.jsonwebtoken.MalformedJwtException
import io.jsonwebtoken.UnsupportedJwtException
import io.jsonwebtoken.security.SignatureException
import jakarta.servlet.FilterChain
import jakarta.servlet.ServletException
import jakarta.servlet.http.HttpServletRequest
import jakarta.servlet.http.HttpServletResponse
import org.apache.commons.logging.LogFactory
import org.springframework.http.HttpHeaders.AUTHORIZATION
import org.springframework.security.authentication.AuthenticationManager
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken
import org.springframework.security.core.context.SecurityContextHolder
import org.springframework.security.core.userdetails.UserDetails
import org.springframework.security.core.userdetails.UserDetailsService
import org.springframework.security.core.userdetails.UsernameNotFoundException
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter
import org.springframework.web.servlet.HandlerExceptionResolver
import java.io.IOException

class JwtAuthenticationFilter(
    private val jwtUtils: JwtUtils,
    private val userDetailsService: UserDetailsService,
    private val handlerExceptionResolver: HandlerExceptionResolver,
    authManager: AuthenticationManager,
    private val userService: UserService
) : BasicAuthenticationFilter(authManager) {

    private val log = LogFactory.getLog(this.javaClass)

    @Throws(IOException::class, ServletException::class)
    override fun doFilterInternal(
        request: HttpServletRequest, response: HttpServletResponse, chain: FilterChain
    ) {
        val token = this.handleAuthorizationHeader(request, response)
        this.handleTenantHeader(request)
        if (!token.isNullOrBlank()) {
            this.handleUsernameByToken(token, request, response, chain)
        }
    }

    private fun handleAuthorizationHeader(request: HttpServletRequest, response: HttpServletResponse): String? {
        val header: String? = request.getHeader(AUTHORIZATION)
        return if (header != null && header.startsWith("Bearer ")) {
            header.substring(7)
        } else {
            try {
                log.info("Authorization Header must starts with Bearer String.")
                throw InvalidRequestHeaderException("Authorization token not found")
            } catch (ex: InvalidRequestHeaderException) {
                handlerExceptionResolver.resolveException(request, response, null, ex)
            }
            null
        }
    }

    private fun handleTenantHeader(request: HttpServletRequest) {
        val tenantUuid: String? = request.getHeader(CoreConst.TENANT_CODE)
        if (!tenantUuid.isNullOrBlank()) {
            // * Set current tenant
            TenantContext.setCurrentTenant(tenantUuid)
        } else {
            log.info("Tenant code header not found.")
        }
    }

    private fun handleUsernameByToken(
        token: String,
        request: HttpServletRequest,
        response: HttpServletResponse,
        chain: FilterChain
    ) {
        try {
            val username = jwtUtils.getUsername(token)
            val user: UserDetails? = userDetailsService.loadUserByUsername(username)
            if (user != null) {
                this.setCurrentTenant(username)
                this.setSecurityContextHolder(user, request)
                chain.doFilter(request, response)
            }
        } catch (ex: ExpiredJwtException) {
            ex.printStackTrace()
            log.info("JWT has expired INFO")
            log.warn("JWT has expired WARN")
            log.error("JWT has expired ERROR")
            handlerExceptionResolver.resolveException(request, response, null, ex)
        } catch (ex: UnsupportedJwtException) {
            ex.printStackTrace()
            log.error("UnsupportedJwtException in JwtAuthenticationFilter")
            handlerExceptionResolver.resolveException(request, response, null, ex)
        } catch (ex: MalformedJwtException) {
            ex.printStackTrace()
            log.error("MalformedJwtException in JwtAuthenticationFilter")
            handlerExceptionResolver.resolveException(request, response, null, ex)
        } catch (ex: SignatureException) {
            ex.printStackTrace()
            log.error("SignatureException in JwtAuthenticationFilter")
            handlerExceptionResolver.resolveException(request, response, null, ex)
        } catch (ex: IllegalArgumentException) {
            ex.printStackTrace()
            log.error("IllegalArgumentException in JwtAuthenticationFilter")
            handlerExceptionResolver.resolveException(request, response, null, ex)
        } catch (ex: UsernameNotFoundException) {
            ex.printStackTrace()
            log.info("UsernameNotFoundException in JwtAuthenticationFilter")
            handlerExceptionResolver.resolveException(request, response, null, ex)
        } catch (ex: Exception) {
            ex.printStackTrace()
            log.error("Exception in JwtAuthenticationFilter")
            handlerExceptionResolver.resolveException(request, response, null, ex)
        }
    }

    private fun setSecurityContextHolder(user: UserDetails, req: HttpServletRequest) {
        val usernamePasswordAuthenticationToken = UsernamePasswordAuthenticationToken(user, null, user.authorities)
        usernamePasswordAuthenticationToken.details = WebAuthenticationDetailsSource().buildDetails(req)
        SecurityContextHolder.getContext().authentication = usernamePasswordAuthenticationToken
    }

    private fun setCurrentTenant(username: String) {
        val userTO = userService.getByUsername(username)
        if (userTO != null) {
            UserSessionContext.setCurrentTenant(userTO)
        }
    }
}