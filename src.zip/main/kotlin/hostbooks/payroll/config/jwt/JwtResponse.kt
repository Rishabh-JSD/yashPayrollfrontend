package hostbooks.payroll.config.jwt

import lombok.Getter
import lombok.Setter

@Getter
@Setter
class JwtResponse {
    private var token: String? = null
    private var type = "Bearer"

    fun JwtResponse(accessToken: String?) {
        token = accessToken
    }
}