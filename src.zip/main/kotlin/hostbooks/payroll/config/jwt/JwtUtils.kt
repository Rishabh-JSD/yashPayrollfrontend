package hostbooks.payroll.config.jwt

import io.jsonwebtoken.Claims
import io.jsonwebtoken.Jwts
import io.jsonwebtoken.SignatureAlgorithm
import io.jsonwebtoken.security.Keys
import org.apache.commons.logging.LogFactory
import org.springframework.beans.factory.annotation.Value
import org.springframework.stereotype.Component
import java.nio.charset.StandardCharsets
import java.security.Key
import java.time.Instant
import java.util.*


@Component
class JwtUtils(
    @Value("\${app.jwtSecret}") private val jwtKey: String,
    @Value("\${app.jwtExpiration}") private val jwtExpiration: Int
) {

    private val log = LogFactory.getLog(this.javaClass)

    fun getUsername(token: String): String = this.getClaims(token).subject

    private fun getExpiration(token: String): Date = this.getClaims(token).expiration

    private fun getClaims(token: String): Claims {
        return Jwts.parserBuilder()
            .setSigningKey(jwtKey.toByteArray())
            .build()
            .parseClaimsJws(token).body
    }

    private fun isTokenExpired(token: String): Boolean = this.getExpiration(token).before(Date())

    fun generateToken(username: String): String {
        val oneMinInMillis = 60000
        val oneHourInMillis = oneMinInMillis * 60
        val token = Jwts.builder()
            .setSubject(username)
            .setIssuedAt(Date.from(Instant.now()))
            .setExpiration(Date(System.currentTimeMillis() + oneHourInMillis * jwtExpiration))
            .signWith(this.getSigningKey(), SignatureAlgorithm.HS512)
        return token.compact()
    }

    private fun getSigningKey(): Key? {
        val keyBytes: ByteArray = this.jwtKey.toByteArray(StandardCharsets.UTF_8)
        return Keys.hmacShaKeyFor(keyBytes)
    }

    fun isTokenValid(token: String): Boolean {
        val claims = this.getClaims(token)
        val expirationDate = claims.expiration
        val now = Date(System.currentTimeMillis())
        return now.before(expirationDate)
    }
}
