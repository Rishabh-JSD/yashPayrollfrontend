package hostbooks.payroll.config.jwt

import org.springframework.security.core.GrantedAuthority
import org.springframework.security.core.userdetails.UserDetails


class SpringUserDetails(
    private val id: Number?,
    private val name: String?,
    private val email: String?,
    private val username: String?,
    private val password: String?,
    private val authorities: MutableCollection<GrantedAuthority>
) : UserDetails {

    fun getId() = id
    fun getName() = name
    fun getEmail() = email
    override fun getAuthorities() = authorities
    override fun getPassword() = password
    override fun getUsername() = username
    override fun isAccountNonExpired() = true
    override fun isAccountNonLocked() = true
    override fun isCredentialsNonExpired() = true
    override fun isEnabled() = true

    companion object {
        @java.io.Serial
        private const val serialVersionUID: Long=1L
    }
}