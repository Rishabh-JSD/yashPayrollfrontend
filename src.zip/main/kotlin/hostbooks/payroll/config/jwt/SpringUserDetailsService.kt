package hostbooks.payroll.config.jwt

import hostbooks.payroll.core.user.dto.UserTO
import hostbooks.payroll.core.user.service.UserService
import org.springframework.security.core.authority.SimpleGrantedAuthority
import org.springframework.security.core.userdetails.UserDetails
import org.springframework.security.core.userdetails.UserDetailsService
import org.springframework.security.core.userdetails.UsernameNotFoundException
import org.springframework.stereotype.Service
import java.util.*

@Service
class SpringUserDetailsService(private val userService: UserService) : UserDetailsService {

    @Throws(UsernameNotFoundException::class)
    override fun loadUserByUsername(username: String): UserDetails {
        val user: UserTO? = userService.getByUsername(username)
        if (user != null) {
            return SpringUserDetails(
                user.id,
                user.name,
                user.email,
                user.username,
                user.password,
                Collections.singleton(SimpleGrantedAuthority("Admin"))
            )
        } else {
            throw UsernameNotFoundException("$username not found")
        }
    }
}