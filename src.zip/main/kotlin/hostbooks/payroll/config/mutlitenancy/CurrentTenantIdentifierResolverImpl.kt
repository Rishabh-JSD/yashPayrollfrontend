package hostbooks.payroll.config.mutlitenancy

import hostbooks.payroll.core.constant.CoreConst
import org.hibernate.context.spi.CurrentTenantIdentifierResolver
import org.springframework.stereotype.Component

@Component
class CurrentTenantIdentifierResolverImpl : CurrentTenantIdentifierResolver {

    override fun resolveCurrentTenantIdentifier(): String {
        val tenantId: String? = TenantContext.getCurrentTenant()
        return if (!tenantId.isNullOrEmpty()) {
            tenantId
        } else if (CoreConst.IS_DEMO_LOGIN) {
            CoreConst.DEFAULT_CLIENT_DB
        } else {
            CoreConst.MASTER_DB
        }
    }

    override fun validateExistingCurrentSessions(): Boolean {
        return true
    }
}