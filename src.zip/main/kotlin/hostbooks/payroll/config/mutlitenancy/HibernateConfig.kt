package hostbooks.payroll.config.mutlitenancy

import org.hibernate.cfg.Environment
import org.hibernate.context.spi.CurrentTenantIdentifierResolver
import org.hibernate.engine.jdbc.connections.spi.MultiTenantConnectionProvider
import org.springframework.boot.autoconfigure.orm.jpa.JpaProperties
import org.springframework.context.annotation.Bean
import org.springframework.orm.jpa.JpaVendorAdapter
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter
import org.springframework.stereotype.Component
import javax.sql.DataSource


@Component
class HibernateConfig(private val jpaProperties: JpaProperties) {

    @Bean
    fun jpaVendorAdapter(): JpaVendorAdapter {
        return HibernateJpaVendorAdapter()
    }

    @Bean
    fun entityManagerFactory(
        dataSource: DataSource,
        multiTenantConnectionProviderImpl: MultiTenantConnectionProvider,
        currentTenantIdentifierResolverImpl: CurrentTenantIdentifierResolver,
        jpaVendorAdapter: JpaVendorAdapter
    ): LocalContainerEntityManagerFactoryBean {
        val jpaPropertiesMap: MutableMap<String, Any> = HashMap(this.jpaProperties.properties)
        jpaPropertiesMap[Environment.MULTI_TENANT_CONNECTION_PROVIDER] = multiTenantConnectionProviderImpl
        jpaPropertiesMap[Environment.MULTI_TENANT_IDENTIFIER_RESOLVER] = currentTenantIdentifierResolverImpl

        val em = LocalContainerEntityManagerFactoryBean()
        em.dataSource = dataSource
        em.setPackagesToScan("hostbooks.payroll")
        em.jpaVendorAdapter = jpaVendorAdapter
        em.setJpaPropertyMap(jpaPropertiesMap)
        return em
    }
}