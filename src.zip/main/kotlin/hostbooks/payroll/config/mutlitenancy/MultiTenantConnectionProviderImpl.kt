package hostbooks.payroll.config.mutlitenancy

import hostbooks.payroll.core.constant.CoreConst
import hostbooks.payroll.core.constant.CoreEnum
import hostbooks.payroll.core.constant.VarLocalThread
import org.apache.commons.logging.LogFactory
import org.hibernate.engine.jdbc.connections.spi.MultiTenantConnectionProvider
import org.springframework.stereotype.Component
import java.sql.Connection
import java.sql.SQLException
import javax.sql.DataSource

@Component
class MultiTenantConnectionProviderImpl(
    private val dataSource: DataSource,
    private val multiTenantDBSource: MultiTenantDBSource
) : MultiTenantConnectionProvider {
    private val log = LogFactory.getLog(this.javaClass)

    companion object {
        @java.io.Serial
        private const val serialVersionUID: Long = 3387516993124229959L
    }

    @Throws(SQLException::class)
    override fun getAnyConnection(): Connection {
        return dataSource.connection
    }

    @Throws(SQLException::class)
    override fun releaseAnyConnection(connection: Connection) {
        connection.close()
    }

    override fun getConnection(tenantIdentifier: String?): Connection {
        if (tenantIdentifier != null && tenantIdentifier != CoreConst.DEFAULT_CLIENT_DB) {
            if (!TenantDBContext.dataWrite.containsKey(tenantIdentifier)) {
                multiTenantDBSource.databaseDetail(tenantIdentifier)
            }
            if (TenantDBContext.dataWrite.containsKey(tenantIdentifier)) {
                return if (CoreEnum.RequestType.READ.name == VarLocalThread.getRequestType()) {
                    log.info("<<<<<<<<<<<= Fetching Client($tenantIdentifier) DB connection =>>>>>>>>>> ${TenantDBContext.dataRead[tenantIdentifier]?.url}")
                    val connection = TenantDBContext.dataRead[tenantIdentifier]?.connection
                    connection!!
                } else {
                    log.info("<<<<<<<<<<<= Fetching Client($tenantIdentifier) DB connection =>>>>>>>>>> ${TenantDBContext.dataWrite[tenantIdentifier]?.url}")
                    TenantDBContext.dataWrite[tenantIdentifier]?.connection!!
                }
            }
        }
        return anyConnection
    }

    override fun releaseConnection(tenantIdentifier: String?, connection: Connection) {
        try {
            connection.close()
        } catch (e: Exception) {
            log.info("Error occurred while closing current database ####################### :: ")
        }
    }

    override fun supportsAggressiveRelease(): Boolean {
        return false
    }

    override fun isUnwrappableAs(aClass: Class<*>): Boolean {
        return false
    }

    override fun <T> unwrap(aClass: Class<T>): T? {
        return null
    }
}