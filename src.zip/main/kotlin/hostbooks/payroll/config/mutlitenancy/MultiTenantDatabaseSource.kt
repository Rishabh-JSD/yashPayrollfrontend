package hostbooks.payroll.config.mutlitenancy

import hostbooks.payroll.core.tenant.dto.TenantDbDetailInternalTO
import hostbooks.payroll.shared.utility.CommonUtil
import org.springframework.boot.context.event.ApplicationReadyEvent
import org.springframework.context.event.EventListener
import org.springframework.jdbc.core.JdbcTemplate
import org.springframework.jdbc.datasource.DriverManagerDataSource
import org.springframework.stereotype.Component
import javax.sql.DataSource

@Component
class MultiTenantDBSource(private val dataSource: DataSource) {

    @EventListener(ApplicationReadyEvent::class)
    fun onApplicationReady() {
        databaseDetail(null)
    }

    private fun getDataSource(url: String, userName: String, password: String): DriverManagerDataSource {
        val driverManagerDataSource = DriverManagerDataSource()
        driverManagerDataSource.setDriverClassName("com.mysql.cj.jdbc.Driver")
        driverManagerDataSource.url = url
        driverManagerDataSource.username = userName
        driverManagerDataSource.password = password
        return driverManagerDataSource
    }

    fun databaseDetail(businessUUID: String?) {
        val jdbcDatabaseDetail = JdbcTemplate(dataSource)
        var dbquery = "SELECT * FROM tenant_db_details_internal"
        businessUUID?.let {
            dbquery += " where tenant_db_uuid='$businessUUID'"
        }

        val rows = jdbcDatabaseDetail.queryForList(dbquery)
        for (row in rows) {
            val tenantDbDetailTO = TenantDbDetailInternalTO()
            tenantDbDetailTO.businessUUID = row["tenant_db_uuid"].toString()
            tenantDbDetailTO.dbName = row["tenant_db_name"].toString()
            tenantDbDetailTO.writeHost = row["write_host"].toString()
            tenantDbDetailTO.writePort = row["write_port"].toString()
            tenantDbDetailTO.writeUser = row["write_user"].toString()
            tenantDbDetailTO.writePass = row["write_pass"].toString()
            tenantDbDetailTO.readHost = row["read_host"].toString()
            tenantDbDetailTO.readPort = row["read_port"].toString()
            tenantDbDetailTO.readUser = row["read_user"].toString()
            tenantDbDetailTO.readPass = row["read_pass"].toString()

            TenantDBContext.dbMap[tenantDbDetailTO.businessUUID!!] = tenantDbDetailTO.dbName!!
            TenantDBContext.dataWrite[tenantDbDetailTO.businessUUID!!] = this.getDataSource(
                CommonUtil.getJdbcUrl(
                    tenantDbDetailTO.dbName!!,
                    tenantDbDetailTO.writeHost!!, tenantDbDetailTO.writePort!!
                ), tenantDbDetailTO.writeUser!!, tenantDbDetailTO.writePass!!
            )
            TenantDBContext.dataRead[tenantDbDetailTO.businessUUID!!] = this.getDataSource(
                CommonUtil.getJdbcUrl(
                    tenantDbDetailTO.dbName!!,
                    tenantDbDetailTO.readHost!!, tenantDbDetailTO.readPort!!
                ), tenantDbDetailTO.readUser!!, tenantDbDetailTO.readPass!!
            )
        }
    }
}