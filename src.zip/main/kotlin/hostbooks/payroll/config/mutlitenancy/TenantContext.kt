package hostbooks.payroll.config.mutlitenancy

import org.apache.commons.logging.LogFactory

object TenantContext {

    private val log = LogFactory.getLog(this.javaClass)

    private val currentTenant: ThreadLocal<String> = InheritableThreadLocal()

    fun getCurrentTenant(): String? {
        return currentTenant.get()
    }

    fun setCurrentTenant(tenant: String) {
        log.debug("Setting tenant to ======================================> $tenant")
        currentTenant.set(tenant)
    }

    fun clear() {
        currentTenant.remove()
    }
}