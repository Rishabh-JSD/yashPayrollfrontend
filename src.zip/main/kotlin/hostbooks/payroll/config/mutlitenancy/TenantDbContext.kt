package hostbooks.payroll.config.mutlitenancy

import hostbooks.payroll.core.constant.CoreConst
import org.springframework.jdbc.datasource.DriverManagerDataSource
import java.util.concurrent.ConcurrentHashMap

object TenantDBContext {

    val dbMap: MutableMap<String, String> = ConcurrentHashMap()
    val dataWrite: MutableMap<String, DriverManagerDataSource> = ConcurrentHashMap()
    val dataRead: MutableMap<String, DriverManagerDataSource> = ConcurrentHashMap()

    init {
        dbMap["Default"] = CoreConst.MASTER_DB
    }
}