package hostbooks.payroll.config.mutlitenancy

import hostbooks.payroll.shared.utility.UserSessionContext
import jakarta.servlet.http.HttpServletRequest
import jakarta.servlet.http.HttpServletResponse
import org.apache.commons.logging.LogFactory
import org.springframework.stereotype.Component
import org.springframework.web.servlet.HandlerInterceptor
import org.springframework.web.servlet.ModelAndView

@Component
class TenantInterceptor : HandlerInterceptor {

    private val log = LogFactory.getLog(this.javaClass)

    override fun preHandle(request: HttpServletRequest, response: HttpServletResponse, handler: Any): Boolean {
        // This method is called before the actual handler method is invoked.
        // You can perform pre-processing here.
        return true // If true is returned, the handler method will be invoked.
    }

    override fun postHandle(request: HttpServletRequest, response: HttpServletResponse, handler: Any, modelAndView: ModelAndView?) {
        // This method is called after the handler method is invoked.
        // You can perform post-processing here.
        TenantContext.clear()
        UserSessionContext.clear()
    }

    override fun afterCompletion(request: HttpServletRequest, response: HttpServletResponse, handler: Any, ex: Exception?) {
        // This method is called after the view is rendered.
        // You can perform cleanup or additional tasks here.
        TenantContext.clear()
        UserSessionContext.clear()
    }
}