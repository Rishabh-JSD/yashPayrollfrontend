package hostbooks.payroll.config.redis.controller

import hostbooks.payroll.config.redis.entity.RedisBlacklistedJwt
import hostbooks.payroll.config.redis.service.RedisBlacklistedJwtService
import hostbooks.payroll.shared.utility.ValidationError
import hostbooks.payroll.shared.utility.model.ResponseTO
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.validation.Errors
import org.springframework.validation.Validator
import org.springframework.web.bind.WebDataBinder
import org.springframework.web.bind.annotation.*
import javax.validation.Valid


@RestController
@RequestMapping("/redis-blacklisted-jwt")
class RedisBlacklistedJwtController(private val redisBlacklistedJwtService: RedisBlacklistedJwtService, private val redisBlacklistedJwtValidator: Validator) {

    @InitBinder
    private fun initBinder(binder: WebDataBinder) {
        binder.validator = this.redisBlacklistedJwtValidator
    }

//    @GetMapping("/list")
//    fun getRedisBlacklistedJwtList(): ResponseEntity<*> {
//        val responseTO: SearchResponseTO<RedisBlacklistedJwt> = redisBlacklistedJwtService.getRedisBlacklistedJwtList()
//        val response = ResponseTO.responseBuilder(200, "COM04", "/redis-blacklisted-jwt", "redisBlacklistedJwt", responseTO)
//        return ResponseEntity<ResponseTO>(response, HttpStatus.OK)
//    }

    @PostMapping("/add")
    fun addRedisBlacklistedJwt(@Valid @RequestBody redisBlacklistedJwt: RedisBlacklistedJwt, errors: Errors): ResponseEntity<*> {
        if (errors.hasErrors()) {
            val validationError: ValidationError = ValidationError.fromBindingErrors(errors)
            return ResponseEntity<Any>(validationError, HttpStatus.OK)
        }
        val addedBlacklistedTO: RedisBlacklistedJwt = redisBlacklistedJwtService.addRedisBlacklistedJwt(redisBlacklistedJwt)
        val responseDTO = ResponseTO.responseBuilder(201, "COM09", "/redis-blacklisted-jwt", "redisBlacklistedJwt", addedBlacklistedTO)
        return ResponseEntity<Any>(responseDTO, HttpStatus.CREATED)
    }

    @GetMapping("/get-by-id")
    fun getRedisBlacklistedJwtById(@RequestParam(name = "redisBlacklistedJwtId") redisBlacklistedJwtId: Long): ResponseEntity<*> {
        val redisBlacklistedJwtTO: RedisBlacklistedJwt? = redisBlacklistedJwtService.getRedisBlacklistedJwtById(redisBlacklistedJwtId)
        val responseDTO = ResponseTO.responseBuilder(200, "COM03", "/redis-blacklisted-jwt", "redisBlacklistedJwt", redisBlacklistedJwtTO)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }

    @DeleteMapping("/delete")
    fun deleteRedisBlacklistedJwt(@RequestParam(name = "redisBlacklistedJwtId") redisBlacklistedJwtId: Long): ResponseEntity<*> {
        val deletedBlacklistedTO: RedisBlacklistedJwt? = redisBlacklistedJwtService.deleteRedisBlacklistedJwt(redisBlacklistedJwtId)
        val responseDTO = ResponseTO.responseBuilder(200, "COM05", "/redis-blacklisted-jwt", "redisBlacklistedJwt", deletedBlacklistedTO)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }
}