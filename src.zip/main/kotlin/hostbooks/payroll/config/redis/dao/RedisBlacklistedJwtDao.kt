package hostbooks.payroll.config.redis.dao

import hostbooks.payroll.config.redis.entity.RedisBlacklistedJwt

interface RedisBlacklistedJwtDao {

    fun addRedisBlacklistedJwt(redisBlacklistedJwt: RedisBlacklistedJwt): RedisBlacklistedJwt

//    fun getRedisBlacklistedJwtList(): MutableList<RedisBlacklistedJwt>

    fun getRedisBlacklistedJwtById(id: Long): RedisBlacklistedJwt?

    fun deleteRedisBlacklistedJwt(id: Long): RedisBlacklistedJwt?

}