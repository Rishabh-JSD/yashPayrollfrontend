package hostbooks.payroll.config.redis.dao

import hostbooks.payroll.config.redis.entity.RedisBlacklistedJwt
import org.springframework.data.redis.core.RedisTemplate
import org.springframework.stereotype.Repository


@Repository
open class RedisBlacklistedJwtDaoImpl(val redisTemplate: RedisTemplate<String, RedisBlacklistedJwt>) : RedisBlacklistedJwtDao {

    override fun addRedisBlacklistedJwt(redisBlacklistedJwt: RedisBlacklistedJwt): RedisBlacklistedJwt {
        redisTemplate.opsForValue().set(redisBlacklistedJwt.id.toString(), redisBlacklistedJwt);
        return redisBlacklistedJwt
    }

//    override fun getRedisBlacklistedJwtList(): MutableList<RedisBlacklistedJwt> {
//        // GET all blacklistedJwt values
////        return redisTemplate.opsForHash<>()
//
//
////        return hashOperations.values(HASH_KEY_NAME)
//
//    }

    override fun getRedisBlacklistedJwtById(id: Long): RedisBlacklistedJwt? {
        return redisTemplate.opsForValue().get(id.toString());
    }

    override fun deleteRedisBlacklistedJwt(id: Long): RedisBlacklistedJwt? {
        return redisTemplate.opsForValue().getAndDelete(id.toString())
    }
}
