package hostbooks.payroll.config.redis.entity

import jakarta.persistence.Id
import org.springframework.data.redis.core.RedisHash
import java.io.Serializable


@RedisHash("RedisBlacklistedJwt")
class RedisBlacklistedJwt : Serializable {

    @Id
    val id: Int? = null
    val jwt: String? = null

    companion object {
        @java.io.Serial
        private const val serialVersionUID: Long = 1L
    }
}