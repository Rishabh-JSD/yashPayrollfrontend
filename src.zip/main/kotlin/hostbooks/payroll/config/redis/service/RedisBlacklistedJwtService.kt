package hostbooks.payroll.config.redis.service

import hostbooks.payroll.config.redis.entity.RedisBlacklistedJwt

interface RedisBlacklistedJwtService {

    fun addRedisBlacklistedJwt(redisBlacklistedJwt: RedisBlacklistedJwt): RedisBlacklistedJwt

//    fun getRedisBlacklistedJwtList(): SearchResponseTO<RedisBlacklistedJwt>

    fun getRedisBlacklistedJwtById(id: Long): RedisBlacklistedJwt?

    fun deleteRedisBlacklistedJwt(id: Long): RedisBlacklistedJwt?
}