package hostbooks.payroll.config.redis.service

import hostbooks.payroll.config.redis.dao.RedisBlacklistedJwtDao
import hostbooks.payroll.config.redis.entity.RedisBlacklistedJwt
import org.springframework.stereotype.Service

@Service
class RedisBlacklistedJwtServiceImpl(private val redisBlacklistedJwtDao: RedisBlacklistedJwtDao) : RedisBlacklistedJwtService {

    override fun addRedisBlacklistedJwt(redisBlacklistedJwt: RedisBlacklistedJwt): RedisBlacklistedJwt {
        return redisBlacklistedJwtDao.addRedisBlacklistedJwt(redisBlacklistedJwt)
    }

//    override fun getRedisBlacklistedJwtList(): SearchResponseTO<RedisBlacklistedJwt> {
//        val searchResponseTO = SearchResponseTO<RedisBlacklistedJwt>()
//        searchResponseTO.list = redisBlacklistedJwtDao.getRedisBlacklistedJwtList()
//        searchResponseTO.pageCount = 1
//        searchResponseTO.totalRowCount = searchResponseTO.list!!.size.toLong()
//        return searchResponseTO
//    }

    override fun getRedisBlacklistedJwtById(id: Long): RedisBlacklistedJwt? {
        return redisBlacklistedJwtDao.getRedisBlacklistedJwtById(id)
    }

    override fun deleteRedisBlacklistedJwt(id: Long): RedisBlacklistedJwt? {
        return redisBlacklistedJwtDao.deleteRedisBlacklistedJwt(id)
    }
}