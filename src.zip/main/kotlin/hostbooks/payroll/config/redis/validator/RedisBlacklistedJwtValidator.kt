package hostbooks.payroll.config.redis.validator

import hostbooks.payroll.config.redis.controller.RedisBlacklistedJwtController
import hostbooks.payroll.config.redis.entity.RedisBlacklistedJwt
import org.springframework.validation.Errors
import org.springframework.validation.Validator
import org.springframework.web.bind.annotation.ControllerAdvice


@ControllerAdvice(assignableTypes = [RedisBlacklistedJwtController::class])
class RedisBlacklistedJwtValidator : Validator {
    override fun supports(clazz: Class<*>): Boolean {
        return RedisBlacklistedJwt::class.java == clazz
    }

    override fun validate(target: Any, errors: Errors) {
        if (target is RedisBlacklistedJwt) {
            //logic for validation
        }
    }
}