package hostbooks.payroll.core.authentication.controller

import hostbooks.payroll.config.jwt.JwtUtils
import hostbooks.payroll.core.authentication.dto.LoginTO
import hostbooks.payroll.core.authentication.dto.ResetPasswordTO
import hostbooks.payroll.core.authentication.dto.UserRegistrationTO
import hostbooks.payroll.core.authentication.service.AuthServiceImpl
import hostbooks.payroll.core.user.dto.UserTO
import hostbooks.payroll.shared.utility.ValidationError
import hostbooks.payroll.shared.utility.model.ResponseDTO
import jakarta.servlet.http.Cookie
import jakarta.servlet.http.HttpServletResponse
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.validation.Errors
import org.springframework.validation.Validator
import org.springframework.web.bind.WebDataBinder
import org.springframework.web.bind.annotation.*
import javax.validation.Valid

@RestController
@RequestMapping("payroll")
class AuthController(private var authValidator: Validator, private var responseDTO: ResponseDTO, private val authServiceImpl: AuthServiceImpl, private val jwtUtils: JwtUtils) {

    @InitBinder
    private fun initBinder(binder: WebDataBinder) {
        binder.validator = this.authValidator
    }

    @RequestMapping(value = ["register"], method = [RequestMethod.POST])
    fun registerUser(@Valid @RequestBody userRegistrationTO: UserRegistrationTO, errors: Errors): ResponseEntity<*> {
        if (errors.hasErrors()) return ResponseEntity(ValidationError.fromBindingErrors(errors), HttpStatus.OK)
        val addedUser = authServiceImpl.registerUser(userRegistrationTO)
        responseDTO = if (addedUser != null) {
            ResponseDTO.responseBuilder(HttpStatus.OK.value(), "COM01", "/register", "auth", addedUser)
        } else {
            ResponseDTO.responseBuilder(HttpStatus.NOT_FOUND.value(), "COM03E", "/register", "auth", null)
        }
        return ResponseEntity(responseDTO, HttpStatus.OK)
    }

    @PostMapping("login")
    fun login(@RequestBody loginTO: LoginTO, response: HttpServletResponse): ResponseEntity<Any> {
        val userTO: UserTO = this.authServiceImpl.verifyUserForLogin(loginTO)
        this.setJwtCookie(userTO, response)
        responseDTO = ResponseDTO.responseBuilder(HttpStatus.OK.value(), "AUTH01", "/login", "auth", userTO)
        return ResponseEntity(responseDTO, HttpStatus.OK)
    }

    private fun setJwtCookie(userTO: UserTO, response: HttpServletResponse) {
        if (userTO.username != null && userTO.enabled) {
            val jwt = jwtUtils.generateToken(userTO.username!!)
            userTO.token = jwt
            val cookie = Cookie("jwt", jwt)
            cookie.isHttpOnly = true
            response.addCookie(cookie)
        }
    }

    @PostMapping("reset-password")
    fun resetPassword(@RequestBody resetPasswordTO: ResetPasswordTO, response: HttpServletResponse): ResponseEntity<Any> {
        val userTO: UserTO? = this.authServiceImpl.resetPassword(resetPasswordTO)
        responseDTO = ResponseDTO.responseBuilder(HttpStatus.OK.value(), "AUTH02", "/reset-password", "auth", userTO)
        return ResponseEntity(responseDTO, HttpStatus.OK)
    }

//    @PostMapping("/logout")
//    fun logoutClient(@RequestBody clientResponseTO: ClientResponseTO): ResponseEntity<*> {
//        userService.logoutClient(clientResponseTO)
//        val response = GlobalResponseTO.responseBuilder(
//            HttpStatus.OK.value(), "COM19", "user/logout", "client",
//            null
//        )
//        return ResponseEntity(response, HttpStatus.OK)
//    }

//    @PutMapping("/deactivate/{client}")
//    fun deActivateClient(@PathVariable("client") clientId: String): ResponseEntity<*> {
//        val response = GlobalResponseTO.responseBuilder(
//            HttpStatus.OK.value(), "COM22", "user/registration", "client",
//            userService.deActivateClient(clientId)
//        )
//        return ResponseEntity(response, HttpStatus.OK)
//    }
}