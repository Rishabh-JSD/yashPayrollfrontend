package hostbooks.payroll.core.authentication.dto


data class LoginTO(
    val email: String,
    val password: String
)
