package hostbooks.payroll.core.authentication.dto

data class ResetPasswordTO(
    val email: String?,
    val password: String?,
    val confirmPassword: String?
)
