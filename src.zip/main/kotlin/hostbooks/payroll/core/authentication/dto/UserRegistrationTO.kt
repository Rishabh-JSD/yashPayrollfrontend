package hostbooks.payroll.core.authentication.dto

import hostbooks.payroll.core.user.dto.UserDetailTO

class UserRegistrationTO {
     var name: String? = null
     var username: String? = null
     var password: String? = null
     var confirmPassword: String? = null
     var email: String? = null
     var enabled: Boolean = true
     var userDetail: UserDetailTO? = null;
     var updatedAt: String? = null
     var createdAt: String?=null;
}
