package hostbooks.payroll.core.authentication.service

import hostbooks.payroll.core.authentication.dto.LoginTO
import hostbooks.payroll.core.authentication.dto.ResetPasswordTO
import hostbooks.payroll.core.authentication.dto.UserRegistrationTO
import hostbooks.payroll.core.user.dto.UserTO

interface AuthService {

    fun registerUser(userRegistrationTO: UserRegistrationTO): UserTO?

    fun updateUser(userTO: UserTO): UserTO?

    fun verifyUserForLogin(loginTO: LoginTO): UserTO

    fun resetPassword(resetPasswordTO: ResetPasswordTO): UserTO?
}
