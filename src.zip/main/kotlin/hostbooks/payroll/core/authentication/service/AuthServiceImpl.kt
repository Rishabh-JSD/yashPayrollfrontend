package hostbooks.payroll.core.authentication.service

import hostbooks.payroll.core.authentication.dto.LoginTO
import hostbooks.payroll.core.authentication.dto.ResetPasswordTO
import hostbooks.payroll.core.authentication.dto.UserRegistrationTO
import hostbooks.payroll.core.commonDao.CommonDao
import hostbooks.payroll.core.exception.PasswordMismatchException
import hostbooks.payroll.core.exception.UserNotFoundException
import hostbooks.payroll.core.user.dto.UserTO
import hostbooks.payroll.core.user.entity.UserBO
import hostbooks.payroll.core.user.service.UserService
import hostbooks.payroll.shared.utility.MapHandler
import jakarta.transaction.Transactional
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder
import org.springframework.stereotype.Service

@Service
class AuthServiceImpl(
    private val mapHandler: MapHandler, private val commonDao: CommonDao, private val userService: UserService
) : AuthService {

    @Transactional
    override fun registerUser(userRegistrationTO: UserRegistrationTO): UserTO? {
        val bCryptPasswordEncoder = BCryptPasswordEncoder()
        userRegistrationTO.password = bCryptPasswordEncoder.encode(userRegistrationTO.password)
        val userBO = mapHandler.mapObject(userRegistrationTO, UserBO::class.java)
        if (userBO != null) {
            return mapHandler.mapObject(commonDao.persist(userBO), UserTO::class.java)
        }
        return null
    }

    @Transactional
    override fun updateUser(userTO: UserTO): UserTO? {
        val userBO = mapHandler.mapObject(userTO, UserBO::class.java)
        if (userBO != null) {
            return mapHandler.mapObject(commonDao.persist(userBO), UserTO::class.java)
        }
        return null
    }

    override fun verifyUserForLogin(loginTO: LoginTO): UserTO {
        userService.getUserByEmail(loginTO.email)
        val userTO: UserTO? = userService.getUserByEmail(loginTO.email)
        if (userTO == null) {
            throw UserNotFoundException("User not found by email = ${loginTO.email}")
        } else {
            if (!BCryptPasswordEncoder().matches(loginTO.password, userTO.password)) {
                throw PasswordMismatchException("Password mismatch")
            }
            userTO.password = null
            return userTO
        }
    }

    override fun resetPassword(resetPasswordTO: ResetPasswordTO): UserTO? {
        val userTO: UserTO? = userService.getUserByEmail(resetPasswordTO.email!!)
        if (userTO == null) {
            throw UserNotFoundException("User not found by email = ${resetPasswordTO.email}")
        } else {
            val bCryptPasswordEncoder = BCryptPasswordEncoder()
            userTO.password = bCryptPasswordEncoder.encode(resetPasswordTO.password)
            return userService.updateUser(userTO)
        }
    }
}
