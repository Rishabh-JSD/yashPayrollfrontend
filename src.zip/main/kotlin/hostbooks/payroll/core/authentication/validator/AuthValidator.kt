package hostbooks.payroll.core.authentication.validator

import hostbooks.payroll.core.authentication.controller.AuthController
import hostbooks.payroll.core.authentication.dto.LoginTO
import hostbooks.payroll.core.authentication.dto.ResetPasswordTO
import hostbooks.payroll.core.authentication.dto.UserRegistrationTO
import hostbooks.payroll.core.commonDao.CommonDao
import hostbooks.payroll.core.dto.FilterInfo
import hostbooks.payroll.core.user.entity.UserBO
import hostbooks.payroll.core.user.service.UserService
import hostbooks.payroll.shared.constant.AppEnum
import hostbooks.payroll.shared.constant.AppMsg
import org.springframework.validation.Errors
import org.springframework.validation.ValidationUtils
import org.springframework.validation.Validator
import org.springframework.web.bind.annotation.ControllerAdvice
import java.util.*

@ControllerAdvice(assignableTypes = [AuthController::class])
class AuthValidator(private val userService: UserService,private val commonDao: CommonDao) : Validator {

    override fun supports(clazz: Class<*>): Boolean {
        return UserRegistrationTO::class.java == clazz || LoginTO::class.java == clazz || ResetPasswordTO::class.java == clazz
    }

    override fun validate(obj: Any, errors: Errors) {
        if (obj is UserRegistrationTO) {
            ValidationUtils.rejectIfEmptyOrWhitespace(errors, "name", "COM06E", AppMsg.RESPONSE["COM06E"]!!)
            ValidationUtils.rejectIfEmptyOrWhitespace(errors, "username", "COM06E", AppMsg.RESPONSE["COM06E"]!!)
            ValidationUtils.rejectIfEmptyOrWhitespace(errors, "password", "COM06E", AppMsg.RESPONSE["COM06E"]!!)
            ValidationUtils.rejectIfEmptyOrWhitespace(errors, "email", "COM06E", AppMsg.RESPONSE["COM06E"]!!)
            // username, email unique check
            if (obj.username != null) {
                val discriminatorMap: WeakHashMap<String, FilterInfo<*>> = WeakHashMap<String, FilterInfo<*>>()
                discriminatorMap["username"] = FilterInfo(AppEnum.FilterType.EQ, obj.username!!)
                if (commonDao.isExistMultiDiscriminatorsSingleVal(UserBO::class.java,discriminatorMap)) {
                    errors.rejectValue("username", "COM02E", AppMsg.RESPONSE["COM02E"]!!)
                }
            }
            if (obj.email != null) {
                val discriminatorMap: WeakHashMap<String, FilterInfo<*>> = WeakHashMap<String, FilterInfo<*>>()
                discriminatorMap["email"] = FilterInfo(AppEnum.FilterType.EQ, obj.email!!)
                if (commonDao.isExistMultiDiscriminatorsSingleVal(UserBO::class.java,discriminatorMap)) {
                    errors.rejectValue("email", "COM02E", AppMsg.RESPONSE["COM02E"]!!)
                }
            }
        } else if (obj is LoginTO) {
            ValidationUtils.rejectIfEmptyOrWhitespace(errors, "password", "COM06E", AppMsg.RESPONSE["COM06E"]!!)
            ValidationUtils.rejectIfEmptyOrWhitespace(errors, "email", "COM06E", AppMsg.RESPONSE["COM06E"]!!)
        } else if (obj is ResetPasswordTO) {
            ValidationUtils.rejectIfEmptyOrWhitespace(errors, "email", "COM06E", AppMsg.RESPONSE["COM06E"]!!)
            ValidationUtils.rejectIfEmptyOrWhitespace(errors, "password", "COM06E", AppMsg.RESPONSE["COM06E"]!!)
            ValidationUtils.rejectIfEmptyOrWhitespace(errors, "confirmPassword", "COM06E", AppMsg.RESPONSE["COM06E"]!!)
            if (obj.password != null && obj.confirmPassword != null && obj.password != obj.confirmPassword) {
                errors.rejectValue("code", "PMS002E", AppMsg.RESPONSE["COM06E"]!!)
            }
        }
    }
}