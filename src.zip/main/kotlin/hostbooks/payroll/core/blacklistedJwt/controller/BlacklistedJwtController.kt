package hostbooks.payroll.core.blacklistedJwt.controller

import hostbooks.payroll.core.blacklistedJwt.dto.BlacklistedJwtTO
import hostbooks.payroll.core.blacklistedJwt.service.BlacklistedJwtService
import hostbooks.payroll.shared.utility.ValidationError
import hostbooks.payroll.shared.utility.model.ResponseTO
import hostbooks.payroll.shared.utility.model.SearchResponseTO
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.validation.Errors
import org.springframework.validation.Validator
import org.springframework.web.bind.WebDataBinder
import org.springframework.web.bind.annotation.*
import javax.validation.Valid

@RestController
@RequestMapping("/blacklisted-jwt")
class BlacklistedJwtController(private val blacklistedJwtService: BlacklistedJwtService, private val blacklistedJwtValidator: Validator) {

    @InitBinder
    private fun initBinder(binder: WebDataBinder) {
        binder.validator = this.blacklistedJwtValidator
    }

    @PostMapping("/list")
    fun getBlackListedJwtList(@RequestBody blacklistedJwtTO: BlacklistedJwtTO): ResponseEntity<*> {
        val responseTO: SearchResponseTO<BlacklistedJwtTO> = blacklistedJwtService.getBlacklistedJwtList(blacklistedJwtTO)
        val response = ResponseTO.responseBuilder(200, "COM04", "/blacklisted-jwt", "blacklistedJwt", responseTO)
        return ResponseEntity<ResponseTO>(response, HttpStatus.OK)
    }

    @PostMapping("/add")
    fun addBlackListedJwt(@Valid @RequestBody blacklistedJwtTO: BlacklistedJwtTO, errors: Errors): ResponseEntity<*> {
        if (errors.hasErrors()) {
            val validationError: ValidationError = ValidationError.fromBindingErrors(errors)
            return ResponseEntity<Any>(validationError, HttpStatus.OK)
        }
        val addedBlacklistedTO: BlacklistedJwtTO = blacklistedJwtService.addBlacklistedJwt(blacklistedJwtTO)
        val responseDTO = ResponseTO.responseBuilder(201, "COM09", "/blacklisted-jwt", "blacklistedJwt", addedBlacklistedTO)
        return ResponseEntity<Any>(responseDTO, HttpStatus.CREATED)
    }

    @PutMapping("/update")
    fun updateBlackListedJwt(@Valid @RequestBody blacklistedJwtTO: BlacklistedJwtTO, errors: Errors): ResponseEntity<*> {
        if (errors.hasErrors()) {
            val validationError: ValidationError = ValidationError.fromBindingErrors(errors)
            return ResponseEntity<Any>(validationError, HttpStatus.OK)
        }
        val updatedBlacklistedJwtTO: BlacklistedJwtTO = blacklistedJwtService.updateBlacklistedJwt(blacklistedJwtTO)
        val responseDTO = ResponseTO.responseBuilder(200, "COM02", "/blacklisted-jwt", "blacklistedJwt", updatedBlacklistedJwtTO)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }

    @DeleteMapping("/delete")
    fun deleteBlackListedJwt(@Valid @RequestParam(name = "blacklistedJwtIdList") blacklistedJwtIdList: List<Long>): ResponseEntity<*> {
        blacklistedJwtService.deleteBlacklistedJwt(blacklistedJwtIdList)
        val responseDTO = ResponseTO.responseBuilder(200, "COM05", "/blacklisted-jwt", "blacklistedJwt", blacklistedJwtIdList)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }

    @GetMapping("/{id}")
    fun getBlackListedJwtById(@PathVariable id: Long): ResponseEntity<*> {
        val blacklistedJwtTO: BlacklistedJwtTO? = blacklistedJwtService.getBlacklistedJwtById(id)
        if (blacklistedJwtTO == null) {
            val responseDTO = ResponseTO.responseBuilder(200, "COM03E", "/blacklisted-jwt", "blacklistedJwt", null)
            return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
        }
        val responseDTO = ResponseTO.responseBuilder(200, "COM11", "/blacklisted-jwt", "blacklistedJwt", blacklistedJwtTO)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }
}