package hostbooks.payroll.core.blacklistedJwt.dto

import hostbooks.payroll.shared.utility.model.AuditTO
import jakarta.persistence.Column

class BlacklistedJwtTO : AuditTO() {
    var id: Long? = null
    var jwt: String? = null
}