package hostbooks.payroll.core.blacklistedJwt.entity

import hostbooks.payroll.shared.constant.Tables
import hostbooks.payroll.shared.utility.model.Audit
import jakarta.persistence.*

@Entity
@Table(name = Tables.MasterDb.BLACKLISTED_JWT)
class BlacklistedJwtBO : Audit() {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", updatable = false, nullable = false)
    var id: Long? = null

    @Column(name = "jwt")
    var jwt: String? = null
}
