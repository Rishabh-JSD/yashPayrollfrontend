package hostbooks.payroll.core.blacklistedJwt.service

import hostbooks.payroll.core.blacklistedJwt.dto.BlacklistedJwtTO
import hostbooks.payroll.shared.utility.model.SearchResponseTO

interface BlacklistedJwtService {

    fun getBlacklistedJwtList(blacklistedJwtTO: BlacklistedJwtTO): SearchResponseTO<BlacklistedJwtTO>

    fun addBlacklistedJwt(blacklistedJwtTO: BlacklistedJwtTO): BlacklistedJwtTO

    fun updateBlacklistedJwt(blacklistedJwtTO: BlacklistedJwtTO): BlacklistedJwtTO

    fun deleteBlacklistedJwt(blacklistedJwtIdList: List<Long>)

    fun getBlacklistedJwtById(id: Long): BlacklistedJwtTO?
}