package hostbooks.payroll.core.blacklistedJwt.service

import hostbooks.payroll.config.redis.entity.RedisBlacklistedJwt
import hostbooks.payroll.config.redis.service.RedisBlacklistedJwtService
import hostbooks.payroll.core.blacklistedJwt.dto.BlacklistedJwtTO
import hostbooks.payroll.core.blacklistedJwt.entity.BlacklistedJwtBO
import hostbooks.payroll.core.commonDao.CommonDao
import hostbooks.payroll.core.dto.FilterInfo
import hostbooks.payroll.core.dto.HbSort
import hostbooks.payroll.shared.constant.AppEnum
import hostbooks.payroll.shared.utility.MapHandler
import hostbooks.payroll.shared.utility.model.SearchResponseTO
import jakarta.transaction.Transactional
import org.springframework.data.domain.Page
import org.springframework.data.domain.PageRequest
import org.springframework.data.domain.Pageable
import org.springframework.stereotype.Service
import java.util.*

@Service
@Transactional
open class BlacklistedJwtServiceImpl(private val commonDao: CommonDao, private val mapHandler: MapHandler, private val redisBlacklistedJwtService: RedisBlacklistedJwtService) :
    BlacklistedJwtService {

    override fun getBlacklistedJwtList(blacklistedJwtTO: BlacklistedJwtTO): SearchResponseTO<BlacklistedJwtTO> {
        val searchResponseTO = SearchResponseTO<BlacklistedJwtTO>()
        val discriminatorMap: WeakHashMap<String, FilterInfo<*>> = WeakHashMap<String, FilterInfo<*>>()
        if (blacklistedJwtTO.id != null) {
            discriminatorMap["id"] = FilterInfo(AppEnum.FilterType.EQ, blacklistedJwtTO.id)
        }
        if (!blacklistedJwtTO.jwt.isNullOrEmpty()) {
            discriminatorMap["jwt"] = FilterInfo(AppEnum.FilterType.EQ, blacklistedJwtTO.jwt)
        }
        val pageable: Pageable = PageRequest.of(0, 10)
        val sorts: List<HbSort> = listOf(HbSort("id", AppEnum.SortDirection.ASC))
        val data: Page<BlacklistedJwtBO> = commonDao.listByFilterPagination(BlacklistedJwtBO::class.java, discriminatorMap, pageable, sorts)
        searchResponseTO.list = mapHandler.mapObjectList(data.content, BlacklistedJwtTO::class.java)
        searchResponseTO.pageCount = data.totalPages.toLong()
        searchResponseTO.totalRowCount = data.totalElements
        return searchResponseTO
    }

    override fun addBlacklistedJwt(blacklistedJwtTO: BlacklistedJwtTO): BlacklistedJwtTO {
        val entity = mapHandler.mapObject(blacklistedJwtTO, BlacklistedJwtBO::class.java)
        val persistedEntity = commonDao.persistWithFlush(entity)
        val addedBlacklistedJwtTO = mapHandler.mapObject(persistedEntity, BlacklistedJwtTO::class.java)
        val redisBlacklistedJwt = mapHandler.mapObject(addedBlacklistedJwtTO, RedisBlacklistedJwt::class.java)
        if (redisBlacklistedJwt != null) {
            redisBlacklistedJwtService.addRedisBlacklistedJwt(redisBlacklistedJwt)
        }
        return addedBlacklistedJwtTO ?: blacklistedJwtTO
    }

    override fun updateBlacklistedJwt(blacklistedJwtTO: BlacklistedJwtTO): BlacklistedJwtTO {
        val entity = mapHandler.mapObject(blacklistedJwtTO, BlacklistedJwtBO::class.java)
        val updatedEntity = commonDao.updateWithFlush(entity)
        return mapHandler.mapObject(updatedEntity, BlacklistedJwtTO::class.java) ?: blacklistedJwtTO
    }

    override fun deleteBlacklistedJwt(blacklistedJwtIdList: List<Long>) {
        for (id in blacklistedJwtIdList) {
            val blacklistedJwt: BlacklistedJwtBO? = commonDao.findByPrimaryKey(BlacklistedJwtBO::class.java, id)
            if (blacklistedJwt != null) {
                commonDao.deleteWithFlush(blacklistedJwt)
            }
        }
    }

    override fun getBlacklistedJwtById(id: Long): BlacklistedJwtTO? {
        val blacklistedJwtBO: BlacklistedJwtBO? = commonDao.findByPrimaryKey(BlacklistedJwtBO::class.java, id)
        return mapHandler.mapObject(blacklistedJwtBO, BlacklistedJwtTO::class.java)
    }

}