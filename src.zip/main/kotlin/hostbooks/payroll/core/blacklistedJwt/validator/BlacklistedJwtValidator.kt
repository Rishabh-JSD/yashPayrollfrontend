package hostbooks.payroll.core.blacklistedJwt.validator

import hostbooks.payroll.core.blacklistedJwt.controller.BlacklistedJwtController
import hostbooks.payroll.core.blacklistedJwt.dto.BlacklistedJwtTO
import org.springframework.validation.Errors
import org.springframework.validation.Validator
import org.springframework.web.bind.annotation.ControllerAdvice

@ControllerAdvice(assignableTypes = [BlacklistedJwtController::class])
class BlacklistedJwtValidator : Validator {
    override fun supports(clazz: Class<*>): Boolean {
        return BlacklistedJwtTO::class.java == clazz
    }

    override fun validate(target: Any, errors: Errors) {
        if (target is BlacklistedJwtTO) {
            //logic for validation
        }
    }
}