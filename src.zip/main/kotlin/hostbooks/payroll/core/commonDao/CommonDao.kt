package hostbooks.payroll.core.commonDao

import hostbooks.payroll.core.dto.FilterInfo
import hostbooks.payroll.core.dto.HbSort
import jakarta.persistence.Tuple
import jakarta.persistence.criteria.Selection
import org.springframework.data.domain.Page
import org.springframework.data.domain.Pageable
import java.util.*

interface CommonDao {


    // ******************************* Writing Data to Database Function Start *******************************
    fun <E> persistWithFlush(model: E): E

    fun <E> updateWithFlush(model: E): E

    fun <E> persist(model: E): E

    fun <E> merge(model: E): E

    fun <E> deleteWithFlush(model: E): E

    fun <E> persistBatch(modelList: List<E>): List<E>

    fun <E> updateBatch(modelList: List<E>): List<E>

    fun <E> delete(model: E): E

    fun <E> updateBySession(model: E): E

    fun <E, T, U> updateValueByDiscriminator(
        modelClass: Class<E>, value: T, discriminator: U, valueLabel: String, discriminatorLabel: String
    )

    fun <E, T, U> updateValueBatchByDiscriminatorList(
        modelClass: Class<E>, value: T, discriminatorList: List<U>, valueLabel: String, discriminatorLabel: String
    )

    fun <E, T, U> updateValueByDiscriminators(
        modelClass: Class<E>,
        value: T,
        valueLabel: String,
        discriminators: WeakHashMap<String, U>
    )

    fun <E, T, U> updateMultipleByFilterDiscriminators(
        modelClass: Class<E>,
        labelValues: WeakHashMap<String, T>,
        discriminatorMap: WeakHashMap<String, FilterInfo<*>>
    )

    fun <E, T, U> updateMultipleByDiscriminator(
        modelClass: Class<E>,
        labelValues: WeakHashMap<String, T>,
        discriminator: U,
        discriminatorLabel: String
    )

    fun <E, T, U> updateMultipleByDiscriminators(
        modelClass: Class<E>,
        labelValues: WeakHashMap<String, T>,
        discriminators: WeakHashMap<String, U>
    )

    fun <E, U> selectLikeByMultipleDiscriminators(
        modelClass: Class<E>?,
        discriminatorValue: U,
        discriminatorLabels: List<String?>?,
        maxResults: Int
    ): List<E>?

    fun <E, U> selectLikeByMultipleDiscriminators(
        modelClass: Class<E>?,
        discriminatorMap: WeakHashMap<String?, U>?,
        maxResults: Int
    ): List<E>?

    // ******************************* Writing Data to Database Function END *******************************

    // ******************************* Read Data Details from Database Function START *******************************

    //is Valid Property Single-Select By Multi field single Value
    fun <E, V> isValidMultiDiscriminatorsSingleVal(
        modelClass: Class<E>,
        discriminatorMap: WeakHashMap<String, FilterInfo<*>>,
        propertyName: String,
        propertyClass: Class<V>
    ): Boolean

    fun <E> isExistMultiDiscriminatorsSingleVal(
        modelClass: Class<E>,
        discriminatorMap: WeakHashMap<String, FilterInfo<*>>
    ): Boolean

    fun <E, U> isExistByDiscriminators(modelClass: Class<E>, discriminatorValue: U, discriminatorLabel: String): Boolean

    // get Model By Primary Key
    fun <E> findByPrimaryKey(modelClass: Class<E>, primaryKey: Any): E?

    // get Model By Any One Field
    fun <E, U> selectSingleByDiscriminator(modelClass: Class<E>, discriminator: U, discriminatorLabel: String): E?

    // get Model Multi-Select By Any One Field
    fun <E, U, V> selectSinglePropertyByDiscriminator(
        modelClass: Class<E>,
        discriminator: U,
        discriminatorLabel: String,
        propertyNames: List<String>,
        propertyClass: Class<V>
    ): V?

    // get Model Single-Select By Any One Field
    fun <E, U, V> selectSinglePropertyByDiscriminator(
        modelClass: Class<E>,
        discriminator: U,
        discriminatorLabel: String,
        propertyName: String,
        propertyType: Class<V>
    ): V?

    // Get Model By Multi field single Value
    fun <E, U> selectSingleByMultiDiscriminatorsSingleVal(
        modelClass: Class<E>,
        discriminatorMap: WeakHashMap<String, U>
    ): E?

    // Get Model Single-Select By Multi field single Value
    fun <E, U, V> selectSingleByMultiDiscriminatorsSingleVal(
        modelClass: Class<E>,
        discriminatorMap: WeakHashMap<String, U>,
        propertyName: String,
        propertyClass: Class<V>
    ): V?

    // Get Model By Multi field single Value (List)
    fun <E, U, V> selectSingleListByMultiDiscriminatorsSingleVal(
        modelClass: Class<E>, discriminatorMap: WeakHashMap<String, U>, propertyName: String, propertyClass: Class<V>
    ): List<V>

    // Get Model By Multi field single Value
    fun <E, U, V> selectSingleByMultiDiscriminatorsSingleVal(
        modelClass: Class<E>,
        discriminatorMap: WeakHashMap<String, U>,
        propertyNames: List<String>,
        propertyType: Class<V>
    ): V?

    //List Model with No Condition
    fun <E> selectAll(modelClass: Class<E>, maxResults: Int): List<E>
    fun <E> selectAllWithGroupBy(modelClass: Class<E>, groupByLabel: String, maxResults: Int): List<E>

    fun <E, U> selectByDiscriminator(
        modelClass: Class<E>,
        discriminator: U,
        discriminatorLabel: String,
        maxResults: Int
    ): List<E>

    fun <E> selectLikeByDiscriminator(
        modelClass: Class<E>,
        discriminatorValue: String,
        discriminatorLabel: String,
        maxResults: Int
    ): List<E>

    fun <E, U> selectByMultipleDiscriminators(
        modelClass: Class<E>,
        discriminators: List<U>,
        discriminatorLabel: String,
        maxResults: Int
    ): List<E>?

    //List Model By Multi Field with Single Value
    fun <E, U> selectByMultipleDiscriminators(
        modelClass: Class<E>,
        discriminatorMap: WeakHashMap<String, U>,
        maxResults: Int
    ): List<E>?

    //List Model By Multi Field with Multi Value
    fun <E, U> selectByMultipleDiscriminatorsMultiVal(
        modelClass: Class<E>,
        discriminatorMap: WeakHashMap<String, List<U>>,
        maxResults: Int
    ): List<E>?

    //List Model By Multi Field And Any One Join Table Field
    fun <E, U> selectByJoinTableDiscriminators(
        modelClass: Class<E>,
        discriminators: String,
        childDiscriminators: String,
        childValue: U,
        discriminatorMap: WeakHashMap<String?, FilterInfo<U>>,
        maxResults: Int
    ): List<E>?

    //List Model By Multi Field with Multi Value
    fun <E, U> selectByMultipleDiscriminatorsByMultiFilter(
        modelClass: Class<E>,
        discriminatorMap: WeakHashMap<String, FilterInfo<U>>,
        maxResults: Int,
        forBranch: Boolean
    ): List<E>?

    //List Model By Multi Field with Multi Value
    fun <E, U> selectByMultipleDiscriminatorsByMultiFilterNested(
        modelClass: Class<E>?,
        discriminatorMap: WeakHashMap<String?, FilterInfo<U>?>?,
        maxResults: Int
    ): List<E>?

    fun <E, U, T, V> selectPropertiesByDiscriminator(
        modelClass: Class<E>?,
        discriminator: U,
        propertyType: Class<V>?,
        discriminatorLabel: String?,
        property: String?,
        maxResults: Int
    ): List<V>?

    fun <E, U, T, V> selectPropertiesByMultiDiscriminator(
        modelClass: Class<E>?,
        propertyType: Class<V>?,
        discriminatorMap: WeakHashMap<String?, FilterInfo<U>?>?,
        property: String?,
        discriminatorId: Int?,
        discriminator: String?,
        maxResults: Int
    ): List<V>?

    fun <E, U, T, V> selectMultiplePropertiesByDiscriminator(
        modelClass: Class<E>?,
        discriminator: U,
        discriminatorLabel: String?,
        properties: List<Selection<*>?>?,
        maxResults: Int
    ): List<Tuple?>?

    // ******************************* Read Data Search & Pagination from Database Function START *******************************
    fun <E> listByFilterPagination(
        modelClass: Class<E>,
        discriminatorMap: WeakHashMap<String, FilterInfo<*>>,
        pageable: Pageable,
        sorts: List<HbSort>?
    ): Page<E>

    fun <E, U> listByFilterPaginationNestedWIthOrExtraFilter(
        modelClass: Class<E>,
        discriminatorMap: WeakHashMap<String, FilterInfo<*>>?,
        discriminatorMap2: WeakHashMap<String, FilterInfo<*>>?,
        forOr: Boolean,
        pageable: Pageable,
        sorts: List<HbSort>,
        forNonCompany: Boolean
    ): Page<E>

    fun <E, U> listByFilterPaginationNested(
        modelClass: Class<E>,
        discriminatorMap: Map<String, FilterInfo<*>>,
        pageable: Pageable,
        sorts: List<HbSort>,
        forNonCompany: Boolean
    ): Page<E>

    fun <E, U> listByFilterPaginationNested(
        modelClass: Class<E>,
        discriminatorMap: Map<String, FilterInfo<*>>,
        pageable: Pageable,
        sorts: List<HbSort>,
        forBranch: Boolean,
        forNonCompany: Boolean
    ): Page<E>


    // ******************************* Read Data Search & Pagination Database Function END *******************************

    // ******************************* HQL Query Handler START *******************************
    fun <T> executeHQLQueryFixed(
        hqlQuery: String,
        queryParameters: WeakHashMap<String, Any>,
        resultType: Class<T>,
        maxResults: Int
    ): List<Any?>?

    fun <T> executeHQLQueryFixedPagination(
        hqlQuery: String,
        queryParameters: WeakHashMap<String, Any>,
        resultType: Class<T>,
        pageable: Pageable
    ): List<Any?>

    fun <T> executeHQLQueryForSingleResultFixed(
        hqlQuery: String,
        queryParameters: WeakHashMap<String, Any>,
        resultType: Class<T>
    ): T

    fun <T> executeHQLQuery(
        hqlQuery: String,
        resultType: Class<T>,
        maxResults: Int
    ): List<T>

    fun <T> executeHQLQueryPagination(
        hqlQuery: String,
        resultType: Class<T>,
        pageable: Pageable
    ): List<T>

    fun <T> executeHQLQueryForSingle(
        hqlQuery: String,
        resultType: Class<T>
    ): T

    fun executeHQLQueryObj(
        hqlQuery: String,
        maxResults: Int
    ): MutableList<Any?>?

    fun executeHQLQueryObjPagination(
        hqlQuery: String,
        pageable: Pageable
    ): MutableList<Any?>?

    fun executeHQLQueryObjForSingle(
        hqlQuery: String
    ): Array<Any>?

    fun executeHQLQueryDyn(
        hqlQuery: String,
        parameters: WeakHashMap<String, Any>,
        maxResults: Int
    ): List<Array<Any>>

    fun executeHQLQueryDynPagination(
        hqlQuery: String,
        parameters: WeakHashMap<String, Any>,
        pageable: Pageable
    ): List<Array<Any>>

    fun executeHQLQueryDynForSingle(
        hqlQuery: String,
        parameters: WeakHashMap<String, Any>
    ): Array<*>?
    // ******************************* HQL Query Handler START *******************************

    // ******************************* Native Query Handler START *******************************
    fun <T> executeSQLQueryFixed(
        hqlQuery: String,
        queryParameters: WeakHashMap<String, Any>,
        resultType: Class<T>,
        maxResults: Int
    ): List<T>

    fun <T> executeSQLQueryFixedPagination(
        hqlQuery: String,
        queryParameters: WeakHashMap<String, Any>,
        resultType: Class<T>,
        pageable: Pageable
    ): List<T>

    fun <T> executeSQLQueryForSingleResultFixed(
        hqlQuery: String,
        queryParameters: WeakHashMap<String, Any>,
        resultType: Class<T>
    ): T

    fun <T> executeSQLQuery(
        hqlQuery: String,
        resultType: Class<T>,
        maxResults: Int
    ): MutableList<Any?>?

    fun <T> executeSQLQueryPagination(
        hqlQuery: String,
        resultType: Class<T>,
        pageable: Pageable
    ): List<T>

    fun <T> executeSQLQueryForSingle(
        hqlQuery: String,
        resultType: Class<T>
    ): T

    fun executeSQLQueryObj(
        hqlQuery: String,
        maxResults: Int
    ): List<Array<Any>>

    fun executeSQLQueryObjPagination(
        hqlQuery: String,
        pageable: Pageable
    ): List<Array<Any>>

    fun executeSQLQueryObjForSingle(
        hqlQuery: String
    ): Any?

    fun executeSQLQueryForCount(
        hqlQuery: String
    ): Any?

    fun executeSQLQueryDyn(
        hqlQuery: String,
        parameters: WeakHashMap<String, Any>,
        maxResults: Int
    ): List<Array<Any>>

    fun executeSQLQueryDynPagination(
        hqlQuery: String,
        parameters: WeakHashMap<String, Any>,
        pageable: Pageable
    ): List<Array<out Any>>

    fun executeSQLQueryDynForSingle(hqlQuery: String, parameters: WeakHashMap<String, Any>): Array<Any>
    fun <E> count(modelClass: Class<E>, discriminatorMap: Map<String, FilterInfo<*>>): Long
    fun executeSQLQuery(
        sqlQuery: String
    ): Int
// ******************************* Native Query Handler END *******************************

}
