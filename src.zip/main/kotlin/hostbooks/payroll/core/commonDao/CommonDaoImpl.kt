package hostbooks.payroll.core.commonDao

import hostbooks.payroll.core.dto.FilterInfo
import hostbooks.payroll.core.dto.HbSort
import hostbooks.payroll.shared.constant.AppEnum.FilterType
import hostbooks.payroll.shared.utility.CommonUtil
import jakarta.persistence.EntityManager
import jakarta.persistence.PersistenceContext
import jakarta.persistence.Query
import jakarta.persistence.Tuple
import jakarta.persistence.criteria.*
import org.hibernate.Session
import org.springframework.data.domain.Page
import org.springframework.data.domain.PageImpl
import org.springframework.data.domain.Pageable
import org.springframework.stereotype.Repository
import java.util.*


@Repository
open class CommonDaoImpl : CommonDao {

    @PersistenceContext
    private lateinit var entityManager: EntityManager

    // ******************************* Writing Data to Database Function Start *******************************
    override fun <E> persistWithFlush(model: E): E {
        entityManager.persist(model)
        entityManager.flush()
        entityManager.clear()
        return model
    }

    override fun <E> updateWithFlush(model: E): E {
        val merge = entityManager.merge(model)
        entityManager.flush()
        entityManager.clear()
        return merge
    }

    override fun <E> deleteWithFlush(model: E): E {
        entityManager.remove(model)
        entityManager.flush()
        entityManager.clear()
        return model
    }

    override fun <E> persistBatch(modelList: List<E>): List<E> {
        val batchSize = 100
        for (i in modelList.indices) {
            entityManager.persist(modelList[i])
            if ((i + 1) % batchSize == 0) {
                entityManager.flush()
                entityManager.clear()
            }
        }
        entityManager.flush()
        entityManager.clear()
        return modelList
    }

    override fun <E> updateBatch(modelList: List<E>): List<E> {
        val batchSize = 100
        for (i in modelList.indices) {
            entityManager.merge(modelList[i])
            if ((i + 1) % batchSize == 0) {
                entityManager.flush()
                entityManager.clear()
            }
        }
        entityManager.flush()
        entityManager.clear()
        return modelList
    }

    override fun <E> persist(model: E): E {
        entityManager.persist(model)
        return model
    }

    override fun <E> merge(model: E): E {
        return entityManager.merge(model)
    }

    override fun <E> delete(model: E): E {
        entityManager.remove(model)
        return model
    }

    override fun <E> updateBySession(model: E): E {
        val session = entityManager.unwrap(Session::class.java)
        session.clear()
        session.merge(model)
        session.flush()
        session.clear()
        return model
    }

    override fun <E, T, U> updateValueByDiscriminator(modelClass: Class<E>, value: T, discriminator: U, valueLabel: String, discriminatorLabel: String) {
        val builder: CriteriaBuilder = entityManager.criteriaBuilder
        val update: CriteriaUpdate<E> = builder.createCriteriaUpdate(modelClass)
        val root: Root<*> = update.from(modelClass)
        update.set(valueLabel, value)
        update.where(builder.equal(root.get<E>(discriminatorLabel), discriminator))
        entityManager.createQuery(update).executeUpdate()
    }

    override fun <E, T, U> updateValueBatchByDiscriminatorList(
        modelClass: Class<E>, value: T, discriminatorList: List<U>, valueLabel: String, discriminatorLabel: String
    ) {
        val builder = entityManager.criteriaBuilder
        val update = builder.createCriteriaUpdate(modelClass)
        val root: Root<*> = update.from(modelClass)
        update[valueLabel] = value
        update.where(root.get<E>(discriminatorLabel).`in`(discriminatorList))
        entityManager.createQuery(update).executeUpdate()
    }

    override fun <E, T, U> updateValueByDiscriminators(
        modelClass: Class<E>, value: T, valueLabel: String, discriminators: WeakHashMap<String, U>
    ) {
        val builder: CriteriaBuilder = entityManager.criteriaBuilder
        val update: CriteriaUpdate<E> = builder.createCriteriaUpdate(modelClass)
        val root: Root<E> = update.from(modelClass)
        update.set(valueLabel, value)
        val predicates: Array<Predicate> =
            discriminators.entries.stream().map { entry -> builder.equal(root.get<E>(entry.key), entry.value) }
                .toArray { size -> arrayOfNulls<Predicate>(size) }
        update.where(builder.and(*predicates))
        entityManager.createQuery(update).executeUpdate()
    }

    override fun <E, T, U> updateMultipleByDiscriminator(
        modelClass: Class<E>, labelValues: WeakHashMap<String, T>, discriminator: U, discriminatorLabel: String
    ) {
        val builder: CriteriaBuilder = entityManager.criteriaBuilder
        val update: CriteriaUpdate<E> = builder.createCriteriaUpdate(modelClass)
        val root: Root<E> = update.from(modelClass)
        labelValues.forEach(update::set)
        update.where(builder.equal(root.get<E>(discriminatorLabel), discriminator))
        entityManager.createQuery(update).executeUpdate()
    }

    override fun <E, U> selectLikeByMultipleDiscriminators(
        modelClass: Class<E>?, discriminatorValue: U, discriminatorLabels: List<String?>?, maxResults: Int
    ): List<E>? {
        val builder = entityManager.criteriaBuilder
        val query: CriteriaQuery<E> = builder.createQuery(modelClass)
        val root: Root<E> = query.from(modelClass)

        val predicates = ArrayList<Predicate>()

        if (discriminatorLabels != null) {
            for (label in discriminatorLabels) {
                if (!CommonUtil.checkNullEmpty(discriminatorValue)) {
                    predicates.add(builder.like(root.get(label), "%$discriminatorValue%"))
                }
            }
        }

        query.where(builder.or(*predicates.toTypedArray()))

        return if (maxResults > 0) {
            entityManager.createQuery(query).setMaxResults(maxResults).resultList
        } else {
            entityManager.createQuery(query).resultList
        }
    }

    override fun <E, U> selectLikeByMultipleDiscriminators(
        modelClass: Class<E>?, discriminatorMap: WeakHashMap<String?, U>?, maxResults: Int
    ): List<E>? {
        val builder = entityManager.criteriaBuilder
        val query: CriteriaQuery<E> = builder.createQuery(modelClass)
        val root: Root<E> = query.from(modelClass)

        val predicates = ArrayList<Predicate>()

        if (discriminatorMap != null) {
            for ((discriminatorLabel, discriminator) in discriminatorMap) {
                predicates.add(builder.like(root.get<String>(discriminatorLabel), "%$discriminator%"))
            }
        }

        query.where(builder.or(*predicates.toTypedArray()))

        return if (maxResults > 0) {
            entityManager.createQuery(query).setMaxResults(maxResults).resultList
        } else {
            entityManager.createQuery(query).resultList
        }
    }

    override fun <E, T, U> updateMultipleByDiscriminators(
        modelClass: Class<E>, labelValues: WeakHashMap<String, T>, discriminators: WeakHashMap<String, U>
    ) {
        val builder: CriteriaBuilder = entityManager.criteriaBuilder
        val update: CriteriaUpdate<E> = builder.createCriteriaUpdate(modelClass)
        val root: Root<E> = update.from(modelClass)
        labelValues.forEach(update::set)

        val predicates: Array<Predicate> =
            discriminators.entries.stream().map { entry -> builder.equal(root.get<E>(entry.key), entry.value) }
                .toArray { size -> arrayOfNulls<Predicate>(size) }

        update.where(builder.and(*predicates))
        entityManager.createQuery(update).executeUpdate()
    }

    override fun <E, V> isValidMultiDiscriminatorsSingleVal(
        modelClass: Class<E>,
        discriminatorMap: WeakHashMap<String, FilterInfo<*>>,
        propertyName: String,
        propertyClass: Class<V>
    ): Boolean {
        val builder = entityManager.criteriaBuilder
        val query = builder.createQuery(propertyClass)
        val root = query.from(modelClass)
        val predicates = ArrayList<Predicate>()

        for ((discriminatorLabel, filterInfo) in discriminatorMap) {
            when (filterInfo.filterType) {
                FilterType.EQ -> predicates.add(
                    builder.equal(
                        root.get<V>(discriminatorLabel), filterInfo.filterValue as V
                    )
                )

                FilterType.NEQ -> predicates.add(
                    builder.notEqual(
                        root.get<V>(discriminatorLabel), filterInfo.filterValue as V
                    )
                )

                else -> {
                    return false
                }
            }
        }
        query.select(root.get<V>(propertyName))
        query.where(builder.and(*predicates.toTypedArray()))
        val list = entityManager.createQuery(query).setMaxResults(1).resultList
        return !CommonUtil.checkNullEmpty(list)
    }

    override fun <E> isExistMultiDiscriminatorsSingleVal(
        modelClass: Class<E>, discriminatorMap: WeakHashMap<String, FilterInfo<*>>
    ): Boolean {
        val builder = entityManager.criteriaBuilder
        val query = builder.createQuery(modelClass)
        val root = query.from(modelClass)
        val predicates = mutableListOf<Predicate>()

        for ((discriminatorLabel, filterInfo) in discriminatorMap) {
            when (filterInfo.filterType) {
                FilterType.EQ -> {
                    predicates.add(builder.equal(root.get<Any>(discriminatorLabel), filterInfo.filterValue))
                }

                FilterType.NEQ -> {
                    predicates.add(builder.notEqual(root.get<Any>(discriminatorLabel), filterInfo.filterValue))
                }

                FilterType.LIKE -> {
                    predicates.add(builder.like(root.get<String>(discriminatorLabel), "%${filterInfo.filterValue}%"))
                }

                FilterType.GT -> {
                    predicates.add(
                        builder.greaterThan(
                            root.get<Comparable<Any>>(discriminatorLabel), filterInfo.filterValue as Comparable<Any>
                        )
                    )
                }

                FilterType.LT -> {
                    predicates.add(
                        builder.lessThan(
                            root.get<Comparable<Any>>(discriminatorLabel), filterInfo.filterValue as Comparable<Any>
                        )
                    )
                }

                FilterType.GEQ -> {
                    predicates.add(
                        builder.greaterThanOrEqualTo(
                            root.get<Comparable<Any>>(discriminatorLabel), filterInfo.filterValue as Comparable<Any>
                        )
                    )
                }

                FilterType.LEQ -> {
                    predicates.add(
                        builder.lessThanOrEqualTo(
                            root.get<Comparable<Any>>(discriminatorLabel), filterInfo.filterValue as Comparable<Any>
                        )
                    )
                }

                else -> {
                    return false
                }
            }
        }

        query.where(builder.and(*predicates.toTypedArray()))
        val list = entityManager.createQuery(query).setMaxResults(1).resultList
        return CommonUtil.checkNullEmpty(list)
    }

    override fun <E, U> isExistByDiscriminators(
        modelClass: Class<E>, discriminatorValue: U, discriminatorLabel: String
    ): Boolean {
        val builder = entityManager.criteriaBuilder
        val query = builder.createQuery(modelClass)
        val root = query.from(modelClass)
        query.where(builder.equal(root.get<U>(discriminatorLabel), discriminatorValue))
        val list = entityManager.createQuery(query).setMaxResults(1).resultList
        return CommonUtil.checkNullEmpty(list)
    }

    override fun <E, T, U> updateMultipleByFilterDiscriminators(
        modelClass: Class<E>, labelValues: WeakHashMap<String, T>, discriminatorMap: WeakHashMap<String, FilterInfo<*>>
    ) {
        val builder: CriteriaBuilder = entityManager.criteriaBuilder
        val update: CriteriaUpdate<E> = builder.createCriteriaUpdate(modelClass)
        val root: Root<E> = update.from(modelClass)
        labelValues.forEach(update::set)
        val predicates: MutableList<Predicate> = ArrayList()
        for ((discriminatorLabel, filterInfo) in discriminatorMap) {
            if (filterInfo != null) {
                when (filterInfo.filterType) {
                    FilterType.EQ -> predicates.add(
                        builder.equal(
                            root.get<E>(discriminatorLabel), filterInfo.filterValue
                        )
                    )

                    FilterType.NEQ -> predicates.add(
                        builder.notEqual(
                            root.get<E>(discriminatorLabel), filterInfo.filterValue
                        )
                    )

                    else -> {}
                }
            }
        }
        update.where(builder.and(*predicates.toTypedArray()))
        entityManager.createQuery(update).executeUpdate()
    }
    // ******************************* Writing Data to Database Function END *******************************

    // ******************************* Read Data Details from Database Function START *******************************

    //************* Single Select Model Functions Start ***************************

    // * get Model By Primary Key
    override fun <E> findByPrimaryKey(modelClass: Class<E>, primaryKey: Any): E? {
        return entityManager.find(modelClass, primaryKey)
    }

    // * get Model By Any One Field
    override fun <E, U> selectSingleByDiscriminator(
        modelClass: Class<E>, discriminator: U, discriminatorLabel: String
    ): E? {
        val builder = entityManager.criteriaBuilder
        val query = builder.createQuery(modelClass)
        val root = query.from(modelClass)
        query.where(builder.equal(root.get<E>(discriminatorLabel), discriminator))
        return CommonUtil.getSingleResult(entityManager.createQuery(query).setMaxResults(1).resultList)
    }

    // * get Model Multi-Select By Any One Field
    override fun <E, U, V> selectSinglePropertyByDiscriminator(
        modelClass: Class<E>,
        discriminator: U,
        discriminatorLabel: String,
        propertyNames: List<String>,
        propertyClass: Class<V>
    ): V? {
        val builder = entityManager.criteriaBuilder
        val query = builder.createQuery(propertyClass)
        val root = query.from(modelClass)
        val properties = ArrayList<Selection<*>>()
        for (propertyName in propertyNames) {
            properties.add(root.get<E>(propertyName))
        }
        query.multiselect(properties)
        query.where(builder.equal(root.get<E>(discriminatorLabel), discriminator))
        return CommonUtil.getSingleResult(entityManager.createQuery(query).setMaxResults(1).resultList)
    }

    // * get Model Single-Select By Any One Field
    override fun <E, U, V> selectSinglePropertyByDiscriminator(
        modelClass: Class<E>, discriminator: U, discriminatorLabel: String, propertyName: String, propertyType: Class<V>
    ): V? {
        val builder = entityManager.criteriaBuilder
        val query = builder.createQuery(propertyType)
        val root = query.from(modelClass)
        query.select(root.get(propertyName))
        query.where(builder.equal(root.get<E>(discriminatorLabel), discriminator))
        return CommonUtil.getSingleResult(entityManager.createQuery(query).setMaxResults(1).resultList)
    }

    // * Get Model By Multi field single Value
    override fun <E, U> selectSingleByMultiDiscriminatorsSingleVal(
        modelClass: Class<E>, discriminatorMap: WeakHashMap<String, U>
    ): E? {
        val builder: CriteriaBuilder = entityManager.criteriaBuilder
        val query: CriteriaQuery<E> = builder.createQuery(modelClass)
        val root: Root<E> = query.from(modelClass)
        val predicates: MutableList<Predicate> = ArrayList()

        for ((key, value) in discriminatorMap) {
            predicates.add(builder.equal(root.get<E>(key), value))
        }

        query.where(builder.and(*predicates.toTypedArray()))

        return CommonUtil.getSingleResult(entityManager.createQuery(query).setMaxResults(1).resultList)
    }

    // * Get Model Property Single-Select By Multi field single Value
    override fun <E, U, V> selectSingleByMultiDiscriminatorsSingleVal(
        modelClass: Class<E>, discriminatorMap: WeakHashMap<String, U>, propertyName: String, propertyClass: Class<V>
    ): V? {
        val builder: CriteriaBuilder = entityManager.criteriaBuilder
        val query: CriteriaQuery<V> = builder.createQuery(propertyClass)
        val root: Root<E> = query.from(modelClass)
        val predicates: MutableList<Predicate> = ArrayList()

        for ((key, value) in discriminatorMap) {
            if (value is FilterInfo<*>) {
                val filterInfo: FilterInfo<U> = value as FilterInfo<U>
                when (filterInfo.filterType) {
                    FilterType.NEQ -> predicates.add(builder.notEqual(root.get<E>(key), filterInfo.filterValue))
                    FilterType.EQ -> predicates.add(builder.equal(root.get<E>(key), filterInfo.filterValue))
                    else -> {}
                }
            } else {
                predicates.add(builder.equal(root.get<E>(key), value))
            }
        }

        query.select(root.get(propertyName))
        query.where(builder.and(*predicates.toTypedArray()))

        return CommonUtil.getSingleResult(entityManager.createQuery(query).setMaxResults(1).resultList)
    }

    // * Get Model Property Single-Select By Multi field single Value (List)
    override fun <E, U, V> selectSingleListByMultiDiscriminatorsSingleVal(
        modelClass: Class<E>, discriminatorMap: WeakHashMap<String, U>, propertyName: String, propertyClass: Class<V>
    ): List<V> {
        val builder: CriteriaBuilder = entityManager.criteriaBuilder
        val query: CriteriaQuery<V> = builder.createQuery(propertyClass)
        val root: Root<E> = query.from(modelClass)
        val predicates: MutableList<Predicate> = ArrayList()

        for ((key, value) in discriminatorMap) {
            predicates.add(builder.equal(root.get<E>(key), value))
        }

        query.select(root.get(propertyName))
        query.where(builder.and(*predicates.toTypedArray()))

        return entityManager.createQuery(query).resultList
    }

    //List Model with No Condition
    override fun <E> selectAll(modelClass: Class<E>, maxResults: Int): List<E> {
        val builder = entityManager.criteriaBuilder
        val query = builder.createQuery(modelClass)
        val root = query.from(modelClass)
        return if (maxResults > 0) {
            entityManager.createQuery(query).setMaxResults(maxResults).resultList
        } else {
            entityManager.createQuery(query).resultList
        }
    }

    override fun <E> selectAllWithGroupBy(modelClass: Class<E>, groupByLabel: String, maxResults: Int): List<E> {
        val builder = entityManager.criteriaBuilder
        val query = builder.createQuery(modelClass)
        val root = query.from(modelClass)
        query.groupBy(root.get<E>(groupByLabel))
        return if (maxResults > 0) {
            entityManager.createQuery(query).setMaxResults(maxResults).resultList
        } else {
            entityManager.createQuery(query).resultList
        }
    }

    //List Model By Any One Field with Single Value
    override fun <E, U> selectByDiscriminator(
        modelClass: Class<E>, discriminator: U, discriminatorLabel: String, maxResults: Int
    ): List<E> {
        val builder = entityManager.criteriaBuilder
        val query = builder.createQuery(modelClass)
        val root = query.from(modelClass)
        query.where(builder.equal(root.get<U>(discriminatorLabel), discriminator))
        return if (maxResults > 0) {
            entityManager.createQuery(query).setMaxResults(maxResults).resultList
        } else {
            entityManager.createQuery(query).resultList
        }
    }

    //List Model By Any One Field with Wild Like Search
    override fun <E> selectLikeByDiscriminator(
        modelClass: Class<E>, discriminatorValue: String, discriminatorLabel: String, maxResults: Int
    ): List<E> {
        val builder = entityManager.criteriaBuilder
        val query = builder.createQuery(modelClass)
        val root = query.from(modelClass)
        query.where(builder.like(root.get<String>(discriminatorLabel), "%$discriminatorValue%"))
        return if (maxResults > 0) {
            entityManager.createQuery(query).setMaxResults(maxResults).resultList
        } else {
            entityManager.createQuery(query).resultList
        }
    }

    override fun <E, U> selectByMultipleDiscriminators(
        modelClass: Class<E>, discriminators: List<U>, discriminatorLabel: String, maxResults: Int
    ): List<E> {
        val builder = entityManager.criteriaBuilder
        val query = builder.createQuery(modelClass)
        val root = query.from(modelClass)
        query.where(root.get<U>(discriminatorLabel).`in`(discriminators))
        return if (maxResults > 0) {
            entityManager.createQuery(query).setMaxResults(maxResults).resultList
        } else {
            entityManager.createQuery(query).resultList
        }
    }

    //List Model By Any One Field with Multi Value
    override fun <E, U> selectByMultipleDiscriminators(
        modelClass: Class<E>, discriminatorMap: WeakHashMap<String, U>, maxResults: Int
    ): List<E> {
        val builder = entityManager.criteriaBuilder
        val query = builder.createQuery(modelClass)
        val root = query.from(modelClass)
        val predicates = mutableListOf<Predicate>()

        for ((discriminatorLabel, discriminator) in discriminatorMap) {
            val path = root.get<Any>(discriminatorLabel)
            val predicate = if (discriminator == null) {
                builder.isNull(path)
            } else {
                builder.equal(path, discriminator)
            }
            predicates.add(predicate)
        }

        query.where(*predicates.toTypedArray())

        return if (maxResults > 0) {
            entityManager.createQuery(query).setMaxResults(maxResults).resultList
        } else {
            entityManager.createQuery(query).resultList
        }
    }


    override fun <E, U> selectByMultipleDiscriminatorsMultiVal(
        modelClass: Class<E>, discriminatorMap: WeakHashMap<String, List<U>>, maxResults: Int
    ): List<E> {
        val builder = entityManager.criteriaBuilder
        val query = builder.createQuery(modelClass)
        val root = query.from(modelClass)
        val predicates = mutableListOf<Predicate>()

        for ((discriminatorLabel, discriminator) in discriminatorMap) {
            if (discriminator != null) {
                val path = root.get<List<U>>(discriminatorLabel)
                val predicate = path.`in`(discriminator)
                predicates.add(predicate)
            }
        }

        query.where(builder.and(*predicates.toTypedArray()))

        return if (maxResults > 0) {
            entityManager.createQuery(query).setMaxResults(maxResults).resultList
        } else {
            entityManager.createQuery(query).resultList
        }
    }
//List Model By child Any One Field

    override fun <E, U> selectByJoinTableDiscriminators(
        modelClass: Class<E>,
        discriminators: String,
        childDiscriminators: String,
        childValue: U,
        discriminatorMap: WeakHashMap<String?, FilterInfo<U>>,
        maxResults: Int
    ): List<E>? {
        val builder = entityManager.criteriaBuilder
        val query: CriteriaQuery<E> = builder.createQuery(modelClass)
        val root: Root<E> = query.from(modelClass)
        val predicates = mutableListOf<Predicate>()


        for (entry in discriminatorMap.entries) {
            val discriminatorLabel = entry.key
            val filterInfo = entry.value
            val rootPath = root.get<String>(discriminatorLabel)

            when (filterInfo.filterType) {
                FilterType.EQ -> predicates.add(builder.equal(rootPath, filterInfo.filterValue))
                FilterType.IN -> predicates.add(rootPath.`in`(filterInfo.filterValues))
                FilterType.LIKE -> predicates.add(builder.like(rootPath, "%${filterInfo.filterValue}%"))
                else -> {
                    return null
                }
            }
        }
        if (CommonUtil.checkNullEmpty(childValue)) {
            val join = root.join<Any, Any>(discriminators) // Replace Any with the actual types for the join
            predicates.add(builder.equal(join.get<String>(childDiscriminators), childValue))
        }

        query.where(*predicates.toTypedArray())

        if (maxResults > 0) {
            return entityManager.createQuery(query).setMaxResults(maxResults).resultList
        }
        return entityManager.createQuery(query).resultList
    }

    override fun <E, U> selectByMultipleDiscriminatorsByMultiFilter(
        modelClass: Class<E>, discriminatorMap: WeakHashMap<String, FilterInfo<U>>, maxResults: Int, forBranch: Boolean
    ): List<E>? {
        val builder = entityManager.criteriaBuilder
        val query: CriteriaQuery<E> = builder.createQuery(modelClass)
        val root: Root<E> = query.from(modelClass)
        val predicates = mutableListOf<Predicate>()

        for (entry in discriminatorMap.entries) {
            val discriminatorLabel = entry.key
            val filterInfo = entry.value

            when (filterInfo.filterType) {
                FilterType.EQ -> predicates.add(
                    builder.equal(
                        root.get<Any>(discriminatorLabel), filterInfo.filterValue
                    )
                )

                FilterType.IN -> predicates.add(root.get<Any>(discriminatorLabel).`in`(filterInfo.filterValues))
                FilterType.LIKE -> predicates.add(
                    builder.like(
                        root.get(discriminatorLabel), "%${filterInfo.filterValue}%"
                    )
                )

                FilterType.GT -> predicates.add(
                    builder.greaterThan(
                        root.get(discriminatorLabel), filterInfo.filterValue as Int
                    )
                )

                FilterType.NEQ -> {
                    if(filterInfo.filterValue !=null){
                        predicates.add(builder.notEqual(root.get<Any>(discriminatorLabel),  filterInfo.filterValue as Any))
                    }
                }

                FilterType.BW -> {
                    if (filterInfo.filterValues?.size == 2) {
                        predicates.add(
                            builder.greaterThanOrEqualTo(
                                root.get(discriminatorLabel), filterInfo.filterValues!![0] as Int
                            )
                        )
                        predicates.add(
                            builder.lessThan(
                                root.get(discriminatorLabel), filterInfo.filterValues!![1] as Int
                            )
                        )
                    }
                }

                FilterType.LT -> predicates.add(
                    builder.lessThan(
                        root.get(discriminatorLabel), filterInfo.filterValue as Int
                    )
                )

                FilterType.GEQ -> predicates.add(
                    builder.greaterThanOrEqualTo(
                        root.get(discriminatorLabel), filterInfo.filterValue as Int
                    )
                )

                FilterType.LEQ -> predicates.add(
                    builder.lessThanOrEqualTo(
                        root.get(discriminatorLabel), filterInfo.filterValue as Int
                    )
                )
                FilterType.FIS -> {
                    val findInSetPredicate: Predicate = builder.greaterThan(
                        builder.function(
                            "LOCATE",
                            Int::class.java,
                            builder.literal(filterInfo.filterValue.toString()),
                            root.get<Any>(discriminatorLabel) // replace with the actual column name
                        ),
                        0 // 0 represents a match in FIND_IN_SET
                    )
                    predicates.add(findInSetPredicate)
                }
                FilterType.NN->{
                    predicates.add(builder.isNotNull(root.get<Any>(discriminatorLabel)))
                }

                else -> {
                    return null
                }
            }
        }

//        if (forBranch) {
//            BranchHandler.getBranchCriteria(builder, root, predicates)
//        }

        query.where(builder.and(*predicates.toTypedArray()))

        if (maxResults > 0) {
            return entityManager.createQuery(query).setMaxResults(maxResults).resultList
        }
        return entityManager.createQuery(query).resultList
    }

    //List Model By Multi Field with Multi Value
    override fun <E, U> selectByMultipleDiscriminatorsByMultiFilterNested(
        modelClass: Class<E>?, discriminatorMap: WeakHashMap<String?, FilterInfo<U>?>?, maxResults: Int
    ): List<E>? {
        val builder = entityManager.criteriaBuilder
        val query: CriteriaQuery<E> = builder.createQuery(modelClass)
        val root: Root<E> = query.from(modelClass)
        val predicates = mutableListOf<Predicate>()

        if (discriminatorMap != null) {
            for (entry in discriminatorMap.entries) {
                val discriminatorLabel = entry.key
                val splitDiscriminatorLabel = discriminatorLabel?.split("\\.")
                var path: Path<*> = root.get<Any>(splitDiscriminatorLabel?.get(0))

                if (splitDiscriminatorLabel != null) {
                    for (i in 1 until splitDiscriminatorLabel.size) {
                        path = path.get<Any>(splitDiscriminatorLabel.get(i))
                    }
                }

                val filterInfo = entry.value

                if (filterInfo != null) {
                    when (filterInfo.filterType) {
                        FilterType.EQ -> predicates.add(builder.equal(path as Path<U>, filterInfo.filterValue))
                        FilterType.IN -> predicates.add(path.`in`(filterInfo.filterValues?.map { builder.literal(it) }))
                        FilterType.LIKE -> predicates.add(
                            builder.like(
                                path as Path<String>, "%${filterInfo.filterValue}%"
                            )
                        )

                        else -> {
                            return null
                        }
                    }
                }
            }
        }

        query.where(builder.and(*predicates.toTypedArray()))

        if (maxResults > 0) {
            return entityManager.createQuery(query).setMaxResults(maxResults).resultList
        }

        return entityManager.createQuery(query).resultList
    }

    override fun <E, U, T, V> selectPropertiesByDiscriminator(
        modelClass: Class<E>?,
        discriminator: U,
        propertyType: Class<V>?,
        discriminatorLabel: String?,
        property: String?,
        maxResults: Int
    ): List<V>? {
        val builder = entityManager.criteriaBuilder
        val query: CriteriaQuery<V> = builder.createQuery(propertyType)
        val root: Root<E> = query.from(modelClass)

        query.where(builder.equal(root.get<V>(discriminatorLabel), discriminator))
        query.select(root.get(property))

        if (maxResults > 0) {
            return entityManager.createQuery(query).setMaxResults(maxResults).resultList
        }

        return entityManager.createQuery(query).resultList
    }

    //List Model By Multi Field And One Integer Set Field
    override fun <E, U, T, V> selectPropertiesByMultiDiscriminator(
        modelClass: Class<E>?,
        propertyType: Class<V>?,
        discriminatorMap: WeakHashMap<String?, FilterInfo<U>?>?,
        property: String?,
        discriminatorId: Int?,
        discriminator: String?,
        maxResults: Int
    ): List<V>? {
        val builder = entityManager.criteriaBuilder
        val query: CriteriaQuery<V> = builder.createQuery(propertyType)
        val root: Root<E> = query.from(modelClass)
        val predicates = mutableListOf<Predicate>()

        if (discriminatorId != null) {
            val findInSetExpression = builder.function(
                "FIND_IN_SET", Integer::class.java, builder.literal(discriminatorId), root.get<String>(discriminator)
            )
            predicates.add(builder.gt(findInSetExpression, builder.literal(0)))
        }

        if (discriminatorMap != null) {
            for (entry in discriminatorMap.entries) {
                val discriminatorLabel = entry.key
                val filterInfo = entry.value

                if (filterInfo != null) {
                    when (filterInfo.filterType) {
                        FilterType.EQ -> predicates.add(
                            builder.equal(
                                root.get<String>(discriminatorLabel), filterInfo.filterValue
                            )
                        )

                        FilterType.IN -> predicates.add(
                            root.get<String>(discriminatorLabel).`in`(filterInfo.filterValues)
                        )

                        FilterType.LIKE -> predicates.add(
                            builder.like(
                                root.get<String>(discriminatorLabel), "%${filterInfo.filterValue}%"
                            )
                        )

                        FilterType.GT -> {
                            val filterValueExpression = builder.literal(filterInfo.filterValue)
                            predicates.add(
                                builder.greaterThan(
                                    root.get(discriminatorLabel), filterValueExpression as Int
                                )
                            )
                        }

                        FilterType.LT -> predicates.add(
                            builder.lessThan(
                                root.get(discriminatorLabel), filterInfo.filterValue as Int
                            )
                        )

                        FilterType.GEQ -> predicates.add(
                            builder.greaterThanOrEqualTo(
                                root.get(discriminatorLabel), filterInfo.filterValue as Int
                            )
                        )

                        FilterType.LEQ -> predicates.add(
                            builder.lessThanOrEqualTo(
                                root.get(discriminatorLabel), filterInfo.filterValue as Int
                            )
                        )

                        else -> {
                            return null
                        }
                    }
                }
            }
        }

        query.where(builder.and(*predicates.toTypedArray()))
        query.select(root.get<V>(property))

        if (maxResults > 0) {
            return entityManager.createQuery(query).setMaxResults(maxResults).resultList
        }

        return entityManager.createQuery(query).resultList
    }

    override fun <E, U, T, V> selectMultiplePropertiesByDiscriminator(
        modelClass: Class<E>?,
        discriminator: U,
        discriminatorLabel: String?,
        properties: List<Selection<*>?>?,
        maxResults: Int
    ): List<Tuple?>? {
        val builder = entityManager.criteriaBuilder
        val query: CriteriaQuery<Tuple> = builder.createTupleQuery()
        val root: Root<E> = query.from(modelClass)

        query.where(builder.equal(root.get<Any>(discriminatorLabel), discriminator))
        query.multiselect(properties)

        if (maxResults > 0) {
            return entityManager.createQuery(query).setMaxResults(maxResults).resultList
        }

        return entityManager.createQuery(query).resultList
    }

    // * Get Model Multi Property By Multi field single Value
    override fun <E, U, V> selectSingleByMultiDiscriminatorsSingleVal(
        modelClass: Class<E>,
        discriminatorMap: WeakHashMap<String, U>,
        propertyNames: List<String>,
        propertyType: Class<V>
    ): V? {
        val builder: CriteriaBuilder = entityManager.criteriaBuilder
        val query: CriteriaQuery<V> = builder.createQuery(propertyType)
        val root: Root<E> = query.from(modelClass)
        val predicates: MutableList<Predicate> = ArrayList()
        val properties: MutableList<Selection<*>> = ArrayList()
        for ((key, value) in discriminatorMap) {
            predicates.add(builder.equal(root.get<E>(key), value))
        }
        for (propertyName in propertyNames) {
            properties.add(root.get<E>(propertyName))
        }
        query.multiselect(properties)
        query.where(builder.and(*predicates.toTypedArray()))
        return CommonUtil.getSingleResult(entityManager.createQuery(query).setMaxResults(1).resultList)
    }

    // ******************************* Read Data Details from Database Function END *******************************


    // ******************************* Read Data Search & Pagination from Database Function START *******************************
    override fun <E> listByFilterPagination(
        modelClass: Class<E>,
        discriminatorMap: WeakHashMap<String, FilterInfo<*>>,
        pageable: Pageable,
        sorts: List<HbSort>?
    ): Page<E> {
        val builder = entityManager.criteriaBuilder
        val query = builder.createQuery(modelClass)
        val root = query.from(modelClass)
        val predicates = ArrayList<Predicate>()

        handlePredicate(discriminatorMap, root, builder, predicates)
        handleSorting(root, builder, sorts, query)

        if (CommonUtil.checkNullEmpty(predicates)) {
            query.where(builder.and(*predicates.toTypedArray()))
        }

        return if (!pageable.isUnpaged) {
            val typedQuery = entityManager.createQuery(query)
            typedQuery.firstResult = pageable.offset.toInt()
            typedQuery.maxResults = pageable.pageSize
            val resultList = typedQuery.resultList
            val total = count(modelClass, discriminatorMap, null)
            PageImpl(resultList, pageable, total)
        } else {
            val resultList = entityManager.createQuery(query).resultList
            val total = count(modelClass, discriminatorMap, null)
            PageImpl(resultList, pageable, total)
        }
    }

    private fun <E> count(
        modelClass: Class<E>,
        discriminatorMap: WeakHashMap<String, FilterInfo<*>>?,
        discriminatorMap2: WeakHashMap<String, FilterInfo<*>>?
    ): Long {
        val builder = entityManager.criteriaBuilder
        val query = builder.createQuery(Long::class.java)
        val root = query.from(modelClass)
        val predicates = ArrayList<Predicate>()
        val predicates2 = ArrayList<Predicate>()

        if (discriminatorMap != null) {
            handlePredicate(discriminatorMap, root, builder, predicates)
        }

        if (discriminatorMap2 != null) {
            handlePredicate(discriminatorMap2, root, builder, predicates2)
        }

        // Combine the predicates from both maps (if needed)
        predicates.addAll(predicates2)

        if (CommonUtil.checkNullEmpty(predicates)) {
            query.where(builder.and(*predicates.toTypedArray()))
        }

        query.select(builder.count(root))
        val countTypedQuery = entityManager.createQuery(query)
        return countTypedQuery.singleResult
    }

    override fun <E, U> listByFilterPaginationNestedWIthOrExtraFilter(
        modelClass: Class<E>,
        discriminatorMap: WeakHashMap<String, FilterInfo<*>>?,
        discriminatorMap2: WeakHashMap<String, FilterInfo<*>>?,
        forOr: Boolean,
        pageable: Pageable,
        sorts: List<HbSort>,
        forNonCompany: Boolean
    ): Page<E> {
        val builder = entityManager.criteriaBuilder
        val query = builder.createQuery(modelClass)
        val root = query.from(modelClass)
        val predicates = ArrayList<Predicate>()
        val predicates2 = ArrayList<Predicate>()
        if (discriminatorMap != null) {
            handlePredicate(discriminatorMap, root, builder, predicates)
        }

        //        if (modelClass == DeliveryChallanBO::class.java) {
//            BranchHandler.getBranchCriteriaInner(builder, root, predicates, "transaction")
//        } else {
//            BranchHandler.getBranchCriteria(builder, root, predicates)
//        }
//        if (VarLocalThread.isApprovalMatrixEnabled()) {
//            ApprovalHandler.applyUserWise(builder, root, predicates)
//        }
//        if (VarLocalThread.isNonCompany() && forNonCompany) {
//            BranchHandler.getNonCompanyCriteria(builder, root, predicates, null)
//        }

        if (CommonUtil.checkNullEmpty(discriminatorMap2)) {
            if (discriminatorMap2 != null) {
                handlePredicate(discriminatorMap2, root, builder, predicates2)
            }
        }

        if (CommonUtil.checkNullEmpty(predicates2) && forOr) {
            query.where(
                builder.or(builder.and(*predicates.toTypedArray()), builder.and(*predicates2.toTypedArray()))
            )
        } else {
            query.where(builder.and(*predicates.toTypedArray()))
        }

        handleSorting(root, builder, sorts, query)
        val typedQuery = entityManager.createQuery(query)
        typedQuery.firstResult = pageable.offset.toInt()
        typedQuery.maxResults = pageable.pageSize
        val resultList = typedQuery.resultList

        val countQuery = builder.createQuery(Long::class.java)
        countQuery.select(builder.count(countQuery.from(modelClass)))

        if (CommonUtil.checkNullEmpty(predicates2) && forOr) {
            countQuery.where(
                builder.or(
                    builder.and(*predicates.toTypedArray()), builder.and(*predicates2.toTypedArray())
                )
            )
        } else {
            countQuery.where(builder.and(*predicates.toTypedArray()))
        }

        val total = this.count(modelClass, discriminatorMap, discriminatorMap2)
        return PageImpl(resultList, pageable, total)
    }

    override fun <E, U> listByFilterPaginationNested(
        modelClass: Class<E>,
        discriminatorMap: Map<String, FilterInfo<*>>,
        pageable: Pageable,
        sorts: List<HbSort>,
        forNonCompany: Boolean
    ): Page<E> {
        return this.listByFilterPaginationNested<E, U>(
            modelClass, discriminatorMap, pageable, sorts, true, forNonCompany
        )
    }

    override fun <E, U> listByFilterPaginationNested(
        modelClass: Class<E>,
        discriminatorMap: Map<String, FilterInfo<*>>,
        pageable: Pageable,
        sorts: List<HbSort>,
        forBranch: Boolean,
        forNonCompany: Boolean
    ): Page<E> {
        val builder = entityManager.criteriaBuilder
        val query = builder.createQuery(modelClass)
        val root = query.from(modelClass)
        val predicates = ArrayList<Predicate>()
        handlePredicate(discriminatorMap, root, builder, predicates)
//        if (forBranch) {
//            if (modelClass == DeliveryChallanBO::class.java) {
//                BranchHandler.getBranchCriteriaInner(builder, root, predicates, "transaction")
//            } else {
//                BranchHandler.getBranchCriteria(builder, root, predicates)
//            }
//        }
//        if (VarLocalThread.isApprovalMatrixEnabled()) {
//            ApprovalHandler.applyUserWise(builder, root, predicates)
//        }
//        if (VarLocalThread.isNonCompany() && forNonCompany) {
//            BranchHandler.getNonCompanyCriteria(builder, root, predicates, null)
//        }
        query.where(builder.and(*predicates.toTypedArray()))
        handleSorting(root, builder, sorts, query)
        val typedQuery = entityManager.createQuery(query)
        typedQuery.firstResult = pageable.offset.toInt()
        typedQuery.maxResults = pageable.pageSize
        val resultList = typedQuery.resultList
        val total = count(modelClass, discriminatorMap)
        return PageImpl(resultList, pageable, total)
    }

    override fun <T> executeHQLQueryFixed(
        hqlQuery: String, queryParameters: WeakHashMap<String, Any>, resultType: Class<T>, maxResults: Int
    ): List<Any?>? {
        val query: Query = entityManager.createQuery(hqlQuery, resultType)
        for ((key, value) in queryParameters) {
            query.setParameter(key, value)
        }
        return query.setMaxResults(maxResults).resultList
    }


    override fun <T> executeHQLQueryFixedPagination(
        hqlQuery: String, queryParameters: WeakHashMap<String, Any>, resultType: Class<T>, pageable: Pageable
    ): List<Any?> {
        val query: Query = entityManager.createQuery(hqlQuery, resultType)
        for ((key, value) in queryParameters) {
            query.setParameter(key, value)
        }
        query.firstResult = pageable.offset.toInt()
        query.maxResults = pageable.pageSize
        return query.resultList
    }

    override fun <T> executeHQLQueryForSingleResultFixed(
        hqlQuery: String, queryParameters: WeakHashMap<String, Any>, resultType: Class<T>
    ): T {
        val query = entityManager.createQuery(hqlQuery, resultType)
        for ((key, value) in queryParameters) {
            query.setParameter(key, value)
        }
        return query.resultList.singleOrNull() as T
    }


    override fun <T> executeHQLQuery(hqlQuery: String, resultType: Class<T>, maxResults: Int): List<T> {
        val query = entityManager.createQuery(hqlQuery, resultType)
        return query.setMaxResults(maxResults).resultList
    }

    override fun <T> executeHQLQueryPagination(hqlQuery: String, resultType: Class<T>, pageable: Pageable): List<T> {
        val query = entityManager.createQuery(hqlQuery, resultType)
        query.firstResult = pageable.offset.toInt()
        query.maxResults = pageable.pageSize
        return query.resultList
    }

    override fun <T> executeHQLQueryForSingle(hqlQuery: String, resultType: Class<T>): T {
        val query = entityManager.createQuery(hqlQuery, resultType)
        return CommonUtil.getSingleResult(query.resultList) as T
    }

    override fun executeHQLQueryObj(hqlQuery: String, maxResults: Int): MutableList<Any?>? {
        val query = entityManager.createQuery(hqlQuery)
        return query.setMaxResults(maxResults).resultList
    }

    override fun executeHQLQueryObjPagination(hqlQuery: String, pageable: Pageable): MutableList<Any?>? {
        val query = entityManager.createQuery(hqlQuery)
        query.firstResult = pageable.offset.toInt()
        query.maxResults = pageable.pageSize
        return query.resultList

    }

    override fun executeHQLQueryObjForSingle(hqlQuery: String): Array<Any>? {
        val query = entityManager.createQuery(hqlQuery)
        return CommonUtil.getSingleResult(query.resultList) as Array<Any>?
    }

    override fun executeHQLQueryDyn(
        hqlQuery: String, parameters: WeakHashMap<String, Any>, maxResults: Int
    ): List<Array<Any>> {
        val query = entityManager.createQuery(hqlQuery)
        for ((key, value) in parameters) {
            query.setParameter(key, value)
        }
        return query.setMaxResults(maxResults).resultList as List<Array<Any>>
    }

    override fun executeHQLQueryDynPagination(
        hqlQuery: String, parameters: WeakHashMap<String, Any>, pageable: Pageable
    ): List<Array<Any>> {
        val query = entityManager.createQuery(hqlQuery)
        for ((key, value) in parameters) {
            query.setParameter(key, value)
        }
        query.firstResult = pageable.offset.toInt()
        query.maxResults = pageable.pageSize
        return query.resultList as List<Array<Any>>
    }


    override fun executeHQLQueryDynForSingle(hqlQuery: String, parameters: WeakHashMap<String, Any>): Array<*>? {
        val query = entityManager.createQuery(hqlQuery)
        for ((key, value) in parameters) {
            query.setParameter(key, value)
        }
        return CommonUtil.getSingleResult(query.resultList) as Array<*>?
    }


    override fun <T> executeSQLQueryFixed(
        hqlQuery: String, queryParameters: WeakHashMap<String, Any>, resultType: Class<T>, maxResults: Int
    ): List<T> {
        val query = entityManager.createNativeQuery(hqlQuery, resultType)
        for ((key, value) in queryParameters) {
            query.setParameter(key, value)
        }
        return query.setMaxResults(maxResults).resultList as List<T>
    }

    override fun <T> executeSQLQueryFixedPagination(
        hqlQuery: String, queryParameters: WeakHashMap<String, Any>, resultType: Class<T>, pageable: Pageable
    ): List<T> {
        val query = entityManager.createNativeQuery(hqlQuery, resultType)
        for ((key, value) in queryParameters) {
            query.setParameter(key, value)
        }
        query.firstResult = pageable.offset.toInt()
        query.maxResults = pageable.pageSize
        return query.resultList as List<T>
    }


    override fun <T> executeSQLQueryForSingleResultFixed(
        hqlQuery: String, queryParameters: WeakHashMap<String, Any>, resultType: Class<T>
    ): T {
        val query = entityManager.createNativeQuery(hqlQuery, resultType)
        for ((key, value) in queryParameters) {
            query.setParameter(key, value)
        }
        return CommonUtil.getSingleResult(query.resultList) as T
    }


    override fun <T> executeSQLQuery(hqlQuery: String, resultType: Class<T>, maxResults: Int): MutableList<Any?>? {
        val query = entityManager.createNativeQuery(hqlQuery, resultType)
        if (maxResults > 0) {
            return query.setMaxResults(maxResults).resultList
        }
        return query.resultList
    }


    override fun executeSQLQuery(sqlQuery: String): Int {
        val query = entityManager.createNativeQuery(sqlQuery)
        return query.executeUpdate()
    }


    override fun <T> executeSQLQueryPagination(hqlQuery: String, resultType: Class<T>, pageable: Pageable): List<T> {
        val query = entityManager.createNativeQuery(hqlQuery, resultType)
        query.firstResult = pageable.offset.toInt()
        query.maxResults = pageable.pageSize
        return query.resultList as List<T>
    }


    override fun <T> executeSQLQueryForSingle(hqlQuery: String, resultType: Class<T>): T {
        val query = entityManager.createNativeQuery(hqlQuery, resultType)
        return CommonUtil.getSingleResult(query.resultList) as T
    }

    override fun executeSQLQueryObj(hqlQuery: String, maxResults: Int): List<Array<Any>> {
        val query = entityManager.createNativeQuery(hqlQuery)
        return query.setMaxResults(maxResults).resultList as List<Array<Any>>
    }

    override fun executeSQLQueryObjPagination(hqlQuery: String, pageable: Pageable): List<Array<Any>> {
        val query = entityManager.createNativeQuery(hqlQuery)
        query.firstResult = pageable.offset.toInt()
        query.maxResults = pageable.pageSize
        return query.resultList as List<Array<Any>>
    }


    override fun executeSQLQueryObjForSingle(hqlQuery: String): Any? {
        val query: Query = entityManager.createNativeQuery(hqlQuery)
        return CommonUtil.getSingleResult(query.resultList)
    }


    override fun executeSQLQueryForCount(hqlQuery: String): Any? {
        val query: Query = entityManager.createNativeQuery(hqlQuery)
        return CommonUtil.getSingleResult(query.resultList)
    }

    override fun executeSQLQueryDyn(
        hqlQuery: String, parameters: WeakHashMap<String, Any>, maxResults: Int
    ): List<Array<Any>> {
        val query = entityManager.createNativeQuery(hqlQuery)
        parameters.forEach { (key, value) ->
            query.setParameter(key, value)
        }
        return query.setMaxResults(maxResults).resultList as List<Array<Any>>
    }


    override fun executeSQLQueryDynPagination(
        hqlQuery: String, parameters: WeakHashMap<String, Any>, pageable: Pageable
    ): List<Array<out Any>> {
        val query: Query = entityManager.createNativeQuery(hqlQuery)
        for ((key, value) in parameters) {
            query.setParameter(key, value)
        }
        query.firstResult = pageable.offset.toInt()
        query.maxResults = pageable.pageSize
        return query.resultList as List<Array<out Any>>
    }

    override fun executeSQLQueryDynForSingle(hqlQuery: String, parameters: WeakHashMap<String, Any>): Array<Any> {
        val query: Query = entityManager.createNativeQuery(hqlQuery)
        for ((key, value) in parameters.entries) {
            query.setParameter(key, value)
        }
        return query.resultList.single() as Array<Any>
    }

    override fun <E> count(modelClass: Class<E>, discriminatorMap: Map<String, FilterInfo<*>>): Long {
        val builder = entityManager.criteriaBuilder
        val countQuery = builder.createQuery(Long::class.java)
        val countRoot = countQuery.from(modelClass)
        val predicates = ArrayList<Predicate>()
        handlePredicate(discriminatorMap, countRoot, builder, predicates)
        countQuery.select(builder.count(countRoot))
        if (CommonUtil.checkNullEmpty(predicates)) {
            countQuery.where(builder.and(*predicates.toTypedArray()))
        }
        return entityManager.createQuery(countQuery).singleResult
    }


    // Helper method to create Sorting
    private fun <E> handleSorting(
        root: Root<E>, builder: CriteriaBuilder, sorts: List<HbSort>?, query: CriteriaQuery<E>
    ) {
        if (!sorts.isNullOrEmpty()) {
            val orderList = ArrayList<Order>()
            for (sort in sorts) {
                var path: Path<E>? = null
                if (CommonUtil.checkNullEmpty(sort.property)) {
                    if (sort.property.contains(".")) {
                        val sortingLabel = sort.property.split("\\.".toRegex()).toTypedArray()
                        path = root.get(sortingLabel[0])
                        for (i in 1 until sortingLabel.size) {
                            if (path != null) {
                                path = path.get(sortingLabel[i])
                            }
                        }
                    } else {
                        path = root.get(sort.property)
                    }
                }
                if (path != null) {
                    if (sort.direction.name == "ASC") {
                        orderList.add(builder.asc(path))
                    } else {
                        orderList.add(builder.desc(path))
                    }
                }
            }
            query.orderBy(orderList)
        }
    }


    // Helper method to create predicate based on filter type
    private fun <E> handlePredicate(
        discriminatorMap: Map<String, FilterInfo<*>?>,
        root: Root<E>,
        builder: CriteriaBuilder,
        predicates: MutableList<Predicate>
    ) {
        for ((discriminatorLabel, discriminatorFilter) in discriminatorMap) {
            var path: Path<E>
            if (discriminatorFilter != null) {
                if (discriminatorFilter.filterType == FilterType.OR) {
                    // Handle OR case
                    val orPredicates = ArrayList<Predicate>()
                    for ((orEntryKey, orEntryValue) in discriminatorFilter.orFilterInfo?.entries ?: emptySet()) {
                        val splitDiscriminatorLabel = orEntryKey.split("\\.".toRegex()).toTypedArray()
                        var orPath = root.get<E>(splitDiscriminatorLabel[0])
                        for (i in 1 until splitDiscriminatorLabel.size) {
                            orPath = orPath.get(splitDiscriminatorLabel[i])
                        }
                        createPredicate(builder, orPath, orEntryValue)?.let { orPredicates.add(it) }
                    }
                    predicates.add(builder.or(*orPredicates.toTypedArray()))
                } else if (discriminatorFilter.filterType == FilterType.IN) {
                    if(discriminatorFilter.filterValues!=null){
                        predicates.add(root.get<E>(discriminatorLabel).`in`(discriminatorFilter.filterValues))
                    }
                } else {
                    // Handle non-OR case
                    val splitDiscriminatorLabel = discriminatorLabel.split("\\.".toRegex()).toTypedArray()
                    path = root.get(splitDiscriminatorLabel[0])
                    for (i in 1 until splitDiscriminatorLabel.size) {
                        path = path.get(splitDiscriminatorLabel[i])
                    }
                    createPredicate(builder, path, discriminatorFilter)?.let { predicates.add(it) }
                }
            }
        }
    }


    private fun <E> createPredicate(
        builder: CriteriaBuilder, path: Path<E>, discriminatorFilter: FilterInfo<*>
    ): Predicate? {
        return when (discriminatorFilter.filterType) {
            FilterType.EQ -> builder.equal(path, discriminatorFilter.filterValue)
            FilterType.NEQ -> builder.notEqual(path, discriminatorFilter.filterValue)
            FilterType.LIKE -> {
                if (discriminatorFilter.filterValue is String) {
                    builder.like(path as Expression<String>, "%" + discriminatorFilter.filterValue + "%")
                } else {
                    null // Handle the case when the filter value is not a string
                }
            }

            FilterType.IN -> path.`in`(discriminatorFilter.filterValues)
            FilterType.GT -> {
                if (discriminatorFilter.filterValue is Int) {
                    builder.greaterThan(path as Expression<Int>, discriminatorFilter.filterValue as Int)
                } else {
                    builder.conjunction()
                }
            }

            FilterType.LT -> {
                if (discriminatorFilter.filterValue is Comparable<*>) {
                    builder.lessThan(path as Expression<Int>, discriminatorFilter.filterValue as Int)
                } else {
                    builder.conjunction()
                }
            }

            FilterType.GEQ -> {
                if (discriminatorFilter.filterValue is Comparable<*>) {
                    builder.greaterThanOrEqualTo(path as Expression<Int>, discriminatorFilter.filterValue as Int)
                } else {
                    builder.conjunction()
                }
            }

            FilterType.LEQ -> {
                if (discriminatorFilter.filterValue is Comparable<*>) {
                    builder.lessThanOrEqualTo(path as Expression<Int>, discriminatorFilter.filterValue as Int)
                } else {
                    builder.conjunction()
                }
            }

//            FilterType.BW -> {
//                if (discriminatorFilter.filterValues?.size == 2) {
//                    val bwStartValue = discriminatorFilter.filterValues?.get(0) as Int
//                    val bwEndValue = discriminatorFilter.filterValues!![1] as Int
//                    return builder.between(path as Expression<Int>, bwStartValue, bwEndValue) // Return the result
//                } else {
//                    return null
//                }
//            }

            FilterType.BW -> {
                if (discriminatorFilter.filterValues?.size == 2) {
                    val startValue = discriminatorFilter.filterValues?.get(0)
                    val endValue = discriminatorFilter.filterValues!![1]

                    // Handle both Int and Date
                    when (startValue) {
                        is Int -> {
                            val bwStartValue = startValue
                            val bwEndValue = endValue as Int
                            return builder.between(path as Expression<Int>, bwStartValue, bwEndValue)
                        }
                        is Date -> {
                            val bwStartDate = startValue
                            val bwEndDate = endValue as Date
                            return builder.between(path as Expression<Date>, bwStartDate, bwEndDate)
                        }
                        else -> {
                            // Handle other types or return null
                            return null
                        }
                    }
                } else {
                    // Handle the case where filterValues size is not 2
                    // You may want to throw an exception or handle it appropriately
                    return null
                }
            }


            FilterType.NIN -> {
                val inClause = builder.`in`(path as Expression<E>)
                val values = discriminatorFilter.filterValues?.filterNotNull() as E // Filter out null values
                inClause.value(values)
                return builder.and(builder.not(inClause))
            }

            FilterType.NN -> return builder.isNotNull(path)
            else -> return null
        }
    }

}
