package hostbooks.payroll.core.constant

object CoreConst {

    const val IS_DEMO_LOGIN = false
    const val DEFAULT_CLIENT_DB = "hb_payroll_default_client"
    const val MASTER_DB = "hb_payroll_master"

    object HttpMethod {
        const val GET = "GET"
        const val POST = "POST"
        const val GET_VIA_POST = "GET_VIA_POST"
        const val PUT = "PUT"
        const val DELETE = "DELETE"
        const val OPTIONS = "OPTIONS"
    }

    // Request Headers
    private const val AUTHORIZATION = "Authorization"
    const val TENANT_CODE = "X-Tenant"
    val HTTP_ALLOWED_METHODS = listOf(HttpMethod.GET, HttpMethod.POST, HttpMethod.GET_VIA_POST, HttpMethod.PUT, HttpMethod.DELETE, HttpMethod.OPTIONS)
    val HTTP_ALLOWED_HEADERS = listOf(
        AUTHORIZATION,
        TENANT_CODE,
        "Accept",
        "Content-Type",
        "Access-Control-Allow-Origin",
        "Access-Control-Request-Method",
        "Access-Control-Request-Headers",
        HttpMethod.GET_VIA_POST
    )

    object PermittedRequestPath {
        private const val LOGIN = "/payroll/login"
        private const val REGISTER = "/payroll/register"
        private const val RESET_PASSWORD = "/payroll/reset-password"
        private const val GRAPHIQL = "/graphiql"
        private const val GRAPHQL = "/graphql"

        val PUBLIC_PATHS = listOf(LOGIN, REGISTER, RESET_PASSWORD)
        val GRAPHQL_PATHS = listOf(GRAPHIQL, GRAPHQL)
    }
}
