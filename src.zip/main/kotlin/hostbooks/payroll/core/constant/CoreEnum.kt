package hostbooks.payroll.core.constant

class CoreEnum {
    enum class RequestType {
        READ,
        WRITE
    }
}