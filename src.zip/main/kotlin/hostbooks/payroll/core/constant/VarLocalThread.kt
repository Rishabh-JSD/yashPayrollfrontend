package hostbooks.payroll.core.constant

import org.springframework.stereotype.Component

@Component
class VarLocalThread {
    companion object {
        private val decimalLimit = ThreadLocal<Int>()
        private val requestType = ThreadLocal<String>()

        init {
            setDecimalLimit(2)
        }

        // DECIMAL LIMIT SETTINGS
        fun setDecimalLimit(limit: Int) {
            decimalLimit.set(limit)
        }

        fun getDecimalLimit(): Int? {
            return decimalLimit.get()
        }

        fun setRequestType(requestType: String) {
            Companion.requestType.set(requestType)
        }

        fun getRequestType(): String? {
            return requestType.get()
        }
    }
}