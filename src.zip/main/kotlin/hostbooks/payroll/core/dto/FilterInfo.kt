package hostbooks.payroll.core.dto

import hostbooks.payroll.shared.constant.AppEnum
import java.util.*

class FilterInfo<U> {
    var filterType: AppEnum.FilterType
    var filterValue: U? = null
    val fieldType: Class<*>? = null
    var filterValues: List<*>? = null
    var orFilterInfo: WeakHashMap<String, FilterInfo<*>>? = null

    constructor(filterType: AppEnum.FilterType, filterValue: U) {
        this.filterType = filterType
        this.filterValue = filterValue
    }

    constructor(filterType: AppEnum.FilterType, orFilterInfo: WeakHashMap<String, FilterInfo<*>>?, filterValue: U) {
        this.orFilterInfo = orFilterInfo
        this.filterValue = filterValue
        this.filterType = filterType
    }

    constructor(filterType: AppEnum.FilterType, filterValue: List<*>?) {
        this.filterType = filterType
        this.filterValues = filterValue
    }

    constructor(filterType: AppEnum.FilterType, startValue: U, endValue: U) {
        this.filterType = filterType
        this.filterValue = startValue
        this.filterValues = listOf(startValue, endValue)
    }
}