package hostbooks.payroll.core.dto

import hostbooks.payroll.shared.constant.AppEnum


class HbSort(var property: String, var direction: AppEnum.SortDirection)

