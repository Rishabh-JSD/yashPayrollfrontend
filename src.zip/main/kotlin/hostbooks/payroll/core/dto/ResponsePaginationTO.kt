package hostbooks.payroll.core.dto

import lombok.Getter
import lombok.Setter

@Getter
@Setter
data class ResponsePaginationTO<T>(
    var pageCount: Int,
    var totalRowCount: Int,
    var list: List<T>?
)
