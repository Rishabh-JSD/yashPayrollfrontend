package hostbooks.payroll.core.exception

class CompanyDetailsUnavailableException(message: String) : Exception(message) {
    companion object {
        private const val serialVersionUID: Long = -3387516993124239959L
    }
}