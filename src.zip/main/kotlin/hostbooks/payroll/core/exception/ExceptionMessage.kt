package hostbooks.payroll.core.exception

import com.fasterxml.jackson.annotation.JsonFormat
import java.time.LocalDateTime

data class ExceptionMessage(
    val status: Int? = null,
    val customMessage: String? = null,
    val exMessage: String? = null,
    val path: String? = null,

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yyyy hh:mm:ss")
    val timestamp: LocalDateTime = LocalDateTime.now()
)
