package hostbooks.payroll.core.exception

import io.jsonwebtoken.ExpiredJwtException
import io.jsonwebtoken.JwtException
import org.springframework.http.HttpHeaders
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.security.core.userdetails.UsernameNotFoundException
import org.springframework.web.bind.annotation.ControllerAdvice
import org.springframework.web.bind.annotation.ExceptionHandler
import org.springframework.web.context.request.ServletWebRequest
import org.springframework.web.context.request.WebRequest

@ControllerAdvice
class GlobalExceptionHandler {

    @ExceptionHandler(Exception::class)
    fun handleOtherExceptions(ex: Exception, webRequest: WebRequest): ResponseEntity<Any> {
        val requestUri = (webRequest as ServletWebRequest).request.requestURI
        val exceptionMessage = ExceptionMessage(
            status = HttpStatus.INTERNAL_SERVER_ERROR.value(),
            customMessage = "Something Went Wrong Please Try Again Or Contact Support",
            exMessage = ex.message,
            path = requestUri
        )
        ex.printStackTrace()
        return ResponseEntity(exceptionMessage, HttpHeaders(), HttpStatus.OK)
    }

    @ExceptionHandler(CustomException::class)
    fun handleCustomExceptions(ex: Exception, webRequest: WebRequest): ResponseEntity<Any> {
        val requestUri = (webRequest as ServletWebRequest).request.requestURI
        val exceptionMessage =
            ExceptionMessage(status = HttpStatus.INTERNAL_SERVER_ERROR.value(), customMessage = "Something Went Wrong", exMessage = ex.message, path = requestUri)
        ex.printStackTrace()
        return ResponseEntity(exceptionMessage, HttpHeaders(), HttpStatus.OK)
    }

    @ExceptionHandler(ExpiredJwtException::class)
    fun handleExpiredJwtException(ex: ExpiredJwtException, webRequest: WebRequest): ResponseEntity<Any> {
        val requestUri = (webRequest as ServletWebRequest).request.requestURI
        val exceptionMessage = ExceptionMessage(status = HttpStatus.FORBIDDEN.value(), customMessage = "Expired Jwt Exception", exMessage = ex.message, path = requestUri)
        return ResponseEntity(exceptionMessage, HttpHeaders(), HttpStatus.OK)
    }

    @ExceptionHandler(JwtException::class)
    fun handleJwtException(ex: JwtException, webRequest: WebRequest): ResponseEntity<Any> {
        val requestUri = (webRequest as ServletWebRequest).request.requestURI
        val exceptionMessage = ExceptionMessage(status = HttpStatus.FORBIDDEN.value(), customMessage = "Claim Jwt Exception", exMessage = ex.message, path = requestUri)
        return ResponseEntity(exceptionMessage, HttpHeaders(), HttpStatus.OK)
    }

    @ExceptionHandler(UserNotFoundException::class)
    fun handleUserNotFoundException(ex: UserNotFoundException, webRequest: WebRequest): ResponseEntity<Any> {
        val requestUri = (webRequest as ServletWebRequest).request.requestURI
        val exceptionMessage = ExceptionMessage(status = HttpStatus.UNAUTHORIZED.value(), customMessage = "User not found.", exMessage = ex.message, path = requestUri)
        return ResponseEntity(exceptionMessage, HttpHeaders(), HttpStatus.OK)
    }

    @ExceptionHandler(UsernameNotFoundException::class)
    fun handleUsernameNotFoundException(ex: UsernameNotFoundException, webRequest: WebRequest): ResponseEntity<Any> {
        val requestUri = (webRequest as ServletWebRequest).request.requestURI
        val exceptionMessage = ExceptionMessage(status = HttpStatus.UNAUTHORIZED.value(), customMessage = "Username not found.", exMessage = ex.message, path = requestUri)
        return ResponseEntity(exceptionMessage, HttpHeaders(), HttpStatus.OK)
    }

    @ExceptionHandler(PasswordMismatchException::class)
    fun handlePasswordMismatchException(ex: PasswordMismatchException, webRequest: WebRequest): ResponseEntity<Any> {
        val requestUri = (webRequest as ServletWebRequest).request.requestURI
        val exceptionMessage = ExceptionMessage(status = HttpStatus.UNAUTHORIZED.value(), customMessage = "Password mismatch.", exMessage = ex.message, path = requestUri)
        return ResponseEntity(exceptionMessage, HttpHeaders(), HttpStatus.OK)
    }

    @ExceptionHandler(InvalidRequestHeaderException::class)
    fun handleInvalidRequestHeaderException(
        ex: InvalidRequestHeaderException, webRequest: WebRequest
    ): ResponseEntity<Any> {
        val requestUri = (webRequest as ServletWebRequest).request.requestURI
        val exceptionMessage = ExceptionMessage(status = HttpStatus.BAD_REQUEST.value(), customMessage = "Invalid request header.", exMessage = ex.message, path = requestUri)
        return ResponseEntity(exceptionMessage, HttpHeaders(), HttpStatus.OK)
    }

    @ExceptionHandler(CompanyDetailsUnavailableException::class)
    fun handleCompanyDetailsUnavailableException(
        ex: CompanyDetailsUnavailableException, webRequest: WebRequest
    ): ResponseEntity<Any> {
        val requestUri = (webRequest as ServletWebRequest).request.requestURI
        val exceptionMessage =
            ExceptionMessage(status = HttpStatus.BAD_REQUEST.value(), customMessage = "Company Details Unavailable.", exMessage = ex.message, path = requestUri)
        return ResponseEntity(exceptionMessage, HttpHeaders(), HttpStatus.OK)
    }
}
