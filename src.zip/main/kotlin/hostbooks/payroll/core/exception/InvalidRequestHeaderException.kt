package hostbooks.payroll.core.exception

class InvalidRequestHeaderException(message: String) : Exception(message) {
    companion object {
        private const val serialVersionUID: Long = -3387516993124229959L
    }
}