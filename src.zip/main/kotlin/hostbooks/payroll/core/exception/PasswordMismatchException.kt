package hostbooks.payroll.core.exception

class PasswordMismatchException(message: String) : Exception(message) {
    companion object {
        private const val serialVersionUID: Long = -3387516993124229459L
    }
}
