package hostbooks.payroll.core.tenant

import hostbooks.payroll.shared.utility.model.SearchRequestTO

class TenantSearchRequestTO : SearchRequestTO() {
    var name: String? = null
}