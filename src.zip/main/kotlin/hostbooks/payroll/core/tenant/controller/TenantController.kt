package hostbooks.payroll.core.tenant.controller

import hostbooks.payroll.core.tenant.TenantSearchRequestTO
import hostbooks.payroll.core.tenant.dto.TenantTO
import hostbooks.payroll.core.tenant.dto.UserTenantTO
import hostbooks.payroll.core.tenant.service.TenantService
import hostbooks.payroll.shared.utility.ValidationError
import hostbooks.payroll.shared.utility.model.ResponseTO
import hostbooks.payroll.shared.utility.model.SearchResponseTO
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.validation.Errors
import org.springframework.validation.Validator
import org.springframework.web.bind.WebDataBinder
import org.springframework.web.bind.annotation.*
import javax.validation.Valid


@RestController
@RequestMapping("/tenant")
class TenantController(private val tenantService: TenantService, private val tenantValidator: Validator) {

    @InitBinder
    private fun initBinder(binder: WebDataBinder) {
        binder.validator = this.tenantValidator
    }

    @PostMapping("/add")
    fun addTenant(@Valid @RequestBody tenantTO: TenantTO, errors: Errors): ResponseEntity<*> {
        if (errors.hasErrors()) {
            val validationError: ValidationError = ValidationError.fromBindingErrors(errors)
            return ResponseEntity<Any>(validationError, HttpStatus.OK)
        }
        val addedTenantTO: TenantTO = tenantService.addTenant(tenantTO)
        val responseDTO = ResponseTO.responseBuilder(200, "COM09", "/tenant/add", "tenant", addedTenantTO)
        return ResponseEntity<Any>(responseDTO, HttpStatus.CREATED)
    }

    @PutMapping("/update")
    fun updateTenant(@Valid @RequestBody tenantTO: TenantTO, errors: Errors): ResponseEntity<*> {
        if (errors.hasErrors()) {
            val validationError: ValidationError = ValidationError.fromBindingErrors(errors)
            return ResponseEntity<Any>(validationError, HttpStatus.OK)
        }
        val updatedTenantTO: TenantTO = tenantService.updateTenant(tenantTO)
        val responseDTO = ResponseTO.responseBuilder(200, "COM02", "/tenant/update", "tenant", updatedTenantTO)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }

    @PostMapping("/list")
    fun getTenantList(@RequestBody tenantSearchRequestTO: TenantSearchRequestTO): ResponseEntity<*> {
        val responseTO: SearchResponseTO<TenantTO> = tenantService.getTenantList(tenantSearchRequestTO)
        val response = ResponseTO.responseBuilder(200, "COM04", "/tenant/list", "tenant", responseTO)
        return ResponseEntity<ResponseTO>(response, HttpStatus.OK)
    }

    @PostMapping("/list/by-user")
    fun getTenantListByUser(@RequestBody tenantSearchRequestTO: TenantSearchRequestTO): ResponseEntity<*> {
        val responseTO: SearchResponseTO<UserTenantTO> = tenantService.getTenantListByUser(tenantSearchRequestTO)
        val response = ResponseTO.responseBuilder(200, "COM04", "/tenant/list/by-user", "tenant", responseTO)
        return ResponseEntity<ResponseTO>(response, HttpStatus.OK)
    }

    @DeleteMapping("/delete")
    fun deleteTenant(@Valid @RequestParam(name = "tenantIdList") tenantIdList: List<Long>): ResponseEntity<*> {
        tenantService.deleteTenant(tenantIdList)
        val responseDTO = ResponseTO.responseBuilder(200, "COM05", "/tenant/delete", "tenant", tenantIdList)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }
}
