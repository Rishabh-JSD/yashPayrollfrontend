package hostbooks.payroll.core.tenant.dto

class TenantDbDetailInternalTO {
    var id: Int? = null
    var tenantId: Int? = null
    var businessUUID: String? = null
    var dbName: String? = null
    var writeHost: String? = null
    var writePort: String? = null
    var writeUser: String? = null
    var writePass: String? = null
    var readHost: String? = null
    var readPort: String? = null
    var readUser: String? = null
    var readPass: String? = null
    var active: Boolean = false
}
