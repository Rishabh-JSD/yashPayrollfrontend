package hostbooks.payroll.core.tenant.dto

import hostbooks.payroll.address.dto.AddressTO
import hostbooks.payroll.shared.utility.model.AuditTO

class TenantDetailsTO : AuditTO() {
    var id: Long? = null;
    var alias: String? = null
    var legalName: String? = null
    var businessType: String? = null
    var logo: String? = null
    var phone: String? = null
    var email: String? = null
    var addressId: Long? = null
    var address: AddressTO? = null
}