package hostbooks.payroll.core.tenant.dto

import hostbooks.payroll.shared.utility.model.AuditTO

class TenantTO : AuditTO() {
    var id: Long? = null
    var ownerId: Long? = null
    var industryId: Long? = null
    var name: String? = null
    var dbName: String? = null
    var dbUuid: String? = null
    var taxCountry: String? = null
    var sell: String? = null
    var timeZone: String? = null
    var tenantDetail: TenantDetailsTO? = null
    var fyDay: String? = null
    var fyMonth: String? = null
    var scriptPrimary: String? = null
    var scriptValuation: String? = null
    var cronStatus = false
    var cronFailedStatus = false
}
