package hostbooks.payroll.core.tenant.dto

class UserTenantTO {

    var id: Long? = null
    var userId: Long? = null
    var tenantId: Long? = null
    var tenant: TenantTO? = null
}
