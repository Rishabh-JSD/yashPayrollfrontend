package hostbooks.payroll.core.tenant.entity

import hostbooks.payroll.shared.constant.Tables
import jakarta.persistence.*
import java.io.Serializable

@Entity
@Table(name = Tables.MasterDb.MASTER_DATASOURCE_INTERNAL)
class MasterDatasourceInternalBO : Serializable {
    companion object {
        private const val serialVersionUID = 193597243763891577L
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", updatable = false)
    val id: Int? = null

    @Column(name = "country")
    val country: String? = null

    @Column(name = "write_host")
    val writeHost: String? = null

    @Column(name = "write_port")
    val writePort: String? = null

    @Column(name = "write_user")
    val writeUser: String? = null

    @Column(name = "write_pass")
    val writePass: String? = null

    @Column(name = "read_host")
    val readHost: String? = null

    @Column(name = "read_port")
    val readPort: String? = null

    @Column(name = "read_user")
    val readUser: String? = null

    @Column(name = "read_pass")
    val readPass: String? = null

    @Column(name = "active")
    val active = false
}

