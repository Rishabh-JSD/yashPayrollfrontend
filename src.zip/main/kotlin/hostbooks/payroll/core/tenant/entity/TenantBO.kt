package hostbooks.payroll.core.tenant.entity

import hostbooks.payroll.shared.constant.Tables
import jakarta.persistence.*
import org.hibernate.annotations.UpdateTimestamp
import java.io.Serializable
import java.util.*


@Entity
@Table(name = Tables.MasterDb.TENANT)
class TenantBO : Serializable {
    companion object {
        private const val serialVersionUID = 3201179579546975295L
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", updatable = false, nullable = false)
    var id: Long? = null

    @Column(name = "owner_id")
    var ownerId: Long? = null

    @Column(name = "industry_id")
    var industryId: Long? = null

    @Column(name = "name")
    var name: String? = null

    @Column(name = "db_name")
    var dbName: String? = null

    @Column(name = "db_uuid")
    var dbUuid: String? = null

    @Column(name = "tenant_detail_id", insertable = false, updatable = false, nullable = false)
    var tenantDetailId: Long? = null

    @Column(nullable = false, updatable = false, name = "created_at")
    @Temporal(TemporalType.TIMESTAMP)
    // @get:CreationTimestamp
    val createdAt: Date = Calendar.getInstance().time

    @Column(name = "created_by", updatable = false)
    var createdBy: Long? = null

    @Column(nullable = false, name = "updated_at")
    @Temporal(TemporalType.TIMESTAMP)
    @get:UpdateTimestamp
    val updatedAt: Date = Calendar.getInstance().time

    @Column(name = "updated_by")
    var updatedBy: Long? = null

    @OneToOne(cascade = [CascadeType.ALL], orphanRemoval = true)
    @JoinColumn(name = "tenant_detail_id")
    var tenantDetail: TenantDetailsBO? = null

}
