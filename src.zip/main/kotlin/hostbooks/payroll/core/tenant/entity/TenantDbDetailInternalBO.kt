package hostbooks.payroll.core.tenant.entity

import hostbooks.payroll.shared.constant.Tables
import jakarta.persistence.*


@Entity
@Table(name = Tables.MasterDb.TENANT_DB_DETAILS_INTERNAL)
class TenantDbDetailInternalBO {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", updatable = false)
    var id: Int? = null

    @Column(name = "tenant_id")
    var tenantId: Long? = null

    @Column(name = "tenant_db_uuid")
    var tenantDbUuid: String? = null

    @Column(name = "tenant_db_name")
    var tenantDbName: String? = null

    @Column(name = "write_host")
    var writeHost: String? = null

    @Column(name = "write_port")
    var writePort: String? = null

    @Column(name = "write_user")
    var writeUser: String? = null

    @Column(name = "write_pass")
    var writePass: String? = null

    @Column(name = "read_host")
    var readHost: String? = null

    @Column(name = "read_port")
    var readPort: String? = null

    @Column(name = "read_user")
    var readUser: String? = null

    @Column(name = "read_pass")
    var readPass: String? = null

    @Column(name = "active")
    var active: Boolean = false
}