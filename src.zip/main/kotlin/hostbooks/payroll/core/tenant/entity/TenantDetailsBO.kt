package hostbooks.payroll.core.tenant.entity

import hostbooks.payroll.address.entity.AddressBO
import hostbooks.payroll.shared.constant.Tables
import hostbooks.payroll.shared.utility.model.Audit
import jakarta.persistence.*
import java.io.Serializable

@Entity
@Table(name = Tables.MasterDb.TENANT_DETAILS)
class TenantDetailsBO: Serializable {
    companion object {
        private const val serialVersionUID = 3201179579546975295L
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", updatable = false, nullable = false)
    var id: Long? = null;

    @Column(name = "alias")
    var alias: String? = null

    @Column(name = "legal_name")
    var legalName: String? = null

    @Column(name = "business_type")
    var businessType: String? = null

    @Column(name = "logo")
    var logo: String? = null

    @Column(name = "phone")
    var phone: String? = null

    @Column(name = "email")
    var email: String? = null

    @Column(name = "address_id", insertable = false, updatable = false, nullable = false)
    var addressId: Long? = null

    @OneToOne(cascade = [CascadeType.ALL], orphanRemoval = true)
    @JoinColumn(name = "address_id", referencedColumnName = "id")
    var address: AddressBO? = null

}