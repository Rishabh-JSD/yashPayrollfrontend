package hostbooks.payroll.core.tenant.entity

import hostbooks.payroll.shared.constant.Tables
import jakarta.persistence.*

@Entity
@Table(name = Tables.MasterDb.TENANT_SETUP_SCRIPT)
class TenantSetupScriptBO {

    companion object {
        private const val serialVersionUID = 193597243763891577L
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", updatable = false)
    val id: Int? = null

    @Column(name = "version")
    val version: String? = null

    @Column(name = "db_script")
    val dbScript: String? = null

    @Column(name = "script_valuation")
    val scriptValuation: String? = null

    @Column(name = "script_path")
    val scriptPath: String? = null

}