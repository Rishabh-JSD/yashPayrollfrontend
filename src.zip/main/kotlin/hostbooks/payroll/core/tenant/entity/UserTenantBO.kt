package hostbooks.payroll.core.tenant.entity

import hostbooks.payroll.shared.constant.Tables
import jakarta.persistence.*

@Entity
@Table(name = Tables.MasterDb.USER_TENANT)
class UserTenantBO {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", updatable = false, nullable = false)
    var id: Long? = null

    @Column(name = "user_id")
    var userId: Long? = null

    @Column(name = "tenant_id")
    var tenantId: Long? = null
}
