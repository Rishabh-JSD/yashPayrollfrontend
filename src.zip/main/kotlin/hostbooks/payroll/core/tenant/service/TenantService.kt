package hostbooks.payroll.core.tenant.service

import hostbooks.payroll.core.tenant.TenantSearchRequestTO
import hostbooks.payroll.core.tenant.dto.TenantTO
import hostbooks.payroll.core.tenant.dto.UserTenantTO
import hostbooks.payroll.shared.utility.model.SearchResponseTO

interface TenantService {

    fun addTenant(tenantTO: TenantTO): TenantTO

    fun updateTenant(tenantTO: TenantTO): TenantTO

    fun getTenantById(id: Long): TenantTO?

    fun getTenantList(tenantSearchRequestTO: TenantSearchRequestTO): SearchResponseTO<TenantTO>

    fun getTenantListByUser(tenantSearchRequestTO: TenantSearchRequestTO): SearchResponseTO<UserTenantTO>

    fun deleteTenant(tenantIdList: List<Long>)
}
