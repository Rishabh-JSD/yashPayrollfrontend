package hostbooks.payroll.core.tenant.service

import hostbooks.payroll.address.dto.AddressTO
import hostbooks.payroll.core.commonDao.CommonDao
import hostbooks.payroll.core.dto.FilterInfo
import hostbooks.payroll.core.dto.HbSort
import hostbooks.payroll.core.exception.CustomException
import hostbooks.payroll.core.tenant.TenantSearchRequestTO
import hostbooks.payroll.core.tenant.dto.TenantDetailsTO
import hostbooks.payroll.core.tenant.dto.TenantTO
import hostbooks.payroll.core.tenant.dto.UserTenantTO
import hostbooks.payroll.core.tenant.entity.*
import hostbooks.payroll.core.user.dto.UserTO
import hostbooks.payroll.shared.constant.AppEnum
import hostbooks.payroll.shared.utility.CommonUtil
import hostbooks.payroll.shared.utility.MapHandler
import hostbooks.payroll.shared.utility.UserSessionContext
import hostbooks.payroll.shared.utility.model.SearchResponseTO
import jakarta.transaction.Transactional
import org.apache.commons.logging.LogFactory
import org.springframework.beans.factory.annotation.Value
import org.springframework.core.io.ClassPathResource
import org.springframework.data.domain.Page
import org.springframework.data.domain.PageRequest
import org.springframework.data.domain.Pageable
import org.springframework.jdbc.core.JdbcTemplate
import org.springframework.jdbc.datasource.DriverManagerDataSource
import org.springframework.jdbc.datasource.init.ResourceDatabasePopulator
import org.springframework.jdbc.support.GeneratedKeyHolder
import org.springframework.stereotype.Service
import java.sql.Connection
import java.sql.Statement.RETURN_GENERATED_KEYS
import java.util.*


@Service
@Transactional
class TenantServiceImpl(
    private val commonDao: CommonDao, private val mapHandler: MapHandler, @Value("\${app.company_setup.script}") private val companySetupScript: String
) : TenantService {
    private val log = LogFactory.getLog(this::class.java)

    override fun addTenant(tenantTO: TenantTO): TenantTO {
        val scriptDetail: TenantSetupScriptBO? = commonDao.selectSingleByDiscriminator(TenantSetupScriptBO::class.java, tenantTO.version, "version")
        log.info("***********Script Location: ${scriptDetail?.scriptPath}, ${scriptDetail?.dbScript}")
        tenantTO.scriptPrimary = scriptDetail?.scriptPath + scriptDetail?.dbScript
        tenantTO.scriptValuation = scriptDetail?.scriptPath + scriptDetail?.scriptValuation
        tenantTO.dbUuid = UUID.randomUUID().toString()
        if(CommonUtil.checkNullEmpty(tenantTO.dbUuid)){
            tenantTO.dbUuid = tenantTO.dbUuid!!.replace(Regex("[a-z]")) {
                it.value.replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale.getDefault()) else it.toString() }
            }
        }
//      * Setup Company database name
        this.createCompanyDbName(tenantTO)
        tenantTO.dbName = this.createCompanyDbName(tenantTO)
        tenantTO.ownerId = UserSessionContext.getCurrentTenant()?.id
        tenantTO.updatedBy = UserSessionContext.getCurrentTenant()?.id
        tenantTO.createdBy = UserSessionContext.getCurrentTenant()?.id
        val addedTenantBO = commonDao.persist(mapHandler.mapObject(tenantTO, TenantBO::class.java))
        val addedTenantTO = mapHandler.mapObject(addedTenantBO, TenantTO::class.java)!!

//      * Get master datasource internal
        val discriminatorMap = WeakHashMap<String, Any>()
        discriminatorMap["active"] = true
        discriminatorMap["country"] = tenantTO.version
        val masterDatasource: MasterDatasourceInternalBO? = commonDao.selectSingleByMultiDiscriminatorsSingleVal(MasterDatasourceInternalBO::class.java, discriminatorMap)
        val tenantDbDetailInternalBO: TenantDbDetailInternalBO?
        if (masterDatasource != null) {
            // * New Tenant DbDetail InternalBO DB
            tenantDbDetailInternalBO = this.makeClientDbDetail(addedTenantTO, masterDatasource)
//          * New Tenant DB
            this.createTenantDb(addedTenantTO, masterDatasource)
            if (tenantDbDetailInternalBO != null) {
//              * New Tenant script
                this.runTenantDbScript(addedTenantTO, tenantDbDetailInternalBO)
//              * Insert tenant & user objects in new tenant db
                this.insertTenantAndUserDetailsInTenantDb(addedTenantTO, tenantDbDetailInternalBO)
//                * Tenant Db Detail Internal Add
                commonDao.persist(tenantDbDetailInternalBO)
            }
        }
        return addedTenantTO
    }

    private fun createCompanyDbName(tenantTO: TenantTO): String? {
        var tg: String? = tenantTO.name?.replace("[^a-zA-Z_]+", "_")
        if (tenantTO.name != null && tenantTO.name?.length!! > 10) {
            tg = tenantTO.name!!.substring(0, 10).replace("[^a-zA-Z_]+", "_")
        }
        tg += tenantTO.dbUuid?.substring(0, 10)?.replace("[^a-zA-Z_]+", "_")

        tenantTO.dbName = tg + "_" + CommonUtil.randomAlphaNumeric(10)
        return tenantTO.dbName?.replace(" ", "_")
    }

    private fun makeClientDbDetail(tenantTO: TenantTO, masterDatasource: MasterDatasourceInternalBO): TenantDbDetailInternalBO? {
        val tenantDbDetailInternalBO: TenantDbDetailInternalBO? = mapHandler.mapObject(masterDatasource, TenantDbDetailInternalBO::class.java)
        tenantDbDetailInternalBO?.id = null
        tenantDbDetailInternalBO?.tenantId = tenantTO.id
        tenantDbDetailInternalBO?.tenantDbUuid = tenantTO.dbUuid
        tenantDbDetailInternalBO?.tenantDbName = tenantTO.dbName
        return tenantDbDetailInternalBO
    }

    private fun createTenantDb(tenantTO: TenantTO, masterDatasource: MasterDatasourceInternalBO) {
        val dataSource = DriverManagerDataSource(
            CommonUtil.getJdbcUrl("", masterDatasource.writeHost, masterDatasource.writePort), masterDatasource.writeUser!!, masterDatasource.writePass!!
        )
        dataSource.setDriverClassName("com.mysql.cj.jdbc.Driver")
        val jdbcTemplate = JdbcTemplate(dataSource)
        try {
            jdbcTemplate.execute("CREATE DATABASE `${tenantTO.dbName}`")
            log.info("Database `${tenantTO.dbName}` created successfully.")
        } catch (e: Exception) {
            log.info("Error creating database `${tenantTO.dbName}`: ${e.message}")
        }
    }

    private fun runTenantDbScript(tenantTO: TenantTO, tenantDbDetailInternalBO: TenantDbDetailInternalBO) {
        try {
            val scriptResource = ClassPathResource(this.companySetupScript)
            if (!scriptResource.exists()) {
                throw CustomException("Script file not found: company-setup-script.sql")
            }
            val dataSource = DriverManagerDataSource(
                CommonUtil.getJdbcUrl(tenantTO.dbName!!, tenantDbDetailInternalBO.writeHost, tenantDbDetailInternalBO.writePort),
                tenantDbDetailInternalBO.writeUser!!,
                tenantDbDetailInternalBO.writePass!!
            )
            dataSource.setDriverClassName("com.mysql.cj.jdbc.Driver")
            val resourceDatabasePopulator = ResourceDatabasePopulator(false, false, "UTF-8", scriptResource)
            resourceDatabasePopulator.execute(dataSource)
            log.info("Database script executed successfully.")
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    @Throws(java.lang.Exception::class)
    private fun insertTenantAndUserDetailsInTenantDb(tenant: TenantTO, tenantDbDetailInternalBO: TenantDbDetailInternalBO) {
        val dataSource = DriverManagerDataSource(
            CommonUtil.getJdbcUrl(tenant.dbName!!, tenantDbDetailInternalBO.writeHost, tenantDbDetailInternalBO.writePort),
            tenantDbDetailInternalBO.writeUser!!,
            tenantDbDetailInternalBO.writePass!!
        )
        dataSource.setDriverClassName("com.mysql.cj.jdbc.Driver")
        val jdbcTemplate = JdbcTemplate(dataSource)
        val userTO: UserTO = UserSessionContext.getCurrentTenant()!!
        val updatedAt: String? = tenant.updatedAt?.let { CommonUtil.formatDateToString(it) }
        val createdAt: String? = tenant.createdAt?.let { CommonUtil.formatDateToString(it) }
        val addressIdTenant: Long?
        var addressIdUser: Long? = null
        val detailsId: Long?
        addressIdTenant = this.addAddress(jdbcTemplate, tenant.tenantDetail?.address!!)
        detailsId = this.saveTenantDetail(jdbcTemplate, tenant.tenantDetail!!, addressIdTenant, createdAt, updatedAt)

        val companySql =
            "INSERT INTO tenant (id, tenant_detail_id, owner_id, industry_id, name, db_name, db_uuid, updated_at, updated_by, created_at, created_by) " + "VALUES (${tenant.id}, ${detailsId}, ${tenant.ownerId}, ${tenant.industryId},'${tenant.name}', '${tenant.dbName}', '${tenant.dbUuid}', '${updatedAt}', " + "${tenant.updatedBy}, '${createdAt}', ${tenant.createdBy}) "

        if (CommonUtil.checkNullEmpty(userTO.userDetail?.address)) {
            addressIdUser = this.addAddress(jdbcTemplate, userTO.userDetail?.address!!)
        }
        val userDetailId: Any = this.saveUserDetail(jdbcTemplate, addressIdUser)
        val userSql =
            "INSERT INTO user (id, user_detail_id, name, username, password, email, enabled, updated_at, created_at) " + "VALUES (${userTO.id},'${userDetailId}', '${userTO.name}', '${userTO.username}', '${userTO.password}', '${userTO.email}', ${userTO.enabled}, " + "'${userTO.updatedAt}', '${userTO.createdAt}') "
        try {
            jdbcTemplate.execute(companySql)
            jdbcTemplate.execute(userSql)
        } catch (e: Exception) {
            e.printStackTrace()
            throw RuntimeException("Failed to execute insert query", e)
        }
    }

    override fun updateTenant(tenantTO: TenantTO): TenantTO {
        val entity = mapHandler.mapObject(tenantTO, TenantBO::class.java)
        val updatedEntity = commonDao.updateWithFlush(entity)
        return mapHandler.mapObject(updatedEntity, TenantTO::class.java) ?: tenantTO
    }

    override fun getTenantById(id: Long): TenantTO? {
        val tenantBO: TenantBO? = commonDao.findByPrimaryKey(TenantBO::class.java, id)
        return mapHandler.mapObject(tenantBO, TenantTO::class.java)
    }

    override fun getTenantList(tenantSearchRequestTO: TenantSearchRequestTO): SearchResponseTO<TenantTO> {
        val searchResponseTO = SearchResponseTO<TenantTO>()
        val discriminatorMap: WeakHashMap<String, FilterInfo<*>> = WeakHashMap<String, FilterInfo<*>>()
        discriminatorMap["ownerId"] = FilterInfo(AppEnum.FilterType.EQ, UserSessionContext.getCurrentTenant()?.id)
        val pageable: Pageable = PageRequest.of(tenantSearchRequestTO.page - 1, tenantSearchRequestTO.limit)
        val sorts: List<HbSort> = listOf(HbSort("name", AppEnum.SortDirection.DESC))
        val data: Page<TenantBO> = commonDao.listByFilterPagination(TenantBO::class.java, discriminatorMap, pageable, sorts)
        searchResponseTO.list = mapHandler.mapObjectList(data.content, TenantTO::class.java)
        searchResponseTO.pageCount = data.totalPages.toLong()
        searchResponseTO.totalRowCount = data.totalElements
        return searchResponseTO
    }

    override fun getTenantListByUser(tenantSearchRequestTO: TenantSearchRequestTO): SearchResponseTO<UserTenantTO> {
        val searchResponseTO = SearchResponseTO<UserTenantTO>()
        val discriminatorMap: WeakHashMap<String, FilterInfo<*>> = WeakHashMap<String, FilterInfo<*>>()
        if (CommonUtil.checkNullEmpty(UserSessionContext.getCurrentTenant())) {
            discriminatorMap["userId"] = FilterInfo(AppEnum.FilterType.LIKE, UserSessionContext.getCurrentTenant()?.id)
        }
        val pageable: Pageable = PageRequest.of(tenantSearchRequestTO.page - 1, tenantSearchRequestTO.limit)
        val data: Page<UserTenantBO> = commonDao.listByFilterPagination(UserTenantBO::class.java, discriminatorMap, pageable, null)
        val userTenantList: MutableList<UserTenantTO> = ArrayList()

        if (data.content.isNotEmpty()) {
            for (userTenant in data.content) {
                val userTenantTO = mapHandler.mapObject(userTenant, UserTenantTO::class.java)
                if (userTenantTO != null) {
                    val tenant = getTenantById(userTenantTO.tenantId!!)
                    userTenantTO.tenant = tenant
                    userTenantList.add(userTenantTO)
                }
            }
        }
        searchResponseTO.list = mapHandler.mapObjectList(userTenantList, UserTenantTO::class.java)
        searchResponseTO.pageCount = data.totalPages.toLong()
        searchResponseTO.totalRowCount = data.totalElements
        return searchResponseTO
    }

    override fun deleteTenant(tenantIdList: List<Long>) {
        for (id in tenantIdList) {
            val tenant: TenantBO? = commonDao.findByPrimaryKey(TenantBO::class.java, id)
            if (tenant != null) {
                commonDao.deleteWithFlush(tenant)
            }
        }
    }

    private fun addAddress(jdbcTemplate: JdbcTemplate, address: AddressTO?): Long {
        val addressId: Long
        // Insert into tenant_address table
        val companyAddressSql = "INSERT INTO address (address_one, address_two, city_name, pincode, state_name, country_name ) VALUES " + "(?,?,?,?,?,?)"
        try {
            val generatedKeyHolder = GeneratedKeyHolder()
            jdbcTemplate.update(
                { connection: Connection ->
                    val ps = connection.prepareStatement(companyAddressSql, RETURN_GENERATED_KEYS)
                    ps.setString(1, address?.addressOne!!)
                    if (CommonUtil.checkNullEmpty(address.addressTwo)) {
                        ps.setString(2, address.addressTwo!!)
                    } else {
                        ps.setString(2, null)
                    }
                    ps.setString(3, address.cityName!!)
                    ps.setString(4, address.stateName!!)
                    ps.setString(5, address.pincode!!)
                    ps.setString(6, address.countryName!!)
                    ps
                }, generatedKeyHolder
            )
            addressId = generatedKeyHolder.key?.toLong()!!
        } catch (e: Exception) {
            // Handle exception
            e.printStackTrace()
            throw RuntimeException("Failed to execute insert query", e)
        }
        return addressId
    }

    private fun saveTenantDetail(jdbcTemplate: JdbcTemplate, tenantDetail: TenantDetailsTO, addressId: Long?, updatedAt: String?, createdAt: String?): Long {
        val detailsId: Long
        val companyDetailSql = "INSERT INTO tenant_details (address_id, business_type, alias, legal_name, logo,phone, email)" + "VALUES" + "(?, ?, ?, ?, ?, ?, ?)"
        try {
            val generatedKeyHolder = GeneratedKeyHolder()
            jdbcTemplate.update(
                { connection: Connection ->
                    val ps = connection.prepareStatement(companyDetailSql, RETURN_GENERATED_KEYS)
                    if (addressId != null) {
                        ps.setLong(1, addressId)
                    } else {
                        ps.setLong(1, 0)
                    }
                    ps.setString(2, tenantDetail.businessType)
                    if (CommonUtil.checkNullEmpty(tenantDetail.alias)) {
                        ps.setString(3, tenantDetail.alias)
                    } else {
                        ps.setString(3, null)
                    }
                    ps.setString(4, tenantDetail.legalName)
                    ps.setString(5, tenantDetail.logo)
                    ps.setString(6, tenantDetail.phone)
                    ps.setString(7, tenantDetail.email)
                    ps
                }, generatedKeyHolder
            )

            detailsId = generatedKeyHolder.key?.toLong()!!
        } catch (e: Exception) {
            // Handle exception
            e.printStackTrace()
            throw RuntimeException("Failed to execute insert query", e)
        }
        return detailsId
    }

    private fun saveUserDetail(jdbcTemplate: JdbcTemplate, addressId: Long?): Any {
        val userDetailId: Long
        val userDetailSql = "INSERT INTO user_details (tenant_creation_limit, address_id) VALUES " + "(?, ?)"
        val keyHolder = GeneratedKeyHolder()
        jdbcTemplate.update({ connection: Connection ->
            val ps = connection.prepareStatement(userDetailSql, RETURN_GENERATED_KEYS)
            ps.setLong(1, 5)
            if (addressId != null) {
                ps.setLong(2, addressId)
            } else {
                ps.setLong(2, 0)
            }
            ps
        }, keyHolder)
        userDetailId = keyHolder.key!!.toLong()
        return userDetailId
    }
}
