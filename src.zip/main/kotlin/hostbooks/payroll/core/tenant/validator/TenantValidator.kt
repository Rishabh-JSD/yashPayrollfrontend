package hostbooks.payroll.core.tenant.validator

import hostbooks.payroll.core.commonDao.CommonDao
import hostbooks.payroll.core.tenant.TenantSearchRequestTO
import hostbooks.payroll.core.tenant.controller.TenantController
import hostbooks.payroll.core.tenant.dto.TenantTO
import hostbooks.payroll.core.tenant.entity.TenantBO
import hostbooks.payroll.core.tenant.entity.TenantDetailsBO
import hostbooks.payroll.shared.constant.AppMsg
import hostbooks.payroll.shared.utility.CommonUtil
import org.springframework.validation.Errors
import org.springframework.validation.Validator
import org.springframework.web.bind.annotation.ControllerAdvice


@ControllerAdvice(assignableTypes = [TenantController::class])
class TenantValidator(private val commonDao: CommonDao) : Validator {
    override fun supports(clazz: Class<*>): Boolean {
        return (clazz == TenantTO::class.java || clazz == TenantSearchRequestTO::class.java)
    }

    override fun validate(target: Any, errors: Errors) {

        val tenant: TenantTO = target as TenantTO

        if(CommonUtil.checkNullEmpty(target)){
            if(commonDao.isExistByDiscriminators(TenantBO::class.java,tenant.name,"name")){
                errors.rejectValue("name", "COM04E", AppMsg.RESPONSE["COM04E"]!!);
            }
            val tenantDetail = tenant.tenantDetail
            if (tenantDetail != null) {
                if (commonDao.isExistByDiscriminators(TenantDetailsBO::class.java, tenantDetail.alias, "alias")) {
                    AppMsg.RESPONSE["COM04E"]?.let { errors.rejectValue("tenantDetail.alias", "COM04E", it) }
                }

                if (commonDao.isExistByDiscriminators(TenantDetailsBO::class.java, tenantDetail.legalName, "legalName")) {
                    AppMsg.RESPONSE["COM04E"]?.let { errors.rejectValue("tenantDetail.legalName", "COM04E", it) }
                }
            }
        }
    }
}