package hostbooks.payroll.core.user.controller

import hostbooks.payroll.core.user.dto.UserTO
import hostbooks.payroll.core.user.service.UserService
import hostbooks.payroll.shared.utility.ValidationError
import hostbooks.payroll.shared.utility.model.ResponseDTO
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.validation.Errors
import org.springframework.validation.Validator
import org.springframework.web.bind.WebDataBinder
import org.springframework.web.bind.annotation.*
import javax.validation.Valid

@CrossOrigin(origins = ["*"], maxAge = 3600)
@RestController
@RequestMapping("/user")
class UserController(private val userService: UserService, private var responseDTO: ResponseDTO,private val userValidator: Validator) {
    @InitBinder
    private fun initBinder(binder: WebDataBinder) {
        binder.validator = this.userValidator
    }

    @RequestMapping(value = ["/add"], method = [RequestMethod.POST])
    fun addUser(@Valid @RequestBody userTO: UserTO, errors: Errors): ResponseEntity<*> {
        if (errors.hasErrors()) return ResponseEntity(ValidationError.fromBindingErrors(errors), HttpStatus.OK)
        return ResponseEntity(ResponseDTO.responseBuilder(200, "COM01", "/user/add", "user", userService.addUser(userTO)!!), HttpStatus.OK)
    }

    @RequestMapping(value = ["/update"], method = [RequestMethod.PUT])
    fun updateUser(@Valid @RequestBody userTO: UserTO, errors: Errors): ResponseEntity<*> {
        if (errors.hasErrors()) return ResponseEntity(ValidationError.fromBindingErrors(errors), HttpStatus.OK)
        return ResponseEntity(ResponseDTO.responseBuilder(200, "COM02", "/user/update", "user", userService.updateUser(userTO)!!), HttpStatus.OK)
    }

    @PostMapping("/list")
    fun getUserList(): ResponseEntity<List<UserTO>> {
        return ResponseEntity.ok(userService.getUserList())
    }
    @RequestMapping(value = ["/get/{id}"], method = [RequestMethod.GET])
    fun getUserById(@PathVariable id:Int): ResponseEntity<*> {
        return ResponseEntity(ResponseDTO.responseBuilder(200, "COM02", "/user/update", "user", userService.getUserById(id)!!), HttpStatus.OK);
    }
}
