package hostbooks.payroll.core.user.dto

import hostbooks.payroll.address.dto.AddressTO
import jakarta.persistence.Column

class UserDetailTO {
    var id: Long? = null
    var tenantCreationLimit: Long? = null
    var gender:String?=null;
    var addressId: Long? = null
    var address:AddressTO?=null
    var phone: String? = null
    var landline: String? = null
    var secondaryEmail: String? = null
}