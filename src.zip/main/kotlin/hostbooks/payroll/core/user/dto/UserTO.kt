package hostbooks.payroll.core.user.dto

class UserTO {
    var id: Long? = null
    var name: String? = null
    var username: String? = null
    var password: String? = null
    var oldPassword: String? = null
    var newPassword: String? = null
    var email: String? = null
    var enabled: Boolean = false
    var updatedAt: String? = null
    var createdAt: String? = null
    var userDetail: UserDetailTO? = null;

    var token: String? = null
}