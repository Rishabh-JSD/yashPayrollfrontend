package hostbooks.payroll.core.user.entity

import hostbooks.payroll.shared.constant.Tables
import jakarta.persistence.*
import org.hibernate.annotations.CreationTimestamp
import java.io.Serializable

@Entity
@Table(name = Tables.USER)
class UserBO : Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", unique = true, nullable = false)
    var id: Long? = null

    @Column(name = "name")
    var name: String? = null

    @Column(name = "username")
    var username: String? = null

    @Column(name = "password")
    var password: String? = null

    @Column(name = "email")
    var email: String? = null

    @Column(name = "enabled")
    var enabled: Boolean? = null

    @Column(name = "updated_at")
    @Temporal(TemporalType.TIMESTAMP)
    @CreationTimestamp
    var updatedAt: String? = null

    @Column(name = "created_at")
    @Temporal(TemporalType.TIMESTAMP)
    @CreationTimestamp
    var createdAt: String? = null

    @Column(name = "user_detail_id", insertable = false, updatable = false, nullable = false)
    var userDetailId: Long? = null

    @OneToOne(cascade = [CascadeType.ALL], orphanRemoval = true)
    @JoinColumn(name = "user_detail_id")
    var userDetail: UserDetailBO? = null
    
    companion object {
        @java.io.Serial
        private const val serialVersionUID = 1L
    }
}
