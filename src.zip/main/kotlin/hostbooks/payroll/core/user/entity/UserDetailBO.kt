package hostbooks.payroll.core.user.entity

import hostbooks.payroll.address.entity.AddressBO
import hostbooks.payroll.shared.constant.Tables
import jakarta.persistence.*

@Entity
@Table(name = Tables.USER_DETAIL)
class UserDetailBO {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", unique = true, nullable = false)
    var id: Long? = null

    @Column(name = "tenant_creation_limit", nullable = false)
    var tenantCreationLimit: Long? = null

    @Column(name = "address_id", insertable = false, updatable = false, nullable = false)
    var addressId: Long? = null

    @Column(name = "gender")
    var gender: String? = null

    @Column(name = "phone")
    var phone: String? = null

    @Column(name = "landline")
    var landline: String? = null

    @Column(name = "secondary_email")
    var secondaryEmail: String? = null

    @OneToOne(cascade = [CascadeType.ALL], orphanRemoval = true)
    @JoinColumn(name = "address_id")
    var address: AddressBO? = null

}