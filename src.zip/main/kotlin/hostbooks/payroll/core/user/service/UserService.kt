package hostbooks.payroll.core.user.service

import hostbooks.payroll.core.user.dto.UserTO

interface UserService {

    fun addUser(userTO: UserTO): UserTO?

    fun updateUser(userTO: UserTO): UserTO?

    fun getByUsername(username: String): UserTO?

    fun getUserByEmail(email: String): UserTO?

    fun getUserById(id: Int): UserTO?

    fun getUserList(): List<UserTO>
}
