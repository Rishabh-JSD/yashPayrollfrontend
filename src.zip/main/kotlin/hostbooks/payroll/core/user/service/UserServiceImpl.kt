package hostbooks.payroll.core.user.service

import hostbooks.payroll.core.commonDao.CommonDao
import hostbooks.payroll.core.dto.FilterInfo
import hostbooks.payroll.core.dto.HbSort
import hostbooks.payroll.core.user.dto.UserTO
import hostbooks.payroll.core.user.entity.UserBO
import hostbooks.payroll.shared.constant.AppEnum
import hostbooks.payroll.shared.utility.MapHandler
import jakarta.transaction.Transactional
import org.springframework.data.domain.Page
import org.springframework.data.domain.PageRequest
import org.springframework.data.domain.Pageable
import org.springframework.stereotype.Service
import java.util.*

@Service
@Transactional
class UserServiceImpl(
    private val commonDao: CommonDao,
    private val mapHandler: MapHandler
) : UserService {

    override fun addUser(userTO: UserTO): UserTO? {
        val addedUser = commonDao.persist(mapHandler.mapObject(userTO, UserBO::class.java))
        return mapHandler.mapObject(addedUser, UserTO::class.java)
    }

    override fun updateUser(userTO: UserTO): UserTO? {
        val updatedUser = commonDao.merge(mapHandler.mapObject(userTO, UserBO::class.java))
        return mapHandler.mapObject(updatedUser, UserTO::class.java)
    }

    override fun getByUsername(username: String): UserTO? {
        val discriminatorMap = WeakHashMap<String, Any>()
        discriminatorMap["username"] = username
        discriminatorMap["enabled"] = true
        val userBO: UserBO? = commonDao.selectSingleByMultiDiscriminatorsSingleVal(UserBO::class.java, discriminatorMap)
        return mapHandler.mapObject(userBO, UserTO::class.java)
    }

    override fun getUserByEmail(email: String): UserTO? {
        val discriminatorMap = WeakHashMap<String, Any>()
        discriminatorMap["email"] = email
        discriminatorMap["enabled"] = true
        val userBO: UserBO? = commonDao.selectSingleByMultiDiscriminatorsSingleVal(UserBO::class.java, discriminatorMap)
        return mapHandler.mapObject(userBO, UserTO::class.java)
    }

    override fun getUserById(id: Int): UserTO? {
        val discriminatorMap = WeakHashMap<String, Any>()
        discriminatorMap["id"] = id
        discriminatorMap["enabled"] = true
        val userBO: UserBO? = commonDao.selectSingleByMultiDiscriminatorsSingleVal(UserBO::class.java, discriminatorMap)
        return mapHandler.mapObject(userBO, UserTO::class.java)
    }

    override fun getUserList(): List<UserTO> {
        val discriminatorMap = WeakHashMap<String, FilterInfo<*>>()
        discriminatorMap["enabled"] = FilterInfo(AppEnum.FilterType.EQ, true)
        val pageable: Pageable = PageRequest.of(0, 10)
        val sorts: List<HbSort> = listOf(HbSort("name", AppEnum.SortDirection.DESC))
        val data: Page<UserBO> = commonDao.listByFilterPagination(UserBO::class.java, discriminatorMap, pageable, sorts)
        val userList = ArrayList<UserTO>()
        for (userBO in data.content) {
            val userTO: UserTO? = mapHandler.mapObject(userBO, UserTO::class.java)
            if (userTO != null) {
                userList.add(userTO)
            }
        }
        return userList
    }
}
