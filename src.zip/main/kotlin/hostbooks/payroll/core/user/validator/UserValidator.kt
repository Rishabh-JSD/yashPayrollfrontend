package hostbooks.payroll.core.user.validator

import hostbooks.payroll.core.commonDao.CommonDao
import hostbooks.payroll.core.exception.PasswordMismatchException
import hostbooks.payroll.core.user.controller.UserController
import hostbooks.payroll.core.user.dto.UserTO
import hostbooks.payroll.core.user.service.UserService
import hostbooks.payroll.shared.constant.AppMsg
import hostbooks.payroll.shared.utility.CommonUtil
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder
import org.springframework.validation.Errors
import org.springframework.validation.Validator
import org.springframework.web.bind.annotation.ControllerAdvice

@ControllerAdvice(assignableTypes = [UserController::class])

class UserValidator(private val commonDao: CommonDao, private val userService: UserService) : Validator {
    override fun supports(clazz: Class<*>): Boolean {
        return (clazz == UserTO::class.java)
    }

    override fun validate(target: Any, errors: Errors) {
        val user: UserTO = target as UserTO
        if (CommonUtil.checkNullEmpty(target)) {
            if (CommonUtil.checkNullEmpty(user.oldPassword)) {
                val userTO: UserTO? = userService.getUserByEmail(user.email!!)
                if (userTO != null) {
                    if (!BCryptPasswordEncoder().matches(user.oldPassword, userTO.password)) {
                        errors.rejectValue("oldPassword", "COM04E", AppMsg.RESPONSE["COM26E"]!!);
                    } else {
                        val bCryptPasswordEncoder = BCryptPasswordEncoder()
                        userTO.password = bCryptPasswordEncoder.encode(user.newPassword);
                    }
                }
            }
        }
    }
}


