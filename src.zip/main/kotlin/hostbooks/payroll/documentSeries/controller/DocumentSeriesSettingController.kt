package hostbooks.payroll.documentSeries.controller

import hostbooks.payroll.documentSeries.dto.DocumentSeriesSettingsTO
import hostbooks.payroll.documentSeries.service.DocumentSeriesSettingsService
import hostbooks.payroll.shared.utility.model.ResponseDTO
import jakarta.servlet.http.HttpServletRequest
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.*


@RestController
@RequestMapping("/documentSeries")
class DocumentSeriesSettingController(private var seriesSettingsService: DocumentSeriesSettingsService) {

    @RequestMapping(value = ["/list"], method = [RequestMethod.GET], name = "Document Series Settings List->MDOC")
    @Throws(
        Exception::class
    )
    fun getAllDocumentSeriesSettings(
        @RequestParam(value = "docType", defaultValue = "") docType: String?,
        request: HttpServletRequest?
    ): ResponseEntity<*> {
        val list: List<DocumentSeriesSettingsTO>? = seriesSettingsService.getSeriesSettingsByDocType(docType)
        val response: ResponseDTO? = ResponseDTO.responseBuilder(200, "COM11", "/documentSeries", "series", list)
        return ResponseEntity<Any>(response, HttpStatus.OK)
    }

    @PostMapping("/add")
    @Throws(java.lang.Exception::class)
    fun addDocumentSeriesSettingsList(
        @RequestBody seriesSettingsTOList:DocumentSeriesSettingsTO,
        request: HttpServletRequest?
    ): ResponseEntity<*> {
        val response = ResponseDTO.responseBuilder(
            200,
            "COM01",
            "/documentSeries",
            "documentSeries",
            seriesSettingsService.addSeriesSettingsList(seriesSettingsTOList)
        )
        return ResponseEntity(response, HttpStatus.CREATED)
    }

    @RequestMapping(value = ["/auto-code"], method = [RequestMethod.GET], name = "Document Series Settings List->MDOC")
    @Throws(
        Exception::class
    )
    fun getAutoCode(
        @RequestParam(value = "docType", defaultValue = "") docType: String,
        @RequestParam(value = "branchId", defaultValue = "") branchId: String,
        request: HttpServletRequest?
    ): ResponseEntity<*> {
        val response: ResponseDTO? = ResponseDTO.responseBuilder(200, "COM11", "/documentSeries", "series", seriesSettingsService.getSeriesSetting(docType,branchId.toInt()))
        return ResponseEntity<Any>(response, HttpStatus.OK)
    }

    @RequestMapping(value = ["/display-style-list"], method = [RequestMethod.GET], name = "Document Series Settings List->MDOC")
    @Throws(
        Exception::class
    )
    fun getDisplayStyle(request: HttpServletRequest?): ResponseEntity<*> {
        val response: ResponseDTO? = ResponseDTO.responseBuilder(200, "COM11", "/documentSeries", "displayStyle", seriesSettingsService.getDisplayStyleList())
        return ResponseEntity<Any>(response, HttpStatus.OK)
    }


}