package hostbooks.payroll.documentSeries.dto

import jakarta.persistence.Column
import jakarta.persistence.GeneratedValue
import jakarta.persistence.GenerationType
import jakarta.persistence.Id
import javax.validation.constraints.NotNull

class DisplayStyleTO {

    var id: Int? = null
    var name: @NotNull String? = null
    var symbol: @NotNull String? = null
}