package hostbooks.payroll.documentSeries.dto

class DocumentSeriesResponse {
    var seriesNumber: String? = null
    var currentNumber: String? = null
    var displayStyle: Int? = null
    var overrideFlag:  Boolean? = null;
}