package hostbooks.payroll.documentSeries.dto

import java.util.*

class DocumentSeriesSettingsTO {
     var seriesId: Int? = null
     var docType: String? = null
     var prefix: String? = null
     var startNumber: String? = null
     var endNumber: Int? = null
     var suffix: String? = null
     var startDate: Date? = null
     var displayStyle: Int? = null
     var status: Boolean? = null
     var branchList: List<Int> = emptyList();
     var overrideFlag:  Boolean? = null;

}