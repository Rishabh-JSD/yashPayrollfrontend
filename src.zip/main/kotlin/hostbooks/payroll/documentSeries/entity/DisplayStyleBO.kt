package hostbooks.payroll.documentSeries.entity

import hostbooks.payroll.shared.constant.Tables
import hostbooks.payroll.shared.utility.model.Audit
import jakarta.persistence.*
import javax.validation.constraints.NotNull

@Entity
@Table(name = Tables.DOCUMENT_STYLE)
class DisplayStyleBO:Audit() {

    companion object {
         const val serialVersionUID = 1L
    }
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", updatable = false)
     var id: Int? = null

    @Column(name = "display_style")
     var name: @NotNull String? = null

    @Column(name = "symbol")
    var symbol: @NotNull String? = null


}