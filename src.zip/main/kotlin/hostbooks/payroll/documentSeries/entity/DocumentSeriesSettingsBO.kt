package hostbooks.payroll.documentSeries.entity

import hostbooks.payroll.shared.constant.Tables
import hostbooks.payroll.shared.utility.model.Audit
import jakarta.persistence.*
import java.io.Serializable
import java.util.*
import javax.validation.constraints.NotNull
@Entity
@Table(name = Tables.DOCUMENT_SERIES_SETTINGS)
class DocumentSeriesSettingsBO: Audit(),Serializable {
    companion object {
         const val serialVersionUID = 1L
    }
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "series_id", updatable = false)
     var seriesId: Int? = null

    @Column(name = "doc_type")
     var docType: @NotNull String? = null

    @Column(name = "prefix")
     var prefix: String? = null

    @Column(name = "suffix")
     var suffix: String? = null

    @Column(name = "start_number")
     var startNumber: String? = null

    @Column(name = "end_number")
     var endNumber: Int? = null

    @Column(name = "start_date")
     var startDate: @NotNull Date? = null

    @Column(name = "display_style")
     var displayStyle: Int? = null

    @Column(name = "status")
     var status: Boolean? = null

    @Column(name = "branch_id")
    var branchId: String? = null

    @Column(name = "override_flag")
    var overrideFlag:  Boolean? = null;

}