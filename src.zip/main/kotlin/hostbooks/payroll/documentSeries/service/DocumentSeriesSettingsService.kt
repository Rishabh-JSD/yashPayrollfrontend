package hostbooks.payroll.documentSeries.service

import hostbooks.payroll.documentSeries.dto.DisplayStyleTO
import hostbooks.payroll.documentSeries.dto.DocumentSeriesResponse
import hostbooks.payroll.documentSeries.dto.DocumentSeriesSettingsTO

interface DocumentSeriesSettingsService {

    @Throws(Exception::class)
    fun addSeriesSettingsList(seriesSettingsList:DocumentSeriesSettingsTO):DocumentSeriesSettingsTO?

    fun addSeriesSettings(seriesSettings: DocumentSeriesSettingsTO): DocumentSeriesSettingsTO?

    fun getSeriesSettingsByDocType(docType: String?): List<DocumentSeriesSettingsTO>?
    fun getSeriesSetting(docType: String,branchId:Int): DocumentSeriesResponse?;

    fun getDisplayStyleList(): List<DisplayStyleTO>?

}