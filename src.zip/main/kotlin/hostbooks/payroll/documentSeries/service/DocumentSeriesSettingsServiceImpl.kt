package hostbooks.payroll.documentSeries.service

import hostbooks.payroll.core.commonDao.CommonDao
import hostbooks.payroll.core.dto.FilterInfo
import hostbooks.payroll.core.exception.CustomException
import hostbooks.payroll.documentSeries.dto.DisplayStyleTO
import hostbooks.payroll.documentSeries.dto.DocumentSeriesResponse
import hostbooks.payroll.documentSeries.dto.DocumentSeriesSettingsTO
import hostbooks.payroll.documentSeries.entity.DisplayStyleBO
import hostbooks.payroll.documentSeries.entity.DocumentSeriesSettingsBO
import hostbooks.payroll.shared.constant.AppConst
import hostbooks.payroll.shared.constant.AppEnum
import hostbooks.payroll.shared.constant.Tables
import hostbooks.payroll.shared.utility.CommonUtil
import hostbooks.payroll.shared.utility.MapHandler
import jakarta.persistence.EntityManager
import jakarta.persistence.PersistenceContext
import jakarta.transaction.Transactional
import org.springframework.stereotype.Service
import java.util.*

@Service
@Transactional
class DocumentSeriesSettingsServiceImpl(private val commonDao: CommonDao, private val mapHandler: MapHandler) : DocumentSeriesSettingsService {

    override fun addSeriesSettingsList(seriesSettingsList: DocumentSeriesSettingsTO): DocumentSeriesSettingsTO? {
        return this.addSeriesSettings(seriesSettingsList)
    }

    override fun addSeriesSettings(seriesSettings: DocumentSeriesSettingsTO): DocumentSeriesSettingsTO? {
        seriesSettings.docType?.let { this.deleteSettingsByDocType(it) }
        val documentSeriesSetting: DocumentSeriesSettingsBO? = mapHandler.mapObject(seriesSettings, DocumentSeriesSettingsBO::class.java)
        if (documentSeriesSetting != null) {
            documentSeriesSetting.branchId = listIntoString(seriesSettings.branchList)
        }
        return mapHandler.mapObject(commonDao.persist(documentSeriesSetting), DocumentSeriesSettingsTO::class.java)
    }

    override fun getSeriesSettingsByDocType(docType: String?): List<DocumentSeriesSettingsTO>? {
        val return_list: MutableList<DocumentSeriesSettingsTO> = mutableListOf()
        val list: List<DocumentSeriesSettingsBO> = commonDao.selectByDiscriminator(DocumentSeriesSettingsBO::class.java, docType, "docType", -1)
        return if (CommonUtil.checkNullEmpty(list)) {
            var documentSeriesSettingsTO: DocumentSeriesSettingsTO?
            for (documentSeries in list) {
                documentSeriesSettingsTO = mapHandler.mapObject(documentSeries, DocumentSeriesSettingsTO::class.java)
                if (documentSeriesSettingsTO != null) {
                    documentSeriesSettingsTO.branchList = stringToIntegerList(documentSeries.branchId)
                }
                if (documentSeriesSettingsTO != null) {
                    return_list.add(documentSeriesSettingsTO)
                }
            }
            return_list
        } else {
            null
        }
    }

    private fun deleteSettingsByDocType(docType: String) {
        val documentSeriesSettingsBO: DocumentSeriesSettingsBO? = commonDao.selectSingleByDiscriminator(DocumentSeriesSettingsBO::class.java, docType, "docType")
        if (CommonUtil.checkNullEmpty(documentSeriesSettingsBO)) {
            commonDao.delete(documentSeriesSettingsBO)
        }
    }

    override fun getSeriesSetting(docType: String, branchId: Int): DocumentSeriesResponse? {
        if (CommonUtil.checkNullEmpty(docType)) {
            val discriminatorMap = WeakHashMap<String, FilterInfo<Any>>()
            discriminatorMap["docType"] = FilterInfo(AppEnum.FilterType.EQ, docType.trim())
            discriminatorMap["branchId"] = FilterInfo(AppEnum.FilterType.FIS, branchId)
            val documentSeriesSettings: List<DocumentSeriesSettingsBO>? = commonDao.selectByMultipleDiscriminatorsByMultiFilter(
                DocumentSeriesSettingsBO::class.java, discriminatorMap, 0, false
            )
            if (CommonUtil.checkNullEmpty(documentSeriesSettings)) {
                var documentSeriesSettingsTO: DocumentSeriesSettingsTO? = documentSeriesSettings?.let {
                    mapHandler.mapObject(
                        it.get(0), DocumentSeriesSettingsTO::class.java
                    )
                }
                if (CommonUtil.checkNullEmpty(documentSeriesSettingsTO)) {
                    return this.generateAutoCode(docType.trim(), documentSeriesSettingsTO)
                }

            }
        }
        return null
    }

    override fun getDisplayStyleList(): List<DisplayStyleTO>? {
        val list: List<DisplayStyleBO> = commonDao.selectAll(DisplayStyleBO::class.java, -1)
        return mapHandler.mapObjectList(list, DisplayStyleTO::class.java)
    }

    private fun generateAutoCode(
        docType: String, documentSeriesSettings: DocumentSeriesSettingsTO?
    ): DocumentSeriesResponse? {
        val tableName: String
        val numberField: String
        when (docType) {
            AppConst.ModuleCode.Employee -> {
                tableName = Tables.EMPLOYEE_COMPANY_DETAILS
                numberField = "current_number"
            }

            AppConst.ModuleCode.Reimburisement_Claim -> {
                tableName = Tables.REIMBURSEMENT_CLAIM
                numberField = "current_number"
            }

            else -> {
                throw CustomException("Module code not found.")
            }
        }
        if (documentSeriesSettings != null) {
            return this.generateAutoSeries(tableName, documentSeriesSettings, numberField)
        }
        return null
    }

    private fun generateAutoSeries(
        tableName: String,
        documentSeriesSettings: DocumentSeriesSettingsTO?,
        numberField: String,
    ): DocumentSeriesResponse {
        val documentSeriesResponse: DocumentSeriesResponse = DocumentSeriesResponse()
        val currentNumber1: Int?
        val docCode: Int? = documentSeriesSettings?.displayStyle
        var displayStyle: String? = null
        val document: DisplayStyleBO? = commonDao.selectSingleByDiscriminator(DisplayStyleBO::class.java, docCode, "id")
        if (documentSeriesSettings != null && (documentSeriesSettings.prefix == null || documentSeriesSettings.prefix == "") && document != null) {
            displayStyle = when (document.symbol) {
                "/" -> {
                    documentSeriesSettings.prefix?.let { document.name?.replace("prefix/", it) }
                }

                "-" -> {
                    documentSeriesSettings.prefix?.let { document.name?.replace("prefix-", it) }
                }

                else -> {
                    documentSeriesSettings.prefix?.let { document.name?.replace("prefix", it) }
                }
            }
        }
        if (documentSeriesSettings != null && (documentSeriesSettings.suffix == null || documentSeriesSettings.suffix == "") && document != null) {
            displayStyle = when (document.symbol) {
                "/" -> {
                    documentSeriesSettings.suffix?.let { displayStyle?.replace("/suffix", it) }
                }

                "-" -> {
                    documentSeriesSettings.suffix?.let { displayStyle?.replace("-suffix", it) }
                }

                else -> {
                    documentSeriesSettings.suffix?.let { displayStyle?.replace("suffix", it) }
                }
            }
        }
        if (!CommonUtil.checkNullEmpty(displayStyle)) {
            if (document != null) {
                if (documentSeriesSettings != null) {
                    displayStyle = documentSeriesSettings.prefix?.let { document.name?.replace("prefix", it) }
                }
            }
        }
        var code: String? = documentSeriesSettings?.suffix?.let { displayStyle.toString().replace("suffix", it) }
        val sql = ("SELECT " + numberField + " FROM $tableName as a WHERE a.display_style = " + (document?.id) + " ORDER BY LENGTH (a.$numberField) DESC LIMIT 1")
        val qry: Any? = commonDao.executeSQLQueryObjForSingle(sql)
        var result: Any? = null
        try {
            result = qry
        } catch (e: Exception) {
            e.printStackTrace()
        }
        val currentNumber: String? = this.getCurrentNumber(result, documentSeriesSettings)
        if (currentNumber != null) {
            currentNumber1 = currentNumber.toIntOrNull()?.plus(1)
            if (code != null) {
                code = code.replace("startNum", (countZeroesFromFront(currentNumber) + currentNumber1))
                documentSeriesResponse.currentNumber = ((countZeroesFromFront(currentNumber) + currentNumber1).toString())
            }
        }
        if (!CommonUtil.checkNullEmpty(result)) {
            if (documentSeriesSettings != null) {
                if (code != null) {
                    code = code.replace("startNum", (documentSeriesSettings.startNumber).toString())
                    documentSeriesResponse.currentNumber = documentSeriesSettings.startNumber
                }
            }
        }
        documentSeriesResponse.seriesNumber = code
        if (document != null) {
            documentSeriesResponse.displayStyle = document.id
        }
        if (documentSeriesSettings != null) {
            documentSeriesResponse.overrideFlag = documentSeriesSettings.overrideFlag
        }
        return documentSeriesResponse
    }

    private fun getCurrentNumber(result: Any?, documentSeriesSettings: DocumentSeriesSettingsTO?): String? {
        var currentNumber: String? = null
        if (CommonUtil.checkNullEmpty(result)) {
            currentNumber = result as String
            if (documentSeriesSettings != null) {
                currentNumber = documentSeriesSettings.prefix?.let { currentNumber!!.replace(it, "") }.toString()
                currentNumber = documentSeriesSettings.suffix?.let { currentNumber!!.replace(it, "") }.toString()
            }
        }
        return currentNumber
    }

    private fun countZeroesFromFront(string: String): String {
        var zeroes: String = ""
        for (char in string) {
            if (char == '0') {
                zeroes += '0'
            } else {
                return zeroes
            }
        }
        return zeroes
    }

    fun <T> listIntoString(list: List<T>?): String? {
        return if (!list.isNullOrEmpty()) {
            val a = StringBuilder()
            for (id in list) {
                a.append(id).append(",")
            }
            a.deleteCharAt(a.length - 1)
            a.toString()
        } else {
            null
        }
    }


    fun stringToIntegerList(list: String?): List<Int> {
        val integerList: MutableList<Int> = ArrayList()
        if (!list.isNullOrEmpty()) {
            val stringTokenizer = StringTokenizer(list, ",")
            while (stringTokenizer.hasMoreElements()) {
                val s = stringTokenizer.nextElement() as String
                if (CommonUtil.checkNullEmpty(s)) {
                    val i = s.toInt()
                    integerList.add(i)
                }
            }
        }
        return integerList
    }
}
