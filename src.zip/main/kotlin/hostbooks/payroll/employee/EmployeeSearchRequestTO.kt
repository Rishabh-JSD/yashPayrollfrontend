package hostbooks.payroll.employee

import hostbooks.payroll.shared.utility.model.SearchRequestTO

class EmployeeSearchRequestTO: SearchRequestTO() {
    var startDate: String? = null
    var endDate: String? = null
}