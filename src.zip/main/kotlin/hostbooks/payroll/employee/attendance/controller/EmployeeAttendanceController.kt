package hostbooks.payroll.employee.attendance.controller

import hostbooks.payroll.employee.EmployeeSearchRequestTO
import hostbooks.payroll.employee.attendance.dto.EmployeeAttendanceTO
import hostbooks.payroll.employee.attendance.service.EmployeeAttendanceService
import hostbooks.payroll.shared.utility.ValidationError
import hostbooks.payroll.shared.utility.model.ResponseTO
import hostbooks.payroll.shared.utility.model.SearchResponseTO
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.validation.Errors
import org.springframework.validation.Validator
import org.springframework.web.bind.WebDataBinder
import org.springframework.web.bind.annotation.*
import javax.validation.Valid

@RestController
    @RequestMapping("/employee-attendance")
class EmployeeAttendanceController(private val employeeAttendanceService: EmployeeAttendanceService, private val employeeAttendanceValidator: Validator) {
    @InitBinder
    private fun initBinder(binder: WebDataBinder) {
        binder.validator = this.employeeAttendanceValidator
    }

    @PostMapping("/add")
    fun addEmployeeAttendance(@Valid @RequestBody employeeAttendanceTO: EmployeeAttendanceTO, errors: Errors): ResponseEntity<*> {
        if (errors.hasErrors()) {
            val validationError: ValidationError = ValidationError.fromBindingErrors(errors)
            return ResponseEntity<Any>(validationError, HttpStatus.BAD_REQUEST)
        }
        val addedEmployeeAttendance: EmployeeAttendanceTO = employeeAttendanceService.addEmployeeAttendance(employeeAttendanceTO)
        val responseDTO = ResponseTO.responseBuilder(201, "COM09", "/employee-attendance", "employeeAttendance", addedEmployeeAttendance)
        return ResponseEntity<Any>(responseDTO, HttpStatus.CREATED)
    }

    @PostMapping("/list")
    fun getEmployeeAttendanceList(@RequestBody employeeSearchRequestTO: EmployeeSearchRequestTO): ResponseEntity<*> {
        val responseTO: SearchResponseTO<EmployeeAttendanceTO> = employeeAttendanceService.getEmployeeAttendanceList(employeeSearchRequestTO)
        val responseDTO = ResponseTO.responseBuilder(200, "COM04", "/employee-attendance", "employeeAttendance", responseTO)
        return ResponseEntity<ResponseTO>(responseDTO, HttpStatus.OK)
    }

    @PutMapping("/update")
    fun updateEmployeeAttendance(@Valid @RequestBody employeeAttendanceTO: EmployeeAttendanceTO, errors: Errors): ResponseEntity<*> {
        if (errors.hasErrors()) {
            val validationError: ValidationError = ValidationError.fromBindingErrors(errors)
            return ResponseEntity<Any>(validationError, HttpStatus.OK)
        }
        val addedEmployeeAttendanceTO: EmployeeAttendanceTO =employeeAttendanceService.updateEmployeeAttendance(employeeAttendanceTO)
        val responseDTO = ResponseTO.responseBuilder(200, "COM02", "/employee-attendance", "employeeAttendance", addedEmployeeAttendanceTO)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }

    @DeleteMapping("/delete")
    fun deleteEmployeeAttendance(@Valid @RequestParam(name = "empAttendanceIdList") empAttendanceIdList: List<Long>): ResponseEntity<*> {
        employeeAttendanceService.deleteEmployeeAttendance(empAttendanceIdList)
        val responseDTO = ResponseTO.responseBuilder(200, "COM05", "/employee-attendance", "employeeAttendance", empAttendanceIdList)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }

    @GetMapping("/{id}")
    fun getEmployeeAttendanceById(@PathVariable id: Long): ResponseEntity<*> {
        val employeeAttendanceTO: EmployeeAttendanceTO? = employeeAttendanceService.getEmployeeAttendanceById(id)
        if (employeeAttendanceTO == null) {
            val responseDTO = ResponseTO.responseBuilder(200, "COM03E", "/employee-attendance", "employeeAttendance", null)
            return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
        }
        val responseDTO = ResponseTO.responseBuilder(200, "COM11", "/employee-attendance", "employeeAttendance", employeeAttendanceTO)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }

    @PutMapping("/update-attendance-list")
    fun updateEmployeeAttendanceList(@Valid @RequestBody employeeAttendanceList: List<EmployeeAttendanceTO>, errors: Errors): ResponseEntity<*> {
        if (errors.hasErrors()) {
            val validationError: ValidationError = ValidationError.fromBindingErrors(errors)
            return ResponseEntity<Any>(validationError, HttpStatus.OK)
        }
        val employeeAttendanceList: List<EmployeeAttendanceTO> = employeeAttendanceService.updateEmployeeAttendanceList(employeeAttendanceList)
        val responseDTO = ResponseTO.responseBuilder(200, "COM02", "/employee-attendance", "employeeAttendance", employeeAttendanceList)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }
}