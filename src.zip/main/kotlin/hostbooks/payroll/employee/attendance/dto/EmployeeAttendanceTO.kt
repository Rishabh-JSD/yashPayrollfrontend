package hostbooks.payroll.employee.attendance.dto

import hostbooks.payroll.employee.attendancePayfrequency.dto.EmployeeAttendancePayFrequencyTO
import hostbooks.payroll.shared.utility.model.AuditTO
import java.util.*

class EmployeeAttendanceTO : AuditTO() {
    var id: Long? = null
    var employeeId: Long? = null
    var employeeNumber: String? =null;
    var date: Date? = null
    var leaveTypeId: Long? = null
    var leaveType: String? = null
    var presentFlag: Boolean = false
    var weekOffFlag: Boolean = false
    var type: String? = null
    var status: String? = null
    var dateString:String?=null
    var updatedAttendancePayFrequency: EmployeeAttendancePayFrequencyTO? = null
}