package hostbooks.payroll.employee.attendance.entity

import hostbooks.payroll.shared.constant.Tables
import hostbooks.payroll.shared.utility.model.Audit
import jakarta.persistence.*
import java.util.*

@Entity
@Table(name = Tables.EMPLOYEE_ATTENDANCE)
class EmployeeAttendanceBO : Audit() {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    var id: Long? = null

    @Column(name = "employee_id")
    var employeeId: Long? = null

    @Column(name = "date")
    var date: Date? = null

    @Column(name = "leave_type_id")
    var leaveTypeId: Long? = null

    @Column(name = "type")
    var type: String? = null

    @Column(name = "status")
    var status: String? = null
}