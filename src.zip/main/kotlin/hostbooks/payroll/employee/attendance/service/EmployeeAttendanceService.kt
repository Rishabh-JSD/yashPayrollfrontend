package hostbooks.payroll.employee.attendance.service

import hostbooks.payroll.employee.EmployeeSearchRequestTO
import hostbooks.payroll.employee.attendance.dto.EmployeeAttendanceTO
import hostbooks.payroll.shared.utility.model.SearchResponseTO

interface EmployeeAttendanceService {

    fun addEmployeeAttendance(employeeAttendanceTO: EmployeeAttendanceTO): EmployeeAttendanceTO

    fun getEmployeeAttendanceList(employeeSearchRequestTO: EmployeeSearchRequestTO): SearchResponseTO<EmployeeAttendanceTO>

    fun updateEmployeeAttendance(employeeAttendanceTO: EmployeeAttendanceTO): EmployeeAttendanceTO

    fun deleteEmployeeAttendance(empAttendanceIdList: List<Long>)

    fun getEmployeeAttendanceById(id: Long):EmployeeAttendanceTO?

    fun updateEmployeeAttendanceList(employeeAttendanceList: List<EmployeeAttendanceTO>): List<EmployeeAttendanceTO>
}