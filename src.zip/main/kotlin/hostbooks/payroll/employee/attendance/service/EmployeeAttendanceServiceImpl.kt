package hostbooks.payroll.employee.attendance.service

import hostbooks.payroll.core.commonDao.CommonDao
import hostbooks.payroll.core.dto.FilterInfo
import hostbooks.payroll.core.dto.HbSort
import hostbooks.payroll.employee.EmployeeSearchRequestTO
import hostbooks.payroll.employee.attendance.dto.EmployeeAttendanceTO
import hostbooks.payroll.employee.attendance.entity.EmployeeAttendanceBO
import hostbooks.payroll.shared.constant.AppEnum
import hostbooks.payroll.shared.utility.MapHandler
import hostbooks.payroll.shared.utility.model.SearchResponseTO
import jakarta.transaction.Transactional
import org.springframework.data.domain.Page
import org.springframework.data.domain.PageRequest
import org.springframework.data.domain.Pageable
import org.springframework.stereotype.Service
import java.text.SimpleDateFormat
import java.util.*

@Service
@Transactional
open class EmployeeAttendanceServiceImpl(
    private val commonDao: CommonDao,
    private val mapHandler: MapHandler
) : EmployeeAttendanceService {
    override fun addEmployeeAttendance(employeeAttendanceTO: EmployeeAttendanceTO): EmployeeAttendanceTO {
        val entity = mapHandler.mapObject(employeeAttendanceTO, EmployeeAttendanceBO::class.java)
        val persistedEntity = commonDao.persistWithFlush(entity)
        return mapHandler.mapObject(persistedEntity, EmployeeAttendanceTO::class.java) ?: employeeAttendanceTO
    }

    override fun getEmployeeAttendanceList(employeeSearchRequestTO: EmployeeSearchRequestTO): SearchResponseTO<EmployeeAttendanceTO> {
        val searchResponseTO = SearchResponseTO<EmployeeAttendanceTO>()
        val discriminatorMap: WeakHashMap<String, FilterInfo<*>> = WeakHashMap<String, FilterInfo<*>>()
        if (employeeSearchRequestTO.startDate != null && employeeSearchRequestTO.endDate != null) {
            val dateFormat = SimpleDateFormat("yyyy-MM-dd")
            var startDate: Date? = dateFormat.parse(employeeSearchRequestTO.startDate);
            var endDate: Date? = dateFormat.parse(employeeSearchRequestTO.endDate);
            discriminatorMap["date"] = FilterInfo(AppEnum.FilterType.BW, startDate, endDate)
        }
        val pageable: Pageable = if (employeeSearchRequestTO.startDate != null && employeeSearchRequestTO.endDate != null) {
            Pageable.unpaged()
        } else {
            PageRequest.of(employeeSearchRequestTO.page - 1, employeeSearchRequestTO.limit)
        }
        val sorts: List<HbSort> = listOf(HbSort("employeeId", AppEnum.SortDirection.ASC))
        val data: Page<EmployeeAttendanceBO> =
            commonDao.listByFilterPagination(EmployeeAttendanceBO::class.java, discriminatorMap, pageable, sorts)
        searchResponseTO.list = mapHandler.mapObjectList(data.content, EmployeeAttendanceTO::class.java)
        searchResponseTO.pageCount = data.totalPages.toLong()
        searchResponseTO.totalRowCount = data.totalElements
        return searchResponseTO
    }

    override fun updateEmployeeAttendance(employeeAttendanceTO: EmployeeAttendanceTO): EmployeeAttendanceTO {
        val entity = mapHandler.mapObject(employeeAttendanceTO, EmployeeAttendanceBO::class.java)
        val updatedEntity = commonDao.updateWithFlush(entity)
        return mapHandler.mapObject(updatedEntity, EmployeeAttendanceTO::class.java) ?: employeeAttendanceTO
    }

    override fun deleteEmployeeAttendance(empAttendanceIdList: List<Long>) {
        for (id in empAttendanceIdList) {
            val leaveAdjustment: EmployeeAttendanceBO? =
                commonDao.findByPrimaryKey(EmployeeAttendanceBO::class.java, id)
            if (leaveAdjustment != null) {
                commonDao.deleteWithFlush(leaveAdjustment)
            }
        }
    }

    override fun getEmployeeAttendanceById(id: Long): EmployeeAttendanceTO? {
        val employeeAttendanceBO: EmployeeAttendanceBO? = commonDao.findByPrimaryKey(EmployeeAttendanceBO::class.java, id)
        return mapHandler.mapObject(employeeAttendanceBO, EmployeeAttendanceTO::class.java)
    }

    override fun updateEmployeeAttendanceList(employeeAttendanceList: List<EmployeeAttendanceTO>): List<EmployeeAttendanceTO> {
        val entityList: List<EmployeeAttendanceBO>? = mapHandler.mapObjectList(employeeAttendanceList, EmployeeAttendanceBO::class.java)
        val persistedEntityList = commonDao.updateBatch(entityList ?: emptyList())
        return mapHandler.mapObjectList(persistedEntityList, EmployeeAttendanceTO::class.java) ?: employeeAttendanceList
    }
}