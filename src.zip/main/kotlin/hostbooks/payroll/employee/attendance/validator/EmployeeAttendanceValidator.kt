package hostbooks.payroll.employee.attendance.validator

import hostbooks.payroll.employee.EmployeeSearchRequestTO
import hostbooks.payroll.employee.attendance.controller.EmployeeAttendanceController
import hostbooks.payroll.employee.attendance.dto.EmployeeAttendanceTO
import org.springframework.validation.Errors
import org.springframework.validation.Validator
import org.springframework.web.bind.annotation.ControllerAdvice

@ControllerAdvice(assignableTypes = [EmployeeAttendanceController::class])
class EmployeeAttendanceValidator : Validator {
    override fun supports(clazz: Class<*>): Boolean {
        return (clazz == EmployeeAttendanceTO::class.java || clazz == EmployeeSearchRequestTO::class.java || clazz == ArrayList::class.java)
    }

    override fun validate(target: Any, errors: Errors) {
        when (target) {
            is List<*> -> target.filterIsInstance<EmployeeAttendanceTO>().forEach { validateEmployeeAttendanceTO(it, errors) }
            is EmployeeAttendanceTO -> validateEmployeeAttendanceTO(target, errors)
        }
    }

    private fun validateEmployeeAttendanceTO(employeeAttendanceTO: EmployeeAttendanceTO, errors: Errors) {
        with(employeeAttendanceTO) {
            validateFieldNotNull("leaveTypeId", leaveTypeId, "Leave Type ID is required", errors)
            validateFieldNotNull("employeeId", employeeId, "Employee ID is required", errors)
            validateFieldNotNull("date", date, "Date is required", errors)
        }
    }

    private fun validateFieldNotNull(fieldName: String, value: Any?, errorMessage: String, errors: Errors) {
        if (value == null) {
            errors.rejectValue(fieldName, "field.required", errorMessage)
        }
    }
}
