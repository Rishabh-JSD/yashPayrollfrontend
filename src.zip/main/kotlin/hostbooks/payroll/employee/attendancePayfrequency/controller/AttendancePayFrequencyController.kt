package hostbooks.payroll.employee.attendancePayfrequency.controller

import hostbooks.payroll.employee.EmployeeSearchRequestTO
import hostbooks.payroll.employee.attendancePayfrequency.dto.AttendancePayFrequencyTO
import hostbooks.payroll.employee.attendancePayfrequency.service.AttendancePayFrequencyService
import hostbooks.payroll.shared.utility.ValidationError
import hostbooks.payroll.shared.utility.model.ResponseTO
import hostbooks.payroll.shared.utility.model.SearchResponseTO
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.validation.Errors
import org.springframework.validation.Validator
import org.springframework.web.bind.WebDataBinder
import org.springframework.web.bind.annotation.*
import javax.validation.Valid

@RestController
@RequestMapping("/attendance-pay-frequency")
class AttendancePayFrequencyController(private val attendancePayFrequencyService: AttendancePayFrequencyService, private val attendancePayFrequencyValidator: Validator) {

    @InitBinder
    private fun initBinder(binder: WebDataBinder) {
        binder.validator = this.attendancePayFrequencyValidator
    }

    @PostMapping("/add")
    fun addAttendancePayFrequency(@Valid @RequestBody attendancePayFrequencyTO: AttendancePayFrequencyTO, errors: Errors): ResponseEntity<*> {
        if (errors.hasErrors()) {
            val validationError: ValidationError = ValidationError.fromBindingErrors(errors)
            return ResponseEntity<Any>(validationError, HttpStatus.BAD_REQUEST)
        }
        val attendancePayFrequencyTO: AttendancePayFrequencyTO = attendancePayFrequencyService.addAttendancePayFrequency(attendancePayFrequencyTO)
        val responseDTO = ResponseTO.responseBuilder(201, "COM09", "/attendance-pay-frequency", "attendancePayFrequency", attendancePayFrequencyTO)
        return ResponseEntity<Any>(responseDTO, HttpStatus.CREATED)
    }

    @PostMapping("/list")
    fun getAttendancePayFrequencyList(@RequestBody employeeSearchRequestTO: EmployeeSearchRequestTO): ResponseEntity<*> {
        val responseTO: SearchResponseTO<AttendancePayFrequencyTO> = attendancePayFrequencyService.getAttendancePayFrequencyList(employeeSearchRequestTO)
        val responseDTO = ResponseTO.responseBuilder(200, "COM04", "/attendance-pay-frequency", "attendancePayFrequency", responseTO)
        return ResponseEntity<ResponseTO>(responseDTO, HttpStatus.OK)
    }

    @PutMapping("/update")
    fun updateAttendancePayFrequency(@Valid @RequestBody attendancePayFrequencyTO: AttendancePayFrequencyTO, errors: Errors): ResponseEntity<*> {
        if (errors.hasErrors()) {
            val validationError: ValidationError = ValidationError.fromBindingErrors(errors)
            return ResponseEntity<Any>(validationError, HttpStatus.OK)
        }
        val attendancePayFrequency: AttendancePayFrequencyTO =attendancePayFrequencyService.updateAttendancePayFrequency(attendancePayFrequencyTO)
        val responseDTO = ResponseTO.responseBuilder(200, "COM02", "/attendance-pay-frequency", "attendancePayFrequency", attendancePayFrequency)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }

    @DeleteMapping("/delete")
    fun deleteAttendancePayFrequency(@Valid @RequestParam(name = "attendancePayFrequencyIdList") attendancePayFrequencyIdList: List<Long>): ResponseEntity<*> {
        attendancePayFrequencyService.deleteAttendancePayFrequency(attendancePayFrequencyIdList)
        val responseDTO = ResponseTO.responseBuilder(200, "COM05", "/attendance-pay-frequency", "attendancePayFrequency", attendancePayFrequencyIdList)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }

    @GetMapping("/{id}")
    fun getAttendancePayFrequencyById(@PathVariable id: Long): ResponseEntity<*> {
        val attendancePayFrequencyTO: AttendancePayFrequencyTO? = attendancePayFrequencyService.getAttendancePayFrequencyById(id)
        if (attendancePayFrequencyTO == null) {
            val responseDTO = ResponseTO.responseBuilder(200, "COM03E", "/attendance-pay-frequency", "attendancePayFrequency", null)
            return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
        }
        val responseDTO = ResponseTO.responseBuilder(200, "COM11", "/attendance-pay-frequency", "attendancePayFrequency", attendancePayFrequencyTO)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }
}