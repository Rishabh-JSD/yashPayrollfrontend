package hostbooks.payroll.employee.attendancePayfrequency.dto

import hostbooks.payroll.shared.utility.model.AuditTO
import java.util.*

class AttendancePayFrequencyTO: AuditTO() {
    var id: Long? = null
    var year: Long? = null
    var month: Long? = null
    var frequencyId: Long? = null
    var startDate: Date? = null
    var endDate: Date? = null
    var totalEmployee: Long? = null
    var status: String? = null
    var employeeAttendancePayFrequency: List<EmployeeAttendancePayFrequencyTO>? = null
}