package hostbooks.payroll.employee.attendancePayfrequency.dto

class EmployeeAttendancePayFrequencyTO {
    var id: Long? = null
    var attendancePayFrequencyId: Long? = null
    var attendanceId: Long? = null
    var leaveTypeId: Long? = null
}