package hostbooks.payroll.employee.attendancePayfrequency.entity

import hostbooks.payroll.shared.constant.Tables
import hostbooks.payroll.shared.utility.model.Audit
import jakarta.persistence.*
import java.util.*
@Entity
@Table(name = Tables.ATTENDANCE_PAY_FREQUENCY)
class AttendancePayFrequencyBO: Audit() {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    var id: Long? = null

    @Column(nullable = false)
    var year: Long? = null

    @Column(nullable = false)
    var month: Long? = null

    @Column(name = "frequency_id", nullable = false)
    var frequencyId: Long? = null

    @Column(name = "start_date", nullable = false)
    var startDate: Date? = null

    @Column(name = "end_date", nullable = false)
    var endDate: Date? = null

    @Column(name = "total_employee", nullable = false)
    var totalEmployee: Long? = null

    @Column(name = "status", nullable = false)
    var status: String? = null

    @OneToMany(cascade = [CascadeType.ALL], orphanRemoval = true)
    @JoinColumn(name = "attendance_pay_frequency_id", referencedColumnName = "id")
    var employeeAttendancePayFrequency: List<EmployeeAttendancePayFrequencyBO>? = null


}