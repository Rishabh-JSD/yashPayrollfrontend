package hostbooks.payroll.employee.attendancePayfrequency.entity

import hostbooks.payroll.shared.constant.Tables
import jakarta.persistence.*

@Entity
@Table(name = Tables.EMPLOYEE_ATTENDANCE_PAY_FREQUENCY)
class EmployeeAttendancePayFrequencyBO {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    var id: Long? = null

    @Column(name = "attendance_pay_frequency_id")
    var attendancePayFrequencyId: Long? = null

    @Column(name = "attendance_id", nullable = false)
    var attendanceId: Long? = null

    @Column(name = "leave_type_id", nullable = false)
    var leaveTypeId: Long? = null
}