package hostbooks.payroll.employee.attendancePayfrequency.service

import hostbooks.payroll.employee.EmployeeSearchRequestTO
import hostbooks.payroll.employee.attendancePayfrequency.dto.AttendancePayFrequencyTO
import hostbooks.payroll.shared.utility.model.SearchResponseTO

interface AttendancePayFrequencyService {

    fun addAttendancePayFrequency(attendancePayFrequencyTO: AttendancePayFrequencyTO): AttendancePayFrequencyTO

    fun getAttendancePayFrequencyList(employeeSearchRequestTO: EmployeeSearchRequestTO): SearchResponseTO<AttendancePayFrequencyTO>

    fun updateAttendancePayFrequency(attendancePayFrequencyTO: AttendancePayFrequencyTO): AttendancePayFrequencyTO

    fun deleteAttendancePayFrequency(attendancePayFrequencyIdList: List<Long>)

    fun getAttendancePayFrequencyById(id: Long): AttendancePayFrequencyTO?
}