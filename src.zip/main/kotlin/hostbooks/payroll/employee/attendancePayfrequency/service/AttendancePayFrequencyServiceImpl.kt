package hostbooks.payroll.employee.attendancePayfrequency.service

import hostbooks.payroll.core.commonDao.CommonDao
import hostbooks.payroll.core.dto.FilterInfo
import hostbooks.payroll.core.dto.HbSort
import hostbooks.payroll.employee.EmployeeSearchRequestTO
import hostbooks.payroll.employee.attendancePayfrequency.dto.AttendancePayFrequencyTO
import hostbooks.payroll.employee.attendancePayfrequency.entity.AttendancePayFrequencyBO
import hostbooks.payroll.shared.constant.AppEnum
import hostbooks.payroll.shared.utility.MapHandler
import hostbooks.payroll.shared.utility.model.SearchResponseTO
import jakarta.transaction.Transactional
import org.springframework.data.domain.Page
import org.springframework.data.domain.PageRequest
import org.springframework.data.domain.Pageable
import org.springframework.stereotype.Service
import java.util.*

@Service
@Transactional
open class AttendancePayFrequencyServiceImpl(private val commonDao: CommonDao,
                                             private val mapHandler: MapHandler
): AttendancePayFrequencyService {
    override fun addAttendancePayFrequency(attendancePayFrequencyTO: AttendancePayFrequencyTO): AttendancePayFrequencyTO {
        val entity = mapHandler.mapObject(attendancePayFrequencyTO, AttendancePayFrequencyBO::class.java)
        val persistedEntity = commonDao.persistWithFlush(entity)
        return mapHandler.mapObject(persistedEntity, AttendancePayFrequencyTO::class.java)?: attendancePayFrequencyTO
    }

    override fun getAttendancePayFrequencyList(employeeSearchRequestTO: EmployeeSearchRequestTO): SearchResponseTO<AttendancePayFrequencyTO> {
        val searchResponseTO = SearchResponseTO<AttendancePayFrequencyTO>()
        val discriminatorMap: WeakHashMap<String, FilterInfo<*>> = WeakHashMap<String, FilterInfo<*>>()
        val pageable: Pageable = PageRequest.of(employeeSearchRequestTO.page - 1, employeeSearchRequestTO.limit)
        val sorts: List<HbSort> = listOf(HbSort("year", AppEnum.SortDirection.ASC))
        val data: Page<AttendancePayFrequencyBO> = commonDao.listByFilterPagination(AttendancePayFrequencyBO::class.java, discriminatorMap, pageable, sorts)
        searchResponseTO.list = mapHandler.mapObjectList(data.content, AttendancePayFrequencyTO::class.java)
        searchResponseTO.pageCount = data.totalPages.toLong()
        searchResponseTO.totalRowCount = data.totalElements
        return searchResponseTO
    }

    override fun updateAttendancePayFrequency(attendancePayFrequencyTO: AttendancePayFrequencyTO): AttendancePayFrequencyTO {
        val entity = mapHandler.mapObject(attendancePayFrequencyTO, AttendancePayFrequencyBO::class.java)
        val updatedEntity = commonDao.updateWithFlush(entity)
        return mapHandler.mapObject(updatedEntity, AttendancePayFrequencyTO::class.java) ?: attendancePayFrequencyTO
    }

    override fun deleteAttendancePayFrequency(attendancePayFrequencyIdList: List<Long>) {
        for (id in attendancePayFrequencyIdList) {
            val attendancePayFrequency: AttendancePayFrequencyBO? = commonDao.findByPrimaryKey(AttendancePayFrequencyBO::class.java, id)
            if (attendancePayFrequency != null) {
                commonDao.deleteWithFlush(attendancePayFrequency)
            }
        }
    }

    override fun getAttendancePayFrequencyById(id: Long): AttendancePayFrequencyTO? {
        val attendancePayFrequencyBO: AttendancePayFrequencyBO? = commonDao.findByPrimaryKey(AttendancePayFrequencyBO::class.java, id)
        return mapHandler.mapObject(attendancePayFrequencyBO, AttendancePayFrequencyTO::class.java)
    }
}