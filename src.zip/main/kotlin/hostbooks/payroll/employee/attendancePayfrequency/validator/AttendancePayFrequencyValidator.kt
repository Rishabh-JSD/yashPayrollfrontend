package hostbooks.payroll.employee.attendancePayfrequency.validator

import hostbooks.payroll.employee.EmployeeSearchRequestTO
import hostbooks.payroll.employee.attendancePayfrequency.dto.AttendancePayFrequencyTO
import org.springframework.validation.Errors
import org.springframework.validation.Validator
import org.springframework.web.bind.annotation.ControllerAdvice

@ControllerAdvice(assignableTypes = [AttendancePayFrequencyTO::class])
class AttendancePayFrequencyValidator: Validator {
    override fun supports(clazz: Class<*>): Boolean {
        return (clazz == AttendancePayFrequencyTO::class.java || clazz == EmployeeSearchRequestTO::class.java)
    }

    override fun validate(target: Any, errors: Errors) {
        if (target is AttendancePayFrequencyTO) {
            //add logic for validation
        }
    }
}