package hostbooks.payroll.employee.controller

import hostbooks.payroll.employee.dto.EmployeeLabelTO
import hostbooks.payroll.employee.dto.EmployeeSearchRequestTO
import hostbooks.payroll.employee.dto.EmployeeTO
import hostbooks.payroll.employee.service.EmployeeService
import hostbooks.payroll.shared.utility.ValidationError
import hostbooks.payroll.shared.utility.model.ResponseDTO
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.validation.Errors
import org.springframework.validation.Validator
import org.springframework.web.bind.WebDataBinder
import org.springframework.web.bind.annotation.*
import javax.validation.Valid

@RestController
@RequestMapping("/employee")
class EmployeeController(private var employeeValidator: Validator, private var employeeService: EmployeeService, private var responseDTO: ResponseDTO) {

    @InitBinder
    private fun initBinder(binder: WebDataBinder) {
        binder.validator = employeeValidator
    }

    @RequestMapping(value = ["/add"], method = [RequestMethod.POST], name = "Employee Master Add->EMPCR")
    fun addEmployee(@Valid @RequestBody employeeTO: EmployeeTO, errors: Errors): ResponseEntity<*> {
        if (errors.hasErrors()) {
            val validationError = ValidationError.fromBindingErrors(errors)
            return ResponseEntity(validationError, HttpStatus.OK)
        }
        val addedEmployeeTO = employeeService.addEmployee(employeeTO)
        responseDTO = ResponseDTO.responseBuilder(200, "COM01", "/employee", "employee", addedEmployeeTO!!)
        return ResponseEntity(responseDTO, HttpStatus.OK)
    }

    @RequestMapping(value = ["/update"], method = [RequestMethod.POST], name = "Employee Master Update->EMPCR")
    fun updateEmployee(@Valid @RequestBody employeeTO: EmployeeTO, errors: Errors): ResponseEntity<*> {
        if (errors.hasErrors()) {
            val validationError = ValidationError.fromBindingErrors(errors)
            return ResponseEntity(validationError, HttpStatus.OK)
        }
        val addedEmployeeTO = employeeService.updateEmployee(employeeTO)
        responseDTO = ResponseDTO.responseBuilder(200, "COM02", "/employee", "employee", addedEmployeeTO!!)
        return ResponseEntity(responseDTO, HttpStatus.OK)
    }

    @RequestMapping(value = ["/list"], method = [RequestMethod.POST], name = "Employee Master List->EMPCR")
    fun getEmployeeList(@RequestBody employeeRequestTO: EmployeeSearchRequestTO): ResponseEntity<*> {
        val searchResponseTO = employeeService.getEmployeeList(employeeRequestTO)
        if (searchResponseTO.list == null || searchResponseTO.list!!.isEmpty()) {
            responseDTO = ResponseDTO.responseBuilder(200, "COM03E", "/employee", "employee", searchResponseTO)
            return ResponseEntity(responseDTO, HttpStatus.OK)
        }
        responseDTO = ResponseDTO.responseBuilder(200, "COM11", "/employee", "employee", searchResponseTO)
        return ResponseEntity(responseDTO, HttpStatus.OK)
    }

    @RequestMapping(value = ["/{id}"], method = [RequestMethod.GET], name = "Employee Master View->EMPCR")
    fun getEmployeeById(@PathVariable id: Long): ResponseEntity<*> {
        val employeeTO = employeeService.getEmployeeById(id)
        if (employeeTO == null) {
            responseDTO = ResponseDTO.responseBuilder(200, "COM03E", "/employee", "employee", null)
            return ResponseEntity(responseDTO, HttpStatus.OK)
        }
        responseDTO = ResponseDTO.responseBuilder(200, "COM03", "/employee", "employee", employeeTO)
        return ResponseEntity(responseDTO, HttpStatus.OK)
    }

    @RequestMapping(value = ["/proxy/{id}"], method = [RequestMethod.GET], name = "Employee Label View->EMPCR")
    fun getEmployeeProxyById(@PathVariable id: Long): ResponseEntity<*> {
        val employeeProxyBO = employeeService.getEmployeeProxyById(id)
        if (employeeProxyBO == null) {
            responseDTO = ResponseDTO.responseBuilder(200, "COM03E", "/employee", "employee", null)
            return ResponseEntity(responseDTO, HttpStatus.OK)
        }
        responseDTO = ResponseDTO.responseBuilder(200, "COM03", "/employee", "employee", employeeProxyBO)
        return ResponseEntity(responseDTO, HttpStatus.OK)
    }

    @RequestMapping(value = ["/delete"], method = [RequestMethod.DELETE], name = "Employee Master Delete->EMPCR")
    fun deleteEmployee(@RequestParam(name = "employeeId") employeeId: List<Long>): ResponseEntity<*> {
        employeeService.deleteEmployee(employeeId)
        responseDTO = ResponseDTO.responseBuilder(200, "COM05", "/employee", "employee", employeeId)
        return ResponseEntity(responseDTO, HttpStatus.OK)
    }

    @RequestMapping(value = ["/employeeName/{id}"], method = [RequestMethod.GET], name = "Employee Master View->EMPCR")
    fun getEmployeeNameById(@PathVariable id: Long): ResponseEntity<*> {
        val employeeLabelTO: EmployeeLabelTO? = employeeService.getEmployeeNameById(id)
        if (employeeLabelTO == null) {
            responseDTO = ResponseDTO.responseBuilder(200, "COM03E", "/employee", "employee", null)
            return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
        }
        responseDTO = ResponseDTO.responseBuilder(200, "COM03", "/employee", "employee", employeeLabelTO)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }
}
