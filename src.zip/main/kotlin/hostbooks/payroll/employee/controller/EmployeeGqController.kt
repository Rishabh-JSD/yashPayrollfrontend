package hostbooks.payroll.employee.controller;

import hostbooks.payroll.employee.dto.EmployeeSearchRequestTO
import hostbooks.payroll.employee.dto.EmployeeTO
import hostbooks.payroll.employee.service.EmployeeService
import hostbooks.payroll.shared.utility.ValidationError
import hostbooks.payroll.shared.utility.model.ResponseDTO
import org.springframework.graphql.data.method.annotation.MutationMapping
import org.springframework.graphql.data.method.annotation.QueryMapping
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.stereotype.Controller
import org.springframework.validation.Errors
import org.springframework.validation.Validator
import org.springframework.web.bind.WebDataBinder
import org.springframework.web.bind.annotation.InitBinder
import javax.validation.Valid

@Controller
class EmployeeGqController(private val employeeService: EmployeeService, private var employeeValidator: Validator) {

    private lateinit var responseDTO: ResponseDTO

    @InitBinder
    private fun initBinder(binder: WebDataBinder) {
        binder.validator = employeeValidator
    }

    @MutationMapping
    fun addEmployee(@Valid employeeTO: EmployeeTO, errors: Errors): ResponseEntity<*> {
        if (errors.hasErrors()) {
            val validationError = ValidationError.fromBindingErrors(errors)
            return ResponseEntity(validationError, HttpStatus.OK)
        }
        val employeeTOReturn = employeeService.addEmployee(employeeTO)
        responseDTO =
            ResponseDTO.responseBuilder(200, "PR001", "/graphql/employee", "graphql/employee", employeeTOReturn!!)
        return ResponseEntity(responseDTO, HttpStatus.OK)
    }

    @QueryMapping
    fun getEmployeeList(employeeSearchRequestTO: EmployeeSearchRequestTO): ResponseEntity<*> {
        val searchResponseTO = employeeService.getEmployeeList(employeeSearchRequestTO)
        if (!searchResponseTO.list.isNullOrEmpty()) {
            responseDTO = ResponseDTO.responseBuilder(HttpStatus.NOT_FOUND.value(), "COM03E", "/employee", "employee", searchResponseTO)
            return ResponseEntity(responseDTO, HttpStatus.OK)
        }
        responseDTO = ResponseDTO.responseBuilder(200, "COM04", "/employee", "employee", searchResponseTO)
        return ResponseEntity(responseDTO, HttpStatus.OK)
    }
}
