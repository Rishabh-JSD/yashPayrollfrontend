package hostbooks.payroll.employee.dto

import hostbooks.payroll.shared.utility.model.AuditTO

class EmployeeAccountTO {
    var id: Long ? = null
    var employeeId: Long ? = null
    var fullName: String ? = ""
    var bankName: String ? = null
    var accountNumber: String? = null
    var branchName: String? = null
    var ifsc: String ? = null
}