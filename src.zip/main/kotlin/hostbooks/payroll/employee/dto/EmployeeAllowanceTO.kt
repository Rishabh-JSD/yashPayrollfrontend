package hostbooks.payroll.employee.dto

import hostbooks.payroll.shared.utility.model.AuditTO
import java.math.BigDecimal

class EmployeeAllowanceTO {
    var id: Long ? = null
    var employeeSalaryDetailId: Long ? = null
    var allowanceMasterId: Long ? = null
    var allowanceMasterName: String ? = null
    var amount: BigDecimal ? = null
}