package hostbooks.payroll.employee.dto

import java.util.*

class EmployeeCompanyDetailsTO {
    var id: Long? = null
    var employeeNumber: String? = null
    var joiningDate: Date? = null // Use nullable Date because it might be null
    var employeeCategoryId: Long? = null
    var employeeCategoryName: String? = null
    var attendanceTypeCode: String? = null
    var contractFrom: Date? = null
    var contractTo: Date? = null
    var shiftTypeId: Long? = null
    var shiftTypeName: String? = null
    var shiftTimingId: Long? = null
    var shiftTimingStartTime: Date? = null
    var shiftTimingEndTime: Date? = null
    var designationId: Long? = 0
    var designationName: String? = null
    var branchId: Long? = null
    var branchName: String? = null
    var costCenterId: Long? = null
    var costCenterName: String? = null
    var departmentId: Long? = null
    var departmentName: String? = null
    var employeeLevelId: Long? = null
    var employeeLevelName: String? = null
    var reportToId: Long? = null
    var reportToName: String? = null
    var functionalAppraiserId: Long? = null
    var functionalAppraiserName: String? = null
    var adminAppraiserId: Long? = null
    var adminAppraiserName: String? = null
    var payFrequencyId: Long? = null
    var payFrequencyName: String? = null
    var separationDate: Date? = null // Use nullable Date because it might be null
    var overtimeFlag: Boolean = false
    var jobDescription: String? = null
    var currentNumber: String? = null
    var displayStyle: Int? = null
}