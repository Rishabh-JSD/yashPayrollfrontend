package hostbooks.payroll.employee.dto

import hostbooks.payroll.shared.utility.model.AuditTO
import java.math.BigDecimal

class EmployeeDeductionTO {
    var id: Long ? = null
    var employeeSalaryDetailId: Long ? = null
    var deductionMasterId: Long ? = null
    var deductionMasterName: String? = null
    var amount: BigDecimal ? = null
}