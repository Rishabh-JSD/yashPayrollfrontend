package hostbooks.payroll.employee.dto

import hostbooks.payroll.shared.utility.model.AuditTO

class EmployeeExperienceAttachmentTO {
    var id: Long ? = null;
    var employeeExperienceId: Long ? = null;
    var documentTypeId: Long ? = null;
    var documentTypeName: String ? = null;
    var remark: String ? = null;
    var documentId: Long ? = null;
}