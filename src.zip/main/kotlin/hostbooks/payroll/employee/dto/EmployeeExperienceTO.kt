package hostbooks.payroll.employee.dto

import hostbooks.payroll.shared.utility.model.AuditTO
import java.util.*

class EmployeeExperienceTO {
    var id: Long ? = null
    var employeeId: Long ? = null
    var title: String ? = null
    var employmentTypeCode: String ? = null
    var companyName: String ? = null
    var countryName: String ? = null
    var stateName: String ? = null
    var startDate: Date? = null // Use nullable Date because it might be null
    var endDate: Date? = null // Use nullable Date because it might be null
    var jobTitle: String ? = null
    var industryId: Long ? = null
    var industryName: String ? = null
    var jobDescription: String ? = null
    var documentId: Long ? = null
    var employeeExperienceAttachments: List<EmployeeExperienceAttachmentTO>? = null // Use nullable List
}