package hostbooks.payroll.employee.dto

class EmployeeLabelTO {
    var id: Long? = null
    var name: String? = null
    var status: String = "ACTIVE"
}