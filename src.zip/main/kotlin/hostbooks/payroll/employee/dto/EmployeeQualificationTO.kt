package hostbooks.payroll.employee.dto

class EmployeeQualificationTO {
    var id: Long ? = null
    var employeeId: Long ? = null
    var documentTypeId: Long ? = null
    var documentTypeName: String ? = null
    var remark: String ? = null
    var institutionDescription: String ? = null
    var countryName: String ? = null
    var stateName: String ? = null
    var documentId: Long ? = null
}