package hostbooks.payroll.employee.dto

import hostbooks.payroll.shared.utility.model.AuditTO

class EmployeeReferenceTO {
    var id: Long ? = null
    var name: String ? = null
    var employeeId: Long ? = null
    var mobile: Long ? = null
}