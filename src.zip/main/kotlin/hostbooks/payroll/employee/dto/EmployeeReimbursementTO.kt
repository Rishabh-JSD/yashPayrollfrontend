package hostbooks.payroll.employee.dto

import hostbooks.payroll.shared.utility.model.AuditTO
import java.math.BigDecimal

class EmployeeReimbursementTO {
    var id: Long ? = null
    var employeeSalaryDetailId: Long ? = null
    var reimbursementMasterId: Long ? = null
    var reimbursementMasterName: String ? = null
    var amount: BigDecimal ? = null
}