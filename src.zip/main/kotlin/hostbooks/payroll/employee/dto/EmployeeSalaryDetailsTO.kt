package hostbooks.payroll.employee.dto

import hostbooks.payroll.shared.utility.model.AuditTO
import java.math.BigDecimal

class EmployeeSalaryDetailsTO {
    var id: Long ? = null;
    var basicSalary: BigDecimal ? = null;
    var ctc: BigDecimal ? = null;
    var netPayBeforeTds: BigDecimal ? = null;
    var taxSummary: String? = null;
    var employeeReimbursement: List<EmployeeReimbursementTO>? = null
    var employeeAllowance: List<EmployeeAllowanceTO>? = null
    var employeeDeduction: List<EmployeeDeductionTO>? = null
}