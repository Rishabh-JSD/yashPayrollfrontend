package hostbooks.payroll.employee.dto

import hostbooks.payroll.shared.utility.model.SearchRequestTO

class EmployeeSearchRequestTO : SearchRequestTO() {
    val searchFor: String? = null;
    val catCode: String? = null;
    val code: String? = null;
}
