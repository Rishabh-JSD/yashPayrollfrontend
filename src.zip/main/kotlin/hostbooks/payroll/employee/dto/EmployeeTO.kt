package hostbooks.payroll.employee.dto

import hostbooks.payroll.address.dto.AddressTO
import hostbooks.payroll.shared.utility.model.AuditTO
import java.math.BigDecimal
import java.util.*

class EmployeeTO : AuditTO() {
    var id: Long? = null
    var profileCompletion: BigDecimal = BigDecimal.ZERO
    var employmentStatusId: Long ? = null
    var employmentStatusName: String? = null
    var name: String? = null
    var fathersName: String? = null
    var dob: Date? = null
    var gender: String ? = null
    var personalEmail: String? = null
    var officialEmail: String? = null
    var phoneNo: Long ? = null
    var maritalStatus: String? = null
    var pan: String? = null
    var verificationAddress: String? = null
    var companyDetailId: Long? = null
    var salaryDetailId: Long ? = null
    var addressCorrespondenceId: Long ? = null
    var sameAsCorrespondence: Boolean = false
    var addressPermanentId: Long ? = null;
    var employeeAccount: List<EmployeeAccountTO>? = emptyList()
    var employeeExperience: List<EmployeeExperienceTO>? = emptyList()
    var employeeKyc: List<EmployeeKycTO>? = emptyList()
    var employeeQualification: List<EmployeeQualificationTO>? = emptyList()
    var employeeReference: List<EmployeeReferenceTO>? = emptyList()
    var employeeCompanyDetails: EmployeeCompanyDetailsTO? = null
    var employeeSalaryDetails: EmployeeSalaryDetailsTO? = null
    var addressCorrespondence: AddressTO? = null
    var addressPermanent: AddressTO? = null
    var termCompleted: Long ? = null;
    var status: String = "ACTIVE"

    //Import Fields
    var genderName: String ? = null
    var verificationName: String? = null



}


