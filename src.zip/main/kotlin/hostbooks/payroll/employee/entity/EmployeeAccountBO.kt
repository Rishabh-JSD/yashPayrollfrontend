package hostbooks.payroll.employee.entity

import hostbooks.payroll.shared.constant.Tables
import hostbooks.payroll.shared.utility.model.Audit
import jakarta.persistence.*
import java.io.Serializable

@Entity
@Table(name = Tables.EMPLOYEE_ACCOUNT)
class EmployeeAccountBO : Serializable {

    companion object {
        private const val serialVersionUID = 3109011182819185419L
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", updatable = false)
    var id: Long ? = null

    @Column(name = "employee_id", insertable = false, updatable = false)
    var employeeId: Long ? = null

    @Column(name = "full_name")
    var fullName: String = ""

    @Column(name = "bank_name")
    var bankName: String = ""

    @Column(name = "account_number")
    var accountNumber: String = ""

    @Column(name = "branch_name")
    var branchName: String = ""

    @Column(name = "ifsc")
    var ifsc: String = ""

}