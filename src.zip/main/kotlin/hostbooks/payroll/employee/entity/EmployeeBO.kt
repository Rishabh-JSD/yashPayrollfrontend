package hostbooks.payroll.employee.entity

import hostbooks.payroll.address.entity.AddressBO
import hostbooks.payroll.shared.constant.Tables
import hostbooks.payroll.shared.utility.model.Audit
import jakarta.persistence.*
import java.io.Serializable
import java.math.BigDecimal
import java.util.*

@Entity
@Table(name = Tables.EMPLOYEE)
class EmployeeBO : Audit(), Serializable {
    companion object {
        private const val serialVersionUID = 3201179579546975295L
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", updatable = false)
    var id: Long ? = null

    @Column(name = "profile_completion")
    var profileCompletion: BigDecimal? = null

    @Column(name = "employment_status_id")
    var employmentStatusId: Long ? = null

    @Column(name = "name")
    var name: String? = null

    @Column(name = "fathers_name")
    var fathersName: String? = null

    @Column(name = "dob")
    var dob: Date? = null

    @Column(name = "gender")
    var gender: String? = null

    @Column(name = "personal_email")
    var personalEmail: String? = null

    @Column(name = "official_email")
    var officialEmail: String? = null

    @Column(name = "phone_no")
    var phoneNo: Long ? = null

    @Column(name = "nationality_id")
    var nationalityId: Long ? = null

    @Column(name = "marital_status")
    var maritalStatus: String? = null

    @Column(name = "pan")
    var pan: String? = null

    @Column(name = "verification_address")
    var verificationAddress: String? = null

    @Column(name = "company_detail_id", insertable = false, updatable = false)
    var companyDetailId: Long ? = null

    @Column(name = "salary_detail_id", insertable = false, updatable = false)
    var salaryDetailId: Long ? = null

    @Column(name = "address_correspondence_id", insertable = false, updatable =  false)
    var addressCorrespondenceId: Long ? = null

    @Column(name = "same_as_correspondence")
    var sameAsCorrespondence: Boolean = false

    @Column(name = "address_permanent_id", insertable = false, updatable = false)
    var addressPermanentId: Long ? = null

    @Column(name = "status", nullable = false)
    var status: String? = null

    @OneToMany(cascade = [CascadeType.ALL], orphanRemoval = true)
    @JoinColumn(name = "employee_id", referencedColumnName = "id")
    var employeeAccount: List<EmployeeAccountBO> ? = null

    @OneToMany(cascade = [CascadeType.ALL], orphanRemoval = true)
    @JoinColumn(name = "employee_id", referencedColumnName = "id")
    var employeeExperience: List<EmployeeExperienceBO>? = null

    @OneToMany(cascade = [CascadeType.ALL], orphanRemoval = true)
    @JoinColumn(name = "employee_id", referencedColumnName = "id")
    var employeeKyc: List<EmployeeKycBO> ? = null

    @OneToMany(cascade = [CascadeType.ALL], orphanRemoval = true)
    @JoinColumn(name = "employee_id", referencedColumnName = "id")
    var employeeQualification: List<EmployeeQualificationBO> ? = null

    @OneToMany(cascade = [CascadeType.ALL], orphanRemoval = true)
    @JoinColumn(name = "employee_id", referencedColumnName = "id")
    var employeeReference: List<EmployeeReferenceBO>? = null

    @OneToOne(cascade = [CascadeType.ALL], orphanRemoval = true)
    @JoinColumn(name = "company_detail_id")
    var employeeCompanyDetails: EmployeeCompanyDetailsBO? = null

    @OneToOne(cascade = [CascadeType.ALL], orphanRemoval = true)
    @JoinColumn(name = "salary_detail_id")
    var employeeSalaryDetails: EmployeeSalaryDetailsBO? = null

    @OneToOne(cascade = [CascadeType.ALL], orphanRemoval = true)
    @JoinColumn(name = "address_correspondence_id")
    var addressCorrespondence: AddressBO? = null

    @OneToOne(cascade = [CascadeType.ALL], orphanRemoval = true)
    @JoinColumn(name = "address_permanent_id")
    var addressPermanent: AddressBO? = null
}
