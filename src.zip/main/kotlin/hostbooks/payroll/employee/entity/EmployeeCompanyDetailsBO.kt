package hostbooks.payroll.employee.entity

import hostbooks.payroll.shared.constant.Tables
import jakarta.persistence.*
import java.io.Serializable
import java.util.*

@Entity
@Table(name = Tables.EMPLOYEE_COMPANY_DETAILS)
class EmployeeCompanyDetailsBO : Serializable {
    companion object {
        private const val serialVersionUID = -6850364773775879679L
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", updatable = false)
    var id: Long? = null

    @Column(name = "employee_number")
    var employeeNumber: String? = null

    @Column(name = "joining_date")
    var joiningDate: Date? = null

    @Column(name = "employee_category_id")
    var employeeCategoryId: Long? = null

    @Column(name = "attendance_type_code")
    var attendanceTypeCode: String? = null

    @Column(name = "contract_from")
    var contractFrom: Date? = null

    @Column(name = "contract_to")
    var contractTo: Date? = null

    @Column(name = "shift_type_id")
    var shiftTypeId: Long? = null

    @Column(name = "shift_timing_id")
    var shiftTimingId: Long? = null

    @Column(name = "designation_id")
    var designationId: Long? = null

    @Column(name = "branch_id")
    var branchId: Long? = null

    @Column(name = "cost_center_id")
    var costCenterId: Long? = null

    @Column(name = "department_id")
    var departmentId: Long? = null

    @Column(name = "employee_level_id")
    var employeeLevelId: Long? = null

    @Column(name = "report_to_id")
    var reportToId: Long? = null

    @Column(name = "functional_appraiser_id")
    var functionalAppraiserId: Long? = null

    @Column(name = "admin_appraiser_id")
    var adminAppraiserId: Long? = null

    @Column(name = "pay_frequency_id")
    var payFrequencyId: Long? = null

    @Column(name = "separation_date")
    var separationDate: Date? = null

    @Column(name = "overtime_flag")
    var overtimeFlag: Boolean = false

    @Column(name = "job_description")
    var jobDescription: String? = null

    @Column(name = "current_number")
    var currentNumber: String? = null

    @Column(name = "display_style")
    var displayStyle: Int? = null

}
