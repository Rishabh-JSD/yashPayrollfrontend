package hostbooks.payroll.employee.entity

import hostbooks.payroll.shared.constant.Tables
import hostbooks.payroll.shared.utility.model.Audit
import jakarta.persistence.*
import java.io.Serializable

@Entity
@Table(name = Tables.EMPLOYEE_EXPERIENCE_ATTACHMENT)
class EmployeeExperienceAttachmentBO : Serializable {
    companion object {
        private const val serialVersionUID = -5315473268202663146L
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", updatable = false)
    var id: Long ? = null

    @Column(name = "employee_experience_id", insertable = false, updatable = false)
    var employeeExperienceId: Long ? = null

    @Column(name = "document_type_id")
    var documentTypeId: Long ? = null

    @Column(name = "remark")
    var remark: String? = null

    @Column(name = "document_id")
    var documentId: Long ? = null

}
