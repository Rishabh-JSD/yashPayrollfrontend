package hostbooks.payroll.employee.entity

import hostbooks.payroll.shared.constant.Tables
import jakarta.persistence.*
import java.io.Serializable
import java.util.*

@Entity
@Table(name = Tables.EMPLOYEE_EXPERIENCE)
class EmployeeExperienceBO : Serializable {
    companion object {
        private const val serialVersionUID = 7528634853104503388L
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", updatable = false)
    var id: Long ? = null

    @Column(name = "employee_id", insertable = false, updatable = false)
    var employeeId: Long ? = null

    @Column(name = "title")
    var title: String? = null

    @Column(name = "employment_type_code")
    var employmentTypeCode: String? = null

    @Column(name = "company_name")
    var companyName: String? = null

    @Column(name = "country_name")
    var countryName: String? = null

    @Column(name = "state_name")
    var stateName: String? = null

    @Column(name = "start_date")
    var startDate: Date? = null

    @Column(name = "end_date")
    var endDate: Date? = null

    @Column(name = "job_title")
    var jobTitle: String? = null

    @Column(name = "industry_id")
    var industryId: Long ? = null

    @Column(name = "job_description")
    var jobDescription: String? = null

    @OneToMany(cascade = [CascadeType.ALL], orphanRemoval = true)
    @JoinColumn(name = "employee_experience_id", referencedColumnName = "id")
    var employeeExperienceAttachments: List<EmployeeExperienceAttachmentBO> ? = emptyList()
}
