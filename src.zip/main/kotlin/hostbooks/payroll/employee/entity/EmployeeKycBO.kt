package hostbooks.payroll.employee.entity

import hostbooks.payroll.shared.constant.Tables
import hostbooks.payroll.shared.utility.model.Audit
import jakarta.persistence.*
import java.io.Serializable


@Entity
@Table(name = Tables.EMPLOYEE_KYC)
class EmployeeKycBO : Serializable {
    companion object {
        private const val serialVersionUID = -9018483116432099223L
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", updatable = false)
    var id: Long ? = null

    @Column(name = "employee_id", insertable = false, updatable = false)
    var employeeId: Long ? = null

    @Column(name = "document_type_id")
    var documentTypeId: Long ? = null

    @Column(name = "remark")
    var remark: String? = null

    @Column(name = "document_id")
    var documentId: Long ? = null

}
