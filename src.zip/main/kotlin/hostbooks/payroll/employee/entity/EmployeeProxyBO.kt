package hostbooks.payroll.employee.entity

import hostbooks.payroll.shared.constant.Tables
import jakarta.persistence.*
import java.io.Serializable
import java.util.*

@Entity
@Table(name = Tables.EMPLOYEE)
class EmployeeProxyBO : Serializable {
    companion object {
        private const val serialVersionUID = -8480798400315942324L
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", updatable = false)
    var id: Long ? = null

    @Column(name = "name")
    var name: String? = null

    @Column(name = "fathers_name")
    var fathersName: String? = null

    @Column(name = "dob")
    var dob: Date? = null

    @Column(name = "gender")
    var gender: String? = null

    @Column(name = "personal_email")
    var personalEmail: String? = null

    @Column(name = "official_email")
    var officialEmail: String? = null

    @Column(name = "phone_no")
    var phoneNo: Long ? = null

    @Column(name = "marital_status")
    var maritalStatus: String? = null

    @Column(name = "pan")
    var pan: String? = null
}
