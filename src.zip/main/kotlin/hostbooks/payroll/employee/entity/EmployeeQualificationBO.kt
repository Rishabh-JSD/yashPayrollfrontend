package hostbooks.payroll.employee.entity

import hostbooks.payroll.shared.constant.Tables
import jakarta.persistence.*
import java.io.Serializable

@Entity
@Table(name = Tables.EMPLOYEE_QUALIFICATION)
class EmployeeQualificationBO : Serializable {
    companion object {
        private const val serialVersionUID = -4843983390685831557L
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", updatable = false)
    var id: Long ? = null

    @Column(name = "employee_id", insertable = false, updatable = false)
    var employeeId: Long ? = null

    @Column(name = "document_type_id")
    var documentTypeId: Long ? = null

    @Column(name = "remark")
    var remark: String? = null

    @Column(name = "institution_description")
    var institutionDescription: String? = null

    @Column(name = "country_name")
    var countryName: String? = null

    @Column(name = "state_name")
    var stateName: String? = null

    @Column(name = "document_id")
    var documentId: Long ? = null

}
