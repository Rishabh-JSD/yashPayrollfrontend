package hostbooks.payroll.employee.entity

import hostbooks.payroll.shared.constant.Tables
import hostbooks.payroll.shared.utility.model.Audit
import jakarta.persistence.*
import java.io.Serializable

@Entity
@Table(name = Tables.EMPLOYEE_REFERENCE)
class EmployeeReferenceBO : Serializable {
    companion object {
        private const val serialVersionUID = -8052724474127177790L
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", updatable = false)
    var id: Long ? = null

    @Column(name = "name")
    var name: String? = null

    @Column(name = "employee_id", insertable = false, updatable = false)
    var employeeId: Long ? = null

    @Column(name = "mobile")
    var mobile: Long ? = null

}
