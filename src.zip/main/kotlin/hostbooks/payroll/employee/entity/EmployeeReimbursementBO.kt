package hostbooks.payroll.employee.entity

import hostbooks.payroll.shared.constant.Tables
import hostbooks.payroll.shared.utility.model.Audit
import jakarta.persistence.*
import java.io.Serializable
import java.math.BigDecimal

@Entity
@Table(name = Tables.EMPLOYEE_REIMBURSEMENT)
class EmployeeReimbursementBO : Serializable {
    companion object {
        private const val serialVersionUID = -4680150453268086929L
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", updatable = false)
    var id: Long ? = null

    @Column(name = "employee_salary_detail_id", insertable = false, updatable = false)
    var employeeSalaryDetailId: Long ? = null

    @Column(name = "reimbursement_master_id")
    var reimbursementMasterId: Long ? = null

    @Column(name = "amount")
    var amount: BigDecimal ? = null

}
