package hostbooks.payroll.employee.entity

import hostbooks.payroll.shared.constant.Tables
import hostbooks.payroll.shared.utility.model.Audit
import jakarta.persistence.*
import java.io.Serializable
import java.math.BigDecimal

@Entity
@Table(name = Tables.EMPLOYEE_SALARY_DETAIL)
class EmployeeSalaryDetailsBO : Serializable {
    companion object {
        private const val serialVersionUID = -4149509659703014575L
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", updatable = false)
    var id: Long ? = null

    @Column(name = "basic_salary")
    var basicSalary: BigDecimal = BigDecimal.ZERO

    @Column(name = "ctc")
    var ctc: BigDecimal = BigDecimal.ZERO

    @Column(name = "net_pay_before_tds")
    var netPayBeforeTds: BigDecimal = BigDecimal.ZERO

    @Column(name = "tax_summary")
    var taxSummary: String ?=null;

    @OneToMany(cascade = [CascadeType.ALL], orphanRemoval = true)
    @JoinColumn(name = "employee_salary_detail_id", referencedColumnName = "id")
    var employeeReimbursement: List<EmployeeReimbursementBO> ? = emptyList()

    @OneToMany(cascade = [CascadeType.ALL], orphanRemoval = true)
    @JoinColumn(name = "employee_salary_detail_id", referencedColumnName = "id")
    var employeeAllowance: List<EmployeeAllowanceBO> ? = emptyList()

    @OneToMany(cascade = [CascadeType.ALL], orphanRemoval = true)
    @JoinColumn(name = "employee_salary_detail_id", referencedColumnName = "id")
    var employeeDeduction: List<EmployeeDeductionBO>? = emptyList()
}
