package hostbooks.payroll.employee.service

import hostbooks.payroll.employee.dto.EmployeeLabelTO
import hostbooks.payroll.employee.dto.EmployeeSearchRequestTO
import hostbooks.payroll.employee.dto.EmployeeTO
import hostbooks.payroll.employee.entity.EmployeeProxyBO
import hostbooks.payroll.shared.utility.model.SearchResponseTO

interface EmployeeService {

    fun addEmployee(employeeTO: EmployeeTO): EmployeeTO?

    fun updateEmployee(employeeTO: EmployeeTO): EmployeeTO?

    fun getEmployeeList(employeeRequestTO: EmployeeSearchRequestTO): SearchResponseTO<EmployeeTO>

    fun getEmployeeById(id: Long): EmployeeTO?

    fun getEmployeeProxyById(employeeId: Long): EmployeeProxyBO?

    fun deleteEmployee(employeeId: List<Long>)

    fun getEmployeeNameById(id: Long): EmployeeLabelTO?

}