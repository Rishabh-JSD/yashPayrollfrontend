package hostbooks.payroll.employee.service

import hostbooks.payroll.employee.dto.*
import org.springframework.stereotype.Service
import java.math.BigDecimal
import java.math.RoundingMode

@Service
class EmployeeServiceHelper {
    private var profileCompletion = 0.0
    private var total = 0.0

    fun calculateProfileCompletion(employeeTO: EmployeeTO): BigDecimal {
        profileCompletion = 0.0
        total = 0.0

        employeeTO.employmentStatusId.let {
            profileCompletion++
        }
        total++

        employeeTO.name.let {
            profileCompletion++
        }
        total++

        employeeTO.fathersName.let {
            profileCompletion++
        }
        total++

        employeeTO.dob?.let {
            profileCompletion++
        }
        total++

        employeeTO.gender.let {
            profileCompletion++
        }
        total++

        employeeTO.personalEmail.let {
            profileCompletion++
        }
        total++

        employeeTO.officialEmail.let {
            profileCompletion++
        }
        total++

        employeeTO.phoneNo.let {
            profileCompletion++
        }
        total++

        employeeTO.maritalStatus.let {
            profileCompletion++
        }
        total++

        employeeTO.pan.let {
            profileCompletion++
        }
        total++

        employeeTO.verificationAddress.let {
            profileCompletion++
        }
        total++

        if (employeeTO.employeeAccount?.isNotEmpty() == true) {
            employeeAccountFields(employeeTO.employeeAccount!!)
        }

        if (employeeTO.employeeExperience?.isNotEmpty() == true) {
            employeeExperienceFields(employeeTO.employeeExperience!!)
        }

        if (employeeTO.employeeKyc?.isNotEmpty() == true) {
            employeeKycFields(employeeTO.employeeKyc!!)
        }

        if (employeeTO.employeeQualification?.isNotEmpty() == true) {
            employeeQualificationFields(employeeTO.employeeQualification!!)
        }

        if (employeeTO.employeeReference?.isNotEmpty() == true) {
            employeeReferenceFields(employeeTO.employeeReference!!)
        }

        employeeTO.employeeCompanyDetails?.let {
            employeeCompanyDetailsFields(it)
        }

        employeeTO.employeeSalaryDetails?.let {
            employeeSalaryDetailsFields(it)
        }

//        employeeTO.addressCorrespondence?.let {
//            employeeAddressFields(it)
//        }
//
//        employeeTO.addressPermanent?.let {
//            employeeAddressFields(it)
//        }

        return roundedValue((profileCompletion / total) * 100)
    }

    private fun employeeAccountFields(employeeAccountTOList: List<EmployeeAccountTO>) {
        for (employeeAccountTO in employeeAccountTOList) {
            employeeAccountTO.fullName.let {
                profileCompletion++
            }
            total++

            employeeAccountTO.bankName.let {
                profileCompletion++
            }
            total++

            employeeAccountTO.accountNumber.let {
                profileCompletion++
            }
            total++

            employeeAccountTO.branchName.let {
                profileCompletion++
            }
            total++

            employeeAccountTO.ifsc.let {
                profileCompletion++
            }
            total++
        }
    }

    private fun employeeExperienceFields(employeeExperienceTOList: List<EmployeeExperienceTO>) {
        for (employeeExperienceTO in employeeExperienceTOList) {
            employeeExperienceTO.title?.let {
                profileCompletion++
            }
            total++

            employeeExperienceTO.employmentTypeCode?.let {
                profileCompletion++
            }
            total++

            employeeExperienceTO.companyName?.let {
                profileCompletion++
            }
            total++

            employeeExperienceTO.countryName?.let {
                profileCompletion++
            }
            total++

            employeeExperienceTO.stateName?.let {
                profileCompletion++
            }
            total++

            employeeExperienceTO.startDate?.let {
                profileCompletion++
            }
            total++

            employeeExperienceTO.endDate?.let {
                profileCompletion++
            }
            total++

            employeeExperienceTO.jobTitle?.let {
                profileCompletion++
            }
            total++

            employeeExperienceTO.industryId?.let {
                profileCompletion++
            }
            total++

            employeeExperienceTO.jobDescription?.let {
                profileCompletion++
            }
            total++

            if (employeeExperienceTO.employeeExperienceAttachments != null && employeeExperienceTO.employeeExperienceAttachments!!.isNotEmpty()) {
                for (employeeExperienceAttachment in employeeExperienceTO.employeeExperienceAttachments!!) {
                    employeeExperienceAttachment.documentTypeId?.let {
                        profileCompletion++
                    }
                    total++

                    employeeExperienceAttachment.remark?.let {
                        profileCompletion++
                    }
                    total++

                    employeeExperienceAttachment.documentId?.let {
                        profileCompletion++
                    }
                    total++
                }
            }
        }
    }

    private fun employeeKycFields(employeeKycTOList: List<EmployeeKycTO>) {
        for (employeeKycTO in employeeKycTOList) {
            employeeKycTO.documentTypeId?.let {
                profileCompletion++
            }
            total++

            employeeKycTO.remark?.let {
                profileCompletion++
            }
            total++

            employeeKycTO.documentId?.let {
                profileCompletion++
            }
            total++
        }
    }

    private fun employeeQualificationFields(employeeQualificationTOList: List<EmployeeQualificationTO>) {
        for (employeeQualificationTO in employeeQualificationTOList) {
            employeeQualificationTO.documentTypeId?.let {
                profileCompletion++
            }
            total++

            employeeQualificationTO.remark?.let {
                profileCompletion++
            }
            total++

            employeeQualificationTO.institutionDescription?.let {
                profileCompletion++
            }
            total++

            employeeQualificationTO.countryName?.let {
                profileCompletion++
            }
            total++

            employeeQualificationTO.stateName?.let {
                profileCompletion++
            }
            total++

            employeeQualificationTO.documentId?.let {
                profileCompletion++
            }
            total++
        }
    }

    private fun employeeReferenceFields(employeeReferenceTOList: List<EmployeeReferenceTO>) {
        for (employeeReferenceTO in employeeReferenceTOList) {
            employeeReferenceTO.name?.let {
                profileCompletion++
            }
            total++

            employeeReferenceTO.mobile?.let {
                profileCompletion++
            }
            total++
        }
    }

    private fun employeeCompanyDetailsFields(employeeCompanyDetailsTO: EmployeeCompanyDetailsTO) {
        employeeCompanyDetailsTO.employeeNumber?.let {
            profileCompletion++
        }
        total++

        employeeCompanyDetailsTO.joiningDate?.let {
            profileCompletion++
        }
        total++

        employeeCompanyDetailsTO.employeeCategoryId?.let {
            profileCompletion++
        }
        total++

        employeeCompanyDetailsTO.employeeNumber?.let {
            profileCompletion++
        }
        total++

        employeeCompanyDetailsTO.attendanceTypeCode?.let {
            profileCompletion++
        }
        total++

        employeeCompanyDetailsTO.contractFrom?.let {
            profileCompletion++
        }
        total++

        employeeCompanyDetailsTO.contractTo?.let {
            profileCompletion++
        }
        total++

        employeeCompanyDetailsTO.shiftTypeId?.let {
            profileCompletion++
        }
        total++

        employeeCompanyDetailsTO.shiftTimingId?.let {
            profileCompletion++
        }
        total++

        employeeCompanyDetailsTO.designationId?.let {
            profileCompletion++
        }
        total++

        employeeCompanyDetailsTO.employeeLevelId?.let {
            profileCompletion++
        }
        total++

        employeeCompanyDetailsTO.payFrequencyId?.let {
            profileCompletion++
        }
        total++

        employeeCompanyDetailsTO.separationDate?.let {
            profileCompletion++
        }
        total++

        employeeCompanyDetailsTO.jobDescription?.let {
            profileCompletion++
        }
        total++
    }

    private fun employeeSalaryDetailsFields(employeeSalaryDetailsTO: EmployeeSalaryDetailsTO) {
        employeeSalaryDetailsTO.basicSalary.let {
            profileCompletion++
        }
        total++

        employeeSalaryDetailsTO.ctc.let {
            profileCompletion++
        }
        total++

        employeeSalaryDetailsTO.netPayBeforeTds.let {
            profileCompletion++
        }
        total++

        employeeSalaryDetailsTO.taxSummary.let {
            profileCompletion++
        }
        total++

        if (employeeSalaryDetailsTO.employeeReimbursement?.isNotEmpty() == true) {
            for (employeeReimbursementTO in employeeSalaryDetailsTO.employeeReimbursement!!) {
                employeeReimbursementTO.reimbursementMasterId.let {
                    profileCompletion++
                }
                total++

                employeeReimbursementTO.amount.let {
                    profileCompletion++
                }
                total++
            }
        }

        if (employeeSalaryDetailsTO.employeeAllowance?.isNotEmpty() == true) {
            for (employeeAllowanceTO in employeeSalaryDetailsTO.employeeAllowance!!) {
                employeeAllowanceTO.allowanceMasterId.let {
                    profileCompletion++
                }
                total++

                employeeAllowanceTO.amount.let {
                    profileCompletion++
                }
                total++
            }
        }

        if (employeeSalaryDetailsTO.employeeDeduction?.isNotEmpty() == true) {
            for (employeeDeductionTO in employeeSalaryDetailsTO.employeeDeduction!!) {
                employeeDeductionTO.deductionMasterId?.let {
                    profileCompletion++
                }
                total++

                employeeDeductionTO.amount?.let {
                    profileCompletion++
                }
                total++
            }
        }
    }

//    private fun employeeAddressFields(addressTO: AddressTO) {
//        addressTO.addressOne?.let {
//            profileCompletion++
//        }
//        total++
//
//        addressTO.cityId?.let {
//            profileCompletion++
//        }
//        total++
//
//        addressTO.pincodeId?.let {
//            profileCompletion++
//        }
//        total++
//
//        addressTO.stateId?.let {
//            profileCompletion++
//        }
//        total++
//
//        addressTO.countryId?.let {
//            profileCompletion++
//        }
//        total++
//    }

    private fun roundedValue(value: Double): BigDecimal {
        return BigDecimal.valueOf(value).setScale(2, RoundingMode.HALF_EVEN)
    }
}
