package hostbooks.payroll.employee.service

import hostbooks.payroll.address.service.AddressService
import hostbooks.payroll.companyDetail.branch.service.BranchService
import hostbooks.payroll.companyDetail.costCenter.service.CostCenterService
import hostbooks.payroll.companyDetail.department.service.DepartmentService
import hostbooks.payroll.core.commonDao.CommonDao
import hostbooks.payroll.core.dto.FilterInfo
import hostbooks.payroll.core.dto.HbSort
import hostbooks.payroll.employee.dto.EmployeeLabelTO
import hostbooks.payroll.employee.dto.EmployeeSearchRequestTO
import hostbooks.payroll.employee.dto.EmployeeTO
import hostbooks.payroll.employee.entity.EmployeeBO
import hostbooks.payroll.employee.entity.EmployeeProxyBO
import hostbooks.payroll.masters.option.service.MasterOptionService
import hostbooks.payroll.shared.constant.AppEnum
import hostbooks.payroll.shared.utility.MapHandler
import hostbooks.payroll.shared.utility.model.CommonListTO
import hostbooks.payroll.shared.utility.model.SearchResponseTO
import jakarta.transaction.Transactional
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.data.domain.Page
import org.springframework.data.domain.PageRequest
import org.springframework.data.domain.Pageable
import org.springframework.stereotype.Service
import java.util.*


@Service
@Transactional
open class EmployeeServiceImpl @Autowired constructor(
    private val masterOptionService: MasterOptionService,
    private val departmentService: DepartmentService,
    private val addressService: AddressService,
    private val branchService: BranchService,
    private val costCenterService: CostCenterService,
    private val employeeServiceHelper: EmployeeServiceHelper,
    private val mapHandler: MapHandler,
    private val commonDao: CommonDao
) : EmployeeService {

    override fun addEmployee(employeeTO: EmployeeTO): EmployeeTO? {
        employeeTO.profileCompletion = employeeServiceHelper.calculateProfileCompletion(employeeTO)
        val employeeBO: EmployeeBO? = mapHandler.mapObject(employeeTO, EmployeeBO::class.java)
        return mapHandler.mapObject(commonDao.persist(employeeBO), EmployeeTO::class.java)
    }

    override fun updateEmployee(employeeTO: EmployeeTO): EmployeeTO? {
        employeeTO.profileCompletion = employeeServiceHelper.calculateProfileCompletion(employeeTO)
        val employeeBO: EmployeeBO? = mapHandler.mapObject(employeeTO, EmployeeBO::class.java)
        return mapHandler.mapObject(commonDao.merge(employeeBO), EmployeeTO::class.java)
    }

    @Transactional(Transactional.TxType.NOT_SUPPORTED)
    override fun getEmployeeList(employeeRequestTO: EmployeeSearchRequestTO): SearchResponseTO<EmployeeTO> {
        val searchResponseTO = SearchResponseTO<EmployeeTO>()
        val discriminatorMap: WeakHashMap<String, FilterInfo<*>> = WeakHashMap<String, FilterInfo<*>>()
        discriminatorMap["status"] = FilterInfo(AppEnum.FilterType.EQ, AppEnum.Status.ACTIVE.toString());
        val commonListTO: CommonListTO<EmployeeTO> = CommonListTO<EmployeeTO>()
        if (employeeRequestTO.searchFor != null) {
            discriminatorMap["name"] = FilterInfo(AppEnum.FilterType.LIKE, employeeRequestTO.searchFor)
        }
        val pageable: Pageable = PageRequest.of(employeeRequestTO.page -1, employeeRequestTO.limit)
       val sorts: List<HbSort> = Arrays.asList<HbSort>(HbSort("id", AppEnum.SortDirection.DESC))
        val data: Page<EmployeeBO> = commonDao.listByFilterPagination(EmployeeBO::class.java, discriminatorMap, pageable, sorts);
        commonListTO.dataList = mapHandler.mapObjectList(data.content, EmployeeTO::class.java)
        commonListTO.totalRow = data.totalElements
        commonListTO.pageCount = data.totalPages.toLong()
        val employeeTOS: MutableList<EmployeeTO> = ArrayList()
        if (commonListTO.dataList != null && commonListTO.dataList!!.isNotEmpty()) {
            for (employeeTO in commonListTO.dataList!!) {
                val employmentStatus = employeeTO.employmentStatusId?.let { masterOptionService.getMasterOptionById(it) }
                if (employmentStatus != null) {
                    employeeTO.employmentStatusName = employmentStatus.name
                }

                if (employeeTO.employeeCompanyDetails?.designationId != null) {
                    val designation =
                        employeeTO.employeeCompanyDetails!!.designationId?.let {
                            masterOptionService.getMasterOptionById(
                                it
                            )
                        }
                    if (designation != null) {
                        employeeTO.employeeCompanyDetails!!.designationName = designation.name.toString()
                    }
                }
                if (employeeTO.employeeCompanyDetails?.departmentId != null) {
                    val department =
                        employeeTO.employeeCompanyDetails!!.departmentId?.let { departmentService.getDepartmentById(it) }
                    if (department != null) {
                        employeeTO.employeeCompanyDetails!!.departmentName = department.name.toString()
                    }
                }
                employeeTOS.add(employeeTO)
            }
        }
        searchResponseTO.list = employeeTOS;
        searchResponseTO.pageCount = commonListTO.pageCount!!
        searchResponseTO.totalRowCount = (commonListTO.totalRow?.toLong() ?: return searchResponseTO);
        return searchResponseTO;
    }

    @Transactional(Transactional.TxType.NOT_SUPPORTED)
    override fun getEmployeeById(id: Long): EmployeeTO? {
        val employeeTO: EmployeeTO? =
            mapHandler.mapObject(commonDao.findByPrimaryKey(EmployeeBO::class.java, id), EmployeeTO::class.java);
        if (employeeTO != null) {
            val employmentStatus = employeeTO.employmentStatusId?.let { masterOptionService.getMasterOptionById(it) }
            if (employmentStatus != null) {
                employeeTO.employmentStatusName = employmentStatus.name
            }
        }

        if (employeeTO != null) {
            if (employeeTO.employeeCompanyDetails != null) {
                if (employeeTO.employeeCompanyDetails?.employeeCategoryId != null) {
                    val categoryId =
                        employeeTO.employeeCompanyDetails!!.employeeCategoryId?.let {
                            masterOptionService.getMasterOptionById(
                                it
                            )
                        }
                    if (categoryId != null) {
                        employeeTO.employeeCompanyDetails!!.employeeCategoryName = categoryId.name.toString();
                    }
                }
                if (employeeTO.employeeCompanyDetails?.shiftTypeId != null) {
                    val shiftType =
                        employeeTO.employeeCompanyDetails!!.shiftTypeId?.let {
                            masterOptionService.getMasterOptionById(
                                it
                            )
                        }
                    if (shiftType != null) {
                        employeeTO.employeeCompanyDetails!!.shiftTypeName = shiftType.name.toString()
                    }
                }
                if (employeeTO.employeeCompanyDetails?.shiftTimingId != null) {
                    val shiftTiming =
                        employeeTO.employeeCompanyDetails!!.shiftTimingId?.let {
                            masterOptionService.getMasterOptionById(
                                it
                            )
                        }
                    if (shiftTiming != null) {
                        employeeTO.employeeCompanyDetails!!.shiftTimingStartTime = shiftTiming.startTime
                        employeeTO.employeeCompanyDetails!!.shiftTimingEndTime = shiftTiming.endTime
                    }
                }
                if (employeeTO.employeeCompanyDetails?.designationId != null) {
                    val designation =
                        employeeTO.employeeCompanyDetails!!.designationId?.let {
                            masterOptionService.getMasterOptionById(
                                it
                            )
                        }
                    if (designation != null) {
                        employeeTO.employeeCompanyDetails!!.designationName = designation.name.toString()
                    }
                }
                if (employeeTO.employeeCompanyDetails?.branchId != null) {
                    val branch = employeeTO.employeeCompanyDetails!!.branchId?.let { branchService.getBranchById(it) }
                    if (branch != null) {
                        employeeTO.employeeCompanyDetails!!.branchName = branch.name.toString()
                    }
                }
                if (employeeTO.employeeCompanyDetails?.costCenterId != null) {
                    val costCenter =
                        employeeTO.employeeCompanyDetails!!.costCenterId?.let { costCenterService.getCostCenterById(it) }
                    if (costCenter != null) {
                        employeeTO.employeeCompanyDetails!!.costCenterName = costCenter.name.toString()
                    }
                }
                if (employeeTO.employeeCompanyDetails?.departmentId != null) {
                    val department =
                        employeeTO.employeeCompanyDetails!!.departmentId?.let { departmentService.getDepartmentById(it) }
                    if (department != null) {
                        employeeTO.employeeCompanyDetails!!.departmentName = department.name.toString()
                    }
                }
                if (employeeTO.employeeCompanyDetails?.employeeLevelId != null) {
                    val employeeLevel =
                        employeeTO.employeeCompanyDetails!!.employeeLevelId?.let {
                            masterOptionService.getMasterOptionById(
                                it
                            )
                        }
                    if (employeeLevel != null) {
                        employeeTO.employeeCompanyDetails!!.employeeLevelName = employeeLevel.name.toString()
                    }
                }
                if (employeeTO.employeeCompanyDetails?.reportToId != null) {
                    val reportTo = employeeTO.employeeCompanyDetails!!.reportToId?.let { getEmployeeProxyById(it) }
                    if (reportTo != null) {
                        employeeTO.employeeCompanyDetails!!.reportToName = reportTo.name.toString()
                    }
                }

                if (employeeTO.employeeCompanyDetails?.functionalAppraiserId != null) {
                    val functionalAppraiser =
                        employeeTO.employeeCompanyDetails!!.functionalAppraiserId?.let { getEmployeeProxyById(it) }
                    if (functionalAppraiser != null) {
                        employeeTO.employeeCompanyDetails!!.functionalAppraiserName =
                            functionalAppraiser.name.toString()
                    }
                }
                if (employeeTO.employeeCompanyDetails?.adminAppraiserId != null) {
                    val adminAppraiser = employeeTO.employeeCompanyDetails!!.adminAppraiserId?.let {
                        getEmployeeProxyById(
                            it
                        )
                    }
                    if (adminAppraiser != null) {
                        employeeTO.employeeCompanyDetails!!.adminAppraiserName = adminAppraiser.name.toString()
                    }
                }
                if (employeeTO.employeeCompanyDetails?.payFrequencyId != null) {
                    val payFrequency =
                        employeeTO.employeeCompanyDetails!!.payFrequencyId?.let {
                            masterOptionService.getMasterOptionById(
                                it
                            )
                        }
                    if (payFrequency != null) {
                        employeeTO.employeeCompanyDetails!!.payFrequencyName = payFrequency.name.toString()
                    }
                }

            }
        }

        if (employeeTO != null) {
            if (employeeTO.employeeSalaryDetails != null) {
                if (employeeTO.employeeSalaryDetails!!.employeeReimbursement?.isNotEmpty() == true) {
                    for (employeeReimbursementTO in employeeTO.employeeSalaryDetails!!.employeeReimbursement!!) {
                        val reimbursementMaster =
                            employeeReimbursementTO.reimbursementMasterId?.let {
                                masterOptionService.getMasterOptionById(
                                    it
                                )
                            }
                        if (reimbursementMaster != null) {
                            employeeReimbursementTO.reimbursementMasterName = reimbursementMaster.name.toString()
                        }
                    }
                }
                if (employeeTO.employeeSalaryDetails!!.employeeAllowance?.isNotEmpty() == true) {
                    for (employeeAllowanceTO in employeeTO.employeeSalaryDetails!!.employeeAllowance!!) {
                        val allowanceMaster =
                            employeeAllowanceTO.allowanceMasterId?.let { masterOptionService.getMasterOptionById(it) }
                        if (allowanceMaster != null) {
                            employeeAllowanceTO.allowanceMasterName = allowanceMaster.name.toString()
                        }
                    }
                }
                if (employeeTO.employeeSalaryDetails!!.employeeDeduction?.isNotEmpty() == true) {
                    for (employeeDeductionTO in employeeTO.employeeSalaryDetails!!.employeeDeduction!!) {
                        val deductionMaster =
                            employeeDeductionTO.deductionMasterId?.let { masterOptionService.getMasterOptionById(it) }
                        if (deductionMaster != null) {
                            employeeDeductionTO.deductionMasterName = deductionMaster.name.toString()
                        }
                    }
                }
            }
        }

        if (employeeTO!!.employeeKyc?.isNotEmpty() == true) {
            for (employeeKycTO in employeeTO.employeeKyc!!) {
                val documentType = employeeKycTO.documentTypeId?.let { masterOptionService.getMasterOptionById(it) }
                if (documentType != null) {
                    employeeKycTO.documentTypeName = documentType.name.toString()
                }
            }
        }

        if (employeeTO.employeeQualification?.isNotEmpty() == true) {
            for (employeeQualificationTO in employeeTO.employeeQualification!!) {
                if (employeeQualificationTO.documentTypeId != null) {
                    val documentType = masterOptionService.getMasterOptionById(employeeQualificationTO.documentTypeId!!)
                    if (documentType != null) {
                        employeeQualificationTO.documentTypeName = documentType.name.toString()
                    }
                }

            }
        }

        if (employeeTO.employeeExperience?.isNotEmpty()  == true) {
            for (employeeExperienceTO in employeeTO.employeeExperience!!) {

                if (employeeExperienceTO.employeeExperienceAttachments != null && employeeExperienceTO.employeeExperienceAttachments!!.isNotEmpty()) {
                    for (employeeExperienceAttachment in employeeExperienceTO.employeeExperienceAttachments!!) {
                        if (employeeExperienceAttachment.documentTypeId != null) {
                            val documentType =
                                masterOptionService.getMasterOptionById(employeeExperienceAttachment.documentTypeId!!)
                            if (documentType != null) {
                                employeeExperienceAttachment.documentTypeName = documentType.name.toString()
                            }
                        }
                    }
                }
            }
        }
        return employeeTO
    }

    @Transactional(Transactional.TxType.NOT_SUPPORTED)
    override fun getEmployeeProxyById(employeeId: Long): EmployeeProxyBO? {
        return commonDao.findByPrimaryKey(EmployeeProxyBO::class.java, employeeId)
    }

    override fun deleteEmployee(employeeId: List<Long>) {
        for (id in employeeId) {
            val emp: EmployeeBO? = commonDao.findByPrimaryKey(EmployeeBO::class.java, id);
            if (emp != null) {
                emp.status = AppEnum.Status.INACTIVE.toString()
            };
            commonDao.merge(emp);
        }
    }

    override fun getEmployeeNameById(id: Long): EmployeeLabelTO? {
        val employeeBO: EmployeeBO? = commonDao.findByPrimaryKey(EmployeeBO::class.java, id)
        return mapHandler.mapObject(employeeBO, EmployeeLabelTO::class.java)
    }

}
