package hostbooks.payroll.employee.validator

import hostbooks.payroll.employee.controller.EmployeeController
import hostbooks.payroll.employee.dto.EmployeeSearchRequestTO
import hostbooks.payroll.employee.dto.EmployeeTO
import org.springframework.validation.Errors
import org.springframework.validation.Validator
import org.springframework.web.bind.annotation.ControllerAdvice

@ControllerAdvice(assignableTypes = [EmployeeController::class])
class EmployeeValidator : Validator {

    override fun supports(clazz: Class<*>): Boolean {
        var support = EmployeeTO::class.java == clazz
        if (!support) {
            support = EmployeeSearchRequestTO::class.java == clazz
        }
        return support
    }

    override fun validate(o: Any, errors: Errors) {
        val employeeTO = o as EmployeeTO

        // You can perform validation here if needed.
        // For example, to reject empty or whitespace for the "name" field:
        // ValidationUtils.rejectIfEmptyOrWhitespace(errors, "name", "PMS001E", APP_MSG.MESSAGE["PR001E"])
    }
}
