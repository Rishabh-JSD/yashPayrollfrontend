package hostbooks.payroll.importMasterTemplate.controller

import hostbooks.payroll.importMasterTemplate.dto.ImportTemplateHolderTO
import hostbooks.payroll.importMasterTemplate.service.ImportTemplateService
import hostbooks.payroll.shared.constant.AppMsg
import hostbooks.payroll.shared.utility.model.ResponseDTO
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.*

@RestController
@RequestMapping("/master")
class ImportTemplateController(private val importTemplateService: ImportTemplateService) {

    @PostMapping("/template/add")
    fun add(@RequestBody headerOptionsTO: ImportTemplateHolderTO): ResponseEntity<*> {
        val headerOptionsTO1 = importTemplateService.addHeaderOptions(headerOptionsTO)
        val response = ResponseDTO.responseBuilder(200, "AddImportTemplate", "TC002", "importTemplate", headerOptionsTO1)
        return ResponseEntity(response, HttpStatus.CREATED)
    }

    @GetMapping("/template/get")
    fun fetch(@RequestParam(name = "txn") txn: String): ResponseEntity<*> {
        val headerOptionsTO1 = importTemplateService.getAllTemplateByTXN(txn)
        val response = ResponseDTO.responseBuilder(200, "listTemplate", "TC002", "importTemplate", headerOptionsTO1)
        return ResponseEntity(response, HttpStatus.CREATED)
    }

    @GetMapping("/template/Id/{id}", name = "Header fetch Get by Id->MTAXR")
    fun getTemplateById(@PathVariable id: Int): ResponseEntity<*> {
        val headerOptionsTO1 = importTemplateService.getTemplateById(id)
        val response = ResponseDTO.responseBuilder(200, "getTemplateById", "TC002", "importTemplate", headerOptionsTO1)
        return ResponseEntity(response, HttpStatus.CREATED)
    }

    @GetMapping("/template/list", name = "Header fetch List->MTAXR")
    fun getAllTemplate(): ResponseEntity<*> {
        val headerOptionsTO1 = importTemplateService.getAllTemplate()
        val response = ResponseDTO.responseBuilder(200, "listTemplate", "TC002", "importTemplate", headerOptionsTO1)
        return ResponseEntity(response, HttpStatus.CREATED)
    }

    @PutMapping("/template/update", name = "Header Update->MTAXR")
    fun updateTemplate(@RequestBody headerOptionsTO: ImportTemplateHolderTO): ResponseEntity<*> {
        val headerOptionsTO1 = importTemplateService.updateTemplate(headerOptionsTO)
        val response = ResponseDTO.responseBuilder(200, "updateImportTemplate", "TC002", "importTemplate", headerOptionsTO1)
        return ResponseEntity(response, HttpStatus.CREATED)
    }

    @DeleteMapping("/delete/{id}", name = "Delete Template->BAC")
    fun deleteTemplateId(@PathVariable id: Int): ResponseEntity<*> {
        val status = importTemplateService.deleteTemplateId(id)
        val response = if (status) {
            AppMsg.RESPONSE["COM05"]?.let { ResponseDTO.responseBuilder(200, "COM05", it, "importTemplate", null) }
        } else {
            AppMsg.RESPONSE.get("COM05")?.let { ResponseDTO.responseBuilder(400, "COM03E", it, "importTemplate", null) }
        }
        return ResponseEntity(response, HttpStatus.OK)
    }
}
