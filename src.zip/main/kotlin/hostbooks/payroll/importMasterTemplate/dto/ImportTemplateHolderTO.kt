package hostbooks.payroll.importMasterTemplate.dto

class ImportTemplateHolderTO {
     var id: Int? = null
     var templateName: String? = null
     var txnType: String? = null
     var standardTemplateFlag = false
     var key: List<String>? = null
     var fieldDisplay: List<String>? = null
}