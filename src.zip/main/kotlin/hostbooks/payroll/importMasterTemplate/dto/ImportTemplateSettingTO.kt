package hostbooks.payroll.importMasterTemplate.dto

class ImportTemplateSettingTO {
      var id: Int? = null
      var templateName: String? = null
      var txnType: String? = null
      var standard_templateFlag = false
      var importTemplateTOList: List<ImportTemplateTO>? = null
}