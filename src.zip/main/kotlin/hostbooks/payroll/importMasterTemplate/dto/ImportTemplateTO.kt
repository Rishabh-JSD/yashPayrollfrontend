package hostbooks.payroll.importMasterTemplate.dto

class ImportTemplateTO {
     var id: Int? = null
     var key: String? = null
     var fieldDisplay: String? = null
     var importTemplateSetting: ImportTemplateSettingTO? = null
}