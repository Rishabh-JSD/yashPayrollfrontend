package hostbooks.payroll.importMasterTemplate.entity

import hostbooks.payroll.shared.constant.Tables
import jakarta.persistence.*
import java.io.Serializable

@Entity
@Table(name = Tables.IMPORT_TEMPLATE_FIELDS)
class ImportTemplateBO :Serializable{
    companion object {
          const val serialVersionUID = 1L
    }
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", updatable = false)
      var id: Int? = null

    @Column(name = "field_key")
      var key: String? = null

    @Column(name = "field_display")
      var fieldDisplay: String? = null

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "import_template_setting_id")
    var importTemplateSetting: ImportTemplateSettingBO? = null
}