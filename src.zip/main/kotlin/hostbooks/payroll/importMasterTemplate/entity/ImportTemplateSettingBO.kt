package hostbooks.payroll.importMasterTemplate.entity

import hostbooks.payroll.shared.constant.Tables
import jakarta.persistence.*
import java.io.Serializable

@Entity
@Table(name = Tables.IMPORT_TEMPLATE_SETTING)
class ImportTemplateSettingBO : Serializable {
    companion object {
         const val serialVersionUID = 1L
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", updatable = false)
     var id: Int? = null

    @Column(name = "template_name")
     var templateName: String? = null

    @Column(name = "txn_type")
     var txnType: String? = null

    @Column(name = "standard_template_flag")
     var standard_templateFlag = false

    @OneToMany(mappedBy = "importTemplateSetting", cascade = [CascadeType.ALL], orphanRemoval = true)
    var importTemplateBOList: List<ImportTemplateBO> = ArrayList()
}