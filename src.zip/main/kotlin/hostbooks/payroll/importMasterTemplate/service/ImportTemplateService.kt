package hostbooks.payroll.importMasterTemplate.service

import hostbooks.payroll.importMasterTemplate.dto.ImportTemplateHolderTO
import hostbooks.payroll.importMasterTemplate.dto.ImportTemplateSettingTO

interface ImportTemplateService {
    fun addHeaderOptions(importTemplateTO: ImportTemplateHolderTO?): ImportTemplateSettingTO?

    fun fetchAllTemplate(title: String): List<ImportTemplateSettingTO?>?

    fun getAllTemplate(): List<ImportTemplateSettingTO?>?

    fun getTemplateById(id: Int): ImportTemplateSettingTO?

    fun updateTemplate(importTemplateTO: ImportTemplateHolderTO?): ImportTemplateSettingTO?
    fun deleteTemplateId(id: Int): Boolean

    fun getAllTemplateByTXN(txn: String): List<ImportTemplateSettingTO>?
    fun fetchTemplateByTemplateTXN(name: String, txnType: String): List<ImportTemplateSettingTO?>?
}