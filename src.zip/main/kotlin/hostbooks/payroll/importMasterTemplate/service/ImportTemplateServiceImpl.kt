package hostbooks.payroll.importMasterTemplate.service

import hostbooks.payroll.core.commonDao.CommonDao
import hostbooks.payroll.importMasterTemplate.dto.ImportTemplateHolderTO
import hostbooks.payroll.importMasterTemplate.dto.ImportTemplateSettingTO
import hostbooks.payroll.importMasterTemplate.dto.ImportTemplateTO
import hostbooks.payroll.importMasterTemplate.entity.ImportTemplateBO
import hostbooks.payroll.importMasterTemplate.entity.ImportTemplateSettingBO
import hostbooks.payroll.shared.utility.CommonUtil
import hostbooks.payroll.shared.utility.MapHandler
import jakarta.transaction.Transactional
import org.springframework.stereotype.Service
import java.util.*

@Service
@Transactional
class ImportTemplateServiceImpl(
    private var mapHandler: MapHandler, private var commonDao: CommonDao
) : ImportTemplateService {

    override fun addHeaderOptions(importTemplateTO: ImportTemplateHolderTO?): ImportTemplateSettingTO? {
        val importTemplateSettingBO = ImportTemplateSettingBO()
        val title = importTemplateTO?.templateName
        val txn_type = importTemplateTO?.txnType
        importTemplateSettingBO.templateName = title
        importTemplateSettingBO.txnType = txn_type
        val keys = importTemplateTO?.key
        val values = importTemplateTO?.fieldDisplay

        val importTemplateBOList = ArrayList<ImportTemplateBO>()
        if (keys != null) {
            for (i in keys.indices) {
                val importTemplateBO = ImportTemplateBO()
                importTemplateBO.key = keys[i]
                importTemplateBO.fieldDisplay = values?.get(i)
                importTemplateBO.importTemplateSetting = importTemplateSettingBO
                importTemplateBOList.add(importTemplateBO)
            }
        }
        importTemplateSettingBO.importTemplateBOList = importTemplateBOList
        val importTemplateSettingBO1 = commonDao.persist(importTemplateSettingBO)
        val templateSettingTO: ImportTemplateSettingTO? = mapHandler.mapObject(importTemplateSettingBO1, ImportTemplateSettingTO::class.java)
        val importTemplateTOS = mapHandler.mapObjectList(importTemplateBOList, ImportTemplateTO::class.java)
        if (templateSettingTO != null) {
            templateSettingTO.importTemplateTOList = importTemplateTOS
        }
        return templateSettingTO
    }

    override fun fetchAllTemplate(title: String): List<ImportTemplateSettingTO?>? {
        val importTemplateSettingBOList: List<ImportTemplateSettingBO> = commonDao.selectByDiscriminator(ImportTemplateSettingBO::class.java, title, "templateName", -1)
        val ImportTeplateSettingTOList = mapHandler.mapObjectList(importTemplateSettingBOList, ImportTemplateSettingTO::class.java)
        val importTemplateTOList = ArrayList<ImportTemplateTO>()
        for (listBO in importTemplateSettingBOList) {
            val importTemplateBOList = listBO.importTemplateBOList
            mapHandler.mapObjectList(importTemplateBOList, ImportTemplateTO::class.java)?.let { importTemplateTOList.addAll(it) }
        }
        if (CommonUtil.checkNullEmpty(ImportTeplateSettingTOList)) {
            ImportTeplateSettingTOList?.get(0)?.importTemplateTOList = importTemplateTOList
            return ImportTeplateSettingTOList
        }
        return emptyList()
    }

    override fun getAllTemplate(): List<ImportTemplateSettingTO>? {
        val list: List<ImportTemplateSettingBO> = commonDao.selectAll(ImportTemplateSettingBO::class.java, -1)
        val importTeplateSettingTOList = mapHandler.mapObjectList(list, ImportTemplateSettingTO::class.java)

        for (i in list.indices) {
            val importTemplateTOList = ArrayList<ImportTemplateTO>()
            val importTemplateBOList = list[i].importTemplateBOList
            mapHandler.mapObjectList(importTemplateBOList, ImportTemplateTO::class.java)?.let { importTemplateTOList.addAll(it) }
            importTeplateSettingTOList?.get(i)?.importTemplateTOList = importTemplateTOList
        }

        return if (CommonUtil.checkNullEmpty(importTeplateSettingTOList)) {
            importTeplateSettingTOList
        } else {
            emptyList()
        }
    }

    override fun getTemplateById(id: Int): ImportTemplateSettingTO? {
        val importTemplateSettingBO = commonDao.findByPrimaryKey(ImportTemplateSettingBO::class.java, id)
        return mapHandler.mapObject(importTemplateSettingBO, ImportTemplateSettingTO::class.java)
    }

    override fun updateTemplate(importTemplateTO: ImportTemplateHolderTO?): ImportTemplateSettingTO? {
        val importTemplateSettingBO = ImportTemplateSettingBO()
        val title = importTemplateTO?.templateName
        val txn_type = importTemplateTO?.txnType
        importTemplateSettingBO.templateName = title
        importTemplateSettingBO.txnType = txn_type
        if (importTemplateTO != null) {
            importTemplateSettingBO.id = importTemplateTO.id
        }
        val keys = importTemplateTO?.key
        val values = importTemplateTO?.fieldDisplay

        val importTemplateBOList = ArrayList<ImportTemplateBO>()
        if (keys != null) {
            for (i in keys.indices) {
                val importTemplateBO = ImportTemplateBO()
                importTemplateBO.key = keys[i]
                importTemplateBO.fieldDisplay = values?.get(i)
                importTemplateBO.importTemplateSetting = importTemplateSettingBO
                importTemplateBOList.add(importTemplateBO)
            }
        }
        importTemplateSettingBO.importTemplateBOList = importTemplateBOList
        val importTemplateSettingBO1 = commonDao.merge(importTemplateSettingBO)
        val templateSettingTO = mapHandler.mapObject(importTemplateSettingBO1, ImportTemplateSettingTO::class.java)
        val importTemplateTOS = mapHandler.mapObjectList(importTemplateBOList, ImportTemplateTO::class.java)
        if (templateSettingTO != null) {
            templateSettingTO.importTemplateTOList = importTemplateTOS
        }
        return templateSettingTO
    }

    override fun deleteTemplateId(id: Int): Boolean {
        val templateBO: ImportTemplateSettingBO? = commonDao.selectSingleByDiscriminator(ImportTemplateSettingBO::class.java, id, "id")
        if (CommonUtil.checkNullEmpty(templateBO)) {
            commonDao.delete(templateBO)
        }
        return true
    }

    override fun getAllTemplateByTXN(txn: String): List<ImportTemplateSettingTO>? {
        val list: List<ImportTemplateSettingBO> = commonDao.selectByDiscriminator(ImportTemplateSettingBO::class.java, txn, "txnType", -1)
        val importTeplateSettingTOList: List<ImportTemplateSettingTO>? = mapHandler.mapObjectList(list, ImportTemplateSettingTO::class.java)

        for (i in list.indices) {
            val importTemplateBOList: List<ImportTemplateBO> = list[i].importTemplateBOList
            val importTemplateTOList: List<ImportTemplateTO>? = mapHandler.mapObjectList(importTemplateBOList, ImportTemplateTO::class.java)
            importTeplateSettingTOList!![i].importTemplateTOList = importTemplateTOList
        }

        return if (CommonUtil.checkNullEmpty(importTeplateSettingTOList)) {
            importTeplateSettingTOList
        } else {
            null
        }
    }

    override fun fetchTemplateByTemplateTXN(name: String, txnType: String): List<ImportTemplateSettingTO> {
        val discriminatorMap = WeakHashMap<String, Any>()
        discriminatorMap["templateName"] = name
        discriminatorMap["txnType"] = txnType
        val importTemplateSettingBOList: List<ImportTemplateSettingBO>? = commonDao.selectByMultipleDiscriminators(ImportTemplateSettingBO::class.java, discriminatorMap, -1)
        val ImportTeplateSettingTOList = mapHandler.mapObjectList(importTemplateSettingBOList, ImportTemplateSettingTO::class.java)
        val importTemplateTOList = ArrayList<ImportTemplateTO>()
        if (importTemplateSettingBOList != null) {
            for (listBO in importTemplateSettingBOList) {
                val importTemplateBOList: List<ImportTemplateBO> = listBO.importTemplateBOList
                mapHandler.mapObjectList(importTemplateBOList, ImportTemplateTO::class.java)?.let { importTemplateTOList.addAll(it) }
            }
        }
        if (CommonUtil.checkNullEmpty(ImportTeplateSettingTOList)) {
            ImportTeplateSettingTOList!![0].importTemplateTOList = importTemplateTOList
            return ImportTeplateSettingTOList
        }
        return emptyList()
    }
}
