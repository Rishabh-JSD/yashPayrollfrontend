package hostbooks.payroll.leave

import hostbooks.payroll.shared.utility.model.SearchRequestTO
import java.util.*

class LeaveSearchRequestTO: SearchRequestTO() {
    var name: String? = null
    var type: String? = null
    var startDate: Date? = null
    var endDate: Date? = null
    var employeeId: Long? = null
}