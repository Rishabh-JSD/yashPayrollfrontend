package hostbooks.payroll.leave.leaveAdjustment.controller

import hostbooks.payroll.leave.LeaveSearchRequestTO
import hostbooks.payroll.leave.leaveAdjustment.dto.LeaveAdjustmentTO
import hostbooks.payroll.leave.leaveAdjustment.service.LeaveAdjustmentService
import hostbooks.payroll.shared.utility.ValidationError
import hostbooks.payroll.shared.utility.model.ResponseTO
import hostbooks.payroll.shared.utility.model.SearchResponseTO
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.validation.Errors
import org.springframework.validation.Validator
import org.springframework.web.bind.WebDataBinder
import org.springframework.web.bind.annotation.*
import javax.validation.Valid

@RestController
@RequestMapping("/leave-adjustment")
class LeaveAdjustmentController(private val leaveAdjustmentService: LeaveAdjustmentService, private val leaveAdjustmentValidator: Validator) {

    @InitBinder
    private fun initBinder(binder: WebDataBinder) {
        binder.validator = this.leaveAdjustmentValidator
    }
    @PostMapping("/add")
    fun addLeaveAdjustment(@Valid @RequestBody leaveAdjustmentTO: LeaveAdjustmentTO, errors: Errors): ResponseEntity<*> {
        if (errors.hasErrors()) {
            val validationError: ValidationError = ValidationError.fromBindingErrors(errors)
            return ResponseEntity<Any>(validationError, HttpStatus.BAD_REQUEST)
        }
        val addedLeaveAdjustmentTO: LeaveAdjustmentTO = leaveAdjustmentService.addLeaveAdjustment(leaveAdjustmentTO)
        val responseDTO = ResponseTO.responseBuilder(201, "COM09", "/leave-adjustment", "leaveAdjustment", addedLeaveAdjustmentTO)
        return ResponseEntity<Any>(responseDTO, HttpStatus.CREATED)
    }

    @PostMapping("/list")
    fun getLeaveAdjustmentList(@RequestBody leaveSearchRequestTO: LeaveSearchRequestTO): ResponseEntity<*> {
        val responseTO: SearchResponseTO<LeaveAdjustmentTO> = leaveAdjustmentService.getLeaveAdjustmentList(leaveSearchRequestTO)
        val responseLeaveAdjustmentTO = ResponseTO.responseBuilder(200, "COM04", "/leave-adjustment", "leaveAdjustment", responseTO)
        return ResponseEntity<ResponseTO>(responseLeaveAdjustmentTO, HttpStatus.OK)
    }

    @PutMapping("/update")
    fun updateLeaveAdjustment(@Valid @RequestBody leaveAdjustmentTO: LeaveAdjustmentTO, errors: Errors): ResponseEntity<*> {
        if (errors.hasErrors()) {
            val validationError: ValidationError = ValidationError.fromBindingErrors(errors)
            return ResponseEntity<Any>(validationError, HttpStatus.OK)
        }
        val addedLeaveAdjustment: LeaveAdjustmentTO =leaveAdjustmentService.updateLeaveAdjustment(leaveAdjustmentTO)
        val responseLeaveAdjustmentTO = ResponseTO.responseBuilder(200, "COM02", "/leave-adjustment", "leaveAdjustment", addedLeaveAdjustment)
        return ResponseEntity<Any>(responseLeaveAdjustmentTO, HttpStatus.OK)
    }

    @DeleteMapping("/delete")
    fun deleteLeaveAdjustment(@Valid @RequestParam(name = "leaveAdjustmentIdList") leaveAdjustmentIdList: List<Long>): ResponseEntity<*> {
        leaveAdjustmentService.deleteLeaveAdjustment(leaveAdjustmentIdList)
        val responseLeaveAdjustmentTO = ResponseTO.responseBuilder(200, "COM05", "/leave-adjustment", "leaveAdjustment", leaveAdjustmentIdList)
        return ResponseEntity<Any>(responseLeaveAdjustmentTO, HttpStatus.OK)
    }

    @GetMapping("/{id}")
    fun getLeaveAdjustmentById(@PathVariable id: Long): ResponseEntity<*> {
        val leaveAdjustmentTO: LeaveAdjustmentTO? = leaveAdjustmentService.getLeaveAdjustmentById(id)
        if (leaveAdjustmentTO == null) {
            val responseDTO = ResponseTO.responseBuilder(200, "COM03E", "/leave-adjustment", "leaveAdjustment", null)
            return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
        }
        val responseDTO = ResponseTO.responseBuilder(200, "COM11", "/leave-adjustment", "leaveAdjustment", leaveAdjustmentTO)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }
}