package hostbooks.payroll.leave.leaveAdjustment.dto

import hostbooks.payroll.shared.utility.model.AuditTO
import java.math.BigDecimal
import java.util.*

class LeaveAdjustmentTO : AuditTO() {
    var id: Long? = null
    var employeeId: Long? = null
    var date: Date? = null
    var leaveTypeId: Long? = null
    var quantity: BigDecimal? = null
    var quantityType: String? = null
    var adjType: String? = null
    var status: String? = null
}