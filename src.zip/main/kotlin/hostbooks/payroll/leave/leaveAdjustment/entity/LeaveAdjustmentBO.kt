package hostbooks.payroll.leave.leaveAdjustment.entity
import hostbooks.payroll.shared.constant.Tables
import hostbooks.payroll.shared.utility.model.Audit
import jakarta.persistence.*
import java.math.BigDecimal
import java.util.*

@Entity
@Table(name = Tables.LEAVE_ADJUSTMENT)
class LeaveAdjustmentBO: Audit() {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    var id: Long? = null

    @Column(name = "employee_id")
    var employeeId: Long? = null

    @Column(name = "date")
    var date: Date? = null

    @Column(name = "leave_type_id")
    var leaveTypeId: Long? = null

    @Column(name = "quantity")
    var quantity: BigDecimal? = null

    @Column(name = "quantity_type")
    var quantityType: String? = null

    @Column(name = "adj_type")
    var adjType: String? = null

    @Column(name = "status")
    var status: String? = null
}