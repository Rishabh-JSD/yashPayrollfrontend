package hostbooks.payroll.leave.leaveAdjustment.service

import hostbooks.payroll.leave.LeaveSearchRequestTO
import hostbooks.payroll.leave.leaveAdjustment.dto.LeaveAdjustmentTO
import hostbooks.payroll.shared.utility.model.SearchResponseTO

interface LeaveAdjustmentService {

   fun addLeaveAdjustment(leaveAdjustmentTO: LeaveAdjustmentTO):LeaveAdjustmentTO

   fun getLeaveAdjustmentList(leaveSearchRequestTO: LeaveSearchRequestTO): SearchResponseTO<LeaveAdjustmentTO>

   fun updateLeaveAdjustment(leaveAdjustmentTO: LeaveAdjustmentTO): LeaveAdjustmentTO

   fun deleteLeaveAdjustment(leaveId: List<Long>)

   fun getLeaveAdjustmentById(id: Long): LeaveAdjustmentTO?

}