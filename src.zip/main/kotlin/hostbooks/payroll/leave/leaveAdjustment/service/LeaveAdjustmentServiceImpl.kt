package hostbooks.payroll.leave.leaveAdjustment.service

import hostbooks.payroll.core.commonDao.CommonDao
import hostbooks.payroll.core.dto.FilterInfo
import hostbooks.payroll.core.dto.HbSort
import hostbooks.payroll.leave.LeaveSearchRequestTO
import hostbooks.payroll.leave.leaveAdjustment.dto.LeaveAdjustmentTO
import hostbooks.payroll.leave.leaveAdjustment.entity.LeaveAdjustmentBO
import hostbooks.payroll.shared.constant.AppEnum
import hostbooks.payroll.shared.utility.MapHandler
import hostbooks.payroll.shared.utility.model.SearchResponseTO
import jakarta.transaction.Transactional
import org.springframework.data.domain.Page
import org.springframework.data.domain.PageRequest
import org.springframework.data.domain.Pageable
import org.springframework.stereotype.Service
import java.util.*

@Service
@Transactional
open class LeaveAdjustmentServiceImpl(private val commonDao: CommonDao,
                                 private val mapHandler: MapHandler
): LeaveAdjustmentService {
    override fun addLeaveAdjustment(leaveAdjustmentTO: LeaveAdjustmentTO): LeaveAdjustmentTO {
        val entity = mapHandler.mapObject(leaveAdjustmentTO, LeaveAdjustmentBO::class.java)
        val persistedEntity = commonDao.persistWithFlush(entity)
        return mapHandler.mapObject(persistedEntity, LeaveAdjustmentTO::class.java)?: leaveAdjustmentTO
    }

    override fun getLeaveAdjustmentList(leaveSearchRequestTO: LeaveSearchRequestTO): SearchResponseTO<LeaveAdjustmentTO> {
        val searchResponseTO = SearchResponseTO<LeaveAdjustmentTO>()
        val discriminatorMap: WeakHashMap<String, FilterInfo<*>> = WeakHashMap<String, FilterInfo<*>>()
        val pageable: Pageable = PageRequest.of(leaveSearchRequestTO.page - 1, leaveSearchRequestTO.limit)
        val sorts: List<HbSort> = listOf(HbSort("date", AppEnum.SortDirection.DESC))
        val data: Page<LeaveAdjustmentBO> = commonDao.listByFilterPagination(LeaveAdjustmentBO::class.java, discriminatorMap, pageable, sorts)
         searchResponseTO.list = mapHandler.mapObjectList(data.content, LeaveAdjustmentTO::class.java)
         searchResponseTO.pageCount = data.totalPages.toLong()
         searchResponseTO.totalRowCount = data.totalElements
        return searchResponseTO
    }

    override fun updateLeaveAdjustment(leaveAdjustmentTO: LeaveAdjustmentTO): LeaveAdjustmentTO {
        val entity = mapHandler.mapObject(leaveAdjustmentTO, LeaveAdjustmentBO::class.java)
        val updatedEntity = commonDao.updateWithFlush(entity)
        return mapHandler.mapObject(updatedEntity, LeaveAdjustmentTO::class.java) ?: leaveAdjustmentTO
    }

    override fun deleteLeaveAdjustment(leaveId: List<Long>) {
        for (id in leaveId) {
            val leaveAdjustment: LeaveAdjustmentBO? = commonDao.findByPrimaryKey(LeaveAdjustmentBO::class.java, id)
            if (leaveAdjustment != null) {
                commonDao.deleteWithFlush(leaveAdjustment)
            }
        }
    }

    override fun getLeaveAdjustmentById(id: Long): LeaveAdjustmentTO? {
        val leaveAdjustmentBO: LeaveAdjustmentBO? = commonDao.findByPrimaryKey(LeaveAdjustmentBO::class.java, id)
        return mapHandler.mapObject(leaveAdjustmentBO, LeaveAdjustmentTO::class.java)
    }
}