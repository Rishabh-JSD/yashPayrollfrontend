package hostbooks.payroll.leave.leaveAdjustment.validator

import hostbooks.payroll.shared.constant.AppEnum
import hostbooks.payroll.leave.LeaveSearchRequestTO
import hostbooks.payroll.leave.leaveAdjustment.controller.LeaveAdjustmentController
import hostbooks.payroll.leave.leaveAdjustment.dto.LeaveAdjustmentTO
import org.springframework.validation.Errors
import org.springframework.validation.Validator
import org.springframework.web.bind.annotation.ControllerAdvice

@ControllerAdvice(assignableTypes = [LeaveAdjustmentController::class])
class LeaveAdjustmentValidator : Validator {
    override fun supports(clazz: Class<*>): Boolean {
        return (clazz == LeaveAdjustmentTO::class.java || clazz == LeaveSearchRequestTO::class.java)
    }

    override fun validate(target: Any, errors: Errors) {
        if (target is LeaveAdjustmentTO) {
            if (target.leaveTypeId == null) {
                errors.rejectValue("leaveTypeId", "field.required", "Leave Type ID is required")
            }
            if (target.quantity == null) {
                errors.rejectValue("quantity", "field.required", "Quantity must be a positive number")
            }
            if (target.employeeId == null) {
                errors.rejectValue("employeeId", "field.required", "Employee ID is required")
            }
            val validAdjTypes = AppEnum.LeaveAdjustmentType.values().map { it.name }.toSet()
            if (target.adjType == null) {
                errors.rejectValue("adjType", "field.required", "AdjType is required")
            } else if (target.adjType !in validAdjTypes) {
                errors.rejectValue("adjType", "field.invalid", "Invalid AdjType")
            }
            val validQuantityType = AppEnum.LeaveQuantityType.values().map { it.name }.toSet()
            if (target.quantityType == null) {
                errors.rejectValue("quantityType", "field.required", "QuantityType is required")
            } else if (target.quantityType !in validQuantityType) {
                errors.rejectValue("quantityType", "field.invalid", "Invalid QuantityType")
            }
        }
    }
}