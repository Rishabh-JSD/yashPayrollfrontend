package hostbooks.payroll.leave.leaveApply.controller

import hostbooks.payroll.leave.LeaveSearchRequestTO
import hostbooks.payroll.leave.leaveApply.dto.LeaveApplyTO
import hostbooks.payroll.leave.leaveApply.service.LeaveApplyService
import hostbooks.payroll.shared.utility.ValidationError
import hostbooks.payroll.shared.utility.model.ResponseTO
import hostbooks.payroll.shared.utility.model.SearchResponseTO
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.validation.Errors
import org.springframework.validation.Validator
import org.springframework.web.bind.WebDataBinder
import org.springframework.web.bind.annotation.*
import javax.validation.Valid

@RestController
@RequestMapping("/leave-apply")
class LeaveApplyController(private val leaveApplyService: LeaveApplyService, private val leaveApplyValidator: Validator) {

    @InitBinder
    private fun initBinder(binder: WebDataBinder) {
        binder.validator = this.leaveApplyValidator
    }

    @PostMapping("/add")
    fun addLeaveApply(@Valid @RequestBody leaveApplyTO: LeaveApplyTO, errors: Errors): ResponseEntity<*> {
        if (errors.hasErrors()) {
            val validationError: ValidationError = ValidationError.fromBindingErrors(errors)
            return ResponseEntity<Any>(validationError, HttpStatus.BAD_REQUEST)
        }
        val addedLeaveApplyTO: LeaveApplyTO = leaveApplyService.addLeaveApply(leaveApplyTO)
        val responseDTO = ResponseTO.responseBuilder(201, "COM09", "/leave-apply", "leaveApply", addedLeaveApplyTO)
        return ResponseEntity<Any>(responseDTO, HttpStatus.CREATED)
    }

    @PostMapping("/list")
    fun getLeaveApplyList(@RequestBody leaveSearchRequestTO: LeaveSearchRequestTO): ResponseEntity<*> {
        val responseTO: SearchResponseTO<LeaveApplyTO> = leaveApplyService.getLeaveApplyList(leaveSearchRequestTO)
        val responseDTO = ResponseTO.responseBuilder(200, "COM04", "/leave-apply", "leaveApply", responseTO)
        return ResponseEntity<ResponseTO>(responseDTO, HttpStatus.OK)
    }

    @PutMapping("/update")
    fun updateLeaveApply(@Valid @RequestBody leaveApplyTO: LeaveApplyTO, errors: Errors): ResponseEntity<*> {
        if (errors.hasErrors()) {
            val validationError: ValidationError = ValidationError.fromBindingErrors(errors)
            return ResponseEntity<Any>(validationError, HttpStatus.OK)
        }
        val addedLeaveApplyTO: LeaveApplyTO =leaveApplyService.updateLeaveApply(leaveApplyTO)
        val responseDTO = ResponseTO.responseBuilder(200, "COM02", "/leave-apply", "leaveApply", addedLeaveApplyTO)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }

    @DeleteMapping("/delete")
    fun deleteLeaveApply(@Valid @RequestParam(name = "leaveApplyIdList") leaveApplyIdList: List<Long>): ResponseEntity<*> {
        leaveApplyService.deleteLeaveApply(leaveApplyIdList)
        val responseDTO = ResponseTO.responseBuilder(200, "COM05", "/leave-apply", "leaveApply", leaveApplyIdList)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }

    @GetMapping("/{id}")
    fun getLeaveApplyById(@PathVariable id: Long): ResponseEntity<*> {
        val leaveApplyTO: LeaveApplyTO? = leaveApplyService.getLeaveApplyById(id)
        if (leaveApplyTO == null) {
            val responseDTO = ResponseTO.responseBuilder(200, "COM03E", "/leave-apply", "leaveApply", null)
            return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
        }
        val responseDTO = ResponseTO.responseBuilder(200, "COM11", "/leave-apply", "leaveApply", leaveApplyTO)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }


}