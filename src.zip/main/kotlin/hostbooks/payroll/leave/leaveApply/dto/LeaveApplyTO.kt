package hostbooks.payroll.leave.leaveApply.dto

import hostbooks.payroll.shared.utility.model.AuditTO
import java.util.*

class LeaveApplyTO: AuditTO() {
    var id: Long? = null
    var employeeId: Long? = null
    var startDate: Date? = null
    var startDateType: String? = null
    var endDate: Date? = null
    var endDateType: String? = null
    var numberOfDays: Double? = null
    var leaveTypeId: Long? = null
    var employeeCcIds: String? = null
    var reason: String? = null
    var approverRemarks: String? = null
    var status: String? = null
}