package hostbooks.payroll.leave.leaveApply.entity

import hostbooks.payroll.shared.constant.Tables
import hostbooks.payroll.shared.utility.model.Audit
import jakarta.persistence.*
import java.util.*

@Entity
@Table(name = Tables.LEAVE_APPLY)
class LeaveApplyBO: Audit() {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", updatable = false, nullable = false)
    var id: Long? = null

    @Column(name = "employee_id")
    var employeeId: Long? = null

    @Column(name = "start_date")
    var startDate: Date? = null

    @Column(name = "start_date_type")
    var startDateType: String? = null

    @Column(name = "end_date")
    var endDate: Date? = null

    @Column(name = "end_date_type")
    var endDateType: String? = null

    @Column(name = "no_of_days")
    var numberOfDays: Double? = null

    @Column(name = "leave_type_id")
    var leaveTypeId: Long? = null

    @Column(name = "employee_cc_ids")
    var employeeCcIds: String? = null

    @Column(name = "reason")
    var reason: String? = null

    @Column(name = "approver_remarks")
    var approverRemarks: String? = null

    @Column(name = "status")
    var status: String? = null

}