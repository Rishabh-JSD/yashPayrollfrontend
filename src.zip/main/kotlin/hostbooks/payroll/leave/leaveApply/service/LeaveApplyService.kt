package hostbooks.payroll.leave.leaveApply.service

import hostbooks.payroll.leave.LeaveSearchRequestTO
import hostbooks.payroll.leave.leaveApply.dto.LeaveApplyTO
import hostbooks.payroll.shared.utility.model.SearchResponseTO

interface LeaveApplyService {

    fun addLeaveApply(leaveApplyTO: LeaveApplyTO): LeaveApplyTO

    fun getLeaveApplyList(leaveSearchRequestTO: LeaveSearchRequestTO): SearchResponseTO<LeaveApplyTO>

    fun updateLeaveApply(leaveApplyTO: LeaveApplyTO): LeaveApplyTO

    fun deleteLeaveApply(leaveApplyIdList: List<Long>)

    fun getLeaveApplyById(id: Long): LeaveApplyTO?
}