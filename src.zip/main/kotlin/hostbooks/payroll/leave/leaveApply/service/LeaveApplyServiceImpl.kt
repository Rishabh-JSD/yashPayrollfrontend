package hostbooks.payroll.leave.leaveApply.service

import hostbooks.payroll.core.commonDao.CommonDao
import hostbooks.payroll.core.dto.FilterInfo
import hostbooks.payroll.core.dto.HbSort
import hostbooks.payroll.leave.LeaveSearchRequestTO
import hostbooks.payroll.leave.leaveApply.dto.LeaveApplyTO
import hostbooks.payroll.leave.leaveApply.entity.LeaveApplyBO
import hostbooks.payroll.shared.constant.AppEnum
import hostbooks.payroll.shared.utility.MapHandler
import hostbooks.payroll.shared.utility.model.SearchResponseTO
import jakarta.transaction.Transactional
import org.springframework.data.domain.Page
import org.springframework.data.domain.PageRequest
import org.springframework.data.domain.Pageable
import org.springframework.stereotype.Service
import java.util.*

@Service
@Transactional
open class LeaveApplyServiceImpl(private val commonDao: CommonDao,
                            private val mapHandler: MapHandler
): LeaveApplyService {

    override fun addLeaveApply(leaveApplyTO: LeaveApplyTO): LeaveApplyTO {
        val entity = mapHandler.mapObject(leaveApplyTO, LeaveApplyBO::class.java)
        val persistedEntity = commonDao.persistWithFlush(entity)
        return mapHandler.mapObject(persistedEntity, LeaveApplyTO::class.java)?: leaveApplyTO
    }

    override fun getLeaveApplyList(leaveSearchRequestTO: LeaveSearchRequestTO): SearchResponseTO<LeaveApplyTO> {
        val searchResponseTO = SearchResponseTO<LeaveApplyTO>()
        val discriminatorMap: WeakHashMap<String, FilterInfo<*>> = WeakHashMap<String, FilterInfo<*>>()
//        if (leaveSearchRequestTO.startDate != null) {
//            discriminatorMap["startDate"] = FilterInfo(AppEnum.FilterType.GEQ, leaveSearchRequestTO.startDate)
//        }
//        if (leaveSearchRequestTO.endDate != null) {
//            discriminatorMap["endDate"] = FilterInfo(AppEnum.FilterType.LEQ, leaveSearchRequestTO.endDate)
//        }
        if (leaveSearchRequestTO.employeeId != null) {
            discriminatorMap["employeeId"] = FilterInfo(AppEnum.FilterType.EQ, leaveSearchRequestTO.employeeId)
        }
        val pageable: Pageable = PageRequest.of(leaveSearchRequestTO.page - 1, leaveSearchRequestTO.limit)
        val sorts: List<HbSort> = listOf(HbSort("startDate", AppEnum.SortDirection.ASC))
        val data: Page<LeaveApplyBO> = commonDao.listByFilterPagination(LeaveApplyBO::class.java, discriminatorMap, pageable, sorts)
        searchResponseTO.list = mapHandler.mapObjectList(data.content, LeaveApplyTO::class.java)
        searchResponseTO.pageCount = data.totalPages.toLong()
        searchResponseTO.totalRowCount = data.totalElements
        return searchResponseTO
    }

    override fun updateLeaveApply(leaveApplyTO: LeaveApplyTO): LeaveApplyTO {
        val entity = mapHandler.mapObject(leaveApplyTO, LeaveApplyBO::class.java)
        val updatedEntity = commonDao.updateWithFlush(entity)
        return mapHandler.mapObject(updatedEntity, LeaveApplyTO::class.java) ?: leaveApplyTO
    }

    override fun deleteLeaveApply(leaveApplyIdList: List<Long>) {
        for (id in leaveApplyIdList) {
            val leaveApply: LeaveApplyBO? = commonDao.findByPrimaryKey(LeaveApplyBO::class.java, id)
            if (leaveApply != null) {
                commonDao.deleteWithFlush(leaveApply)
            }
        }
    }

    override fun getLeaveApplyById(id: Long): LeaveApplyTO? {
        val leaveApplyBO: LeaveApplyBO? = commonDao.findByPrimaryKey(LeaveApplyBO::class.java, id)
        return mapHandler.mapObject(leaveApplyBO, LeaveApplyTO::class.java)
    }
}