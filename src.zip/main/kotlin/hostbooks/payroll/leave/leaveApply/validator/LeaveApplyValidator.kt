package hostbooks.payroll.leave.leaveApply.validator

import hostbooks.payroll.leave.LeaveSearchRequestTO
import hostbooks.payroll.leave.leaveApply.controller.LeaveApplyController
import hostbooks.payroll.leave.leaveApply.dto.LeaveApplyTO
import org.springframework.validation.Errors
import org.springframework.validation.Validator
import org.springframework.web.bind.annotation.ControllerAdvice

@ControllerAdvice(assignableTypes = [LeaveApplyController::class])
class LeaveApplyValidator : Validator {
    override fun supports(clazz: Class<*>): Boolean {
        return (clazz == LeaveApplyTO::class.java || clazz == LeaveSearchRequestTO::class.java)
    }

    override fun validate(target: Any, errors: Errors) {
        if (target is LeaveApplyTO) {
            //add logic for validation
        }
    }
}