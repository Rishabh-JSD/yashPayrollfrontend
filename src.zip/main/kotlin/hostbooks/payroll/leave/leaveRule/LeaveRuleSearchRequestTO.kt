package hostbooks.payroll.leave.leaveRule

import hostbooks.payroll.shared.utility.model.SearchRequestTO

class LeaveRuleSearchRequestTO: SearchRequestTO() {
    var code: String? = null
}