package hostbooks.payroll.leave.leaveRule.combinedRestriction.controller

import hostbooks.payroll.leave.leaveRule.LeaveRuleSearchRequestTO
import hostbooks.payroll.leave.leaveRule.combinedRestriction.dto.LRCombinedRestrictionTO
import hostbooks.payroll.leave.leaveRule.combinedRestriction.service.LRCombinedRestrictionService
import hostbooks.payroll.shared.utility.ValidationError
import hostbooks.payroll.shared.utility.model.ResponseTO
import hostbooks.payroll.shared.utility.model.SearchResponseTO
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.validation.Errors
import org.springframework.validation.Validator
import org.springframework.web.bind.WebDataBinder
import org.springframework.web.bind.annotation.*
import javax.validation.Valid

@RestController
@RequestMapping("/leave-rule-combined-restriction")
class LRCombinedRestrictionController(private val lrCombinedRestrictionService: LRCombinedRestrictionService, private val lrCombinedRestrictionValidator: Validator) {
    @InitBinder
    private fun initBinder(binder: WebDataBinder) {
        binder.validator = this.lrCombinedRestrictionValidator
    }

    @PostMapping("/list")
    fun getLRCombinedRestrictionList(@RequestBody leaveRuleSearchRequestTO: LeaveRuleSearchRequestTO): ResponseEntity<*> {
        val responseTO: SearchResponseTO<LRCombinedRestrictionTO> = lrCombinedRestrictionService.getLRCombinedRestrictionList(leaveRuleSearchRequestTO)
        val response = ResponseTO.responseBuilder(200, "COM04", "/leave-rule-combined-restriction", "leaveRuleCombinedRestriction", responseTO)
        return ResponseEntity<ResponseTO>(response, HttpStatus.OK)
    }

    @PostMapping("/add")
    fun addLRCombinedRestriction(@Valid @RequestBody lrCombinedRestrictionTO: LRCombinedRestrictionTO, errors: Errors): ResponseEntity<*> {
        if (errors.hasErrors()) {
            val validationError: ValidationError = ValidationError.fromBindingErrors(errors)
            return ResponseEntity<Any>(validationError, HttpStatus.BAD_REQUEST)
        }
        val addedLRCombinedRestrictionTO: LRCombinedRestrictionTO = lrCombinedRestrictionService.addLRCombinedRestriction(lrCombinedRestrictionTO)
        val responseDTO = ResponseTO.responseBuilder(200, "COM09", "/leave-rule-combined-restriction", "leaveRuleCombinedRestriction", addedLRCombinedRestrictionTO)
        return ResponseEntity<Any>(responseDTO, HttpStatus.CREATED)
    }

    @PutMapping("/update")
    fun updateLRCombinedRestriction(@Valid @RequestBody lrCombinedRestrictionTO: LRCombinedRestrictionTO, errors: Errors): ResponseEntity<*> {
        if (errors.hasErrors()) {
            val validationError: ValidationError = ValidationError.fromBindingErrors(errors)
            return ResponseEntity<Any>(validationError, HttpStatus.OK)
        }
        val addedLrCombinedRestrictionTO: LRCombinedRestrictionTO =lrCombinedRestrictionService.updateLRCombinedRestriction(lrCombinedRestrictionTO)
        val responseDTO = ResponseTO.responseBuilder(200, "COM02", "/leave-rule-combined-restriction", "leaveRuleCombinedRestriction", addedLrCombinedRestrictionTO)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }

    @RequestMapping(value = ["/delete"], method = [RequestMethod.DELETE])
    fun deleteLRCombinedRestriction(@Valid @RequestParam(name = "lrCombinedRestrictionId") lrCombinedRestrictionId: List<Long>): ResponseEntity<*> {
        lrCombinedRestrictionService.deleteLRCombinedRestriction(lrCombinedRestrictionId)
        val responseDTO = ResponseTO.responseBuilder(200, "COM05", "/leave-rule-combined-restriction", "leaveRuleCombinedRestriction", lrCombinedRestrictionId)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }

}