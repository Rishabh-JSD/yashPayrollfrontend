package hostbooks.payroll.leave.leaveRule.combinedRestriction.dto

import hostbooks.payroll.shared.utility.model.AuditTO

class LRCombinedRestrictionOptionsTO {
    var id: Long? = null
    var combinedRestrictionId: Long? = null
    var leaveTypeId: Long? = null
    var quantity: Double? = null
}