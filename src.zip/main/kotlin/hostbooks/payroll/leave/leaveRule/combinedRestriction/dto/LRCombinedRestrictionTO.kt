package hostbooks.payroll.leave.leaveRule.combinedRestriction.dto

import hostbooks.payroll.shared.utility.model.AuditTO
import hostbooks.payroll.leave.leaveRule.combinedRestriction.entity.LRCombinedRestrictionOptionsBO

class LRCombinedRestrictionTO: AuditTO() {
    var id: Long? = null
    var leaveTypeIds: List<Long>? = null
    var status: String = "ACTIVE"
    var lrCombinedRestrictionOptions: List<LRCombinedRestrictionOptionsBO> = emptyList()
}