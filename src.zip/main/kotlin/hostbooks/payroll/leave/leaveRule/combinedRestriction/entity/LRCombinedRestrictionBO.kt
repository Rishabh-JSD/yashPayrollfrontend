package hostbooks.payroll.leave.leaveRule.combinedRestriction.entity

import hostbooks.payroll.shared.constant.Tables
import hostbooks.payroll.shared.utility.model.Audit
import jakarta.persistence.*
import java.io.Serializable

@Entity
@Table(name = Tables.LR_COMBINED_RESTRICTION)
class LRCombinedRestrictionBO: Audit(), Serializable {
    companion object {
        private const val serialVersionUID = 3201179579546975295L
    }
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", updatable = false)
    var id: Long? = null

    @Column(name = "leave_type_ids")
    var leaveTypeIds: String? = null

    @Column(name = "status")
    var status: String? = null

    @OneToMany(cascade = [CascadeType.ALL], orphanRemoval = true)
    @JoinColumn(name = "combined_restriction_id", referencedColumnName = "id")
    var lrCombinedRestrictionOptions: List<LRCombinedRestrictionOptionsBO> = mutableListOf()
}