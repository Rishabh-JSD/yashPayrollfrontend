package hostbooks.payroll.leave.leaveRule.combinedRestriction.entity

import hostbooks.payroll.shared.constant.Tables
import hostbooks.payroll.shared.utility.model.Audit
import jakarta.persistence.*
import java.io.Serializable

@Entity
@Table(name = Tables.LR_COMBINED_RESTRICTION_OPTION)
class LRCombinedRestrictionOptionsBO: Serializable {
    companion object {
        private const val serialVersionUID = 3109011182819185419L
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", updatable = false)
    var id: Long? = null

    @Column(name = "combined_restriction_id")
    var combinedRestrictionId: Long? = null

    @Column(name = "leave_type_id")
    var leaveTypeId: Long? = null

    @Column(name = "quantity")
    var quantity: Double? = null
}