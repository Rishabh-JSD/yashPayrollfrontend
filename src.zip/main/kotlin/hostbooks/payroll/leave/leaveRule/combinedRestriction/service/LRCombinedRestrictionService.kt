package hostbooks.payroll.leave.leaveRule.combinedRestriction.service

import hostbooks.payroll.shared.utility.model.SearchResponseTO
import hostbooks.payroll.leave.leaveRule.LeaveRuleSearchRequestTO
import hostbooks.payroll.leave.leaveRule.combinedRestriction.dto.LRCombinedRestrictionTO

interface LRCombinedRestrictionService {

    fun getLRCombinedRestrictionList(leaveRuleSearchRequestTO: LeaveRuleSearchRequestTO): SearchResponseTO<LRCombinedRestrictionTO>

    fun addLRCombinedRestriction(lrCombinedRestrictionTO: LRCombinedRestrictionTO): LRCombinedRestrictionTO

    fun updateLRCombinedRestriction(lrCombinedRestrictionTO: LRCombinedRestrictionTO): LRCombinedRestrictionTO

    fun deleteLRCombinedRestriction(lrCombinedRestrictionId: List<Long>)
}