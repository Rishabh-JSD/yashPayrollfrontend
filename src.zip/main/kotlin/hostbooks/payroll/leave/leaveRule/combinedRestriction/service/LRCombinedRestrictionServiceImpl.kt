package hostbooks.payroll.leave.leaveRule.combinedRestriction.service

import hostbooks.payroll.companyDetail.branch.entity.BranchBO
import hostbooks.payroll.core.commonDao.CommonDao
import hostbooks.payroll.core.dto.FilterInfo
import hostbooks.payroll.core.dto.HbSort
import hostbooks.payroll.leave.leaveRule.LeaveRuleSearchRequestTO
import hostbooks.payroll.leave.leaveRule.combinedRestriction.dto.LRCombinedRestrictionTO
import hostbooks.payroll.leave.leaveRule.combinedRestriction.entity.LRCombinedRestrictionBO
import hostbooks.payroll.masters.option.dto.MasterOptionTO
import hostbooks.payroll.shared.constant.AppEnum
import hostbooks.payroll.shared.utility.MapHandler
import hostbooks.payroll.shared.utility.model.SearchResponseTO
import jakarta.transaction.Transactional
import org.springframework.data.domain.Page
import org.springframework.data.domain.PageRequest
import org.springframework.data.domain.Pageable
import org.springframework.stereotype.Service
import java.util.*

@Service
@Transactional
open class LRCombinedRestrictionServiceImpl(private val commonDao: CommonDao,
                                       private val mapHandler: MapHandler
): LRCombinedRestrictionService {
    override fun getLRCombinedRestrictionList(leaveRuleSearchRequestTO: LeaveRuleSearchRequestTO): SearchResponseTO<LRCombinedRestrictionTO> {
        val searchResponseTO = SearchResponseTO<LRCombinedRestrictionTO>()
        val discriminatorMap: WeakHashMap<String, FilterInfo<*>> = WeakHashMap<String, FilterInfo<*>>()
        discriminatorMap["status"] = FilterInfo(AppEnum.FilterType.EQ, AppEnum.Status.ACTIVE.toString())
        val pageable: Pageable = PageRequest.of(leaveRuleSearchRequestTO.page - 1, leaveRuleSearchRequestTO.limit)
        val data: Page<LRCombinedRestrictionBO> = commonDao.listByFilterPagination(LRCombinedRestrictionBO::class.java, discriminatorMap, pageable, null)
        val lrCombinedRestrictionList = ArrayList<LRCombinedRestrictionTO>()

        data.content.forEach { lrCombinedRestrictionBO ->
            val lrCombinedRestrictionTO = mapHandler.mapObject(lrCombinedRestrictionBO, LRCombinedRestrictionTO::class.java)
            if (lrCombinedRestrictionTO != null) {
                val leaveTypeIds = lrCombinedRestrictionBO.leaveTypeIds
                if (!leaveTypeIds.isNullOrBlank()) {
                    val idsArray: List<Long> = leaveTypeIds.split(",").mapNotNull { it.trim().toLongOrNull() }
                    lrCombinedRestrictionTO.leaveTypeIds = idsArray
                }
                lrCombinedRestrictionList.add(lrCombinedRestrictionTO)
            }
        }


        searchResponseTO.list = lrCombinedRestrictionList
        searchResponseTO.pageCount = data.totalPages.toLong()
        searchResponseTO.totalRowCount = data.totalElements
        return searchResponseTO
    }

    override fun addLRCombinedRestriction(lrCombinedRestrictionTO: LRCombinedRestrictionTO): LRCombinedRestrictionTO {
        val entity = mapHandler.mapObject(lrCombinedRestrictionTO, LRCombinedRestrictionBO::class.java)
        entity!!.leaveTypeIds = lrCombinedRestrictionTO.leaveTypeIds!!.joinToString (", ")
        val persistedEntity = commonDao.persistWithFlush(entity)
        return mapHandler.mapObject(persistedEntity, LRCombinedRestrictionTO::class.java)?: lrCombinedRestrictionTO
    }

    override fun updateLRCombinedRestriction(lrCombinedRestrictionTO: LRCombinedRestrictionTO): LRCombinedRestrictionTO {
        val entity = mapHandler.mapObject(lrCombinedRestrictionTO, LRCombinedRestrictionBO::class.java)
        entity!!.leaveTypeIds = lrCombinedRestrictionTO.leaveTypeIds!!.joinToString (", ")
        val updatedEntity = commonDao.updateWithFlush(entity)
        return mapHandler.mapObject(updatedEntity, LRCombinedRestrictionTO::class.java) ?: lrCombinedRestrictionTO
    }

    override fun deleteLRCombinedRestriction(lrCombinedRestrictionId: List<Long>) {
        for (id in lrCombinedRestrictionId) {
            val lrCombinedRestriction: LRCombinedRestrictionBO? = commonDao.findByPrimaryKey(LRCombinedRestrictionBO::class.java, id)
            if (lrCombinedRestriction != null) {
                lrCombinedRestriction.status = AppEnum.Status.INACTIVE.toString()
            }
            commonDao.merge(lrCombinedRestriction);
        }
    }



}