package hostbooks.payroll.leave.leaveRule.combinedRestriction.validator

import hostbooks.payroll.leave.leaveRule.LeaveRuleSearchRequestTO
import hostbooks.payroll.leave.leaveRule.combinedRestriction.controller.LRCombinedRestrictionController
import hostbooks.payroll.leave.leaveRule.combinedRestriction.dto.LRCombinedRestrictionTO
import org.springframework.validation.Errors
import org.springframework.validation.Validator
import org.springframework.web.bind.annotation.ControllerAdvice

@ControllerAdvice(assignableTypes = [LRCombinedRestrictionController::class])
class LrCombinedRestrictionValidator: Validator {
    override fun supports(clazz: Class<*>): Boolean {
        return (clazz == LRCombinedRestrictionTO::class.java || clazz == LeaveRuleSearchRequestTO::class.java)
    }

    override fun validate(target: Any, errors: Errors) {
        if (target is LRCombinedRestrictionTO) {
            if (target.leaveTypeIds.isNullOrEmpty()) {
                errors.rejectValue("LeaveTypeIds", "field.required", "LeaveTypeIds is required")
            }
        }
    }

}