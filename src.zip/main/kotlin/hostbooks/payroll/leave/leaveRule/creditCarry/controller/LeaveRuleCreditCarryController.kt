package hostbooks.payroll.leave.leaveRule.creditCarry.controller

import hostbooks.payroll.leave.leaveRule.LeaveRuleSearchRequestTO
import hostbooks.payroll.leave.leaveRule.creditCarry.dto.LeaveRuleCreditCarryTO
import hostbooks.payroll.leave.leaveRule.creditCarry.service.LeaveRuleCreditCarryService
import hostbooks.payroll.shared.utility.ValidationError
import hostbooks.payroll.shared.utility.model.ResponseTO
import hostbooks.payroll.shared.utility.model.SearchResponseTO
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.validation.Errors
import org.springframework.validation.Validator
import org.springframework.web.bind.WebDataBinder
import org.springframework.web.bind.annotation.*
import javax.validation.Valid

@RestController
@RequestMapping("/leave-rule-credit-carry")
class LeaveRuleCreditCarryController(private val leaveRuleCreditCarryService: LeaveRuleCreditCarryService, private val leaveRuleCreditCarryValidator: Validator) {
    @InitBinder
    private fun initBinder(binder: WebDataBinder) {
        binder.validator = this.leaveRuleCreditCarryValidator
    }

    @PostMapping("/list")
    fun getLeaveRuleCreditCarryList(@RequestBody leaveRuleSearchRequestTO: LeaveRuleSearchRequestTO): ResponseEntity<*> {
        val responseTO: SearchResponseTO<LeaveRuleCreditCarryTO> = leaveRuleCreditCarryService.getLeaveRuleCreditCarryList(leaveRuleSearchRequestTO)
        val response = ResponseTO.responseBuilder(200, "COM04", "/leave-rule-credit-carry", "leaveRuleCreditCarry", responseTO)
        return ResponseEntity<ResponseTO>(response, HttpStatus.OK)
    }

    @PostMapping("/add")
    fun addLeaveRuleCreditCarry(@Valid @RequestBody leaveRuleCreditCarryTO: LeaveRuleCreditCarryTO, errors: Errors): ResponseEntity<*> {
        if (errors.hasErrors()) {
            val validationError: ValidationError = ValidationError.fromBindingErrors(errors)
            return ResponseEntity<Any>(validationError, HttpStatus.BAD_REQUEST)
        }
        val addedLeaveRuleCreditCarry: LeaveRuleCreditCarryTO = leaveRuleCreditCarryService.addLeaveRuleCreditCarry(leaveRuleCreditCarryTO)
        val responseDTO = ResponseTO.responseBuilder(200, "COM09", "/leave-rule-credit-carry", "leaveRuleCreditCarry", addedLeaveRuleCreditCarry)
        return ResponseEntity<Any>(responseDTO, HttpStatus.CREATED)
    }

    @PutMapping("/update")
    fun updateLeaveRuleCreditCarry(@Valid @RequestBody leaveRuleCreditCarryTO: LeaveRuleCreditCarryTO, errors: Errors): ResponseEntity<*> {
        if (errors.hasErrors()) {
            val validationError: ValidationError = ValidationError.fromBindingErrors(errors)
            return ResponseEntity<Any>(validationError, HttpStatus.OK)
        }
        val addedLeaveRuleCreditCarryTO: LeaveRuleCreditCarryTO =leaveRuleCreditCarryService.updateLeaveRuleCreditCarry(leaveRuleCreditCarryTO)
        val responseDTO = ResponseTO.responseBuilder(200, "COM02", "/leave-rule-credit-carry", "leaveRuleCreditCarry", addedLeaveRuleCreditCarryTO)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }

    @RequestMapping(value = ["/delete"], method = [RequestMethod.DELETE])
    fun deleteLeaveRuleCreditCarry(@Valid @RequestParam(name = "leaveRuleCreditCarryId") leaveRuleCreditCarryId: List<Long>): ResponseEntity<*> {
        leaveRuleCreditCarryService.deleteLeaveRuleCreditCarry(leaveRuleCreditCarryId)
        val responseDTO = ResponseTO.responseBuilder(200, "COM05", "/leave-rule-credit-carry", "leaveRuleCreditCarry", leaveRuleCreditCarryId)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }

    @GetMapping("/{id}")
    fun getLeaveRuleCreditCarryById(@PathVariable id: Long): ResponseEntity<*> {
        val leaveRuleCreditCarryTO: LeaveRuleCreditCarryTO? = leaveRuleCreditCarryService.getLeaveRuleCreditCarryById(id)
        if (leaveRuleCreditCarryTO == null) {
            val responseDTO = ResponseTO.responseBuilder(200, "COM03E", "/leave-rule-credit-carry", "leaveRuleCreditCarry", null)
            return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
        }
        val responseDTO = ResponseTO.responseBuilder(200, "COM11", "/leave-rule-credit-carry", "leaveRuleCreditCarry", leaveRuleCreditCarryTO)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }

}