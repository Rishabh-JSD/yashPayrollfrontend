package hostbooks.payroll.leave.leaveRule.creditCarry.dto

import hostbooks.payroll.shared.utility.model.AuditTO

class LeaveRuleCreditCarryTO: AuditTO() {
    var id: Long? = null
    var leaveTypeId: Long? = null
    var creditDays: Double? = null
    var carryDays: Double? = null
    var status: String = "ACTIVE"
}