package hostbooks.payroll.leave.leaveRule.creditCarry.service

import hostbooks.payroll.leave.leaveRule.LeaveRuleSearchRequestTO
import hostbooks.payroll.leave.leaveRule.creditCarry.dto.LeaveRuleCreditCarryTO
import hostbooks.payroll.shared.utility.model.SearchResponseTO

interface LeaveRuleCreditCarryService {

    fun getLeaveRuleCreditCarryList(leaveRuleSearchRequestTO: LeaveRuleSearchRequestTO): SearchResponseTO<LeaveRuleCreditCarryTO>

    fun addLeaveRuleCreditCarry(leaveRuleCreditCarryTO: LeaveRuleCreditCarryTO): LeaveRuleCreditCarryTO

    fun updateLeaveRuleCreditCarry(leaveRuleCreditCarryTO: LeaveRuleCreditCarryTO): LeaveRuleCreditCarryTO

    fun deleteLeaveRuleCreditCarry(leaveRuleCreditCarryId: List<Long>)

    fun getLeaveRuleCreditCarryById(id: Long): LeaveRuleCreditCarryTO?
}