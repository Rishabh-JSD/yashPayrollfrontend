package hostbooks.payroll.leave.leaveRule.creditCarry.service

import hostbooks.payroll.core.commonDao.CommonDao
import hostbooks.payroll.core.dto.FilterInfo
import hostbooks.payroll.core.dto.HbSort
import hostbooks.payroll.leave.leaveRule.LeaveRuleSearchRequestTO
import hostbooks.payroll.leave.leaveRule.creditCarry.dto.LeaveRuleCreditCarryTO
import hostbooks.payroll.leave.leaveRule.creditCarry.entity.LeaveRuleCreditCarryBO
import hostbooks.payroll.leave.leaveRule.utilisationPeriod.dto.LeaveRuleUtilisationPeriodTO
import hostbooks.payroll.shared.constant.AppEnum
import hostbooks.payroll.shared.utility.MapHandler
import hostbooks.payroll.shared.utility.model.SearchResponseTO
import jakarta.transaction.Transactional
import org.springframework.data.domain.Page
import org.springframework.data.domain.PageRequest
import org.springframework.data.domain.Pageable
import org.springframework.stereotype.Service
import java.util.*

@Service
@Transactional
open class LeaveRuleCreditCarryServiceImpl(private val commonDao: CommonDao, private val mapHandler: MapHandler)
    :LeaveRuleCreditCarryService{
    override fun getLeaveRuleCreditCarryList(leaveRuleSearchRequestTO: LeaveRuleSearchRequestTO): SearchResponseTO<LeaveRuleCreditCarryTO> {
        val searchResponseTO = SearchResponseTO<LeaveRuleCreditCarryTO>()
        val discriminatorMap: WeakHashMap<String, FilterInfo<*>> = WeakHashMap<String, FilterInfo<*>>()
        discriminatorMap["status"] = FilterInfo(AppEnum.FilterType.EQ, AppEnum.Status.ACTIVE.toString())
        val pageable: Pageable = PageRequest.of(leaveRuleSearchRequestTO.page - 1, leaveRuleSearchRequestTO.limit)
        val data: Page<LeaveRuleCreditCarryBO> = commonDao.listByFilterPagination(LeaveRuleCreditCarryBO::class.java, discriminatorMap, pageable, null)
        val lrCreditCarryList = ArrayList<LeaveRuleCreditCarryTO>()

        data.content.forEach { lrCreditCarryBO ->
            val lrCreditCarryTO = mapHandler.mapObject(lrCreditCarryBO, LeaveRuleCreditCarryTO::class.java)
            if (lrCreditCarryTO != null) {
                lrCreditCarryList.add(lrCreditCarryTO)
            }
        }

        searchResponseTO.list = lrCreditCarryList
        searchResponseTO.pageCount = data.totalPages.toLong()
        searchResponseTO.totalRowCount = data.totalElements
        return searchResponseTO
    }

    override fun addLeaveRuleCreditCarry(leaveRuleCreditCarryTO: LeaveRuleCreditCarryTO): LeaveRuleCreditCarryTO {
        val entity = mapHandler.mapObject(leaveRuleCreditCarryTO, LeaveRuleCreditCarryBO::class.java)
        val persistedEntity = commonDao.persistWithFlush(entity)
        return mapHandler.mapObject(persistedEntity, LeaveRuleCreditCarryTO::class.java)?: leaveRuleCreditCarryTO
    }

    override fun updateLeaveRuleCreditCarry(leaveRuleCreditCarryTO: LeaveRuleCreditCarryTO): LeaveRuleCreditCarryTO {
        val entity = mapHandler.mapObject(leaveRuleCreditCarryTO, LeaveRuleCreditCarryBO::class.java)
        val updatedEntity = commonDao.updateWithFlush(entity)
        return mapHandler.mapObject(updatedEntity, LeaveRuleCreditCarryTO::class.java) ?: leaveRuleCreditCarryTO
    }

    override fun deleteLeaveRuleCreditCarry(leaveRuleCreditCarryId: List<Long>) {
        for (id in leaveRuleCreditCarryId) {
            val leaveRuleCreditCarry: LeaveRuleCreditCarryBO? = commonDao.findByPrimaryKey(LeaveRuleCreditCarryBO::class.java, id)
            if (leaveRuleCreditCarry != null) {
                leaveRuleCreditCarry.status = AppEnum.Status.INACTIVE.toString()
                commonDao.merge(leaveRuleCreditCarry);
            }
        }
    }

    override fun getLeaveRuleCreditCarryById(id: Long): LeaveRuleCreditCarryTO? {
        val leaveRuleCreditCarryBO: LeaveRuleCreditCarryBO? = commonDao.findByPrimaryKey(LeaveRuleCreditCarryBO::class.java, id)
        return mapHandler.mapObject(leaveRuleCreditCarryBO, LeaveRuleCreditCarryTO::class.java)
    }
}