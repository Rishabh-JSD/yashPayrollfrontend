package hostbooks.payroll.leave.leaveRule.creditCarry.validator

import hostbooks.payroll.leave.leaveRule.LeaveRuleSearchRequestTO
import hostbooks.payroll.leave.leaveRule.creditCarry.controller.LeaveRuleCreditCarryController
import hostbooks.payroll.leave.leaveRule.creditCarry.dto.LeaveRuleCreditCarryTO
import org.springframework.validation.Errors
import org.springframework.validation.Validator
import org.springframework.web.bind.annotation.ControllerAdvice

@ControllerAdvice(assignableTypes = [LeaveRuleCreditCarryController::class])
class LeaveRuleCreditCarryValidator: Validator {
    override fun supports(clazz: Class<*>): Boolean {
        return (clazz == LeaveRuleCreditCarryTO::class.java || clazz == LeaveRuleSearchRequestTO::class.java)
    }

    override fun validate(target: Any, errors: Errors) {
        if (target is LeaveRuleCreditCarryTO) {
//            if (target.leaveTypeId.isNullOrEmpty()) {
//                errors.rejectValue("leaveTypeId", "field.required", "leaveTypeId is required")
//            }
        }
    }
}