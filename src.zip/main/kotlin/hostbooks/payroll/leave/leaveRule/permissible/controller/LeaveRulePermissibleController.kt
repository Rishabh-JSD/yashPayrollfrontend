package hostbooks.payroll.leave.leaveRule.permissible.controller

import hostbooks.payroll.leave.leaveRule.LeaveRuleSearchRequestTO
import hostbooks.payroll.leave.leaveRule.permissible.dto.LeaveRulePermissibleTO
import hostbooks.payroll.leave.leaveRule.permissible.service.LeaveRulePermissibleService
import hostbooks.payroll.shared.utility.ValidationError
import hostbooks.payroll.shared.utility.model.ResponseTO
import hostbooks.payroll.shared.utility.model.SearchResponseTO
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.validation.Errors
import org.springframework.validation.Validator
import org.springframework.web.bind.WebDataBinder
import org.springframework.web.bind.annotation.*
import javax.validation.Valid

@RestController
@RequestMapping("/leave-rule-permissible")
class LeaveRulePermissibleController(private val leaveRulePermissibleService: LeaveRulePermissibleService,
                                     private val leaveRulePermissibleValidator:  Validator) {
    @InitBinder
    private fun initBinder(binder: WebDataBinder) {
        binder.validator = this.leaveRulePermissibleValidator
    }

    @PostMapping("/list")
    fun getLeaveRulePermissibleList(@RequestBody leaveRuleSearchRequestTO: LeaveRuleSearchRequestTO): ResponseEntity<*> {
        val responseTO: SearchResponseTO<LeaveRulePermissibleTO> = leaveRulePermissibleService.getLeaveRulePermissibleList(leaveRuleSearchRequestTO)
        val response = ResponseTO.responseBuilder(200, "COM04", "/leave-rule-permissible", "leaveRulePermissible", responseTO)
        return ResponseEntity<ResponseTO>(response, HttpStatus.OK)
    }

    @PostMapping("/add")
    fun addLeaveRulePermissible(@Valid @RequestBody leaveRulePermissibleTO: LeaveRulePermissibleTO, errors: Errors): ResponseEntity<*> {
        if (errors.hasErrors()) {
            val validationError: ValidationError = ValidationError.fromBindingErrors(errors)
            return ResponseEntity<Any>(validationError, HttpStatus.BAD_REQUEST)
        }
        val addedLeaveRulePermissible: LeaveRulePermissibleTO = leaveRulePermissibleService.addLeaveRulePermissible(leaveRulePermissibleTO)
        val responseDTO = ResponseTO.responseBuilder(200, "COM09", "/leave-rule-permissible", "leaveRulePermissible", addedLeaveRulePermissible)
        return ResponseEntity<Any>(responseDTO, HttpStatus.CREATED)
    }

    @PutMapping("/update")
    fun updateLeaveRulePermissible(@Valid @RequestBody leaveRulePermissibleTO: LeaveRulePermissibleTO, errors: Errors): ResponseEntity<*> {
        if (errors.hasErrors()) {
            val validationError: ValidationError = ValidationError.fromBindingErrors(errors)
            return ResponseEntity<Any>(validationError, HttpStatus.OK)
        }
        val addedLeaveRulePermissibleTO: LeaveRulePermissibleTO =leaveRulePermissibleService.updateLeaveRulePermissible(leaveRulePermissibleTO)
        val responseDTO = ResponseTO.responseBuilder(200, "COM02", "/leave-rule-permissible", "leaveRulePermissible", addedLeaveRulePermissibleTO)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }

    @RequestMapping(value = ["/delete"], method = [RequestMethod.DELETE])
    fun deleteLeaveRulePermissible(@Valid @RequestParam(name = "leaveRulePermissibleId") leaveRulePermissibleId: List<Long>): ResponseEntity<*> {
        leaveRulePermissibleService.deleteLeaveRulePermissible(leaveRulePermissibleId)
        val responseDTO = ResponseTO.responseBuilder(200, "COM05", "/leave-rule-permissible", "leaveRulePermissible", leaveRulePermissibleId)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }

    @GetMapping("/{id}")
    fun getLeaveRulePermissibleById(@PathVariable id: Long): ResponseEntity<*> {
        val leaveRulePermissibleTO: LeaveRulePermissibleTO? = leaveRulePermissibleService.getLeaveRulePermissibleById(id)
        if (leaveRulePermissibleTO == null) {
            val responseDTO = ResponseTO.responseBuilder(200, "COM03E", "/leave-rule-permissible", "leaveRulePermissible", null)
            return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
        }
        val responseDTO = ResponseTO.responseBuilder(200, "COM11", "/leave-rule-permissible", "leaveRulePermissible", leaveRulePermissibleTO)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }

}