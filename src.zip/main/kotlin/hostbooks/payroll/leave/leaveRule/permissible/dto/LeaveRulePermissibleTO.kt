package hostbooks.payroll.leave.leaveRule.permissible.dto

import hostbooks.payroll.shared.utility.model.AuditTO

class LeaveRulePermissibleTO: AuditTO() {
    var id: Long? = null
    var leaveTypeId: Long? = null
    var maxNo: Double? = null
    var status: String = "ACTIVE"
}