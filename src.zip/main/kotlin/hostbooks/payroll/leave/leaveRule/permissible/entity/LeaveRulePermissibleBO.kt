package hostbooks.payroll.leave.leaveRule.permissible.entity

import hostbooks.payroll.shared.constant.Tables
import hostbooks.payroll.shared.utility.model.Audit
import jakarta.persistence.*

@Entity
@Table(name = Tables.LEAVE_RULE_PERMISSIBLE)
class LeaveRulePermissibleBO: Audit() {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    var id: Long? = null

    @Column(name = "leave_type_id")
    var leaveTypeId: Long? = null

    @Column(name = "max_no")
    var maxNo: Double? = null

    @Column(name = "status")
    var status: String? = null
}