package hostbooks.payroll.leave.leaveRule.permissible.service

import hostbooks.payroll.leave.leaveRule.LeaveRuleSearchRequestTO
import hostbooks.payroll.leave.leaveRule.permissible.dto.LeaveRulePermissibleTO
import hostbooks.payroll.shared.utility.model.SearchResponseTO

interface LeaveRulePermissibleService {

    fun getLeaveRulePermissibleList(leaveRuleSearchRequestTO: LeaveRuleSearchRequestTO): SearchResponseTO<LeaveRulePermissibleTO>

    fun addLeaveRulePermissible(leaveRulePermissibleTO: LeaveRulePermissibleTO): LeaveRulePermissibleTO

    fun updateLeaveRulePermissible(leaveRulePermissibleTO: LeaveRulePermissibleTO): LeaveRulePermissibleTO

    fun deleteLeaveRulePermissible(leaveRulePermissibleId: List<Long>)

    fun getLeaveRulePermissibleById(id: Long): LeaveRulePermissibleTO?
}