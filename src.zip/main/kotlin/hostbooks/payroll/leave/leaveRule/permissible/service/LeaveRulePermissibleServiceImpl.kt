package hostbooks.payroll.leave.leaveRule.permissible.service

import hostbooks.payroll.core.commonDao.CommonDao
import hostbooks.payroll.core.dto.FilterInfo
import hostbooks.payroll.core.dto.HbSort
import hostbooks.payroll.leave.leaveRule.LeaveRuleSearchRequestTO
import hostbooks.payroll.leave.leaveRule.combinedRestriction.dto.LRCombinedRestrictionTO
import hostbooks.payroll.leave.leaveRule.permissible.dto.LeaveRulePermissibleTO
import hostbooks.payroll.leave.leaveRule.permissible.entity.LeaveRulePermissibleBO
import hostbooks.payroll.shared.constant.AppEnum
import hostbooks.payroll.shared.utility.MapHandler
import hostbooks.payroll.shared.utility.model.SearchResponseTO
import jakarta.transaction.Transactional
import org.springframework.data.domain.Page
import org.springframework.data.domain.PageRequest
import org.springframework.data.domain.Pageable
import org.springframework.stereotype.Service
import java.util.*
@Service
@Transactional
open class LeaveRulePermissibleServiceImpl(private val commonDao: CommonDao,
                                           private val mapHandler: MapHandler
): LeaveRulePermissibleService {
    override fun getLeaveRulePermissibleList(leaveRuleSearchRequestTO: LeaveRuleSearchRequestTO): SearchResponseTO<LeaveRulePermissibleTO> {
        val searchResponseTO = SearchResponseTO<LeaveRulePermissibleTO>()
        val discriminatorMap: WeakHashMap<String, FilterInfo<*>> = WeakHashMap<String, FilterInfo<*>>()
        discriminatorMap["status"] = FilterInfo(AppEnum.FilterType.EQ, AppEnum.Status.ACTIVE.toString())
        val pageable: Pageable = PageRequest.of(leaveRuleSearchRequestTO.page - 1, leaveRuleSearchRequestTO.limit)
        val data: Page<LeaveRulePermissibleBO> = commonDao.listByFilterPagination(LeaveRulePermissibleBO::class.java, discriminatorMap, pageable, null)
        val lrPermissibleList = ArrayList<LeaveRulePermissibleTO>()

        data.content.forEach { lrPermissibleBO ->
            val lrPermissibleTO = mapHandler.mapObject(lrPermissibleBO, LeaveRulePermissibleTO::class.java)
            if (lrPermissibleTO != null) {
                lrPermissibleList.add(lrPermissibleTO)
            }
        }

        searchResponseTO.list = lrPermissibleList
        searchResponseTO.pageCount = data.totalPages.toLong()
        searchResponseTO.totalRowCount = data.totalElements
        return searchResponseTO
    }

    override fun addLeaveRulePermissible(leaveRulePermissibleTO: LeaveRulePermissibleTO): LeaveRulePermissibleTO {
        val entity = mapHandler.mapObject(leaveRulePermissibleTO, LeaveRulePermissibleBO::class.java)
        val persistedEntity = commonDao.persistWithFlush(entity)
        return mapHandler.mapObject(persistedEntity, LeaveRulePermissibleTO::class.java)?: leaveRulePermissibleTO
    }

    override fun updateLeaveRulePermissible(leaveRulePermissibleTO: LeaveRulePermissibleTO): LeaveRulePermissibleTO {
        val entity = mapHandler.mapObject(leaveRulePermissibleTO, LeaveRulePermissibleBO::class.java)
        val updatedEntity = commonDao.updateWithFlush(entity)
        return mapHandler.mapObject(updatedEntity, LeaveRulePermissibleTO::class.java) ?: leaveRulePermissibleTO
    }

    override fun deleteLeaveRulePermissible(leaveRulePermissibleId: List<Long>) {
        for (id in leaveRulePermissibleId) {
            val leaveRulePermissible: LeaveRulePermissibleBO? = commonDao.findByPrimaryKey(LeaveRulePermissibleBO::class.java, id)
            if (leaveRulePermissible != null) {
                leaveRulePermissible.status = AppEnum.Status.INACTIVE.toString()
                commonDao.merge(leaveRulePermissible);
            }
        }
    }

    override fun getLeaveRulePermissibleById(id: Long): LeaveRulePermissibleTO? {
        val leaveRulePermissibleBO: LeaveRulePermissibleBO? = commonDao.findByPrimaryKey(LeaveRulePermissibleBO::class.java, id)
        return mapHandler.mapObject(leaveRulePermissibleBO, LeaveRulePermissibleTO::class.java)
    }
}