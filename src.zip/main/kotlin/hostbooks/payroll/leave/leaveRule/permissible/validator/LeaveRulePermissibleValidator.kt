package hostbooks.payroll.leave.leaveRule.permissible.validator

import hostbooks.payroll.leave.leaveRule.LeaveRuleSearchRequestTO
import hostbooks.payroll.leave.leaveRule.permissible.controller.LeaveRulePermissibleController
import hostbooks.payroll.leave.leaveRule.permissible.dto.LeaveRulePermissibleTO
import org.springframework.validation.Errors
import org.springframework.validation.Validator
import org.springframework.web.bind.annotation.ControllerAdvice

@ControllerAdvice(assignableTypes = [LeaveRulePermissibleController::class])
class LeaveRulePermissibleValidator: Validator {
    override fun supports(clazz: Class<*>): Boolean {
        return (clazz == LeaveRulePermissibleTO::class.java || clazz == LeaveRuleSearchRequestTO::class.java)
    }

    override fun validate(target: Any, errors: Errors) {
        if (target is LeaveRulePermissibleTO) {
//            if (target.leaveTypeId.isNullOrEmpty()) {
//                errors.rejectValue("leaveTypeId", "field.required", "LeaveTypeId is required")
//            }
//            if (target.status.isNullOrEmpty()) {
//                errors.rejectValue("status", "field.required", "Status is required")
//            }
        }
    }
}