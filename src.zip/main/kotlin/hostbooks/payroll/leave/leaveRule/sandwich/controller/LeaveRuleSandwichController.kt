package hostbooks.payroll.leave.leaveRule.sandwich.controller

import hostbooks.payroll.leave.leaveRule.LeaveRuleSearchRequestTO
import hostbooks.payroll.leave.leaveRule.sandwich.dto.LeaveRuleSandwichTO
import hostbooks.payroll.leave.leaveRule.sandwich.service.LeaveRuleSandwichService
import hostbooks.payroll.shared.utility.ValidationError
import hostbooks.payroll.shared.utility.model.ResponseTO
import hostbooks.payroll.shared.utility.model.SearchResponseTO
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.validation.Errors
import org.springframework.validation.Validator
import org.springframework.web.bind.WebDataBinder
import org.springframework.web.bind.annotation.*
import javax.validation.Valid

@RestController
@RequestMapping("/leave-rule-sandwich")
class LeaveRuleSandwichController(private val leaveRuleSandwichService: LeaveRuleSandwichService, private val leaveRuleSandwichValidator: Validator) {
    @InitBinder
    private fun initBinder(binder: WebDataBinder) {
        binder.validator = this.leaveRuleSandwichValidator
    }

    @PostMapping("/list")
    fun getLeaveRuleSandwichList(@RequestBody leaveRuleSearchRequestTO: LeaveRuleSearchRequestTO): ResponseEntity<*> {
        val responseTO: SearchResponseTO<LeaveRuleSandwichTO> = leaveRuleSandwichService.getLeaveRuleSandwichList(leaveRuleSearchRequestTO)
        val response = ResponseTO.responseBuilder(200, "COM04", "/leave-rule-sandwich", "leaveRuleSandwich", responseTO)
        return ResponseEntity<ResponseTO>(response, HttpStatus.OK)
    }

    @PostMapping("/add")
    fun addLeaveRuleSandwich(@Valid @RequestBody leaveRuleSandwichTO: LeaveRuleSandwichTO, errors: Errors): ResponseEntity<*> {
        if (errors.hasErrors()) {
            val validationError: ValidationError = ValidationError.fromBindingErrors(errors)
            return ResponseEntity<Any>(validationError, HttpStatus.BAD_REQUEST)
        }
        val addedLeaveRuleSandwich: LeaveRuleSandwichTO = leaveRuleSandwichService.addLeaveRuleSandwich(leaveRuleSandwichTO)
        val responseDTO = ResponseTO.responseBuilder(200, "COM09", "/leave-rule-sandwich", "leaveRuleSandwich", addedLeaveRuleSandwich)
        return ResponseEntity<Any>(responseDTO, HttpStatus.CREATED)
    }

    @PutMapping("/update")
    fun updateLeaveRuleSandwich(@Valid @RequestBody leaveRuleSandwichTO: LeaveRuleSandwichTO, errors: Errors): ResponseEntity<*> {
        if (errors.hasErrors()) {
            val validationError: ValidationError = ValidationError.fromBindingErrors(errors)
            return ResponseEntity<Any>(validationError, HttpStatus.OK)
        }
        val addedLeaveRuleSandwichTO:LeaveRuleSandwichTO =leaveRuleSandwichService.updateLeaveRuleSandwich(leaveRuleSandwichTO)
        val responseDTO = ResponseTO.responseBuilder(200, "COM02", "/leave-rule-sandwich", "leaveRuleSandwich", addedLeaveRuleSandwichTO)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }

    @DeleteMapping("/delete")
    fun deleteLeaveRuleSandwich(@Valid @RequestParam(name = "leaveRuleSandwichId") leaveRuleSandwichId: List<Long>): ResponseEntity<*> {
        leaveRuleSandwichService.deleteLeaveRuleSandwich(leaveRuleSandwichId)
        val responseDTO = ResponseTO.responseBuilder(200, "COM05", "/leave-rule-sandwich", "leaveRuleSandwich", leaveRuleSandwichId)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }

    @GetMapping("/{id}")
    fun getLeaveRuleSandwichById(@PathVariable id: Long): ResponseEntity<*> {
        val leaveRuleSandwichTO: LeaveRuleSandwichTO? = leaveRuleSandwichService.getLeaveRuleSandwichById(id)
        if (leaveRuleSandwichTO == null) {
            val responseDTO = ResponseTO.responseBuilder(200, "COM03E", "/leave-rule-sandwich", "leaveRuleSandwich", null)
            return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
        }
        val responseDTO = ResponseTO.responseBuilder(200, "COM11", "/leave-rule-sandwich", "leaveRuleSandwich", leaveRuleSandwichTO)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }

}