package hostbooks.payroll.leave.leaveRule.sandwich.dto

import hostbooks.payroll.shared.utility.model.AuditTO

class LeaveRuleSandwichTO: AuditTO() {
    var id: Long? = null
    var weekOffFlag: Boolean? = null
    var leaveTypeIds: List<Long>? = null
    var dayBeforeFlag: Boolean? = null
    var dayAfterFlag: Boolean? = null
    var lopFlag: Boolean? = null
    var status: String = "ACTIVE"
}