package hostbooks.payroll.leave.leaveRule.sandwich.entity

import hostbooks.payroll.shared.constant.Tables
import hostbooks.payroll.shared.utility.model.Audit
import jakarta.persistence.*

@Entity
@Table(name = Tables.LEAVE_RULE_SANDWICH)
class LeaveRuleSandwichBO: Audit() {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    var id: Long? = null

    @Column(name = "week_off_flag")
    var weekOffFlag: Boolean? = null

    @Column(name = "leave_type_ids")
    var leaveTypeIds: String? = null

    @Column(name = "day_before_flag")
    var dayBeforeFlag: Boolean? = null

    @Column(name = "day_after_flag")
    var dayAfterFlag: Boolean? = null

    @Column(name = "lop_flag")
    var lopFlag: Boolean? = null

    @Column(name = "status")
    var status: String? = null
}