package hostbooks.payroll.leave.leaveRule.sandwich.service

import hostbooks.payroll.leave.leaveRule.LeaveRuleSearchRequestTO
import hostbooks.payroll.leave.leaveRule.sandwich.dto.LeaveRuleSandwichTO
import hostbooks.payroll.shared.utility.model.SearchResponseTO

interface LeaveRuleSandwichService {
    fun getLeaveRuleSandwichList(leaveRuleSearchRequestTO: LeaveRuleSearchRequestTO): SearchResponseTO<LeaveRuleSandwichTO>

    fun addLeaveRuleSandwich(leaveRuleSandwichTO: LeaveRuleSandwichTO): LeaveRuleSandwichTO

    fun updateLeaveRuleSandwich(leaveRuleSandwichTO: LeaveRuleSandwichTO): LeaveRuleSandwichTO

    fun deleteLeaveRuleSandwich(leaveRuleSandwichId: List<Long>)

    fun getLeaveRuleSandwichById(id: Long): LeaveRuleSandwichTO?
}