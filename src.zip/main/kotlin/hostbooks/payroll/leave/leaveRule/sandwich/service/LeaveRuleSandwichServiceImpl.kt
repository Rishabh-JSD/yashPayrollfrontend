package hostbooks.payroll.leave.leaveRule.sandwich.service

import hostbooks.payroll.core.commonDao.CommonDao
import hostbooks.payroll.core.dto.FilterInfo
import hostbooks.payroll.core.dto.HbSort
import hostbooks.payroll.leave.leaveRule.LeaveRuleSearchRequestTO
import hostbooks.payroll.leave.leaveRule.permissible.dto.LeaveRulePermissibleTO
import hostbooks.payroll.leave.leaveRule.sandwich.dto.LeaveRuleSandwichTO
import hostbooks.payroll.leave.leaveRule.sandwich.entity.LeaveRuleSandwichBO
import hostbooks.payroll.shared.constant.AppEnum
import hostbooks.payroll.shared.utility.MapHandler
import hostbooks.payroll.shared.utility.model.SearchResponseTO
import jakarta.transaction.Transactional
import org.springframework.data.domain.Page
import org.springframework.data.domain.PageRequest
import org.springframework.data.domain.Pageable
import org.springframework.stereotype.Service
import java.util.*

@Service
@Transactional
open class LeaveRuleSandwichServiceImpl(private val commonDao: CommonDao,
                                   private val mapHandler: MapHandler
): LeaveRuleSandwichService {
    override fun getLeaveRuleSandwichList(leaveRuleSearchRequestTO: LeaveRuleSearchRequestTO): SearchResponseTO<LeaveRuleSandwichTO> {
        val searchResponseTO = SearchResponseTO<LeaveRuleSandwichTO>()
        val discriminatorMap: WeakHashMap<String, FilterInfo<*>> = WeakHashMap<String, FilterInfo<*>>()
        discriminatorMap["status"] = FilterInfo(AppEnum.FilterType.EQ, AppEnum.Status.ACTIVE.toString())
        val pageable: Pageable = PageRequest.of(leaveRuleSearchRequestTO.page - 1, leaveRuleSearchRequestTO.limit)
        val data: Page<LeaveRuleSandwichBO> = commonDao.listByFilterPagination(LeaveRuleSandwichBO::class.java, discriminatorMap, pageable, null)
        val lrSandwichList = ArrayList<LeaveRuleSandwichTO>()

        data.content.forEach { lrSandwichBO ->
            val lrSandwichTO = mapHandler.mapObject(lrSandwichBO, LeaveRuleSandwichTO::class.java)
            if (lrSandwichTO != null) {
                val leaveTypeIds = lrSandwichBO.leaveTypeIds
                if (!leaveTypeIds.isNullOrBlank()) {
                    val idsArray: List<Long> = leaveTypeIds.split(",").mapNotNull { it.trim().toLongOrNull() }
                    lrSandwichTO.leaveTypeIds = idsArray
                }
                lrSandwichList.add(lrSandwichTO)
            }
        }
        searchResponseTO.list = lrSandwichList
        searchResponseTO.pageCount = data.totalPages.toLong()
        searchResponseTO.totalRowCount = data.totalElements
        return searchResponseTO
    }

    override fun addLeaveRuleSandwich(leaveRuleSandwichTO: LeaveRuleSandwichTO): LeaveRuleSandwichTO {
        val entity = mapHandler.mapObject(leaveRuleSandwichTO, LeaveRuleSandwichBO::class.java)
        entity!!.leaveTypeIds = leaveRuleSandwichTO.leaveTypeIds!!.joinToString (", ")
        val persistedEntity = commonDao.persistWithFlush(entity)
        return mapHandler.mapObject(persistedEntity, LeaveRuleSandwichTO::class.java)?: leaveRuleSandwichTO
    }

    override fun updateLeaveRuleSandwich(leaveRuleSandwichTO: LeaveRuleSandwichTO): LeaveRuleSandwichTO {
        val entity = mapHandler.mapObject(leaveRuleSandwichTO, LeaveRuleSandwichBO::class.java)
        entity!!.leaveTypeIds = leaveRuleSandwichTO.leaveTypeIds!!.joinToString (", ")
        val updatedEntity = commonDao.updateWithFlush(entity)
        return mapHandler.mapObject(updatedEntity, LeaveRuleSandwichTO::class.java) ?: leaveRuleSandwichTO
    }

    override fun deleteLeaveRuleSandwich(leaveRuleSandwichId: List<Long>) {
        for (id in leaveRuleSandwichId) {
            val leaveRuleSandwich: LeaveRuleSandwichBO? = commonDao.findByPrimaryKey(LeaveRuleSandwichBO::class.java, id)
            if (leaveRuleSandwich != null) {
                commonDao.deleteWithFlush(leaveRuleSandwich)
            }
        }
    }

    override fun getLeaveRuleSandwichById(id: Long): LeaveRuleSandwichTO? {
        val leaveRuleSandwichBO: LeaveRuleSandwichBO? = commonDao.findByPrimaryKey(LeaveRuleSandwichBO::class.java, id)
        return mapHandler.mapObject(leaveRuleSandwichBO, LeaveRuleSandwichTO::class.java)
    }
}