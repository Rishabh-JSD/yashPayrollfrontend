package hostbooks.payroll.leave.leaveRule.sandwich.validator

import hostbooks.payroll.leave.leaveRule.LeaveRuleSearchRequestTO
import hostbooks.payroll.leave.leaveRule.sandwich.controller.LeaveRuleSandwichController
import hostbooks.payroll.leave.leaveRule.sandwich.dto.LeaveRuleSandwichTO
import org.springframework.validation.Errors
import org.springframework.validation.Validator
import org.springframework.web.bind.annotation.ControllerAdvice

@ControllerAdvice(assignableTypes = [LeaveRuleSandwichController::class])
class LeaveRuleSandwichValidator: Validator {
    override fun supports(clazz: Class<*>): Boolean {
        return (clazz == LeaveRuleSandwichTO::class.java || clazz == LeaveRuleSearchRequestTO::class.java)
    }

    override fun validate(target: Any, errors: Errors) {
        if (target is LeaveRuleSandwichTO) {
            if (target.status.isNullOrEmpty()) {
                errors.rejectValue("status", "field.required", "Status is required")
            }
        }
    }
}