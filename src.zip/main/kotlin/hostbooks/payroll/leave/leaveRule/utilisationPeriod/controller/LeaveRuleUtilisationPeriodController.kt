package hostbooks.payroll.leave.leaveRule.utilisationPeriod.controller

import hostbooks.payroll.leave.leaveRule.LeaveRuleSearchRequestTO
import hostbooks.payroll.leave.leaveRule.utilisationPeriod.dto.LeaveRuleUtilisationPeriodTO
import hostbooks.payroll.leave.leaveRule.utilisationPeriod.service.LeaveRuleUtilisationPeriodService
import hostbooks.payroll.shared.utility.ValidationError
import hostbooks.payroll.shared.utility.model.ResponseTO
import hostbooks.payroll.shared.utility.model.SearchResponseTO
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.validation.Errors
import org.springframework.validation.Validator
import org.springframework.web.bind.WebDataBinder
import org.springframework.web.bind.annotation.*
import javax.validation.Valid

@RestController
@RequestMapping("/leave-rule-utilisation-period")
class LeaveRuleUtilisationPeriodController(private val leaveRuleUtilisationPeriodService: LeaveRuleUtilisationPeriodService, private val leaveRuleUtilisationPeriodValidator:  Validator) {

    @InitBinder
    private fun initBinder(binder: WebDataBinder) {
        binder.validator = this.leaveRuleUtilisationPeriodValidator
    }

    @PostMapping("/list")
    fun getLeaveRuleUtilisationPeriodList(@RequestBody leaveRuleSearchRequestTO: LeaveRuleSearchRequestTO): ResponseEntity<*> {
        val responseTO: SearchResponseTO<LeaveRuleUtilisationPeriodTO> = leaveRuleUtilisationPeriodService.getLeaveRuleUtilisationPeriodList(leaveRuleSearchRequestTO)
        val response = ResponseTO.responseBuilder(200, "COM04", "/leave-rule-utilization-period", "leaveRuleUtilisationPeriod", responseTO)
        return ResponseEntity<ResponseTO>(response, HttpStatus.OK)
    }

    @PostMapping("/add")
    fun addLeaveRuleUtilisationPeriod(@Valid @RequestBody leaveRuleUtilisationPeriodTO: LeaveRuleUtilisationPeriodTO, errors: Errors): ResponseEntity<*> {
        if (errors.hasErrors()) {
            val validationError: ValidationError = ValidationError.fromBindingErrors(errors)
            return ResponseEntity<Any>(validationError, HttpStatus.BAD_REQUEST)
        }
        val addedLeaveRuleUtilisationPeriod: LeaveRuleUtilisationPeriodTO = leaveRuleUtilisationPeriodService.addLeaveRuleUtilisationPeriod(leaveRuleUtilisationPeriodTO)
        val responseDTO = ResponseTO.responseBuilder(200, "COM09", "/leave-rule-utilization-period", "leaveRuleUtilisationPeriod", addedLeaveRuleUtilisationPeriod)
        return ResponseEntity<Any>(responseDTO, HttpStatus.CREATED)
    }

    @PutMapping("/update")
    fun updateLeaveRuleUtilisationPeriod(@Valid @RequestBody leaveRuleUtilisationPeriodTO: LeaveRuleUtilisationPeriodTO, errors: Errors): ResponseEntity<*> {
        if (errors.hasErrors()) {
            val validationError: ValidationError = ValidationError.fromBindingErrors(errors)
            return ResponseEntity<Any>(validationError, HttpStatus.OK)
        }
        val addedLeaveRuleUtilisationPeriodTO: LeaveRuleUtilisationPeriodTO =leaveRuleUtilisationPeriodService.updateLeaveRuleUtilisationPeriod(leaveRuleUtilisationPeriodTO)
        val responseDTO = ResponseTO.responseBuilder(200, "COM02", "/leave-rule-utilization-period", "leaveRuleUtilisationPeriod", addedLeaveRuleUtilisationPeriodTO)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }

    @RequestMapping(value = ["/delete"], method = [RequestMethod.DELETE])
    fun deleteLeaveRuleUtilisationPeriod(@Valid @RequestParam(name = "leaveRuleUtilisationPeriodId") leaveRuleUtilisationPeriodId: List<Long>): ResponseEntity<*> {
        leaveRuleUtilisationPeriodService.deleteLeaveRuleUtilisationPeriod(leaveRuleUtilisationPeriodId)
        val responseDTO = ResponseTO.responseBuilder(200, "COM05", "/leave-rule-utilization-period", "leaveRuleUtilisationPeriod", leaveRuleUtilisationPeriodId)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }

    @GetMapping("/{id}")
    fun getLeaveRuleUtilisationPeriodById(@PathVariable id: Long): ResponseEntity<*> {
        val leaveRuleUtilisationPeriodTO: LeaveRuleUtilisationPeriodTO? = leaveRuleUtilisationPeriodService.getLeaveRuleUtilisationPeriodById(id)
        if (leaveRuleUtilisationPeriodTO == null) {
            val responseDTO = ResponseTO.responseBuilder(200, "COM03E", "/leave-rule-utilization-period", "leaveRuleUtilisationPeriod", null)
            return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
        }
        val responseDTO = ResponseTO.responseBuilder(200, "COM11", "/leave-rule-utilization-period", "leaveRuleUtilisationPeriod", leaveRuleUtilisationPeriodTO)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }

}