package hostbooks.payroll.leave.leaveRule.utilisationPeriod.dto

import hostbooks.payroll.shared.utility.model.AuditTO

class LeaveRuleUtilisationPeriodTO:AuditTO() {
    var id: Long? = null
    var leaveTypeId: Long? = null
    var noOfDays: Double? = null
    var status: String = "ACTIVE"
}