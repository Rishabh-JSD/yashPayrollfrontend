package hostbooks.payroll.leave.leaveRule.utilisationPeriod.entity

import hostbooks.payroll.shared.constant.Tables
import hostbooks.payroll.shared.utility.model.Audit
import jakarta.persistence.*

@Entity
@Table(name = Tables.LEAVE_RULE_UTILISATION_PERIOD)
class LeaveRuleUtilisationPeriodBO: Audit() {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    var id: Long? = null

    @Column(name = "leave_type_id")
    var leaveTypeId: Long? = null

    @Column(name = "no_of_days")
    var noOfDays: Double? = null

    @Column(name = "status")
    var status: String? = null
}