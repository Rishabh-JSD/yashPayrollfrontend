package hostbooks.payroll.leave.leaveRule.utilisationPeriod.service

import hostbooks.payroll.leave.leaveRule.LeaveRuleSearchRequestTO
import hostbooks.payroll.leave.leaveRule.utilisationPeriod.dto.LeaveRuleUtilisationPeriodTO
import hostbooks.payroll.shared.utility.model.SearchResponseTO

interface LeaveRuleUtilisationPeriodService {

    fun getLeaveRuleUtilisationPeriodList(leaveRuleSearchRequestTO: LeaveRuleSearchRequestTO): SearchResponseTO<LeaveRuleUtilisationPeriodTO>

    fun addLeaveRuleUtilisationPeriod(leaveRuleUtilisationPeriodTO: LeaveRuleUtilisationPeriodTO): LeaveRuleUtilisationPeriodTO

    fun updateLeaveRuleUtilisationPeriod(leaveRuleUtilisationPeriodTO: LeaveRuleUtilisationPeriodTO): LeaveRuleUtilisationPeriodTO

    fun deleteLeaveRuleUtilisationPeriod(leaveRuleUtilisationPeriodId: List<Long>)

    fun getLeaveRuleUtilisationPeriodById(id: Long): LeaveRuleUtilisationPeriodTO?
}