package hostbooks.payroll.leave.leaveRule.utilisationPeriod.service

import hostbooks.payroll.core.commonDao.CommonDao
import hostbooks.payroll.core.dto.FilterInfo
import hostbooks.payroll.core.dto.HbSort
import hostbooks.payroll.leave.leaveRule.LeaveRuleSearchRequestTO
import hostbooks.payroll.leave.leaveRule.permissible.dto.LeaveRulePermissibleTO
import hostbooks.payroll.leave.leaveRule.utilisationPeriod.dto.LeaveRuleUtilisationPeriodTO
import hostbooks.payroll.leave.leaveRule.utilisationPeriod.entity.LeaveRuleUtilisationPeriodBO
import hostbooks.payroll.shared.constant.AppEnum
import hostbooks.payroll.shared.utility.MapHandler
import hostbooks.payroll.shared.utility.model.SearchResponseTO
import jakarta.transaction.Transactional
import org.springframework.data.domain.Page
import org.springframework.data.domain.PageRequest
import org.springframework.data.domain.Pageable
import org.springframework.stereotype.Service
import java.util.*

@Service
@Transactional
open class LeaveRuleUtilisationPeriodServiceImpl(private val commonDao: CommonDao,
                                            private val mapHandler: MapHandler
):LeaveRuleUtilisationPeriodService {
    override fun getLeaveRuleUtilisationPeriodList(leaveRuleSearchRequestTO: LeaveRuleSearchRequestTO): SearchResponseTO<LeaveRuleUtilisationPeriodTO> {
        val searchResponseTO = SearchResponseTO<LeaveRuleUtilisationPeriodTO>()
        val discriminatorMap: WeakHashMap<String, FilterInfo<*>> = WeakHashMap<String, FilterInfo<*>>()
        discriminatorMap["status"] = FilterInfo(AppEnum.FilterType.EQ, AppEnum.Status.ACTIVE.toString())
        val pageable: Pageable = PageRequest.of(leaveRuleSearchRequestTO.page - 1, leaveRuleSearchRequestTO.limit)
        val data: Page<LeaveRuleUtilisationPeriodBO> = commonDao.listByFilterPagination(LeaveRuleUtilisationPeriodBO::class.java, discriminatorMap, pageable, null)
        val lrUtilisationPeriodList = ArrayList<LeaveRuleUtilisationPeriodTO>()

        data.content.forEach { lrUtilisationPeriodBO ->
            val lrUtilisationPeriodTO = mapHandler.mapObject(lrUtilisationPeriodBO, LeaveRuleUtilisationPeriodTO::class.java)
            if (lrUtilisationPeriodTO != null) {
                lrUtilisationPeriodList.add(lrUtilisationPeriodTO)
            }
        }
        searchResponseTO.list = lrUtilisationPeriodList
        searchResponseTO.pageCount = data.totalPages.toLong()
        searchResponseTO.totalRowCount = data.totalElements
        return searchResponseTO
    }

    override fun addLeaveRuleUtilisationPeriod(leaveRuleUtilisationPeriodTO: LeaveRuleUtilisationPeriodTO): LeaveRuleUtilisationPeriodTO {
        val entity = mapHandler.mapObject(leaveRuleUtilisationPeriodTO, LeaveRuleUtilisationPeriodBO::class.java)
        val persistedEntity = commonDao.persistWithFlush(entity)
        return mapHandler.mapObject(persistedEntity, LeaveRuleUtilisationPeriodTO::class.java)?: leaveRuleUtilisationPeriodTO
    }

    override fun updateLeaveRuleUtilisationPeriod(leaveRuleUtilisationPeriodTO: LeaveRuleUtilisationPeriodTO): LeaveRuleUtilisationPeriodTO {
        val entity = mapHandler.mapObject(leaveRuleUtilisationPeriodTO, LeaveRuleUtilisationPeriodBO::class.java)
        val updatedEntity = commonDao.updateWithFlush(entity)
        return mapHandler.mapObject(updatedEntity, LeaveRuleUtilisationPeriodTO::class.java) ?: leaveRuleUtilisationPeriodTO
    }

    override fun deleteLeaveRuleUtilisationPeriod(leaveRuleUtilisationPeriodId: List<Long>) {
        for (id in leaveRuleUtilisationPeriodId) {
            val leaveRuleUtilisationPeriod: LeaveRuleUtilisationPeriodBO? = commonDao.findByPrimaryKey(LeaveRuleUtilisationPeriodBO::class.java, id)
            if (leaveRuleUtilisationPeriod != null) {
                leaveRuleUtilisationPeriod.status = AppEnum.Status.INACTIVE.toString()
                commonDao.merge(leaveRuleUtilisationPeriod);
            }
        }
    }

    override fun getLeaveRuleUtilisationPeriodById(id: Long): LeaveRuleUtilisationPeriodTO? {
        val leaveRuleUtilisationPeriodBO: LeaveRuleUtilisationPeriodBO? = commonDao.findByPrimaryKey(LeaveRuleUtilisationPeriodBO::class.java, id)
        return mapHandler.mapObject(leaveRuleUtilisationPeriodBO, LeaveRuleUtilisationPeriodTO::class.java)
    }
}