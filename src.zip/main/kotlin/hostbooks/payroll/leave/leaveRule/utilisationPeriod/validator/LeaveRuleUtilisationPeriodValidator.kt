package hostbooks.payroll.leave.leaveRule.utilisationPeriod.validator

import hostbooks.payroll.leave.leaveRule.LeaveRuleSearchRequestTO
import hostbooks.payroll.leave.leaveRule.utilisationPeriod.controller.LeaveRuleUtilisationPeriodController
import hostbooks.payroll.leave.leaveRule.utilisationPeriod.dto.LeaveRuleUtilisationPeriodTO
import org.springframework.validation.Errors
import org.springframework.validation.Validator
import org.springframework.web.bind.annotation.ControllerAdvice

@ControllerAdvice(assignableTypes = [LeaveRuleUtilisationPeriodController::class])
class LeaveRuleUtilisationPeriodValidator: Validator {

    override fun supports(clazz: Class<*>): Boolean {
        return (clazz == LeaveRuleUtilisationPeriodTO::class.java || clazz == LeaveRuleSearchRequestTO::class.java)
    }

    override fun validate(target: Any, errors: Errors) {
        if (target is LeaveRuleUtilisationPeriodTO) {
            if (target.status.isNullOrEmpty()) {
                errors.rejectValue("status", "field.required", "Status is required")
            }
        }
    }
}