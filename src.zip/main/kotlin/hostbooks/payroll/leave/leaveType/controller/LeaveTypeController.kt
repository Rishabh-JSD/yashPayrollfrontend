package hostbooks.payroll.leave.leaveType.controller

import hostbooks.payroll.leave.LeaveSearchRequestTO
import hostbooks.payroll.leave.leaveType.dto.LeaveTypeTO
import hostbooks.payroll.leave.leaveType.service.LeaveTypeService
import hostbooks.payroll.shared.utility.ValidationError
import hostbooks.payroll.shared.utility.model.ResponseTO
import hostbooks.payroll.shared.utility.model.SearchResponseTO
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.validation.Errors
import org.springframework.validation.Validator
import org.springframework.web.bind.WebDataBinder
import org.springframework.web.bind.annotation.*
import javax.validation.Valid

@RestController
@RequestMapping("/leave-type")
class LeaveTypeController(private val leaveTypeService: LeaveTypeService, private val leaveTypeValidator: Validator) {
    @InitBinder
    private fun initBinder(binder: WebDataBinder) {
        binder.validator = this.leaveTypeValidator
    }

    @PostMapping("/list")
    fun getLeaveTypeList(@RequestBody leaveSearchRequestTO: LeaveSearchRequestTO): ResponseEntity<*> {
        val responseTO: SearchResponseTO <LeaveTypeTO> = leaveTypeService.getLeaveTypeList(leaveSearchRequestTO)
        val response = ResponseTO.responseBuilder(200, "COM04", "/leave-type", "leaveType", responseTO)
        return ResponseEntity<ResponseTO>(response, HttpStatus.OK)
    }

    @PostMapping("/add")
    fun addLeaveType(@Valid @RequestBody leaveTypeTO: LeaveTypeTO, errors: Errors): ResponseEntity<*> {
        if (errors.hasErrors()) {
            val validationError: ValidationError = ValidationError.fromBindingErrors(errors)
            return ResponseEntity<Any>(validationError, HttpStatus.OK)
        }
        val addedLeaveTypeTO: LeaveTypeTO = leaveTypeService.addLeaveType(leaveTypeTO)
        val responseDTO = ResponseTO.responseBuilder(201, "COM09", "/leave-type", "leaveType", addedLeaveTypeTO)
        return ResponseEntity<Any>(responseDTO, HttpStatus.CREATED)
    }

    @PostMapping("/add-attendance-types")
    fun addAttendanceTypes(@Valid @RequestBody attendanceTypes: List<LeaveTypeTO>, errors: Errors): ResponseEntity<*> {
        if (errors.hasErrors()) {
            val validationError: ValidationError = ValidationError.fromBindingErrors(errors)
            return ResponseEntity<Any>(validationError, HttpStatus.BAD_REQUEST)
        }
        val addedAttendanceTypes: List<LeaveTypeTO> = leaveTypeService.addAttendanceTypes(attendanceTypes)
        val responseDTO = ResponseTO.responseBuilder(201, "COM09", "/leave-types", "leaveType", addedAttendanceTypes)
        return ResponseEntity<Any>(responseDTO, HttpStatus.CREATED)
    }

    @PutMapping("/update-attendance-types")
    fun updateAttendanceType(@Valid @RequestBody attendanceTypes: List<LeaveTypeTO>, errors: Errors): ResponseEntity<*> {
        if (errors.hasErrors()) {
            val validationError: ValidationError = ValidationError.fromBindingErrors(errors)
            return ResponseEntity<Any>(validationError, HttpStatus.OK)
        }
        val leaveTypeTO: List<LeaveTypeTO> = leaveTypeService.updateAttendanceTypes(attendanceTypes)
        val responseDTO = ResponseTO.responseBuilder(200, "COM02", "/leave-type", "leaveType", leaveTypeTO)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }


    @PutMapping("/update")
    fun updateLeaveType(@Valid @RequestBody leaveTypeTO: LeaveTypeTO, errors: Errors): ResponseEntity<*> {
        if (errors.hasErrors()) {
            val validationError: ValidationError = ValidationError.fromBindingErrors(errors)
            return ResponseEntity<Any>(validationError, HttpStatus.OK)
        }
        val addedLeaveTypeTO: LeaveTypeTO = leaveTypeService.updateLeaveType(leaveTypeTO)
        val responseDTO = ResponseTO.responseBuilder(200, "COM02", "/leave-type", "leaveType", addedLeaveTypeTO)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }

    @DeleteMapping("/delete")
    fun deleteLeaveTypes(@Valid @RequestParam(name = "leaveTypeIdList") leaveTypeIdList: List<Long>): ResponseEntity<*> {
        leaveTypeService.deleteLeaveType(leaveTypeIdList)
        val responseDTO = ResponseTO.responseBuilder(200, "COM05", "/leave-type", "leaveType", leaveTypeIdList)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }

    @GetMapping("/{id}")
    fun getLeaveTypeById(@PathVariable id: Long): ResponseEntity<*> {
        val leaveTypeTO: LeaveTypeTO? = leaveTypeService.getLeaveTypeById(id)
        if (leaveTypeTO == null) {
            val responseDTO = ResponseTO.responseBuilder(200, "COM03E", "/leave-type", "leaveType", null)
            return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
        }
        val responseDTO = ResponseTO.responseBuilder(200, "COM11", "/leave-type", "leaveType", leaveTypeTO)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }
}