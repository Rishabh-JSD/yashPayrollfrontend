package hostbooks.payroll.leave.leaveType.dto

import hostbooks.payroll.shared.utility.model.AuditTO

class LeaveTypeTO : AuditTO() {
    var id: Long? = null
    var name: String? = null
    var code: String? = null
    var status: String? = null
    var type: String? = null
}