package hostbooks.payroll.leave.leaveType.entity

import hostbooks.payroll.shared.constant.Tables
import hostbooks.payroll.shared.utility.model.Audit
import jakarta.persistence.*

@Entity
@Table(name = Tables.LEAVE_TYPE)
class LeaveTypeBO : Audit() {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", updatable = false, nullable = false)
    var id: Long? = null

    @Column(name = "name")
    var name: String? = null

    @Column(name = "code")
    var code: String? = null

    @Column(name = "status", nullable = false)
    var status: String? = null

    @Column(name = "type", nullable = false)
    var type: String? = null
}