package hostbooks.payroll.leave.leaveType.service

import hostbooks.payroll.leave.LeaveSearchRequestTO
import hostbooks.payroll.leave.leaveType.dto.LeaveTypeTO
import hostbooks.payroll.shared.utility.model.SearchResponseTO

interface LeaveTypeService {

    fun getLeaveTypeList(leaveSearchRequestTO: LeaveSearchRequestTO): SearchResponseTO<LeaveTypeTO>

    fun addLeaveType(leaveTypeTO: LeaveTypeTO): LeaveTypeTO

    fun addAttendanceTypes(leaveTypeTOList: List<LeaveTypeTO>): List<LeaveTypeTO>

    fun updateLeaveType(leaveTypeTO: LeaveTypeTO): LeaveTypeTO

    fun updateAttendanceTypes(attendanceTypeTOList: List<LeaveTypeTO>): List<LeaveTypeTO>

    fun deleteLeaveType(leaveTypeIdList: List<Long>)

    fun isLeaveTypeExist(leaveTypeTO: LeaveTypeTO, type: String):Boolean

    fun getLeaveTypeById(id: Long): LeaveTypeTO?
}