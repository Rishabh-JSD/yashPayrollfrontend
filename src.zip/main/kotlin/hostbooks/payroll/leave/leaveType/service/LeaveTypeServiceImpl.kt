package hostbooks.payroll.leave.leaveType.service

import hostbooks.payroll.core.commonDao.CommonDao
import hostbooks.payroll.core.dto.FilterInfo
import hostbooks.payroll.core.dto.HbSort
import hostbooks.payroll.leave.LeaveSearchRequestTO
import hostbooks.payroll.leave.leaveType.dto.LeaveTypeTO
import hostbooks.payroll.leave.leaveType.entity.LeaveTypeBO
import hostbooks.payroll.shared.constant.AppEnum
import hostbooks.payroll.shared.utility.MapHandler
import hostbooks.payroll.shared.utility.model.SearchResponseTO
import jakarta.transaction.Transactional
import org.springframework.data.domain.Page
import org.springframework.data.domain.PageRequest
import org.springframework.data.domain.Pageable
import org.springframework.stereotype.Service
import java.util.*

@Service
@Transactional
open class LeaveTypeServiceImpl(private val commonDao: CommonDao,
                                private val mapHandler: MapHandler
): LeaveTypeService {
    override fun getLeaveTypeList(leaveSearchRequestTO: LeaveSearchRequestTO): SearchResponseTO<LeaveTypeTO> {
        val searchResponseTO = SearchResponseTO<LeaveTypeTO>()
        val discriminatorMap: WeakHashMap<String, FilterInfo<*>> = WeakHashMap<String, FilterInfo<*>>()
        if (!leaveSearchRequestTO.name.isNullOrEmpty()) {
            discriminatorMap["name"] = FilterInfo(AppEnum.FilterType.LIKE, leaveSearchRequestTO.name)
        }
        if (!leaveSearchRequestTO.type.isNullOrEmpty()) {
            discriminatorMap["type"] = FilterInfo(AppEnum.FilterType.EQ, leaveSearchRequestTO.type)
        }
        val pageable: Pageable = PageRequest.of(leaveSearchRequestTO.page - 1, leaveSearchRequestTO.limit)
        val sorts: List<HbSort> = listOf(HbSort("id", AppEnum.SortDirection.ASC))
        val data: Page<LeaveTypeBO> = commonDao.listByFilterPagination(LeaveTypeBO::class.java, discriminatorMap, pageable, sorts)
        searchResponseTO.list = mapHandler.mapObjectList(data.content, LeaveTypeTO::class.java)
        searchResponseTO.pageCount = data.totalPages.toLong()
        searchResponseTO.totalRowCount = data.totalElements
        return searchResponseTO
    }

    override fun addLeaveType(leaveTypeTO: LeaveTypeTO): LeaveTypeTO {
        val entity = mapHandler.mapObject(leaveTypeTO, LeaveTypeBO::class.java)
        val persistedEntity = commonDao.persistWithFlush(entity)
        return mapHandler.mapObject(persistedEntity, LeaveTypeTO::class.java)?: leaveTypeTO
    }

    override fun addAttendanceTypes(leaveTypeTOList: List<LeaveTypeTO>): List<LeaveTypeTO> {
        val entityList: List<LeaveTypeBO>? = mapHandler.mapObjectList(leaveTypeTOList, LeaveTypeBO::class.java)
        val persistedEntityList = commonDao.persistBatch(entityList ?: emptyList())
        return mapHandler.mapObjectList(persistedEntityList, LeaveTypeTO::class.java) ?: leaveTypeTOList
    }

    override fun updateLeaveType(leaveTypeTO: LeaveTypeTO): LeaveTypeTO {
        val entity = mapHandler.mapObject(leaveTypeTO, LeaveTypeBO::class.java)
        val updatedEntity = commonDao.updateWithFlush(entity)
        return mapHandler.mapObject(updatedEntity, LeaveTypeTO::class.java) ?: leaveTypeTO
    }

    override fun updateAttendanceTypes(attendanceTypeTOList: List<LeaveTypeTO>): List<LeaveTypeTO> {
        val entityList: List<LeaveTypeBO>? = mapHandler.mapObjectList(attendanceTypeTOList, LeaveTypeBO::class.java)
        val persistedEntityList = commonDao.updateBatch(entityList ?: emptyList())
        return mapHandler.mapObjectList(persistedEntityList, LeaveTypeTO::class.java) ?: attendanceTypeTOList
    }

    override fun deleteLeaveType(leaveTypeIdList: List<Long>) {
        for (id in leaveTypeIdList) {
            val leaveType: LeaveTypeBO? = commonDao.findByPrimaryKey(LeaveTypeBO::class.java, id)
            if (leaveType != null) {
                commonDao.deleteWithFlush(leaveType)
            }
        }
    }

    override fun isLeaveTypeExist(leaveTypeTO: LeaveTypeTO, type: String): Boolean {
        return when (type) {
            "name" -> commonDao.isExistByDiscriminators(LeaveTypeBO::class.java, leaveTypeTO.name, "name")
            "code" -> commonDao.isExistByDiscriminators(LeaveTypeBO::class.java, leaveTypeTO.code, "code")
            else -> false
        }
    }

    override fun getLeaveTypeById(id: Long): LeaveTypeTO? {
        val leaveTypeBO: LeaveTypeBO? = commonDao.findByPrimaryKey(LeaveTypeBO::class.java, id)
        return mapHandler.mapObject(leaveTypeBO, LeaveTypeTO::class.java)
    }

}