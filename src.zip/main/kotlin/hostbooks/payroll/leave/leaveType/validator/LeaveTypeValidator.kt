package hostbooks.payroll.leave.leaveType.validator

import hostbooks.payroll.leave.LeaveSearchRequestTO
import hostbooks.payroll.leave.leaveType.controller.LeaveTypeController
import hostbooks.payroll.leave.leaveType.dto.LeaveTypeTO
import hostbooks.payroll.leave.leaveType.service.LeaveTypeService
import hostbooks.payroll.shared.constant.AppEnum
import hostbooks.payroll.shared.utility.CommonUtil
import org.springframework.validation.Errors
import org.springframework.validation.Validator
import org.springframework.web.bind.annotation.ControllerAdvice

@ControllerAdvice(assignableTypes = [LeaveTypeController::class])
class LeaveTypeValidator(private val leaveTypeService: LeaveTypeService) : Validator {
    override fun supports(clazz: Class<*>): Boolean {
        return (clazz == LeaveTypeTO::class.java || clazz == LeaveSearchRequestTO::class.java || clazz == ArrayList::class.java)
    }

    override fun validate(target: Any, errors: Errors) {
        if (target is List<*>) {
            for (leaveTypeTO in target) {
                if (leaveTypeTO is LeaveTypeTO) {
                    validateLeaveTypeTO(leaveTypeTO, errors)
                }
            }
        } else if (target is LeaveTypeTO) {
            validateLeaveTypeTO(target, errors)
        }
    }

    private fun validateLeaveTypeTO(leaveTypeTO: LeaveTypeTO, errors: Errors) {
        if (leaveTypeTO.name.isNullOrEmpty()) {
            errors.rejectValue("name", "field.required", "Name is required")
        }
        if (leaveTypeTO.code.isNullOrEmpty()) {
            errors.rejectValue("code", "field.required", "Code is required")
        }
        if (!CommonUtil.checkNullEmpty(leaveTypeTO.id)) {
            val isNameExist: Boolean = leaveTypeService.isLeaveTypeExist(leaveTypeTO, "name")
            val isCodeExist: Boolean = leaveTypeService.isLeaveTypeExist(leaveTypeTO, "code")
            if (isNameExist) {
                errors.rejectValue("name", "field.required", "Duplicate Leave type name")
            }
            if (isCodeExist) {
                errors.rejectValue("code", "field.required", "Duplicate Leave type code")
            }
        }

        val validLeaveOrAttendanceType = AppEnum.LeaveOrAttendanceType.values().map { it.name }.toSet()
        if (leaveTypeTO.type == null) {
            errors.rejectValue("type", "field.required", "Type is required")
        } else if (leaveTypeTO.type !in validLeaveOrAttendanceType) {
            errors.rejectValue("type", "field.invalid", "Invalid Type")
        }
    }
}