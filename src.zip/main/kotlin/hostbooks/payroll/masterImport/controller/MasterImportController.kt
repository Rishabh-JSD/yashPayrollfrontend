package hostbooks.payroll.masterImport.controller

import MasterImportService
import hostbooks.payroll.masterImport.dto.MasterImportTO
import hostbooks.payroll.shared.utility.model.ResponseDTO
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.*

@RestController
@RequestMapping("/masterImport")
class MasterImportController(private var masterImportService:MasterImportService){
    private var response: ResponseDTO? = null
    @RequestMapping(value = ["/valid"], method = [RequestMethod.POST], name = "import valid->MTRCK")
    fun masterImportValidate(@RequestBody masterImportTO: MasterImportTO): ResponseEntity<*> {
        var masterImportResponse = masterImportService.validate(masterImportTO);
        response = ResponseDTO.responseBuilder(200, "COM13", "/masterImport", "importValidation",masterImportResponse);
        return ResponseEntity<Any>(response, HttpStatus.CREATED)
    }

    @RequestMapping(value = ["/addImport"], method = [RequestMethod.POST], name = "import add->MTRCK")
    fun masterImportAdd(@RequestBody masterImportTO: MasterImportTO): ResponseEntity<*> {
        masterImportService.addImportAll(masterImportTO);
        response = ResponseDTO.responseBuilder(200, "COM13", "/masterImport", "masterAddImport",null);
        return ResponseEntity<Any>(response, HttpStatus.CREATED)
    }
}