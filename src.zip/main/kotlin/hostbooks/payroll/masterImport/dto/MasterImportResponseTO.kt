package hostbooks.payroll.masterImport.dto

class MasterImportResponseTO {
    var rowData: MutableList<Any>? = mutableListOf();
    var errorList: MutableList<Any>? = mutableListOf();
}