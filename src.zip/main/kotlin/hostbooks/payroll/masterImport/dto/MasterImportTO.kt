package hostbooks.payroll.masterImport.dto

class MasterImportTO {
     var rowCellsList: List<Any>? = null
     var validData: List<MasterImportValidField>? = null;
     var importType: String? = null
     var documentSeries: String? = null
     var countRow: Int? = null
     var txnType: String? = null
     var branchId: Int? = null
     var contactIds: List<String>? = null
     var subsidyType: String? = null
}