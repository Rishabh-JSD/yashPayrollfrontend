package hostbooks.payroll.masterImport.dto

class MasterImportValidField {
    private val apiName: String? = null

    private val displayName: String? = null

    private val inputType: String? = null

    private val isMandatory = false

    private val unique = false

    private val importFileColumnIndex: Int? = null

    private val fieldValue: String? = null

    private val importType: String? = null
}