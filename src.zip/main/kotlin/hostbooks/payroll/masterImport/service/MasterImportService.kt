
import hostbooks.payroll.masterImport.dto.MasterImportResponseTO
import hostbooks.payroll.masterImport.dto.MasterImportTO

interface MasterImportService {
    fun validate(masterImportTO: MasterImportTO): MasterImportResponseTO?;

    fun addImportAll(masterImportTO: MasterImportTO);

}