package hostbooks.payroll.masterImport.service

import MasterImportService
import hostbooks.payroll.companyDetail.branch.entity.BranchBO
import hostbooks.payroll.companyDetail.costCenter.entity.CostCenterBO
import hostbooks.payroll.companyDetail.department.entity.DepartmentBO
import hostbooks.payroll.core.commonDao.CommonDao
import hostbooks.payroll.core.dto.FilterInfo
import hostbooks.payroll.documentSeries.dto.DocumentSeriesResponse
import hostbooks.payroll.documentSeries.service.DocumentSeriesSettingsService
import hostbooks.payroll.employee.attendance.dto.EmployeeAttendanceTO
import hostbooks.payroll.employee.attendance.service.EmployeeAttendanceService
import hostbooks.payroll.employee.dto.EmployeeTO
import hostbooks.payroll.employee.entity.EmployeeBO
import hostbooks.payroll.employee.entity.EmployeeCompanyDetailsBO
import hostbooks.payroll.employee.service.EmployeeService
import hostbooks.payroll.leave.leaveType.entity.LeaveTypeBO
import hostbooks.payroll.masterImport.dto.MasterImportResponseTO
import hostbooks.payroll.masterImport.dto.MasterImportTO
import hostbooks.payroll.masters.holiday.calendar.dto.HolidayCalendarTO
import hostbooks.payroll.masters.holiday.calendar.entity.HolidayCalendarBO
import hostbooks.payroll.masters.holiday.calendar.service.HolidayCalendarService
import hostbooks.payroll.masters.holiday.typeMaster.entity.HolidayTypeMasterBO
import hostbooks.payroll.masters.option.entity.MasterOptionBO
import hostbooks.payroll.shared.constant.AppConst
import hostbooks.payroll.shared.constant.AppEnum
import hostbooks.payroll.shared.utility.CommonUtil
import hostbooks.payroll.shared.utility.MapHandler
import jakarta.transaction.Transactional
import org.springframework.stereotype.Service
import java.text.SimpleDateFormat
import java.util.*


@Service
@Transactional
open class MasterImportServiceImpl(
    private var employeeService: EmployeeService,
    private val employeeAttendanceService: EmployeeAttendanceService,
    private val holidayCalendarService: HolidayCalendarService,
    private val documentSeriesSettingsService: DocumentSeriesSettingsService,
    private val mapHandler: MapHandler,
    private val commonDao: CommonDao
) : MasterImportService {
    override fun validate(masterImportTO: MasterImportTO): MasterImportResponseTO? {
        val masterImportResponse: MasterImportResponseTO = MasterImportResponseTO()
        var errorList: MutableList<Any>
        when (masterImportTO.importType) {
            "employee" -> {
                if (CommonUtil.checkNullEmpty(masterImportTO.rowCellsList)) {
                    var index = 0
                    for (employee in masterImportTO.rowCellsList!!) {
                        var employeeTO: EmployeeTO? = mapHandler.mapObject(employee, EmployeeTO::class.java)
                        errorList = mutableListOf()
                        if (CommonUtil.checkNullEmpty(employeeTO)) {
                            if (employeeTO != null) {
                                if (!CommonUtil.checkNullEmpty(employeeTO.name)) {
                                    errorList.add("Name" + " Please Add Name " + (index + 1) + ".")
                                }
                                if (CommonUtil.checkNullEmpty(employeeTO.genderName)) {
                                    if (employeeTO.genderName.equals("Male")) {
                                        employeeTO.gender = "Male"
                                    } else if (employeeTO.genderName.equals("Female")) {
                                        employeeTO.gender = "Female"
                                    } else if (employeeTO.genderName.equals("Other")) {
                                        employeeTO.gender = "Other"
                                    } else if (employeeTO.genderName.equals("Not wiiling to specify")) {
                                        employeeTO.gender = "Not wiiling to specify"
                                    } else {
                                        errorList.add("Gender Name" + " Is Not Valid " + (index + 1) + ".")
                                    }
                                } else {
                                    errorList.add("Gender Name" + " Please Add Gender Name " + (index + 1) + ".")
                                }
//                                if (CommonUtil.checkNullEmpty(employeeTO.nationName)) {
//                                    val country: CountriesBO? = commonDao.selectSingleByDiscriminator(
//                                        CountriesBO::class.java,
//                                        employeeTO.nationName,
//                                        "name"
//                                    )
//                                    if (country != null) {
//                                        employeeTO.nationalityId = country.id
//                                    } else {
//                                        errorList.add("Nation Name" + " Is Not Valid " + (index + 1) + ".")
//                                    }
//                                } else {
//                                    errorList.add("Nation Name" + " Please Add Nation Name " + (index + 1) + ".")
//                                }
                                if (CommonUtil.checkNullEmpty(employeeTO.maritalStatus)) {
                                    if (employeeTO.maritalStatus.equals("Married")) {
                                        employeeTO.maritalStatus = "Married"
                                    } else if (employeeTO.maritalStatus == "Unmarried") {
                                        employeeTO.maritalStatus = "Unmarried"
                                    } else if (employeeTO.maritalStatus == "Not wiiling to specify") {
                                        employeeTO.maritalStatus = "Not wiiling to specify"
                                    } else {
                                        errorList.add("Marital Status" + " Is Not Valid " + (index + 1) + ".")
                                    }
                                } else {
                                    errorList.add("Marital Status" + " Please Add Marital Status" + (index + 1) + ".")
                                }

                                if (!CommonUtil.checkNullEmpty(employeeTO.fathersName)) {
                                    errorList.add("Fathers Name" + " Please Add Fathers Name" + (index + 1) + ".")
                                }

                                if (CommonUtil.checkNullEmpty(employeeTO.employmentStatusName)) {
                                    val discriminatorMap = WeakHashMap<String, FilterInfo<Any>>()
                                    discriminatorMap["catCode"] = FilterInfo(AppEnum.FilterType.EQ, "EMPS")
                                    discriminatorMap["name"] =
                                        FilterInfo(AppEnum.FilterType.EQ, employeeTO.employmentStatusName as Any)
                                    discriminatorMap["status"] = FilterInfo(AppEnum.FilterType.EQ, "ACTIVE")
                                    var masterOptions: List<MasterOptionBO>? =
                                        commonDao.selectByMultipleDiscriminatorsByMultiFilter(
                                            MasterOptionBO::class.java,
                                            discriminatorMap,
                                            -1,
                                            false
                                        )
                                    if (CommonUtil.checkNullEmpty(masterOptions)) {
                                        employeeTO.employmentStatusId = masterOptions!!.get(0).id
                                    } else {
                                        errorList.add("Employee Employment Status Name" + " Not Found In System " + (index + 1) + ".")
                                    }
                                } else {
                                    errorList.add("Employee Employment Status Name" + " Please Add Employment Status Name " + (index + 1) + ".")
                                }
                                if (CommonUtil.checkNullEmpty(employeeTO.verificationName)) {
                                    if (employeeTO.verificationName.equals("Correspondence Verified")) {
                                        employeeTO.verificationAddress = "correspondence"
                                    } else if (employeeTO.verificationName.equals("Permanent Verified")) {
                                        employeeTO.verificationAddress = "permanent"
                                    } else if (employeeTO.verificationName.equals("Not Verified")) {
                                        employeeTO.verificationAddress = "not_verified"
                                    } else {
                                        errorList.add("Verification Name" + " Is Not Valid " + (index + 1) + ".")
                                    }
                                } else {
                                    errorList.add("Verification Name" + " Please Add Verification Name" + (index + 1) + ".")
                                }
                                if (CommonUtil.checkNullEmpty(employeeTO.addressCorrespondence)) {
                                    if (employeeTO.addressCorrespondence?.addressOne == null) {
                                        errorList.add("Address One" + " Please Add Address One" + (index + 1) + ".")
                                    }
                                    if (employeeTO.addressCorrespondence?.addressTwo == null) {
                                        errorList.add("Address Two" + " Please Add Address Two" + (index + 1) + ".")
                                    }
//                                    if (employeeTO.addressCorrespondence?.cityName == null) {
//                                        errorList.add("City Name" + " Please Add City Name" + (index + 1) + ".")
//                                    } else {
//                                        val citiesBO: CitiesBO? = commonDao.selectSingleByDiscriminator(
//                                            CitiesBO::class.java,
//                                            employeeTO.addressCorrespondence?.cityName,
//                                            "name"
//                                        )
//                                        if (citiesBO != null) {
//                                            employeeTO.addressCorrespondence?.cityId = citiesBO.id
//                                        } else {
//                                            errorList.add("City Name" + " Is Not Valid " + (index + 1) + ".")
//                                        }
//                                    }
//
//                                    if (employeeTO.addressCorrespondence?.stateName == null) {
//                                        errorList.add("State Name" + " Please Add State Name" + (index + 1) + ".")
//                                    } else {
//                                        val statesBO: StatesBO? = commonDao.selectSingleByDiscriminator(
//                                            StatesBO::class.java,
//                                            employeeTO.addressCorrespondence?.stateName,
//                                            "name"
//                                        )
//                                        if (statesBO != null) {
//                                            employeeTO.addressCorrespondence?.stateId = statesBO.id
//                                        } else {
//                                            errorList.add("State Name" + " Is Not Valid " + (index + 1) + ".")
//                                        }
//                                    }
//
//                                    if (employeeTO.addressCorrespondence?.countryName == null) {
//                                        errorList.add("Country Name" + " Please Add Country Name" + (index + 1) + ".")
//                                    } else {
//                                        val countriesBO: CountriesBO? = commonDao.selectSingleByDiscriminator(
//                                            CountriesBO::class.java,
//                                            employeeTO.addressCorrespondence?.stateName,
//                                            "name"
//                                        )
//                                        if (countriesBO != null) {
//                                            employeeTO.addressCorrespondence?.countryId = countriesBO.id
//                                        } else {
//                                            errorList.add("Country Name" + " Is Not Valid " + (index + 1) + ".")
//                                        }
//                                    }
                                } else {
                                    errorList.add("Correspondence Address" + " Please Add Correspondence Address" + (index + 1) + ".")
                                }

                                if (CommonUtil.checkNullEmpty(employeeTO.employeeCompanyDetails)) {
                                    if (employeeTO.employeeCompanyDetails?.branchName != null) {
                                        var branchBO: BranchBO? = commonDao.selectSingleByDiscriminator(
                                            BranchBO::class.java,
                                            employeeTO.employeeCompanyDetails?.branchName,
                                            "name"
                                        )
                                        if (CommonUtil.checkNullEmpty(branchBO)) {
                                            employeeTO.employeeCompanyDetails!!.branchId = branchBO?.id
                                            var documentSeriesResponse: DocumentSeriesResponse? =
                                                documentSeriesSettingsService.getSeriesSetting(
                                                    "EMP",
                                                    employeeTO.employeeCompanyDetails!!.branchId!!.toInt()
                                                )
                                            if (CommonUtil.checkNullEmpty(documentSeriesResponse)) {
                                                employeeTO.employeeCompanyDetails!!.employeeNumber =
                                                    documentSeriesResponse!!.seriesNumber
                                                employeeTO.employeeCompanyDetails!!.currentNumber =
                                                    documentSeriesResponse.currentNumber
                                                employeeTO.employeeCompanyDetails!!.displayStyle =
                                                    documentSeriesResponse.displayStyle
                                            } else {
                                                errorList.add("Document Series" + " Is Not Found For Branch At Row " + (index + 1) + ".")
                                            }

                                        } else {
                                            errorList.add("Branch Name" + " Is Not Valid " + (index + 1) + ".")
                                        }
                                    } else {
                                        errorList.add("Employee Company Details (Branch Name)" + " Please Add Employee Company Details (Branch Name)" + (index + 1) + ".")
                                    }

                                    if (CommonUtil.checkNullEmpty(employeeTO.employeeCompanyDetails!!.employeeCategoryName)) {
                                        val discriminatorMap = WeakHashMap<String, FilterInfo<Any>>()
                                        discriminatorMap["catCode"] = FilterInfo(AppEnum.FilterType.EQ, "EMPT")
                                        discriminatorMap["name"] = FilterInfo(
                                            AppEnum.FilterType.EQ,
                                            employeeTO.employeeCompanyDetails!!.employeeCategoryName as Any
                                        )
                                        discriminatorMap["code"] = FilterInfo(AppEnum.FilterType.NN, null)
                                        discriminatorMap["status"] = FilterInfo(AppEnum.FilterType.EQ, "ACTIVE")
                                        var masterOptions: List<MasterOptionBO>? =
                                            commonDao.selectByMultipleDiscriminatorsByMultiFilter(
                                                MasterOptionBO::class.java,
                                                discriminatorMap,
                                                -1,
                                                false
                                            )
                                        if (CommonUtil.checkNullEmpty(masterOptions)) {
                                            employeeTO.employeeCompanyDetails!!.employeeCategoryId =
                                                masterOptions!!.get(0).id
                                            if (masterOptions.get(0).code == "CONTRACT") {
                                                if (!CommonUtil.checkNullEmpty(employeeTO.employeeCompanyDetails!!.contractFrom)) {
                                                    errorList.add("Employee Company Details (Contract From)" + " Please Add Employee Company Details (Contract From)" + (index + 1) + ".")
                                                }
                                                if (!CommonUtil.checkNullEmpty(employeeTO.employeeCompanyDetails!!.contractTo)) {
                                                    errorList.add("Employee Company Details (Contract To)" + " Please Add Employee Company Details (Contract To)" + (index + 1) + ".")
                                                }
                                            } else if ((masterOptions.get(0).code == "PERMANENT" || masterOptions.get(0).code == "CONSULT")) {
                                                if (!CommonUtil.checkNullEmpty(employeeTO.employeeCompanyDetails!!.separationDate)) {
                                                    errorList.add("Employee Company Details (Separation Date)" + " Please Add Employee Company Details (Separation Date)" + (index + 1) + ".")
                                                }
                                            }
                                        } else {
                                            errorList.add("Employee Company Details (Employee Category Name)" + " Not Found In System" + (index + 1) + ".")
                                        }
                                    } else {
                                        errorList.add("Employee Company Details (Employee Category Name)" + " Please Add Employee Company Details (Employee Category Name)" + (index + 1) + ".")
                                    }

                                    if (!CommonUtil.checkNullEmpty(employeeTO.employeeCompanyDetails!!.joiningDate)) {
                                        errorList.add("Employee Company Details (Joining Date)" + " Please Add Employee Company Details (Joining Date)" + (index + 1) + ".")
                                    }

                                    if (CommonUtil.checkNullEmpty(employeeTO.employeeCompanyDetails!!.shiftTypeName)) {
                                        val discriminatorMap = WeakHashMap<String, FilterInfo<Any>>()
                                        discriminatorMap["catCode"] = FilterInfo(AppEnum.FilterType.EQ, "SHIFTTYPE")
                                        discriminatorMap["status"] = FilterInfo(AppEnum.FilterType.EQ, "ACTIVE")
                                        var masterOptions: List<MasterOptionBO>? =
                                            commonDao.selectByMultipleDiscriminatorsByMultiFilter(
                                                MasterOptionBO::class.java,
                                                discriminatorMap,
                                                -1,
                                                false
                                            )
                                        if (CommonUtil.checkNullEmpty(masterOptions)) {
                                            employeeTO.employeeCompanyDetails!!.shiftTypeId = masterOptions!!.get(0).id
                                        } else {
                                            errorList.add("Employee Company Details (Employee Shift Type Name)" + " Not Found In System " + (index + 1) + ".")
                                        }
                                    } else {
                                        errorList.add("Employee Company Details (Employee Shift Type Name)" + " Please Add Employee Company Details (Employee Shift Type Name) " + (index + 1) + ".")
                                    }

                                    if (CommonUtil.checkNullEmpty(employeeTO.employeeCompanyDetails!!.designationName)) {
                                        val discriminatorMap = WeakHashMap<String, FilterInfo<Any>>()
                                        discriminatorMap["catCode"] = FilterInfo(AppEnum.FilterType.EQ, "DES")
                                        discriminatorMap["name"] = FilterInfo(
                                            AppEnum.FilterType.EQ,
                                            employeeTO.employeeCompanyDetails!!.designationName as Any
                                        )
                                        discriminatorMap["status"] = FilterInfo(AppEnum.FilterType.EQ, "ACTIVE")
                                        var masterOptions: List<MasterOptionBO>? =
                                            commonDao.selectByMultipleDiscriminatorsByMultiFilter(
                                                MasterOptionBO::class.java,
                                                discriminatorMap,
                                                -1,
                                                false
                                            )
                                        if (CommonUtil.checkNullEmpty(masterOptions)) {
                                            employeeTO.employeeCompanyDetails!!.designationId =
                                                masterOptions!!.get(0).id
                                        } else {
                                            errorList.add("Employee Company Details (Employee Designation Name)" + " Not Found In System " + (index + 1) + ".")
                                        }
                                    } else {
                                        errorList.add("Employee Company Details (Employee Designation Name)" + " Please Add Employee Company Details (Employee Designation Name) " + (index + 1) + ".")
                                    }

                                    if (CommonUtil.checkNullEmpty(employeeTO.employeeCompanyDetails!!.costCenterName)) {
                                        val costCenterBO: CostCenterBO? = commonDao.selectSingleByDiscriminator(
                                            CostCenterBO::class.java,
                                            employeeTO.employeeCompanyDetails!!.costCenterName,
                                            "name"
                                        )
                                        if (CommonUtil.checkNullEmpty(costCenterBO)) {
                                            employeeTO.employeeCompanyDetails!!.costCenterId = costCenterBO!!.id
                                        } else {
                                            errorList.add("Employee Company Details (Employee Cost Centre Name)" + " Not Found In System " + (index + 1) + ".")
                                        }
                                    } else {
                                        errorList.add("Employee Company Details (Employee Cost Centre Name)" + " Please Add Employee Company Details (Employee Cost Centre Name) " + (index + 1) + ".")
                                    }

                                    if (CommonUtil.checkNullEmpty(employeeTO.employeeCompanyDetails!!.departmentName)) {
                                        val departmentBO: DepartmentBO? = commonDao.selectSingleByDiscriminator(
                                            DepartmentBO::class.java,
                                            employeeTO.employeeCompanyDetails!!.departmentName,
                                            "name"
                                        )
                                        if (CommonUtil.checkNullEmpty(departmentBO)) {
                                            employeeTO.employeeCompanyDetails!!.departmentId = departmentBO!!.id
                                        } else {
                                            errorList.add("Employee Company Details (Employee Department Name)" + " Not Found In System " + (index + 1) + ".")
                                        }
                                    } else {
                                        errorList.add("Employee Company Details (Employee Department Name)" + " Please Add Employee Company Details (Employee Department Name) " + (index + 1) + ".")
                                    }

                                    if (CommonUtil.checkNullEmpty(employeeTO.employeeCompanyDetails!!.employeeLevelName)) {
                                        val discriminatorMap = WeakHashMap<String, FilterInfo<Any>>()
                                        discriminatorMap["catCode"] = FilterInfo(AppEnum.FilterType.EQ, "EMPL")
                                        discriminatorMap["name"] = FilterInfo(
                                            AppEnum.FilterType.EQ,
                                            employeeTO.employeeCompanyDetails?.employeeLevelName as Any
                                        )
                                        var masterOptions: List<MasterOptionBO>? =
                                            commonDao.selectByMultipleDiscriminatorsByMultiFilter(
                                                MasterOptionBO::class.java,
                                                discriminatorMap,
                                                -1,
                                                false
                                            )
                                        if (CommonUtil.checkNullEmpty(masterOptions)) {
                                            employeeTO.employeeCompanyDetails!!.employeeLevelId =
                                                masterOptions!!.get(0).id
                                        } else {
                                            errorList.add("Employee Company Details (Employee Level Name)" + " Not Found In System " + (index + 1) + ".")
                                        }
                                    } else {
                                        errorList.add("Employee Company Details (Employee Level Name)" + " Please Add Employee Company Details (Employee Level Name) " + (index + 1) + ".")
                                    }

                                    if (CommonUtil.checkNullEmpty(employeeTO.employeeCompanyDetails!!.payFrequencyName)) {
                                        val discriminatorMap = WeakHashMap<String, FilterInfo<Any>>()
                                        discriminatorMap["catCode"] = FilterInfo(AppEnum.FilterType.EQ, "PAYF")
                                        discriminatorMap["name"] = FilterInfo(
                                            AppEnum.FilterType.EQ,
                                            employeeTO.employeeCompanyDetails?.payFrequencyName as Any
                                        )
                                        var masterOptions: List<MasterOptionBO>? =
                                            commonDao.selectByMultipleDiscriminatorsByMultiFilter(
                                                MasterOptionBO::class.java,
                                                discriminatorMap,
                                                -1,
                                                false
                                            )
                                        if (CommonUtil.checkNullEmpty(masterOptions)) {
                                            employeeTO.employeeCompanyDetails!!.payFrequencyId =
                                                masterOptions!!.get(0).id
                                        } else {
                                            errorList.add("Employee Company Details (Employee Pay Frequency Name)" + " Not Found In System " + (index + 1) + ".")
                                        }
                                    } else {
                                        errorList.add("Employee Company Details (Employee Pay Frequency Name)" + " Please Add Employee Company Details (Pay Frequency Name) " + (index + 1) + ".")
                                    }
                                    if (CommonUtil.checkNullEmpty(employeeTO.employeeCompanyDetails!!.shiftTypeId)) {
                                        val discriminatorMap = WeakHashMap<String, FilterInfo<Any>>()
                                        discriminatorMap["catCode"] = FilterInfo(AppEnum.FilterType.EQ, "SHIFTTIME")
                                        discriminatorMap["parentId"] = FilterInfo(
                                            AppEnum.FilterType.EQ,
                                            employeeTO.employeeCompanyDetails!!.shiftTypeId as Any
                                        )
                                        discriminatorMap["status"] = FilterInfo(AppEnum.FilterType.EQ, "ACTIVE")
                                        var masterOptions: List<MasterOptionBO>? =
                                            commonDao.selectByMultipleDiscriminatorsByMultiFilter(
                                                MasterOptionBO::class.java,
                                                discriminatorMap,
                                                -1,
                                                false
                                            )
                                        if (CommonUtil.checkNullEmpty(masterOptions)) {
                                            employeeTO.employeeCompanyDetails!!.shiftTimingId =
                                                masterOptions!!.get(0).id
                                        } else {
                                            errorList.add("Employee Company Details (Employee Shift Timing)" + " Not Found In System " + (index + 1) + ".")
                                        }
                                    } else {
                                        errorList.add("Employee Company Details (Employee  Shift Timing)" + " Please Add Employee Company Details (Employee  Shift Timing) " + (index + 1) + ".")
                                    }


                                } else {
                                    errorList.add("Employee Company Details" + " Please Add Employee Company Details" + (index + 1) + ".")
                                }

                                if (CommonUtil.checkNullEmpty(employeeTO.employeeSalaryDetails)) {
                                    if (!CommonUtil.checkNullEmpty(employeeTO.employeeSalaryDetails?.basicSalary)) {
                                        errorList.add("Employee Salary Details (Basic Salary)" + " Please Add Employee Salary Details (Basic Salary)" + (index + 1) + ".")
                                    }
                                    if (!CommonUtil.checkNullEmpty(employeeTO.employeeSalaryDetails?.ctc)) {
                                        errorList.add("Employee Salary Details (CTC)" + " Please Add Employee Salary Details (CTC)" + (index + 1) + ".")
                                    }
                                    if (!CommonUtil.checkNullEmpty(employeeTO.employeeSalaryDetails?.netPayBeforeTds)) {
                                        errorList.add("Employee Salary Details (Net PayBeforeTds)" + " Please Add Employee Salary Details (Net PayBeforeTds)" + (index + 1) + ".")
                                    }

                                    if (!CommonUtil.checkNullEmpty(employeeTO.employeeSalaryDetails?.taxSummary)) {
                                        errorList.add("Employee Salary Details (Tax Summary)" + " Please Add Employee Salary Details (Tax Summary)" + (index + 1) + ".")
                                    }
                                } else {
                                    errorList.add("Employee Salary Details" + " Please Add Employee Salary Details" + (index + 1) + ".")
                                }
                            }
                        }
                        if (CommonUtil.checkNullEmpty(errorList)) {
                            masterImportResponse.errorList?.addAll(errorList)

                        } else {
                            if (employeeTO != null) {
                                masterImportResponse.rowData?.add(employeeTO)
                            }
                        }
                        index++
                    }
                }
            }

            "attendance" -> {
                if (CommonUtil.checkNullEmpty(masterImportTO.rowCellsList)) {
                    var index = 0
                    for (employee in masterImportTO.rowCellsList!!) {
                        var employeeAttendanceTO: EmployeeAttendanceTO? =
                            mapHandler.mapObject(employee, EmployeeAttendanceTO::class.java)
                        errorList = mutableListOf()
                        if (CommonUtil.checkNullEmpty(employeeAttendanceTO)) {
                            employeeAttendanceTO?.status = AppConst.AttendanceStatus.DRAFT;
                            if (employeeAttendanceTO != null) {
                                if (CommonUtil.checkNullEmpty(employeeAttendanceTO)) {
                                    if (!CommonUtil.checkNullEmpty(employeeAttendanceTO.leaveType)) {
                                        errorList.add("Leave Type" + " Please Add Leave Type At Row " + (index + 1) + ".")
                                    }
                                    if (CommonUtil.checkNullEmpty(employeeAttendanceTO.leaveType)) {
                                        val leaveType: LeaveTypeBO? = commonDao.selectSingleByDiscriminator(
                                            LeaveTypeBO::class.java,
                                            employeeAttendanceTO.leaveType,
                                            "code"
                                        )
                                        if (leaveType != null) {
                                            employeeAttendanceTO.leaveTypeId = leaveType.id;
                                            employeeAttendanceTO.type = leaveType.code;
                                        } else {
                                            errorList.add("Leave Type" + "This Leave Type doesn't exist In System At Row " + (index + 1) + ".")
                                        }
                                    }
                                    if (CommonUtil.checkNullEmpty(employeeAttendanceTO.employeeNumber)) {
                                        val employeeCompanyDetails: EmployeeCompanyDetailsBO? =
                                            commonDao.selectSingleByDiscriminator(
                                                EmployeeCompanyDetailsBO::class.java,
                                                employeeAttendanceTO.employeeNumber,
                                                "employeeNumber"
                                            )
                                        if (!CommonUtil.checkNullEmpty(employeeCompanyDetails)) {
                                            errorList.add("Employee employeeNumber" + "This Employee Number doesn't exist In System At Row " + (index + 1) + ".")
                                        } else {
                                            val employeeBO: EmployeeBO? = commonDao.selectSingleByDiscriminator(
                                                EmployeeBO::class.java,
                                                employeeCompanyDetails?.id,
                                                "companyDetailId",
                                            )
                                            if (employeeBO != null) {
                                                employeeAttendanceTO.employeeId = employeeBO.id
                                            }
                                        }
                                    }
                                    if (CommonUtil.checkNullEmpty(employeeAttendanceTO.dateString)) {
                                        val dateFormat = SimpleDateFormat("MM/dd/yy")
                                        employeeAttendanceTO.date = dateFormat.parse(employeeAttendanceTO.dateString)
                                    }
                                    employeeAttendanceTO.status = "ACTIVE"
                                }
                            }
                        }
                        if (CommonUtil.checkNullEmpty(errorList)) {
                            masterImportResponse.errorList?.addAll(errorList)
                        } else {
                            if (employeeAttendanceTO != null) {
                                masterImportResponse.rowData?.add(employeeAttendanceTO)
                            }
                        }
                        index++
                    }
                }
            }

            "holiday" -> {
                if (CommonUtil.checkNullEmpty(masterImportTO.rowCellsList)) {
                    var index = 0
                    for (holiday in masterImportTO.rowCellsList!!) {
                        var holidayCalendarTO: HolidayCalendarTO? =
                            mapHandler.mapObject(holiday, HolidayCalendarTO::class.java)
                        errorList = mutableListOf()
                        if (CommonUtil.checkNullEmpty(holidayCalendarTO)) {

                            if (holidayCalendarTO != null) {
                                if (CommonUtil.checkNullEmpty(holidayCalendarTO.dateString)) {
                                    val inputDateFormat = SimpleDateFormat("dd/MM/yyyy")
                                    val outputDateFormat = SimpleDateFormat("yyyy/MM/dd")
                                    holidayCalendarTO.date = outputDateFormat.parse(outputDateFormat.format(inputDateFormat.parse(holidayCalendarTO.dateString)))
                                    val discriminatorMap: WeakHashMap<String, FilterInfo<*>> = WeakHashMap<String, FilterInfo<*>>()
                                    discriminatorMap["status"] = FilterInfo(AppEnum.FilterType.EQ, AppEnum.Status.ACTIVE.toString())
                                    discriminatorMap["date"] = FilterInfo(AppEnum.FilterType.EQ, holidayCalendarTO.date)
                                    val dateExist = commonDao.isExistMultiDiscriminatorsSingleVal(HolidayCalendarBO::class.java, discriminatorMap)
                                    if(dateExist){
                                        errorList.add("Date" + "Same Date Already Exist "+ holidayCalendarTO.dateString +" at index "+ (index + 1) + ".")
                                    }
                                }else{
                                    errorList.add("Date" + " Please Add Date At Row " + (index + 1) + ".")
                                }
                                if (!CommonUtil.checkNullEmpty(holidayCalendarTO.name)) {
                                    errorList.add("Name" + " Please Add Name " + (index + 1) + ".")
                                }
                                if (CommonUtil.checkNullEmpty(holidayCalendarTO.typeName)) {
                                    val discriminatorMap = WeakHashMap<String, FilterInfo<Any>>()
                                    discriminatorMap["status"] = FilterInfo(AppEnum.FilterType.EQ, "ACTIVE")
                                    discriminatorMap["name"] =
                                        FilterInfo(AppEnum.FilterType.EQ, holidayCalendarTO.typeName as Any)
                                    var holidayTypeMasterBO: List<HolidayTypeMasterBO>? =
                                        commonDao.selectByMultipleDiscriminatorsByMultiFilter(
                                            HolidayTypeMasterBO::class.java,
                                            discriminatorMap,
                                            -1,
                                            false
                                        )
                                    if (CommonUtil.checkNullEmpty(holidayTypeMasterBO)) {
                                        holidayCalendarTO.masterId = holidayTypeMasterBO!![0].id
                                    } else {
                                        errorList.add("Holiday Type Name" + " Not Found In System " + (index + 1) + ".")
                                    }
                                } else {
                                    errorList.add("Holiday Type Name" + " Please Add Holiday Type Name " + (index + 1) + ".")
                                }
                            }
                        }
                        if (CommonUtil.checkNullEmpty(errorList)) {
                            masterImportResponse.errorList?.addAll(errorList)
                        } else {
                            if (holidayCalendarTO != null) {
                                masterImportResponse.rowData?.add(holidayCalendarTO)
                            }
                        }
                        index++
                    }
                }
            }
        }
        return masterImportResponse
    }

    override fun addImportAll(masterImportTO: MasterImportTO) {
        if (masterImportTO.importType == "employee") {
            if (CommonUtil.checkNullEmpty(masterImportTO.rowCellsList)) {
                var index = 0
                for (employee in masterImportTO.rowCellsList!!) {
                    var employeeTO: EmployeeTO? = mapHandler.mapObject(employee, EmployeeTO::class.java)
                    if (CommonUtil.checkNullEmpty(employeeTO)) {
                        if (employeeTO != null) {
                            if (CommonUtil.checkNullEmpty(employeeTO)) {
                                employeeService.addEmployee(employeeTO)
                            }
                        }
                    }
                    index++
                }
            }
        } else if (masterImportTO.importType == "attendance") {
            if (CommonUtil.checkNullEmpty(masterImportTO.rowCellsList)) {
                var index = 0
                for (employee in masterImportTO.rowCellsList!!) {
                    var employeeAttendanceTO: EmployeeAttendanceTO? =
                        mapHandler.mapObject(employee, EmployeeAttendanceTO::class.java)
                    if (CommonUtil.checkNullEmpty(employeeAttendanceTO)) {
                        if (employeeAttendanceTO != null) {
                            if (CommonUtil.checkNullEmpty(employeeAttendanceTO)) {
                                employeeAttendanceService.addEmployeeAttendance(employeeAttendanceTO)
                            }
                        }
                    }
                    index++
                }
            }
        } else if (masterImportTO.importType == "holiday") {
            if (CommonUtil.checkNullEmpty(masterImportTO.rowCellsList)) {
                var index = 0
                for (holiday in masterImportTO.rowCellsList!!) {
                    var holidayCalendarTO: HolidayCalendarTO? =
                        mapHandler.mapObject(holiday, HolidayCalendarTO::class.java)
                    if (CommonUtil.checkNullEmpty(holidayCalendarTO)) {
                        if (holidayCalendarTO != null) {
                            if (CommonUtil.checkNullEmpty(holidayCalendarTO)) {
                                holidayCalendarService.addHolidayCalendar(holidayCalendarTO)
                            }
                        }
                    }
                    index++
                }
            }
        }
    }
}