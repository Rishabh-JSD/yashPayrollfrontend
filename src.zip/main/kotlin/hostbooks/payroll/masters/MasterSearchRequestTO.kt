package hostbooks.payroll.masters

import hostbooks.payroll.shared.utility.model.SearchRequestTO
import java.util.*

class MasterSearchRequestTO : SearchRequestTO() {

    private val status: String? = null
    val searchFor: String? = null
    val catCode: String? = null;
    val code: String? = null;
    var type:String?=null;
    var startDate: String? = null
    var endDate: String? = null

}