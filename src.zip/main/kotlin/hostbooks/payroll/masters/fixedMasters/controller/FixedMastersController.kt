package hostbooks.payroll.masters.fixedMasters.controller

import hostbooks.payroll.masters.MasterSearchRequestTO
import hostbooks.payroll.masters.fixedMasters.dto.FixedMastersTO
import hostbooks.payroll.masters.fixedMasters.service.FixedMastersService
import hostbooks.payroll.shared.utility.ValidationError
import hostbooks.payroll.shared.utility.model.ResponseTO
import hostbooks.payroll.shared.utility.model.SearchResponseTO
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.validation.Errors
import org.springframework.validation.Validator
import org.springframework.web.bind.WebDataBinder
import org.springframework.web.bind.annotation.*
import javax.validation.Valid

class FixedMastersController (private val fixedMastersService: FixedMastersService, private val fixedMastersValidator: Validator) {

    @InitBinder
    private fun initBinder(binder: WebDataBinder) {
        binder.validator = this.fixedMastersValidator
    }

    @RequestMapping(value = ["/add"], method = [RequestMethod.POST])
    fun addFixedMaster(@RequestBody requestTO: @Valid FixedMastersTO, result: Errors): ResponseEntity<*> {
        if (result.hasErrors()) {
            val validationError: ValidationError = ValidationError.fromBindingErrors(result)
            return ResponseEntity<ValidationError>(validationError, HttpStatus.OK)
        }
        val fixedMastersTO: FixedMastersTO = fixedMastersService.addFixedMaster(requestTO)
        val responseDTO = ResponseTO.responseBuilder(200, "COM01", "/fixed-masters", "master", fixedMastersTO)
        return ResponseEntity<Any>(responseDTO, HttpStatus.CREATED)
    }

    @RequestMapping(value = ["/update"], method = [RequestMethod.PUT])
    fun updateFixedMaster(@RequestBody requestTO: @Valid FixedMastersTO, result: Errors): ResponseEntity<*> {
        if (result.hasErrors()) {
            val validationError: ValidationError = ValidationError.fromBindingErrors(result)
            return ResponseEntity<ValidationError>(validationError, HttpStatus.OK)
        }
        val fixedMastersTO: FixedMastersTO = fixedMastersService.updateFixedMaster(requestTO)
        val responseDTO = ResponseTO.responseBuilder(200, "COM02", "/fixed-masters", "master", fixedMastersTO)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }

    @RequestMapping(value = ["/list"], method = [RequestMethod.POST])
    fun getFixedMasterList(@RequestBody masterSearchRequestTO: MasterSearchRequestTO): ResponseEntity<*> {
        val searchResponseTO: SearchResponseTO<FixedMastersTO> = fixedMastersService.getFixedMasterList(masterSearchRequestTO)
        if (searchResponseTO.list == null || searchResponseTO.list!!.isEmpty()) {
            val responseDTO = ResponseTO.responseBuilder(200, "COM03E", "/allowance", "allowance", searchResponseTO)
            return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
        }
        val responseDTO = ResponseTO.responseBuilder(200, "COM11", "/fixed-masters", "master", searchResponseTO)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }

    @RequestMapping(value = ["/{id}"], method = [RequestMethod.GET])
    fun getFixedMasterById(@PathVariable("id") id: Long): ResponseEntity<*> {
        val fixedMastersTO: FixedMastersTO? = fixedMastersService.getFixedMasterById(id)
        if (fixedMastersTO == null) {
            val responseDTO = ResponseTO.responseBuilder(200, "COM03E", "/fixed-masters", "master", null)
            return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
        }
        val responseDTO = ResponseTO.responseBuilder(200, "COM11", "/fixed-masters", "master", fixedMastersTO)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }

//    @RequestMapping(value = ["/type/{type}"], method = [RequestMethod.GET])
//    fun getFixedMasterListByType(@PathVariable("type") type: String): ResponseEntity<*> {
//        val list: List<FixedMastersTO>? = fixedMastersService.getFixedMasterListByType(type)
//        if (list == null || list.isEmpty()) {
//            val responseDTO = ResponseTO.responseBuilder(200, "COM03E", "/fixed-masters", "master", list)
//            return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
//        }
//        val responseDTO = ResponseTO.responseBuilder(200, "COM11", "/fixed-masters", "master", list)
//        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
//    }

    @RequestMapping(value = ["/delete"], method = [RequestMethod.DELETE],)
    fun deleteFixedMaster(@RequestParam(name = "masterId") masterId: List<Long>): ResponseEntity<*>? {
        fixedMastersService.deleteFixedMaster(masterId)
        val responseDTO = ResponseTO.responseBuilder(200, "COM05", "/fixed-masters", "master", null)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }
}