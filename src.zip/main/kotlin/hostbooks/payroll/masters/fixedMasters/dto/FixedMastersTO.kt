package hostbooks.payroll.masters.fixedMasters.dto

class FixedMastersTO {
    var id: Long? = null
    var name: String? = null
    var code: String? = null
    var type: String? = null
    var description: String? = null
    var status: String = "ACTIVE"
}