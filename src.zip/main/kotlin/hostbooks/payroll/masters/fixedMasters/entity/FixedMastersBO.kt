package hostbooks.payroll.masters.fixedMasters.entity

import hostbooks.payroll.shared.constant.Tables
import hostbooks.payroll.shared.utility.model.Audit
import jakarta.persistence.*
import lombok.Getter
import lombok.Setter

@Entity
@Table(name = Tables.FIXED_MASTERS)
class FixedMastersBO : Audit() {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", updatable = false)
    var id: Long? = null

    @Column(name = "name")
    var name: String? = null

    @Column(name = "code", unique = true)
    var code: String? = null

    @Column(name = "type")
    var type: String? = null

    @Column(name = "description")
    val description: String? = null

    @Column(name = "status", nullable = false)
    var status: String? = null
}