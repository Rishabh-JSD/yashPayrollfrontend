package hostbooks.payroll.masters.fixedMasters.service

import hostbooks.payroll.masters.MasterSearchRequestTO
import hostbooks.payroll.masters.fixedMasters.dto.FixedMastersTO
import hostbooks.payroll.shared.utility.model.SearchResponseTO

interface FixedMastersService {

    fun addFixedMaster(fixedMastersTO: FixedMastersTO): FixedMastersTO

    fun updateFixedMaster(fixedMastersTO: FixedMastersTO): FixedMastersTO

    fun deleteFixedMaster(fixedMastersId: List<Long>)

    fun getFixedMasterList(masterSearchRequestTO: MasterSearchRequestTO): SearchResponseTO<FixedMastersTO>

    fun getFixedMasterById(id: Long): FixedMastersTO?
}