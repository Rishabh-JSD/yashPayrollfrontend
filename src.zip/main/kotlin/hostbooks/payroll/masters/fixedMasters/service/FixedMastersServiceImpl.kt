package hostbooks.payroll.masters.fixedMasters.service

import hostbooks.payroll.core.commonDao.CommonDao
import hostbooks.payroll.core.dto.FilterInfo
import hostbooks.payroll.core.dto.HbSort
import hostbooks.payroll.masters.MasterSearchRequestTO
import hostbooks.payroll.masters.fixedMasters.dto.FixedMastersTO
import hostbooks.payroll.masters.fixedMasters.entity.FixedMastersBO
import hostbooks.payroll.masters.master.dto.MasterTO
import hostbooks.payroll.shared.constant.AppEnum
import hostbooks.payroll.shared.utility.MapHandler
import hostbooks.payroll.shared.utility.model.SearchResponseTO
import jakarta.transaction.Transactional
import org.springframework.data.domain.Page
import org.springframework.data.domain.PageRequest
import org.springframework.data.domain.Pageable
import org.springframework.stereotype.Service
import java.util.*

@Service
@Transactional
open class FixedMastersServiceImpl ( private val commonDao: CommonDao,
private val mapHandler: MapHandler,
) : FixedMastersService {

    override fun addFixedMaster(fixedMastersTO: FixedMastersTO): FixedMastersTO {
        val entity = mapHandler.mapObject(fixedMastersTO, FixedMastersBO::class.java)
        val persistedEntity = commonDao.persistWithFlush(entity)
        return mapHandler.mapObject(persistedEntity, FixedMastersTO::class.java) ?: fixedMastersTO
    }

    override fun updateFixedMaster(fixedMastersTO: FixedMastersTO): FixedMastersTO {
        val entity = mapHandler.mapObject(fixedMastersTO, FixedMastersBO::class.java)
        val updatedEntity = commonDao.updateWithFlush(entity)
        return mapHandler.mapObject(updatedEntity, FixedMastersTO::class.java) ?: fixedMastersTO
    }

    override fun deleteFixedMaster(fixedMastersId: List<Long>) {
        for (id in fixedMastersId) {
            val fixedMasters: FixedMastersBO? = commonDao.findByPrimaryKey(FixedMastersBO::class.java, id)
            if (fixedMasters != null) {
                fixedMasters.status = AppEnum.Status.INACTIVE.toString()
            }
            commonDao.merge(fixedMasters);
        }
    }

    override fun getFixedMasterList(masterSearchRequestTO: MasterSearchRequestTO): SearchResponseTO<FixedMastersTO> {
        val searchResponseTO = SearchResponseTO<FixedMastersTO>()
        val discriminatorMap: WeakHashMap<String, FilterInfo<*>> = WeakHashMap()
        discriminatorMap["status"] = FilterInfo(AppEnum.FilterType.EQ, AppEnum.Status.ACTIVE.toString())
        val sorts: List<HbSort> = listOf(HbSort("name", AppEnum.SortDirection.DESC))
        val pageable: Pageable = PageRequest.of(masterSearchRequestTO.page - 1, masterSearchRequestTO.limit)
        val data: Page<FixedMastersBO> =
            commonDao.listByFilterPagination(FixedMastersBO::class.java, discriminatorMap, pageable, sorts)

        val masterList = ArrayList<FixedMastersTO>()

        data.content.forEach { fixedMastersBO ->
            val fixedMasterTO: FixedMastersTO? = mapHandler.mapObject(fixedMastersBO, FixedMastersTO::class.java)
            if (fixedMasterTO != null) {
                masterList.add(fixedMasterTO)
            }
        }

        searchResponseTO.list = masterList
        searchResponseTO.pageCount = data.totalPages.toLong()
        searchResponseTO.totalRowCount = data.totalElements
        return searchResponseTO
    }

    override fun getFixedMasterById(id: Long): FixedMastersTO? {
        val fixedMastersBO: FixedMastersBO? = commonDao.findByPrimaryKey(FixedMastersBO::class.java, id)
        return if(fixedMastersBO!!.status=="ACTIVE") {
            mapHandler.mapObject(fixedMastersBO, FixedMastersTO::class.java)
        }
        else {
            null
        }
    }
}