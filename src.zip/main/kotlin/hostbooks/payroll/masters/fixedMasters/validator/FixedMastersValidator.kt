package hostbooks.payroll.masters.fixedMasters.validator

import hostbooks.payroll.masters.MasterSearchRequestTO
import hostbooks.payroll.masters.fixedMasters.controller.FixedMastersController
import hostbooks.payroll.masters.fixedMasters.dto.FixedMastersTO
import org.springframework.validation.Errors
import org.springframework.validation.Validator
import org.springframework.web.bind.annotation.ControllerAdvice

@ControllerAdvice(assignableTypes = [FixedMastersController::class])
class FixedMastersValidator : Validator {

        override fun supports(clazz: Class<*>): Boolean {
            return (clazz == FixedMastersTO::class.java || clazz == MasterSearchRequestTO::class.java)
        }

        override fun validate(target: Any, errors: Errors) {
            if (target is FixedMastersTO) {
                // validation logic for MasterTO
            }
        }
}