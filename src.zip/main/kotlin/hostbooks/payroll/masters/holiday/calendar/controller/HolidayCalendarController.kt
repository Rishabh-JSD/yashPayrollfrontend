package hostbooks.payroll.masters.holiday.calendar.controller

import hostbooks.payroll.masters.MasterSearchRequestTO
import hostbooks.payroll.shared.utility.ValidationError
import hostbooks.payroll.shared.utility.model.ResponseTO
import hostbooks.payroll.shared.utility.model.SearchResponseTO
import hostbooks.payroll.masters.holiday.calendar.dto.HolidayCalendarTO
import hostbooks.payroll.masters.holiday.calendar.service.HolidayCalendarService
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.validation.Errors
import org.springframework.validation.Validator
import org.springframework.web.bind.WebDataBinder
import org.springframework.web.bind.annotation.*
import javax.validation.Valid

@RestController
@RequestMapping("/holiday-calendar")
class HolidayCalendarController(
    private val holidayCalendarService: HolidayCalendarService,
    private val holidayCalendarValidator: Validator
) {

    @InitBinder
    private fun initBinder(binder: WebDataBinder) {
        binder.validator = this.holidayCalendarValidator
    }

    @RequestMapping(value = ["/add"], method = [RequestMethod.POST])
    fun addHolidayCalendar(@Valid @RequestBody holidayCalendarTO: HolidayCalendarTO, errors: Errors): ResponseEntity<Any> {
        if (errors.hasErrors()) {
            val validationError: ValidationError = ValidationError.fromBindingErrors(errors)
            return ResponseEntity<Any>(validationError, HttpStatus.OK)
        }
        val holidayCalendarTOReturn: HolidayCalendarTO = holidayCalendarService.addHolidayCalendar(holidayCalendarTO)
        val responseDTO =
            ResponseTO.responseBuilder(200, "COM01", "/holiday-calendar", "holidayCalendar", holidayCalendarTOReturn)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }

    @RequestMapping(value = ["/update"], method = [RequestMethod.POST])
    fun updateHolidayCalendar(@Valid @RequestBody holidayCalendarTO: HolidayCalendarTO, errors: Errors): ResponseEntity<Any> {
        if (errors.hasErrors()) {
            val validationError: ValidationError = ValidationError.fromBindingErrors(errors)
            return ResponseEntity<Any>(validationError, HttpStatus.OK)
        }
        val holidayCalendarTOReturn: HolidayCalendarTO = holidayCalendarService.updateHolidayCalendar(holidayCalendarTO)
        val responseDTO =
            ResponseTO.responseBuilder(200, "COM02", "/holiday-calendar", "holidayCalendar", holidayCalendarTOReturn)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }

    @RequestMapping(value = ["/delete"], method = [RequestMethod.DELETE])
    fun deleteHolidayCalendar(@RequestParam(name = "holidayCalendarId") holidayCalendarId: List<Long>): ResponseEntity<*>? {
        holidayCalendarService.deleteHolidayCalendar(holidayCalendarId)
        val responseDTO =
            ResponseTO.responseBuilder(200, "COM05", "/holiday-calendar", "holidayCalendar", holidayCalendarId)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }


    @RequestMapping(value = ["/list"], method = [RequestMethod.POST])
    fun getHolidayCalendarList(@RequestBody masterSearchRequestTO: MasterSearchRequestTO): ResponseEntity<*> {
        val responseTO: SearchResponseTO<HolidayCalendarTO> = holidayCalendarService.getHolidayCalendarList(masterSearchRequestTO)
        val response = ResponseTO.responseBuilder(200, "COM11", "/holiday-calendar", "holidayCalendar", responseTO)
        return ResponseEntity<ResponseTO>(response, HttpStatus.OK)
    }
}