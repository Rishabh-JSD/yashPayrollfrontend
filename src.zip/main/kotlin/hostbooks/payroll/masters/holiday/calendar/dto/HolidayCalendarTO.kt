package hostbooks.payroll.masters.holiday.calendar.dto

import hostbooks.payroll.shared.utility.model.AuditTO
import java.util.*

class HolidayCalendarTO : AuditTO() {
    var id: Long? = null
    var masterId: Long? = null
    var name: String? = null
    var date: Date? = null
    var status: String = "ACTIVE"
    var typeName: String? = null
    var dateString: String? = null

}