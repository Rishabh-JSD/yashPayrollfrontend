package hostbooks.payroll.masters.holiday.calendar.entity

import hostbooks.payroll.shared.constant.Tables
import hostbooks.payroll.shared.utility.model.Audit
import jakarta.persistence.*
import java.util.*

@Entity
@Table(name = Tables.HOLIDAY_CALENDAR)
class HolidayCalendarBO : Audit() {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", updatable = false, nullable = false)
    var id: Long? = null

    @Column(name = "master_id", nullable = false)
    var masterId: Long? = null

    @Column(name = "name", nullable = false)
    var name: String? = null

    @Column(name = "status", nullable = false)
    var status: String? = null

    @Column(name = "date", nullable = false)
    var date: Date? = null

}

