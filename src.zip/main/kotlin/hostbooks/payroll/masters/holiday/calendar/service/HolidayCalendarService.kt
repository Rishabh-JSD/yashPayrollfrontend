package hostbooks.payroll.masters.holiday.calendar.service

import hostbooks.payroll.masters.MasterSearchRequestTO
import hostbooks.payroll.shared.utility.model.SearchResponseTO
import hostbooks.payroll.masters.holiday.calendar.dto.HolidayCalendarTO

interface HolidayCalendarService {

    fun addHolidayCalendar(holidayCalendarTO: HolidayCalendarTO): HolidayCalendarTO

    fun updateHolidayCalendar(holidayCalendarTO: HolidayCalendarTO): HolidayCalendarTO

    fun deleteHolidayCalendar(holidayCalendarId: List<Long>)

    fun getHolidayCalendarList(masterSearchRequestTO: MasterSearchRequestTO): SearchResponseTO<HolidayCalendarTO>

    fun isSameDateExist(holidayCalendarTO: HolidayCalendarTO): Boolean
}