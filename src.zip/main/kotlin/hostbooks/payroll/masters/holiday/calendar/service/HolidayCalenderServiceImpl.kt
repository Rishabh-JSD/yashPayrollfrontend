package hostbooks.payroll.masters.holiday.calendar.service

import hostbooks.payroll.shared.constant.AppEnum
import hostbooks.payroll.shared.utility.MapHandler
import hostbooks.payroll.shared.utility.model.SearchResponseTO
import hostbooks.payroll.core.commonDao.CommonDao
import hostbooks.payroll.core.dto.FilterInfo
import hostbooks.payroll.core.dto.HbSort
import hostbooks.payroll.employee.entity.EmployeeBO
import hostbooks.payroll.masters.MasterSearchRequestTO
import hostbooks.payroll.masters.holiday.calendar.dto.HolidayCalendarTO
import hostbooks.payroll.masters.holiday.calendar.entity.HolidayCalendarBO
import hostbooks.payroll.masters.holiday.typeMaster.service.HolidayTypeMasterService
import hostbooks.payroll.masters.option.entity.MasterOptionBO
import jakarta.transaction.Transactional
import org.springframework.data.domain.Page
import org.springframework.data.domain.PageRequest
import org.springframework.data.domain.Pageable
import org.springframework.stereotype.Service
import java.text.SimpleDateFormat
import java.util.*

@Service
@Transactional
open class HolidayCalenderServiceImpl(
    private val commonDao: CommonDao,
    private val mapHandler: MapHandler,
    private val holidayTypeMasterService: HolidayTypeMasterService
) : HolidayCalendarService {

    override fun addHolidayCalendar(holidayCalendarTO: HolidayCalendarTO): HolidayCalendarTO {
        val entity = mapHandler.mapObject(holidayCalendarTO, HolidayCalendarBO::class.java)
        val persistedEntity = commonDao.persistWithFlush(entity)
        return mapHandler.mapObject(persistedEntity, HolidayCalendarTO::class.java) ?: holidayCalendarTO
    }

    override fun updateHolidayCalendar(holidayCalendarTO: HolidayCalendarTO): HolidayCalendarTO {
        val entity = mapHandler.mapObject(holidayCalendarTO, HolidayCalendarBO::class.java)
        val updatedEntity = commonDao.updateWithFlush(entity)
        return mapHandler.mapObject(updatedEntity, HolidayCalendarTO::class.java) ?: holidayCalendarTO
    }

    override fun deleteHolidayCalendar(holidayCalendarId: List<Long>) {
        for (id in holidayCalendarId) {
            val holidayCalendar: HolidayCalendarBO? =
                commonDao.findByPrimaryKey(HolidayCalendarBO::class.java, id)
            if (holidayCalendar != null) {
                holidayCalendar.status = AppEnum.Status.INACTIVE.toString()
            }
            commonDao.merge(holidayCalendar);
        }
    }

    override fun getHolidayCalendarList(masterSearchRequestTO: MasterSearchRequestTO): SearchResponseTO<HolidayCalendarTO> {
        val searchResponseTO = SearchResponseTO<HolidayCalendarTO>()
        val discriminatorMap: WeakHashMap<String, FilterInfo<*>> = WeakHashMap()
        discriminatorMap["status"] = FilterInfo(AppEnum.FilterType.EQ, AppEnum.Status.ACTIVE.toString())
        if (masterSearchRequestTO.startDate != null && masterSearchRequestTO.endDate != null) {
            val inRange = mutableListOf<Date>()
            inRange.add(SimpleDateFormat("yyyy-MM-dd").parse(masterSearchRequestTO.startDate))
            inRange.add(SimpleDateFormat("yyyy-MM-dd").parse( masterSearchRequestTO.endDate))
            discriminatorMap["date"] = FilterInfo<Any>(AppEnum.FilterType.BW, inRange)
        }
        val sorts: List<HbSort> = listOf(HbSort("name", AppEnum.SortDirection.DESC))
        val pageable: Pageable =
            PageRequest.of(masterSearchRequestTO.page - 1, masterSearchRequestTO.limit)
        val data: Page<HolidayCalendarBO> =
            commonDao.listByFilterPagination(HolidayCalendarBO::class.java, discriminatorMap, pageable, sorts)

        val holidayCalendarList = ArrayList<HolidayCalendarTO>()

        data.content.forEach { holidayCalendarBO ->
            val holidayCalendarTO: HolidayCalendarTO? =
                mapHandler.mapObject(holidayCalendarBO, HolidayCalendarTO::class.java)
            if (holidayCalendarTO != null) {
                if (holidayCalendarTO.masterId != null) {
                    val masterId = holidayCalendarTO.masterId!!.toLong()
                    holidayCalendarTO.typeName = holidayTypeMasterService.getHolidayTypeMasterById(masterId)!!.name
                }

                holidayCalendarList.add(holidayCalendarTO)
            }
        }

        searchResponseTO.list = holidayCalendarList
        searchResponseTO.pageCount = data.totalPages.toLong()
        searchResponseTO.totalRowCount = data.totalElements
        return searchResponseTO
    }

    override fun isSameDateExist(holidayCalendarTO: HolidayCalendarTO): Boolean {
        val discriminatorMap: WeakHashMap<String, FilterInfo<*>> = WeakHashMap<String, FilterInfo<*>>()
        discriminatorMap["status"] = FilterInfo(AppEnum.FilterType.EQ, AppEnum.Status.ACTIVE.toString())
        discriminatorMap["date"] = FilterInfo(AppEnum.FilterType.EQ, formatDate(holidayCalendarTO.date))
        return commonDao.isExistMultiDiscriminatorsSingleVal(HolidayCalendarBO::class.java, discriminatorMap)
    }

    fun formatDate(date: Date?): Date? {
        if (date == null) return null
        val outputFormat = SimpleDateFormat("yyyy/MM/dd")
        val formattedDateStr = outputFormat.format(date)
        return outputFormat.parse(formattedDateStr)
    }

}