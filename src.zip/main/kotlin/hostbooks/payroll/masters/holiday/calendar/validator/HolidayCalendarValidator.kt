package hostbooks.payroll.masters.holiday.calendar.validator

import hostbooks.payroll.masters.MasterSearchRequestTO
import hostbooks.payroll.masters.holiday.calendar.controller.HolidayCalendarController
import hostbooks.payroll.masters.holiday.calendar.dto.HolidayCalendarTO
import hostbooks.payroll.masters.holiday.calendar.service.HolidayCalendarService
import org.springframework.validation.Errors
import org.springframework.validation.Validator
import org.springframework.web.bind.annotation.ControllerAdvice

@ControllerAdvice(assignableTypes = [HolidayCalendarController::class])
class HolidayCalendarValidator(private val holidayCalendarService: HolidayCalendarService) : Validator {
    override fun supports(clazz: Class<*>): Boolean {
        return (clazz == HolidayCalendarTO::class.java || clazz == MasterSearchRequestTO::class.java)
    }

    override fun validate(target: Any, errors: Errors) {
        if (target is HolidayCalendarTO) {
            // validation logic for HolidayCalendarTO
            if(target.id == null){
            var isSameDateExist: Boolean = holidayCalendarService.isSameDateExist(target)
                if (isSameDateExist) {
                    errors.rejectValue(
                        "date",
                        "Duplicate Date",
                        "Duplicate not allowed for date: ${target.date}"
                    )
                }
            }
        }
    }
}