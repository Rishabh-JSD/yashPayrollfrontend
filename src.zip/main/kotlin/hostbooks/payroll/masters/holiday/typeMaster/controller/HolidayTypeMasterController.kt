package hostbooks.payroll.masters.holiday.typeMaster.controller

import hostbooks.payroll.masters.MasterSearchRequestTO
import hostbooks.payroll.shared.utility.ValidationError
import hostbooks.payroll.shared.utility.model.ResponseTO
import hostbooks.payroll.shared.utility.model.SearchResponseTO
import hostbooks.payroll.masters.holiday.typeMaster.dto.HolidayTypeMasterTO
import hostbooks.payroll.masters.holiday.typeMaster.service.HolidayTypeMasterService
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.validation.Errors
import org.springframework.validation.Validator
import org.springframework.web.bind.WebDataBinder
import org.springframework.web.bind.annotation.*
import javax.validation.Valid

@RestController
@RequestMapping("/holiday-type")
class HolidayTypeMasterController(
    private val holidayTypeMasterService: HolidayTypeMasterService,
    private val holidayTypeMasterValidator: Validator
) {

    @InitBinder
    private fun initBinder(binder: WebDataBinder) {
        binder.validator = this.holidayTypeMasterValidator
    }

    @RequestMapping(value = ["/add"], method = [RequestMethod.POST])
    fun addHolidayTypeMaster(@Valid @RequestBody holidayTypeMasterTO: HolidayTypeMasterTO, errors: Errors): ResponseEntity<Any> {
        if (errors.hasErrors()) {
            val validationError: ValidationError = ValidationError.fromBindingErrors(errors)
            return ResponseEntity<Any>(validationError, HttpStatus.OK)
        }
        val holidayTypeMasterTOReturn: HolidayTypeMasterTO =
            holidayTypeMasterService.addHolidayTypeMaster(holidayTypeMasterTO)
        val responseDTO =
            ResponseTO.responseBuilder(200, "COM01", "/holiday-type", "holidayTypeMaster", holidayTypeMasterTOReturn)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }

    @RequestMapping(value = ["/update"], method = [RequestMethod.POST])
    fun updateHolidayTypeMaster(@Valid @RequestBody holidayTypeMasterTO: HolidayTypeMasterTO, errors: Errors): ResponseEntity<Any> {
        if (errors.hasErrors()) {
            val validationError: ValidationError = ValidationError.fromBindingErrors(errors)
            return ResponseEntity<Any>(validationError, HttpStatus.OK)
        }
        val holidayTypeMasterTOReturn: HolidayTypeMasterTO =
            holidayTypeMasterService.updateHolidayTypeMaster(holidayTypeMasterTO)
        val responseDTO =
            ResponseTO.responseBuilder(200, "COM02", "/holiday-type", "holidayTypeMaster", holidayTypeMasterTOReturn)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }

    @RequestMapping(value = ["/delete"], method = [RequestMethod.DELETE])
    fun deleteHolidayTypeMaster(@RequestParam(name = "holidayTypeMasterId") holidayTypeMasterId: List<Long>): ResponseEntity<*>? {
        holidayTypeMasterService.deleteHolidayTypeMaster(holidayTypeMasterId)
        val responseDTO =
            ResponseTO.responseBuilder(200, "COM05", "/holiday-type", "holidayTypeMaster", holidayTypeMasterId)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }


    @RequestMapping(value = ["/list"], method = [RequestMethod.POST])
    fun getHolidayTypeMasterList(@RequestBody masterSearchRequestTO: MasterSearchRequestTO): ResponseEntity<*> {
        val responseTO: SearchResponseTO<HolidayTypeMasterTO> =
            holidayTypeMasterService.getHolidayTypeMasterList(masterSearchRequestTO)
        val response = ResponseTO.responseBuilder(200, "COM11", "/holiday-type", "holidayTypeMaster", responseTO)
        return ResponseEntity<ResponseTO>(response, HttpStatus.OK)
    }

    @RequestMapping(value = ["/{id}"], method = [RequestMethod.GET])
    fun getHolidayTypeMasterById(@PathVariable id: Long): ResponseEntity<*> {
        val holidayTypeMasterTO: HolidayTypeMasterTO? = holidayTypeMasterService.getHolidayTypeMasterById(id)
        if (holidayTypeMasterTO == null) {
            val responseDTO = ResponseTO.responseBuilder(200, "COM03E", "/holiday-type", "holidayTypeMaster", null)
            return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
        }
        val responseDTO =
            ResponseTO.responseBuilder(200, "COM11", "/holiday-type", "holidayTypeMaster", holidayTypeMasterTO)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }
}