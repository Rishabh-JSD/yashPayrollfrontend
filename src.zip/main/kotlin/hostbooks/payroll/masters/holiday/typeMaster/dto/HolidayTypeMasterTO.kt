package hostbooks.payroll.masters.holiday.typeMaster.dto

import hostbooks.payroll.shared.utility.model.AuditTO

class HolidayTypeMasterTO : AuditTO() {
    var id: Long? = null
    var code: String? = null
    var name: String? = null
    var status: String = "ACTIVE"
}