package hostbooks.payroll.masters.holiday.typeMaster.service

import hostbooks.payroll.masters.MasterSearchRequestTO
import hostbooks.payroll.shared.utility.model.SearchResponseTO
import hostbooks.payroll.masters.holiday.typeMaster.dto.HolidayTypeMasterTO


interface HolidayTypeMasterService {

    fun addHolidayTypeMaster(holidayTypeMasterTO: HolidayTypeMasterTO): HolidayTypeMasterTO

    fun updateHolidayTypeMaster(holidayTypeMasterTO: HolidayTypeMasterTO): HolidayTypeMasterTO

    fun deleteHolidayTypeMaster(holidayTypeMasterId: List<Long>)

    fun getHolidayTypeMasterList(masterSearchRequestTO: MasterSearchRequestTO): SearchResponseTO<HolidayTypeMasterTO>

    fun getHolidayTypeMasterById(id: Long): HolidayTypeMasterTO?
}