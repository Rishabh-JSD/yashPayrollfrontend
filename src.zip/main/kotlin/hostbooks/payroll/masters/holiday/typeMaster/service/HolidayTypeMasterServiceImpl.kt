package hostbooks.payroll.masters.holiday.typeMaster.service

import hostbooks.payroll.shared.constant.AppEnum
import hostbooks.payroll.shared.utility.MapHandler
import hostbooks.payroll.shared.utility.model.SearchResponseTO
import hostbooks.payroll.core.commonDao.CommonDao
import hostbooks.payroll.core.dto.FilterInfo
import hostbooks.payroll.core.dto.HbSort
import hostbooks.payroll.masters.MasterSearchRequestTO
import hostbooks.payroll.masters.holiday.typeMaster.dto.HolidayTypeMasterTO
import hostbooks.payroll.masters.holiday.typeMaster.entity.HolidayTypeMasterBO
import jakarta.transaction.Transactional
import org.springframework.data.domain.Page
import org.springframework.data.domain.PageRequest
import org.springframework.data.domain.Pageable
import org.springframework.stereotype.Service
import java.util.*

@Service
@Transactional
open class HolidayTypeMasterServiceImpl(
    private val commonDao: CommonDao,
    private val mapHandler: MapHandler
) : HolidayTypeMasterService {

    override fun addHolidayTypeMaster(holidayTypeMasterTO: HolidayTypeMasterTO): HolidayTypeMasterTO {
        val entity = mapHandler.mapObject(holidayTypeMasterTO, HolidayTypeMasterBO::class.java)
        val persistedEntity = commonDao.persistWithFlush(entity)
        return mapHandler.mapObject(persistedEntity, HolidayTypeMasterTO::class.java) ?: holidayTypeMasterTO
    }

    override fun updateHolidayTypeMaster(holidayTypeMasterTO: HolidayTypeMasterTO): HolidayTypeMasterTO {
        val entity = mapHandler.mapObject(holidayTypeMasterTO, HolidayTypeMasterBO::class.java)
        val updatedEntity = commonDao.updateWithFlush(entity)
        return mapHandler.mapObject(updatedEntity, HolidayTypeMasterTO::class.java) ?: holidayTypeMasterTO
    }

    override fun deleteHolidayTypeMaster(holidayTypeMasterId: List<Long>) {
        for (id in holidayTypeMasterId) {
            val holidayTypeMasterBO: HolidayTypeMasterBO? =
                commonDao.findByPrimaryKey(HolidayTypeMasterBO::class.java, id)
            if (holidayTypeMasterBO != null) {
                holidayTypeMasterBO.status = AppEnum.Status.INACTIVE.toString()
            }
            commonDao.merge(holidayTypeMasterBO);
        }
    }

    override fun getHolidayTypeMasterList(masterSearchRequestTO: MasterSearchRequestTO): SearchResponseTO<HolidayTypeMasterTO> {
        val searchResponseTO = SearchResponseTO<HolidayTypeMasterTO>()
        val discriminatorMap: WeakHashMap<String, FilterInfo<*>> = WeakHashMap()
        discriminatorMap["status"] = FilterInfo(AppEnum.FilterType.EQ, AppEnum.Status.ACTIVE.toString())
        if (masterSearchRequestTO.searchFor != null) {
            discriminatorMap["name"] = FilterInfo(AppEnum.FilterType.LIKE, masterSearchRequestTO.searchFor)
        }
        val sorts: List<HbSort> = listOf(HbSort("name", AppEnum.SortDirection.DESC))
        val pageable: Pageable =
            PageRequest.of(masterSearchRequestTO.page - 1, masterSearchRequestTO.limit)
        val data: Page<HolidayTypeMasterBO> =
            commonDao.listByFilterPagination(HolidayTypeMasterBO::class.java, discriminatorMap, pageable, sorts)

        val holidayTypeMasterList = ArrayList<HolidayTypeMasterTO>()

        data.content.forEach { holidayTypeMasterBO ->
            val holidayTypeMasterTO: HolidayTypeMasterTO? =
                mapHandler.mapObject(holidayTypeMasterBO, HolidayTypeMasterTO::class.java)
            if (holidayTypeMasterTO != null) {
                holidayTypeMasterList.add(holidayTypeMasterTO)
            }
        }

        searchResponseTO.list = holidayTypeMasterList
        searchResponseTO.pageCount = data.totalPages.toLong()
        searchResponseTO.totalRowCount = data.totalElements
        return searchResponseTO
    }

    override fun getHolidayTypeMasterById(id: Long): HolidayTypeMasterTO? {
        val holidayTypeMasterBO: HolidayTypeMasterBO? = commonDao.findByPrimaryKey(HolidayTypeMasterBO::class.java, id)
        return mapHandler.mapObject(holidayTypeMasterBO, HolidayTypeMasterTO::class.java)
    }


}