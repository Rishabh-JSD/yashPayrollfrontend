package hostbooks.payroll.masters.holiday.typeMaster.validator

import hostbooks.payroll.masters.MasterSearchRequestTO
import hostbooks.payroll.masters.holiday.typeMaster.controller.HolidayTypeMasterController
import hostbooks.payroll.masters.holiday.typeMaster.dto.HolidayTypeMasterTO
import org.springframework.validation.Errors
import org.springframework.validation.Validator
import org.springframework.web.bind.annotation.ControllerAdvice

@ControllerAdvice(assignableTypes = [HolidayTypeMasterController::class])
class HolidayTypeMasterValidator : Validator {

    override fun supports(clazz: Class<*>): Boolean {
        return (clazz == HolidayTypeMasterTO::class.java || clazz == MasterSearchRequestTO::class.java)
    }

    override fun validate(target: Any, errors: Errors) {
        if (target is HolidayTypeMasterTO) {
            // validation logic for MasterTO
        }
    }
}