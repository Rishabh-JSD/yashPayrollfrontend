package hostbooks.payroll.masters.master.controller

import hostbooks.payroll.shared.utility.ValidationError
import hostbooks.payroll.shared.utility.model.ResponseTO
import hostbooks.payroll.shared.utility.model.SearchResponseTO
import hostbooks.payroll.masters.MasterSearchRequestTO
import hostbooks.payroll.masters.master.dto.MasterTO
import hostbooks.payroll.masters.master.service.MasterService
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.validation.Errors
import org.springframework.validation.Validator
import org.springframework.web.bind.WebDataBinder
import org.springframework.web.bind.annotation.*
import javax.validation.Valid

@RestController
@RequestMapping("/master")
class MasterController(private val masterService: MasterService, private val masterValidator: Validator) {

    @InitBinder
    private fun initBinder(binder: WebDataBinder) {
        binder.validator = this.masterValidator
    }

    @RequestMapping(value = ["/add"], method = [RequestMethod.POST])
    fun addMaster(@Valid @RequestBody masterTO: MasterTO, errors: Errors): ResponseEntity<Any> {
        if (errors.hasErrors()) {
            val validationError: ValidationError = ValidationError.fromBindingErrors(errors)
            return ResponseEntity<Any>(validationError, HttpStatus.OK)
        }
        val masterTOReturn: MasterTO = masterService.addMaster(masterTO)
        val responseDTO = ResponseTO.responseBuilder(200, "COM01", "/master", "master", masterTOReturn)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }

    @RequestMapping(value = ["/update"], method = [RequestMethod.POST])
    fun updateMaster(@Valid @RequestBody masterTO: MasterTO, errors: Errors): ResponseEntity<Any> {
        if (errors.hasErrors()) {
            val validationError: ValidationError = ValidationError.fromBindingErrors(errors)
            return ResponseEntity<Any>(validationError, HttpStatus.OK)
        }
        val masterTOReturn: MasterTO = masterService.updateMaster(masterTO)
        val responseDTO = ResponseTO.responseBuilder(200, "COM02", "/master", "master", masterTOReturn)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }

    @RequestMapping(value = ["/delete"], method = [RequestMethod.DELETE])
    fun deleteMaster(@RequestParam(name = "masterId") masterId: List<Long>): ResponseEntity<*>? {
        masterService.deleteMaster(masterId)
        val responseDTO = ResponseTO.responseBuilder(200, "COM05", "/master", "master", masterId)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }


    @RequestMapping(value = ["/list"], method = [RequestMethod.POST])
    fun getMasterList(@RequestBody masterSearchRequestTO: MasterSearchRequestTO): ResponseEntity<*> {
        val responseTO: SearchResponseTO<MasterTO> = masterService.getMasterList(masterSearchRequestTO)
        val response = ResponseTO.responseBuilder(200, "COM11", "/master", "master", responseTO)
        return ResponseEntity<ResponseTO>(response, HttpStatus.OK)
    }
}
