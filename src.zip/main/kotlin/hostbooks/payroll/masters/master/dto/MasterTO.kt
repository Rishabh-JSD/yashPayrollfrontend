package hostbooks.payroll.masters.master.dto

import hostbooks.payroll.shared.utility.model.AuditTO

class MasterTO : AuditTO() {
    var id: Long? = null
    var code: String? = null
    var name: String? = null
    var status: String = "ACTIVE"
}