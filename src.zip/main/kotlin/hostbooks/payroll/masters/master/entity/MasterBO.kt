package hostbooks.payroll.masters.master.entity

import hostbooks.payroll.shared.constant.Tables
import hostbooks.payroll.shared.utility.model.Audit
import jakarta.persistence.*

@Entity
@Table(name = Tables.PAYROLL_MASTER)
class MasterBO : Audit() {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", updatable = false, nullable = false)
    var id: Long? = null

    @Column(name = "code", unique = true, nullable = false)
    var code: String? = null

    @Column(name = "name")
    var name: String? = null

    @Column(name = "status", nullable = false)
    var status: String? = null
}