package hostbooks.payroll.masters.master.service

import hostbooks.payroll.shared.utility.model.SearchResponseTO
import hostbooks.payroll.masters.MasterSearchRequestTO
import hostbooks.payroll.masters.master.dto.MasterTO

interface MasterService {

    fun addMaster(masterTO: MasterTO): MasterTO

    fun updateMaster(masterTO: MasterTO): MasterTO

    fun deleteMaster(masterId: List<Long>)

    fun getMasterList(masterSearchRequestTO: MasterSearchRequestTO): SearchResponseTO<MasterTO>


}