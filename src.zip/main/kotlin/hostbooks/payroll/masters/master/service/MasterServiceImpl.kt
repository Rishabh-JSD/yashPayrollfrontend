package hostbooks.payroll.masters.master.service

import hostbooks.payroll.shared.constant.AppEnum
import hostbooks.payroll.shared.utility.MapHandler
import hostbooks.payroll.shared.utility.model.SearchResponseTO
import hostbooks.payroll.core.commonDao.CommonDao
import hostbooks.payroll.core.dto.FilterInfo
import hostbooks.payroll.core.dto.HbSort
import hostbooks.payroll.masters.MasterSearchRequestTO
import hostbooks.payroll.masters.master.dto.MasterTO
import hostbooks.payroll.masters.master.entity.MasterBO
import jakarta.transaction.Transactional
import org.springframework.data.domain.Page
import org.springframework.data.domain.PageRequest
import org.springframework.data.domain.Pageable
import org.springframework.stereotype.Service
import java.util.*


@Service
@Transactional
open class MasterServiceImpl(
    private val commonDao: CommonDao,
    private val mapHandler: MapHandler
) : MasterService {

    override fun addMaster(masterTO: MasterTO): MasterTO {
        val entity = mapHandler.mapObject(masterTO, MasterBO::class.java)
        val persistedEntity = commonDao.persistWithFlush(entity)
        return mapHandler.mapObject(persistedEntity, MasterTO::class.java) ?: masterTO
    }

    override fun updateMaster(masterTO: MasterTO): MasterTO {
        val entity = mapHandler.mapObject(masterTO, MasterBO::class.java)
        val updatedEntity = commonDao.updateWithFlush(entity)
        return mapHandler.mapObject(updatedEntity, MasterTO::class.java) ?: masterTO
    }

    override fun deleteMaster(masterId: List<Long>) {
        for (id in masterId) {
            val master: MasterBO? = commonDao.findByPrimaryKey(MasterBO::class.java, id)
            if (master != null) {
                master.status = AppEnum.Status.INACTIVE.toString()
            }
            commonDao.merge(master);
        }
    }

    override fun getMasterList(masterSearchRequestTO: MasterSearchRequestTO): SearchResponseTO<MasterTO> {
        val searchResponseTO = SearchResponseTO<MasterTO>()
        val discriminatorMap: WeakHashMap<String, FilterInfo<*>> = WeakHashMap()
        discriminatorMap["status"] = FilterInfo(AppEnum.FilterType.EQ, AppEnum.Status.ACTIVE.toString())
        if (masterSearchRequestTO.searchFor != null) {
            discriminatorMap["code"] = FilterInfo(AppEnum.FilterType.EQ, masterSearchRequestTO.searchFor)
        }
        val sorts: List<HbSort> = listOf(HbSort("name", AppEnum.SortDirection.DESC))
        val pageable: Pageable = PageRequest.of(masterSearchRequestTO.page - 1, masterSearchRequestTO.limit)
        val data: Page<MasterBO> =
            commonDao.listByFilterPagination(MasterBO::class.java, discriminatorMap, pageable, sorts)

        val masterList = ArrayList<MasterTO>()

        data.content.forEach { masterBO ->
            val masterTO: MasterTO? = mapHandler.mapObject(masterBO, MasterTO::class.java)
            if (masterTO != null) {
                masterList.add(masterTO)
            }
        }

        searchResponseTO.list = masterList
        searchResponseTO.pageCount = data.totalPages.toLong()
        searchResponseTO.totalRowCount = data.totalElements
        return searchResponseTO
    }


}