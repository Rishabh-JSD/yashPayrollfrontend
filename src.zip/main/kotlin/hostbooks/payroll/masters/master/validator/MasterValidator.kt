package hostbooks.payroll.masters.master.validator

import hostbooks.payroll.masters.MasterSearchRequestTO
import hostbooks.payroll.masters.master.controller.MasterController
import hostbooks.payroll.masters.master.dto.MasterTO
import org.springframework.validation.Errors
import org.springframework.validation.Validator
import org.springframework.web.bind.annotation.ControllerAdvice

@ControllerAdvice(assignableTypes = [MasterController::class])
class MasterValidator : Validator {

    override fun supports(clazz: Class<*>): Boolean {
        return (clazz == MasterTO::class.java || clazz == MasterSearchRequestTO::class.java)
    }

    override fun validate(target: Any, errors: Errors) {
        if (target is MasterTO) {
            // validation logic for MasterTO
        }
    }
}