package hostbooks.payroll.masters.option.controller

import hostbooks.payroll.masters.MasterSearchRequestTO
import hostbooks.payroll.shared.utility.ValidationError
import hostbooks.payroll.shared.utility.model.ResponseTO
import hostbooks.payroll.shared.utility.model.SearchResponseTO
import hostbooks.payroll.masters.option.dto.MasterOptionTO
import hostbooks.payroll.masters.option.service.MasterOptionService
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.validation.Errors
import org.springframework.validation.Validator
import org.springframework.web.bind.WebDataBinder
import org.springframework.web.bind.annotation.*
import javax.validation.Valid

@CrossOrigin(origins = ["*"], maxAge = 3600)
@RestController
@RequestMapping("/master-option")
class MasterOptionController(
    private val masterOptionService: MasterOptionService,
    private val masterOptionValidator: Validator
) {

    @InitBinder
    private fun initBinder(binder: WebDataBinder) {
        binder.validator = this.masterOptionValidator
    }

    @RequestMapping(value = ["/add"], method = [RequestMethod.POST])
    fun addMasterOption(@Valid @RequestBody masterOptionTO: MasterOptionTO, errors: Errors): ResponseEntity<Any> {
        if (errors.hasErrors()) {
            val validationError: ValidationError = ValidationError.fromBindingErrors(errors)
            return ResponseEntity<Any>(validationError, HttpStatus.OK)
        }
        val masterOptionTOReturn: MasterOptionTO = masterOptionService.addMasterOption(masterOptionTO)
        val responseDTO =
            ResponseTO.responseBuilder(200, "COM01", "/master-option", "masterOption", masterOptionTOReturn)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }

    @RequestMapping(value = ["/update"], method = [RequestMethod.POST])
    fun updateMasterOption(@Valid @RequestBody masterOptionTO: MasterOptionTO, errors: Errors): ResponseEntity<Any> {
        if (errors.hasErrors()) {
            val validationError: ValidationError = ValidationError.fromBindingErrors(errors)
            return ResponseEntity<Any>(validationError, HttpStatus.OK)
        }
        val masterOptionTOReturn: MasterOptionTO = masterOptionService.updateMasterOption(masterOptionTO)
        val responseDTO =
            ResponseTO.responseBuilder(200, "COM02", "/master-option", "masterOption", masterOptionTOReturn)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }


    @RequestMapping(value = ["/delete"], method = [RequestMethod.DELETE])
    fun deleteMasterOptions(@RequestParam(name = "masterOptionId") masterOptionId: List<Long>): ResponseEntity<*>? {
        masterOptionService.deleteMasterOption(masterOptionId)
        val responseDTO = ResponseTO.responseBuilder(200, "COM05", "/master-option", "masterOption", masterOptionId)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }

    @RequestMapping(value = ["/list"], method = [RequestMethod.POST])
    fun getMasterOptionList(@RequestBody masterSearchRequestTO: MasterSearchRequestTO): ResponseEntity<*> {
        val responseTO: SearchResponseTO<MasterOptionTO> = masterOptionService.getMasterOptionList(masterSearchRequestTO)
        val response = ResponseTO.responseBuilder(200, "COM11", "/master-option", "masterOption", responseTO)
        return ResponseEntity<ResponseTO>(response, HttpStatus.OK)
    }

    @RequestMapping(value = ["/{id}"], method = [RequestMethod.GET])
    fun getMasterOptionById(@PathVariable id: Long): ResponseEntity<*> {
        val masterOptionTO: MasterOptionTO? = masterOptionService.getMasterOptionById(id)
        if (masterOptionTO == null) {
            val responseDTO = ResponseTO.responseBuilder(200, "COM03E", "/master-option", "masterOption", null)
            return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
        }
        val responseDTO = ResponseTO.responseBuilder(200, "COM11", "/master-option", "masterOption", masterOptionTO)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }
}