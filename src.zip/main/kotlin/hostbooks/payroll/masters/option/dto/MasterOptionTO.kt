package hostbooks.payroll.masters.option.dto

import hostbooks.payroll.shared.utility.model.AuditTO
import java.util.*

class MasterOptionTO : AuditTO() {
    var id: Long? = null
    var name: String? = null
    var catCode: String = ""
    var reportingToId: Long? = null
    var reportingToName: String? = null
    var description: String? = null
    var parentId: Long? = null
    var parent_cat_option_id: Long? = null
    var startTime: Date? = null
    var endTime: Date? = null
    var shiftTypeName: String? = null
    var workingHours: Double? = null
    var shiftStartTolerance: String? = null
    var shiftEndTolerance: String? = null
    var fixedShiftFlag = false
    var startDay: Long? = null
    var endDay: Long? = null
    var days: Long? = null
    var preDefinedFlag = false
    var levelRefId: Long? = null
    var level: Int? = null
    var maxLevel: Long? = null
    var status: String = "ACTIVE"
    var documentCategoryName: String? = null
    var designationLevel: Long? = null
    var code: String? = null
    var coaId: Int? = null
}