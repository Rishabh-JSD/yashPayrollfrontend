package hostbooks.payroll.masters.option.entity

import hostbooks.payroll.shared.constant.Tables
import hostbooks.payroll.shared.utility.model.Audit
import jakarta.persistence.*
import java.util.*

@Entity
@Table(name = Tables.PAYROLL_MASTER_OPTION)
class MasterOptionBO : Audit() {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", updatable = false, nullable = false)
    var id: Long? = null

    @Column(name = "name")
    var name: String? = null

    @Column(name = "cat_code", nullable = false)
    var catCode: String = ""

    @Column(name = "reporting_to_id")
    var reportingToId: Long? = null

    @Column(name = "description")
    var description: String? = null

    @Column(name = "parent_id")
    var parentId: Long? = null

    @Column(name = "parent_cat_option_id")
    var parentCatOptionId: Long? = null

    @Column(name = "start_time")
    var startTime: Date? = null

    @Column(name = "end_time")
    var endTime: Date? = null

    @Column(name = "working_hours")
    var workingHours: Double? = null

    @Column(name = "shift_start_tolerance")
    var shiftStartTolerance: String? = null

    @Column(name = "shift_end_tolerance")
    var shiftEndTolerance: String? = null

    @Column(name = "fixed_shift_flag")
    var fixedShiftFlag: Boolean = false

    @Column(name = "start_day")
    var startDay: Long? = null

    @Column(name = "end_day")
    var endDay: Long? = null

    @Column(name = "days")
    var days: Long? = null

    @Column(name = "pre_defined_flag")
    var preDefinedFlag: Boolean = false

    @Column(name = "level_ref_id")
    var levelRefId: Long? = null

    @Column(name = "level")
    var level: Long? = null

    @Column(name = "status", nullable = false)
    var status: String? = null

    @Column(name = "code")
    var code: String? = null

    @Column(name = "coa_id")
    var coaId: Int? = null

}