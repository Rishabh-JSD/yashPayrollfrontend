package hostbooks.payroll.masters.option.service

import hostbooks.payroll.masters.MasterSearchRequestTO
import hostbooks.payroll.masters.option.dto.MasterOptionTO
import hostbooks.payroll.shared.utility.model.SearchResponseTO

interface MasterOptionService {

    fun addMasterOption(masterOptionTO: MasterOptionTO): MasterOptionTO

    fun updateMasterOption(masterOptionTO: MasterOptionTO): MasterOptionTO

    fun deleteMasterOption(masterOptionId: List<Long>)

    fun getMasterOptionList(masterSearchRequestTO: MasterSearchRequestTO): SearchResponseTO<MasterOptionTO>

    fun getMasterOptionById(id: Long): MasterOptionTO?

    fun isDuplicatePayFrequency(masterOptionTO: MasterOptionTO, type: String): Boolean

    fun isDuplicateMonthlyPayFrequency(masterOptionTO: MasterOptionTO): Boolean
}