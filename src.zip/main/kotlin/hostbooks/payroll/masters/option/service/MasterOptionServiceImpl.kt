package hostbooks.payroll.masters.option.service

import hostbooks.payroll.core.commonDao.CommonDao
import hostbooks.payroll.core.dto.FilterInfo
import hostbooks.payroll.core.dto.HbSort
import hostbooks.payroll.core.user.service.UserService
import hostbooks.payroll.employee.entity.EmployeeBO
import hostbooks.payroll.masters.MasterSearchRequestTO
import hostbooks.payroll.masters.option.dto.MasterOptionTO
import hostbooks.payroll.masters.option.entity.MasterOptionBO
import hostbooks.payroll.shared.constant.AppConst
import hostbooks.payroll.shared.constant.AppEnum
import hostbooks.payroll.shared.utility.MapHandler
import hostbooks.payroll.shared.utility.model.SearchResponseTO
import jakarta.transaction.Transactional
import org.springframework.data.domain.Page
import org.springframework.data.domain.PageRequest
import org.springframework.stereotype.Service
import java.util.*

@Service
@Transactional
open class MasterOptionServiceImpl(
    private val commonDao: CommonDao,
    private val mapHandler: MapHandler,
    private val userService: UserService,
) : MasterOptionService {

    override fun addMasterOption(masterOptionTO: MasterOptionTO): MasterOptionTO {
        val entity = mapHandler.mapObject(masterOptionTO, MasterOptionBO::class.java)
        val persistedEntity = commonDao.persistWithFlush(entity)
        return mapHandler.mapObject(persistedEntity, MasterOptionTO::class.java) ?: masterOptionTO
    }

    override fun updateMasterOption(masterOptionTO: MasterOptionTO): MasterOptionTO {
        val entity = mapHandler.mapObject(masterOptionTO, MasterOptionBO::class.java)
        val updatedEntity = commonDao.updateWithFlush(entity)
        return mapHandler.mapObject(updatedEntity, MasterOptionTO::class.java) ?: masterOptionTO
    }

    override fun deleteMasterOption(masterOptionId: List<Long>) {
        for (id in masterOptionId) {
            val masterOption: MasterOptionBO? = commonDao.findByPrimaryKey(MasterOptionBO::class.java, id)
            if (masterOption != null) {
                masterOption.status = AppEnum.Status.INACTIVE.toString()
            }
            commonDao.merge(masterOption);
        }
    }

    override fun getMasterOptionList(masterSearchRequestTO: MasterSearchRequestTO): SearchResponseTO<MasterOptionTO> {
        val searchResponseTO = SearchResponseTO<MasterOptionTO>()
        val discriminatorMap = WeakHashMap<String, FilterInfo<*>>()
        discriminatorMap["status"] = FilterInfo(AppEnum.FilterType.EQ, AppEnum.Status.ACTIVE.toString())
        if (masterSearchRequestTO.searchFor != null) {
            discriminatorMap["name"] = FilterInfo(AppEnum.FilterType.LIKE, masterSearchRequestTO.searchFor)
        }
        if (masterSearchRequestTO.catCode != null) {
            discriminatorMap["catCode"] = FilterInfo(AppEnum.FilterType.EQ, masterSearchRequestTO.catCode)
        }

        val sorts = listOf(HbSort("name", AppEnum.SortDirection.DESC))
        val pageable = PageRequest.of(masterSearchRequestTO.page - 1, masterSearchRequestTO.limit)
        val data: Page<MasterOptionBO> =
            commonDao.listByFilterPagination(MasterOptionBO::class.java, discriminatorMap, pageable, sorts)

        val masterOptionList = ArrayList<MasterOptionTO>()
        var maxLevel: Long = 0
        data.content.forEach { masterOptionBO ->
            val masterOptionTO = mapHandler.mapObject(masterOptionBO, MasterOptionTO::class.java)
            if (masterOptionTO != null) {
                if (masterOptionTO.createdBy != null) {
                    masterOptionTO.createdByName = userService.getUserById(masterOptionTO.createdBy!!.toInt())!!.name
                }
                if (masterOptionTO.updatedBy != null) {
                    masterOptionTO.updatedByName = userService.getUserById(masterOptionTO.updatedBy!!.toInt())!!.name
                }
                if(masterOptionTO.reportingToId!=null){
                    masterOptionTO.reportingToName = masterOptionTO.reportingToId?.let { commonDao.selectSinglePropertyByDiscriminator(
                        EmployeeBO::class.java, it, "id", "name", String::class.java)}
                }
                if(masterOptionTO.parentId != null){
                    val parentMasterOption = getMasterOptionById(masterOptionTO.parentId!!)
                    if (parentMasterOption != null) {
                        if (parentMasterOption.catCode == AppConst.MasterOption.SHIFT_TYPE) {
                            masterOptionTO.shiftTypeName = parentMasterOption.name
                        } else if (parentMasterOption.catCode == AppConst.MasterOption.DOCUMENT_CATEGORY) {
                            masterOptionTO.documentCategoryName = parentMasterOption.name
                        }
                    }
                }

                if (masterOptionTO.levelRefId != null) {
                    val levelMasterOption = getMasterOptionById(masterOptionTO.levelRefId!!)
                    if (levelMasterOption != null) {
                        masterOptionTO.designationLevel = levelMasterOption.level?.toLong()
                    }
                }

                if (masterOptionTO.level != null) {
                    masterOptionTO.maxLevel = 0
                    if (masterOptionTO.level!! > maxLevel) {
                        maxLevel = masterOptionTO.level!!.toLong();
                    }
                }
                masterOptionList.add(masterOptionTO)
            }
        }
        masterOptionList.forEach { it.maxLevel = maxLevel }
        searchResponseTO.list = masterOptionList
        searchResponseTO.pageCount = data.totalPages.toLong()
        searchResponseTO.totalRowCount = data.totalElements

        return searchResponseTO
    }


    override fun getMasterOptionById(id: Long): MasterOptionTO? {
        val masterOptionBO: MasterOptionBO? = commonDao.findByPrimaryKey(MasterOptionBO::class.java, id)
        return if (masterOptionBO?.status == "ACTIVE") {
            mapHandler.mapObject(masterOptionBO, MasterOptionTO::class.java)
        } else {
            null
        }
    }

    override fun isDuplicatePayFrequency(masterOptionTO: MasterOptionTO, type: String): Boolean {
        return when (type) {
            "name" -> commonDao.isExistByDiscriminators(MasterOptionBO::class.java, masterOptionTO.name, type)
            else -> false
        }
    }

    override fun isDuplicateMonthlyPayFrequency(masterOptionTO: MasterOptionTO): Boolean {
        val discriminatorMap: WeakHashMap<String, FilterInfo<*>> = WeakHashMap<String, FilterInfo<*>>()
        if(masterOptionTO.id != null){
            discriminatorMap.apply {
                this["startDay"] = FilterInfo(AppEnum.FilterType.EQ, masterOptionTO.startDay)
                this["id"] = FilterInfo(AppEnum.FilterType.NEQ, masterOptionTO.id)
            }
        } else {
                discriminatorMap.apply {
                this["startDay"] = FilterInfo(AppEnum.FilterType.EQ, masterOptionTO.startDay)
            }
        }
        return commonDao.isExistMultiDiscriminatorsSingleVal(MasterOptionBO::class.java, discriminatorMap)
    }
}