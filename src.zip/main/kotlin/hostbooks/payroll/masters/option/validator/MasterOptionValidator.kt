package hostbooks.payroll.masters.option.validator

import hostbooks.payroll.masters.MasterSearchRequestTO
import hostbooks.payroll.masters.option.controller.MasterOptionController
import hostbooks.payroll.masters.option.dto.MasterOptionTO
import hostbooks.payroll.masters.option.service.MasterOptionService
import hostbooks.payroll.shared.constant.AppEnum
import hostbooks.payroll.shared.utility.CommonUtil
import org.springframework.validation.Errors
import org.springframework.validation.Validator
import org.springframework.web.bind.annotation.ControllerAdvice

@ControllerAdvice(assignableTypes = [MasterOptionController::class])

class MasterOptionValidator(private val masterOptionService: MasterOptionService) : Validator {
    override fun supports(clazz: Class<*>): Boolean {
        return (clazz == MasterOptionTO::class.java || clazz == MasterSearchRequestTO::class.java)
    }

    override fun validate(target: Any, errors: Errors) {
        if (target is MasterOptionTO) {
            if (target.id == null) {
                if (CommonUtil.checkNullEmpty(target.name)) {
                    val payFrequencyTypes =
                        arrayListOf(AppEnum.PayFrequencyType.WEEKLY, AppEnum.PayFrequencyType.DAILY).map { it.name }
                            .toSet()
                    if (target.name in payFrequencyTypes) {
                        val isNameExist: Boolean = masterOptionService.isDuplicatePayFrequency(target, "name")
                        if (isNameExist) {
                            errors.rejectValue("name", "field.required", "Duplicate not allowed for pay frequency: ${target.name}"
                            )
                        }
                    }
                }
            }
            if (target.name == AppEnum.PayFrequencyType.MONTHLY.name) {
                val isDuplicateMonthlyPayFrequency: Boolean = masterOptionService.isDuplicateMonthlyPayFrequency(target)
                if (isDuplicateMonthlyPayFrequency) {
                    errors.rejectValue("startDay", "field.required", "Duplicate pay frequency for start day: ${target.startDay}")
                }
            }
        }
    }
}