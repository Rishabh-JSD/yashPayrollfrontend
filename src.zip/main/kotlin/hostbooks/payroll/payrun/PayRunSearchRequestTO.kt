package hostbooks.payroll.payrun

import hostbooks.payroll.shared.utility.model.SearchRequestTO

class PayRunSearchRequestTO: SearchRequestTO() {
}