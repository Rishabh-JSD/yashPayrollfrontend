package hostbooks.payroll.payrun.controller

import hostbooks.payroll.payrun.PayRunSearchRequestTO
import hostbooks.payroll.payrun.dto.PayRunTO
import hostbooks.payroll.payrun.service.PayRunService
import hostbooks.payroll.shared.utility.ValidationError
import hostbooks.payroll.shared.utility.model.ResponseTO
import hostbooks.payroll.shared.utility.model.SearchResponseTO
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.validation.Errors
import org.springframework.validation.Validator
import org.springframework.web.bind.WebDataBinder
import org.springframework.web.bind.annotation.*
import javax.validation.Valid

@RestController
@RequestMapping("/pay-run")
class PayRunController(private val payRunService: PayRunService, private val payRunValidator: Validator) {
    @InitBinder
    private fun initBinder(binder: WebDataBinder) {
        binder.validator = this.payRunValidator
    }

    @PostMapping("/add")
    fun addPayRun(@Valid @RequestBody payRunTO: PayRunTO, errors: Errors): ResponseEntity<*> {
        if (errors.hasErrors()) {
            val validationError: ValidationError = ValidationError.fromBindingErrors(errors)
            return ResponseEntity<Any>(validationError, HttpStatus.BAD_REQUEST)
        }
        val addedPayRunTO: PayRunTO = payRunService.addPayRun(payRunTO)
        val responseDTO = ResponseTO.responseBuilder(201, "COM09", "/pay-run", "payRun", addedPayRunTO)
        return ResponseEntity<Any>(responseDTO, HttpStatus.CREATED)
    }

    @PostMapping("/list")
    fun getPayRunList(@RequestBody payRunSearchRequestTO: PayRunSearchRequestTO): ResponseEntity<*> {
        val responseTO: SearchResponseTO<PayRunTO> = payRunService.getPayRunList(payRunSearchRequestTO)
        val responsePayRunTO = ResponseTO.responseBuilder(200, "COM04", "/pay-run", "payRun", responseTO)
        return ResponseEntity<ResponseTO>(responsePayRunTO, HttpStatus.OK)
    }

    @PutMapping("/update")
    fun updatePayRun(@Valid @RequestBody payRunTO: PayRunTO, errors: Errors): ResponseEntity<*> {
        if (errors.hasErrors()) {
            val validationError: ValidationError = ValidationError.fromBindingErrors(errors)
            return ResponseEntity<Any>(validationError, HttpStatus.OK)
        }
        val addedPayRunTO: PayRunTO =payRunService.updatePayRun(payRunTO)
        val responseLeaveAdjustmentTO = ResponseTO.responseBuilder(200, "COM02", "/pay-run", "payRun", addedPayRunTO)
        return ResponseEntity<Any>(responseLeaveAdjustmentTO, HttpStatus.OK)
    }

    @DeleteMapping("/delete")
    fun deletePayRun(@Valid @RequestParam(name = "payRunIdList") payRunIdList: List<Long>): ResponseEntity<*> {
        payRunService.deletePayRun(payRunIdList)
        val responsePayRunTO = ResponseTO.responseBuilder(200, "COM05", "/pay-run", "payRun", payRunIdList)
        return ResponseEntity<Any>(responsePayRunTO, HttpStatus.OK)
    }

    @GetMapping("/{id}")
    fun getPayRunById(@PathVariable id: Long): ResponseEntity<*> {
        val payRunTO: PayRunTO? = payRunService.getPayRunById(id)
        if (payRunTO == null) {
            val responseDTO = ResponseTO.responseBuilder(200, "COM03E", "/pay-run", "payRun", null)
            return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
        }
        val responseDTO = ResponseTO.responseBuilder(200, "COM11", "/pay-run", "payRun", payRunTO)
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }
}