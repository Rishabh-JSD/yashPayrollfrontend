package hostbooks.payroll.payrun.dto

import java.math.BigDecimal

class PayRunEmployeeLineTO {
    var id: Long? = null
    var payRunId: Long? = null
    var employeeId: Long = 0
    var employeeName: String? = null
    var paidDays: Int = 0
    var lopDays: Int = 0
    var grossPay: BigDecimal = BigDecimal.ZERO
    var deduction: BigDecimal = BigDecimal.ZERO
    var basic: BigDecimal = BigDecimal.ZERO
    var allowances: BigDecimal = BigDecimal.ZERO
    var incomeTax: BigDecimal = BigDecimal.ZERO
    var taxes: BigDecimal = BigDecimal.ZERO
    var addition: BigDecimal = BigDecimal.ZERO
    var reimbursement: BigDecimal = BigDecimal.ZERO
    var adjustment: BigDecimal = BigDecimal.ZERO
    var netPayment: BigDecimal = BigDecimal.ZERO
    var bankTransfer: BigDecimal = BigDecimal.ZERO
    var bankId: String? = null
    var chequePayment: BigDecimal = BigDecimal.ZERO
    var chequeDetails: String? = null
    var chequeBankId: String? = null
    var paymentStatus: String? = null
    var status: String? = null
}