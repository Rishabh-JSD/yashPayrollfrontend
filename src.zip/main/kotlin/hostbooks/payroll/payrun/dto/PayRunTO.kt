package hostbooks.payroll.payrun.dto

import hostbooks.payroll.shared.utility.model.AuditTO
import java.math.BigDecimal
import java.util.*

class PayRunTO: AuditTO() {
    var id: Long? = null
    var payRunRefId: Long?=null
    var year: Int = 0
    var month: Int = 0
    var startDate: Date? = null
    var endDate: Date? = null
    var totalEmployee: Long = 0
    var payrollCost: BigDecimal = BigDecimal.ZERO
    var taxes: BigDecimal = BigDecimal.ZERO
    var netPay: BigDecimal = BigDecimal.ZERO
    var payRunType: String? = null
    var status: String? = null
    var payRunEmployeeLine :List<PayRunEmployeeLineTO> = emptyList()
}