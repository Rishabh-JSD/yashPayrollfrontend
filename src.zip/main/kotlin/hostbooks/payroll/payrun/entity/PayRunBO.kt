package hostbooks.payroll.payrun.entity

import hostbooks.payroll.shared.constant.Tables
import hostbooks.payroll.shared.utility.model.Audit
import jakarta.persistence.*
import java.math.BigDecimal
import java.sql.Date

@Entity
@Table(name = Tables.PAY_RUN)
class PayRunBO: Audit() {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    var id: Long? = null

    @Column(name = "pay_run_ref_id")
    var payRunRefId: Long? =null

    @Column(name = "year", nullable = false)
    var year: Int = 0

    @Column(name = "month", nullable = false)
    var month: Int = 0

    @Column(name = "start_date", nullable = false)
    @Temporal(TemporalType.DATE)
    var startDate: Date? = null

    @Column(name = "end_date", nullable = false)
    @Temporal(TemporalType.DATE)
    var endDate: Date? = null

    @Column(name = "total_employee", nullable = false)
    var totalEmployee: Long = 0

    @Column(name = "payroll_cost", nullable = false)
    var payrollCost: BigDecimal = BigDecimal.ZERO

    @Column(name = "taxes", nullable = false)
    var taxes: BigDecimal = BigDecimal.ZERO

    @Column(name = "net_pay", nullable = false)
    var netPay: BigDecimal = BigDecimal.ZERO

    @Column(name = "pay_run_type", nullable = false)
    var payRunType: String? = null

    @Column(name = "status", nullable = false)
    var status: String? = null

    @OneToMany(cascade = [CascadeType.ALL], orphanRemoval = true)
    @JoinColumn(name = "pay_run_id", referencedColumnName = "id")
    var payRunEmployeeLine:MutableList<PayRunEmployeeLineBO>?=null
}