package hostbooks.payroll.payrun.entity

import hostbooks.payroll.shared.constant.Tables
import jakarta.persistence.*
import java.math.BigDecimal

@Entity
@Table(name = Tables.PAY_RUN_EMPLOYEE_LINE)
class PayRunEmployeeLineBO {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    var id: Long? = null

    @Column(name = "pay_run_id")
    var payRunId: Long? = null

    @Column(name = "employee_id", nullable = false)
    var employeeId: Long = 0

    @Column(name = "employee_name", nullable = false)
    var employeeName: String? = null

    @Column(name = "paid_days", nullable = false)
    var paidDays: Int = 0

    @Column(name = "lop_days", nullable = false)
    var lopDays: Int = 0

    @Column(name = "gross_pay", nullable = false)
    var grossPay: BigDecimal = BigDecimal.ZERO

    @Column(name = "deduction", nullable = false)
    var deduction: BigDecimal = BigDecimal.ZERO

    @Column(name = "basic", nullable = false)
    var basic: BigDecimal = BigDecimal.ZERO

    @Column(name = "allowances", nullable = false)
    var allowances: BigDecimal = BigDecimal.ZERO

    @Column(name = "income_tax", nullable = false)
    var incomeTax: BigDecimal = BigDecimal.ZERO

    @Column(name = "taxes", nullable = false)
    var taxes: BigDecimal = BigDecimal.ZERO

    @Column(name = "addition", nullable = false)
    var addition: BigDecimal = BigDecimal.ZERO

    @Column(name = "reimbursement", nullable = false)
    var reimbursement: BigDecimal = BigDecimal.ZERO

    @Column(name = "adjustment", nullable = false)
    var adjustment: BigDecimal = BigDecimal.ZERO

    @Column(name = "net_payment", nullable = false)
    var netPayment: BigDecimal = BigDecimal.ZERO

    @Column(name = "bank_transfer", nullable = false)
    var bankTransfer: BigDecimal = BigDecimal.ZERO

    @Column(name = "bank_id" )
    var bankId: String? = null

    @Column(name = "cheque_payment")
    var chequePayment: BigDecimal = BigDecimal.ZERO

    @Column(name = "cheque_details")
    var chequeDetails: String? = null

    @Column(name = "cheque_bank_id")
    var chequeBankId: String? = null

    @Column(name = "payment_status", nullable = false)
    var paymentStatus: String? = null

    @Column(name = "status", nullable = false)
    var status: String? = null
}