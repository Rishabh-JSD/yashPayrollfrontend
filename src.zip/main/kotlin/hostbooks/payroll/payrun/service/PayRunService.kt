package hostbooks.payroll.payrun.service

import hostbooks.payroll.payrun.PayRunSearchRequestTO
import hostbooks.payroll.payrun.dto.PayRunTO
import hostbooks.payroll.shared.utility.model.SearchResponseTO

interface PayRunService {

    fun addPayRun(payRunTO: PayRunTO): PayRunTO

    fun getPayRunList(payRunSearchRequestTO: PayRunSearchRequestTO): SearchResponseTO<PayRunTO>

    fun updatePayRun(payRunTO: PayRunTO): PayRunTO

    fun deletePayRun(payRunIdList: List<Long>)

    fun getPayRunById(id: Long): PayRunTO?
}