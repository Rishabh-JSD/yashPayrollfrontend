package hostbooks.payroll.payrun.service

import hostbooks.payroll.core.commonDao.CommonDao
import hostbooks.payroll.core.dto.FilterInfo
import hostbooks.payroll.core.dto.HbSort
import hostbooks.payroll.payrun.PayRunSearchRequestTO
import hostbooks.payroll.payrun.dto.PayRunTO
import hostbooks.payroll.payrun.entity.PayRunBO
import hostbooks.payroll.shared.constant.AppEnum
import hostbooks.payroll.shared.utility.MapHandler
import hostbooks.payroll.shared.utility.model.SearchResponseTO
import jakarta.transaction.Transactional
import org.springframework.data.domain.Page
import org.springframework.data.domain.PageRequest
import org.springframework.data.domain.Pageable
import org.springframework.stereotype.Service
import java.util.*

@Service
@Transactional
open class PayRunServiceImpl(private val commonDao: CommonDao,
                             private val mapHandler: MapHandler
):PayRunService {
    override fun addPayRun(payRunTO: PayRunTO): PayRunTO {
        val entity = mapHandler.mapObject(payRunTO, PayRunBO::class.java)
        val persistedEntity = commonDao.persistWithFlush(entity)
        return mapHandler.mapObject(persistedEntity, PayRunTO::class.java)?: payRunTO
    }

    override fun getPayRunList(payRunSearchRequestTO: PayRunSearchRequestTO): SearchResponseTO<PayRunTO> {
        val searchResponseTO = SearchResponseTO<PayRunTO>()
        val discriminatorMap: WeakHashMap<String, FilterInfo<*>> = WeakHashMap<String, FilterInfo<*>>()
        val pageable: Pageable = PageRequest.of(payRunSearchRequestTO.page - 1, payRunSearchRequestTO.limit)
        val sorts: List<HbSort> = listOf(HbSort("status", AppEnum.SortDirection.DESC))
        val data: Page<PayRunBO> = commonDao.listByFilterPagination(PayRunBO::class.java, discriminatorMap, pageable, sorts)
        searchResponseTO.list = mapHandler.mapObjectList(data.content, PayRunTO::class.java)
        searchResponseTO.pageCount = data.totalPages.toLong()
        searchResponseTO.totalRowCount = data.totalElements
        return searchResponseTO
    }

    override fun updatePayRun(payRunTO: PayRunTO): PayRunTO {
        val entity = mapHandler.mapObject(payRunTO, PayRunBO::class.java)
        val updatedEntity = commonDao.updateWithFlush(entity)
        return mapHandler.mapObject(updatedEntity, PayRunTO::class.java) ?: payRunTO
    }

    override fun deletePayRun(payRunIdList: List<Long>) {
        for (id in payRunIdList) {
            val payRun: PayRunBO? = commonDao.findByPrimaryKey(PayRunBO::class.java, id)
            if (payRun != null) {
                commonDao.deleteWithFlush(payRun)
            }
        }
    }

    override fun getPayRunById(id: Long): PayRunTO? {
        val payRunBO: PayRunBO? = commonDao.findByPrimaryKey(PayRunBO::class.java, id)
        return mapHandler.mapObject(payRunBO, PayRunTO::class.java)
    }
}