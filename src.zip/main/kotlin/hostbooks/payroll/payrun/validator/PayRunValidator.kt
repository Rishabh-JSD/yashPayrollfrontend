package hostbooks.payroll.payrun.validator

import hostbooks.payroll.payrun.PayRunSearchRequestTO
import hostbooks.payroll.payrun.controller.PayRunController
import hostbooks.payroll.payrun.dto.PayRunTO
import hostbooks.payroll.shared.constant.AppEnum
import org.springframework.validation.Errors
import org.springframework.validation.Validator
import org.springframework.web.bind.annotation.ControllerAdvice

@ControllerAdvice(assignableTypes = [PayRunController::class])
class PayRunValidator: Validator {
    override fun supports(clazz: Class<*>): Boolean {
        return (clazz == PayRunTO::class.java || clazz == PayRunSearchRequestTO::class.java)
    }

    override fun validate(target: Any, errors: Errors) {
        if (target is PayRunTO) {
            val validPayRunStatus = AppEnum.PayRunStatus.values().map { it.name }.toSet()
            if (target.status == null) {
                errors.rejectValue("status", "field.required", "Status is required")
            } else if (target.status !in validPayRunStatus) {
                errors.rejectValue("status", "field.invalid", "Invalid PayRun Status")
            }
        }
    }
}