package hostbooks.payroll.reimbursementClaim.controller

import hostbooks.payroll.reimbursementClaim.dto.ReimbursementClaimSearchTO
import hostbooks.payroll.reimbursementClaim.dto.ReimbursementClaimTO
import hostbooks.payroll.reimbursementClaim.service.ReimbursementClaimService
import hostbooks.payroll.shared.utility.ValidationError
import hostbooks.payroll.shared.utility.model.ResponseTO
import hostbooks.payroll.shared.utility.model.SearchResponseTO
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.validation.Errors
import org.springframework.web.bind.annotation.*

@RestController
@RequestMapping("/reimbursement-claim")
class ReimbursementClaimController (private val reimbursementClaimService: ReimbursementClaimService){
    @RequestMapping(value = ["/add"], method = [RequestMethod.POST])
    fun addReimbursementClaim(@RequestBody reimbursementClaimTO: ReimbursementClaimTO, errors: Errors): ResponseEntity<Any> {
        if (errors.hasErrors()) {
            val validationError: ValidationError = ValidationError.fromBindingErrors(errors)
            return ResponseEntity<Any>(validationError, HttpStatus.OK)
        }
        val responseDTO = ResponseTO.responseBuilder(200, "COM01", "/reimbursement-claim", "reimbursementClaim", reimbursementClaimService.addReimbursementClaim(reimbursementClaimTO))
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }

    @RequestMapping(value = ["/update"], method = [RequestMethod.POST])
    fun updateReimbursementClaim(@RequestBody reimbursementClaimTO: ReimbursementClaimTO, errors: Errors): ResponseEntity<Any> {
        if (errors.hasErrors()) {
            val validationError: ValidationError = ValidationError.fromBindingErrors(errors)
            return ResponseEntity<Any>(validationError, HttpStatus.OK)
        }
        val responseDTO = ResponseTO.responseBuilder(200, "COM02", "/reimbursement-claim", "reimbursementClaim",  reimbursementClaimService.updateReimbursementClaim(reimbursementClaimTO))
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }


    @RequestMapping(value = ["/delete"], method = [RequestMethod.DELETE])
    fun deleteReimbursementClaims(@RequestParam(name = "ReimbursementClaimId") reimbursementClaimId: Long): ResponseEntity<*>? {
        val responseDTO = ResponseTO.responseBuilder(200, "COM05", "/reimbursement-claim", "reimbursementClaim", reimbursementClaimService.deleteReimbursementClaim(reimbursementClaimId))
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }

    @RequestMapping(value = ["/{id}"], method = [RequestMethod.GET])
    fun getReimbursementClaimById(@PathVariable(name = "id") reimbursementClaimId: Long): ResponseEntity<*>? {
        val responseDTO = ResponseTO.responseBuilder(200, "COM11", "/reimbursement-claim", "reimbursementClaim", reimbursementClaimService.getReimbursementClaim(reimbursementClaimId))
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }

    @RequestMapping(value = ["/list"], method = [RequestMethod.POST])
    fun getReimbursementClaimList(@RequestBody reimbursementClaimSearchTO: ReimbursementClaimSearchTO): ResponseEntity<*> {
        val responseTO: SearchResponseTO<ReimbursementClaimTO> = reimbursementClaimService.getReimbursementClaimList(reimbursementClaimSearchTO)
        val response = ResponseTO.responseBuilder(200, "COM11", "/reimbursement-claim", "reimbursementClaim", responseTO)
        return ResponseEntity<ResponseTO>(response, HttpStatus.OK)
    }
}