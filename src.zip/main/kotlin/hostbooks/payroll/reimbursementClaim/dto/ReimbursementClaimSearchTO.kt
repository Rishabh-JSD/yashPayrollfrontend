package hostbooks.payroll.reimbursementClaim.dto

import hostbooks.payroll.shared.utility.model.SearchRequestTO

class ReimbursementClaimSearchTO:SearchRequestTO() {
    var searchFor: String? = null
    var status: String? = null
}