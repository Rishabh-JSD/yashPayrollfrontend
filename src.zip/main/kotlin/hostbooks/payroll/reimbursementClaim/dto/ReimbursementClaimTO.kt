package hostbooks.payroll.reimbursementClaim.dto

import java.util.*

class ReimbursementClaimTO {
    var id: Long? = null

    var employeeId: Int? = null

    var claimNumber: String? = null

    var displayStyle: Int? = null

    var currentNumber: String? = null

    var claimDate: Date? = null

    var status: String? = null

    var amount: Int ? = null

    var branchId:Int? = null

    var reimbursements:List<ReimbursementsTO>?= mutableListOf();
}