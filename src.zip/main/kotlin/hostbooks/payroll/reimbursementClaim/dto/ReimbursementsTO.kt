package hostbooks.payroll.reimbursementClaim.dto

import java.util.*

class ReimbursementsTO {

    var id: Long? = null

    var reimbursementClaimId: Int? = null

    var reimbursementMasterId:Int?=null;

    var description : String? = null

    var date: Date? = null

    var amount: Int? = null

    var approvedAmount: Int? = null

    var rejectedAmount: Date? = null

}