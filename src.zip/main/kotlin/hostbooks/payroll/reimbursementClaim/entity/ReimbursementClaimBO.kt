package hostbooks.payroll.reimbursementClaim.entity

import hostbooks.payroll.ruleMaster.entity.RuleMasterOptionBO
import hostbooks.payroll.shared.constant.Tables
import hostbooks.payroll.shared.utility.model.Audit
import jakarta.persistence.*
import java.util.*

@Entity
@Table(name = Tables.REIMBURSEMENT_CLAIM)
class ReimbursementClaimBO : Audit() {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    var id: Long? = null

    @Column(name = "branch_id")
    var branchId: Int? = null

    @Column(name = "employee_id")
    var employeeId: Int? = null

    @Column(name = "claim_number")
    var claimNumber: String? = null

    @Column(name = "display_style")
    var displayStyle: Int? = null

    @Column(name = "current_number")
    var currentNumber: String? = null

    @Column(name = "claim_date")
    var claimDate: Date? = null

    @Column(name = "status")
    var status: String? = null

    @OneToMany(cascade = [CascadeType.ALL], orphanRemoval = true)
    @JoinColumn(name = "reimbursement_claim_id", referencedColumnName = "id")
    var reimbursements:List<ReimbursementsBO>?= mutableListOf();

}