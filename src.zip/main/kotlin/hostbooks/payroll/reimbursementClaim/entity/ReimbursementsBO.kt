package hostbooks.payroll.reimbursementClaim.entity

import hostbooks.payroll.shared.constant.Tables
import hostbooks.payroll.shared.utility.model.Audit
import jakarta.persistence.*
import java.util.*

@Entity
@Table(name = Tables.REIMBURSEMENTS)
class ReimbursementsBO:Audit() {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    var id: Long? = null

    @Column(name = "reimbursement_claim_id")
    var reimbursementClaimId: Int? = null

    @Column(name = "reimbursement_master_id")
    var  reimbursementMasterId: Int? = null

    @Column(name = "description")
    var description: String? = null

    @Column(name = "date")
    var date: Date? = null

    @Column(name = "amount")
    var amount: Int? = null

    @Column(name = "approved_amount")
    var approvedAmount: Int? = null

    @Column(name = "rejected_amount")
    var rejectedAmount: Date? = null

}