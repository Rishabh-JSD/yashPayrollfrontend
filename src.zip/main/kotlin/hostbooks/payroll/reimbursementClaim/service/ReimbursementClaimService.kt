package hostbooks.payroll.reimbursementClaim.service

import hostbooks.payroll.reimbursementClaim.dto.ReimbursementClaimSearchTO
import hostbooks.payroll.reimbursementClaim.dto.ReimbursementClaimTO
import hostbooks.payroll.shared.utility.model.SearchResponseTO

interface ReimbursementClaimService {

    fun addReimbursementClaim(reimbursementClaimTO: ReimbursementClaimTO): ReimbursementClaimTO?

    fun updateReimbursementClaim(reimbursementClaimTO: ReimbursementClaimTO): ReimbursementClaimTO?

    fun deleteReimbursementClaim(reimbursementClaimId: Long): ReimbursementClaimTO?

    fun getReimbursementClaimList(reimbursementClaimSearchTO: ReimbursementClaimSearchTO): SearchResponseTO<ReimbursementClaimTO>;

    fun getReimbursementClaim(reimbursementClaimId: Long): ReimbursementClaimTO?;

}