package hostbooks.payroll.reimbursementClaim.service

import hostbooks.payroll.core.commonDao.CommonDao
import hostbooks.payroll.core.dto.FilterInfo
import hostbooks.payroll.core.dto.HbSort
import hostbooks.payroll.employee.dto.EmployeeTO
import hostbooks.payroll.employee.entity.EmployeeBO
import hostbooks.payroll.reimbursementClaim.dto.ReimbursementClaimSearchTO
import hostbooks.payroll.reimbursementClaim.dto.ReimbursementClaimTO
import hostbooks.payroll.reimbursementClaim.entity.ReimbursementClaimBO
import hostbooks.payroll.shared.constant.AppEnum
import hostbooks.payroll.shared.utility.CommonUtil
import hostbooks.payroll.shared.utility.MapHandler
import hostbooks.payroll.shared.utility.model.CommonListTO
import hostbooks.payroll.shared.utility.model.SearchResponseTO
import jakarta.transaction.Transactional
import org.springframework.data.domain.Page
import org.springframework.data.domain.PageRequest
import org.springframework.data.domain.Pageable
import org.springframework.stereotype.Service
import java.util.*

@Service
@Transactional
open class ReimbursementClaimServiceImpl(
    private val commonDao: CommonDao,
    private val mapHandler: MapHandler

):ReimbursementClaimService{
    override fun addReimbursementClaim(reimbursementClaimTO: ReimbursementClaimTO): ReimbursementClaimTO? {
       val reimbursementClaim:ReimbursementClaimBO? = commonDao.persist(mapHandler.mapObject(reimbursementClaimTO,ReimbursementClaimBO::class.java));
        return mapHandler.mapObject(reimbursementClaim,ReimbursementClaimTO::class.java);
    }

    override fun updateReimbursementClaim(reimbursementClaimTO: ReimbursementClaimTO): ReimbursementClaimTO? {
        val reimbursementClaim:ReimbursementClaimBO? = commonDao.merge(mapHandler.mapObject(reimbursementClaimTO,ReimbursementClaimBO::class.java));
        return mapHandler.mapObject(reimbursementClaim,ReimbursementClaimTO::class.java);
    }

    override fun deleteReimbursementClaim(reimbursementClaimId: Long): ReimbursementClaimTO? {
        TODO("Not yet implemented")
    }

    override fun getReimbursementClaimList(reimbursementClaimSearchTO: ReimbursementClaimSearchTO): SearchResponseTO<ReimbursementClaimTO> {
        var searchResponseTO = SearchResponseTO<ReimbursementClaimTO>()
        val discriminatorMap: WeakHashMap<String, FilterInfo<*>> = WeakHashMap<String, FilterInfo<*>>()
        discriminatorMap["status"] = FilterInfo(AppEnum.FilterType.EQ, reimbursementClaimSearchTO.status);
        val commonListTO: CommonListTO<ReimbursementClaimTO> = CommonListTO<ReimbursementClaimTO>()
        if (reimbursementClaimSearchTO.searchFor != null) {
            discriminatorMap["employee_id"] = FilterInfo(AppEnum.FilterType.LIKE, reimbursementClaimSearchTO.searchFor)
        }
        val pageable: Pageable = PageRequest.of(reimbursementClaimSearchTO.page - 1, reimbursementClaimSearchTO.limit)
        val sorts: List<HbSort> = listOf<HbSort>(HbSort("id", AppEnum.SortDirection.DESC))
        val data: Page<ReimbursementClaimBO> = commonDao.listByFilterPagination(ReimbursementClaimBO::class.java, discriminatorMap, pageable, sorts);
        commonListTO.dataList = mapHandler.mapObjectList(data.content, ReimbursementClaimTO::class.java)
        commonListTO.totalRow = data.totalElements
        commonListTO.pageCount = data.totalPages.toLong()
        val reimbursementClaimList: MutableList<ReimbursementClaimTO> = ArrayList();
        if (commonListTO.dataList != null && commonListTO.dataList!!.isNotEmpty()) {
            for (reimbursementClaim in commonListTO.dataList!!) {
                if(CommonUtil.checkNullEmpty(reimbursementClaim)){
                    if(CommonUtil.checkNullEmpty(reimbursementClaim.reimbursements)){
                        for (reimbursements in reimbursementClaim.reimbursements!!){
                            reimbursementClaim.amount = reimbursementClaim.amount?.plus(reimbursements.amount!!)
                        }
                    }
                    reimbursementClaimList.add(reimbursementClaim);
                }
            }
        }
        searchResponseTO.list = reimbursementClaimList;
        searchResponseTO.pageCount = commonListTO.pageCount!!
        searchResponseTO.totalRowCount = (commonListTO.totalRow ?: return searchResponseTO);
        return searchResponseTO;
    }

    override fun getReimbursementClaim(reimbursementClaimId: Long): ReimbursementClaimTO? {
       val reimbursementClaimTO: ReimbursementClaimTO? = mapHandler.mapObject(commonDao.findByPrimaryKey(ReimbursementClaimBO::class.java,reimbursementClaimId),ReimbursementClaimTO::class.java);
        return reimbursementClaimTO;
    }

}