package hostbooks.payroll.ruleMaster.controller

import hostbooks.payroll.masters.MasterSearchRequestTO
import hostbooks.payroll.ruleMaster.dto.RuleMasterTO
import hostbooks.payroll.ruleMaster.service.RuleMasterService
import hostbooks.payroll.shared.utility.ValidationError
import hostbooks.payroll.shared.utility.model.ResponseTO
import hostbooks.payroll.shared.utility.model.SearchResponseTO
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.validation.Errors
import org.springframework.web.bind.annotation.*

@RestController
@RequestMapping("/rule-master")
class RuleMasterController(private val ruleMasterService: RuleMasterService) {
    @RequestMapping(value = ["/add"], method = [RequestMethod.POST])
    fun addRuleMaster( @RequestBody ruleMasterTO: RuleMasterTO, errors: Errors): ResponseEntity<Any> {
        if (errors.hasErrors()) {
            val validationError: ValidationError = ValidationError.fromBindingErrors(errors)
            return ResponseEntity<Any>(validationError, HttpStatus.OK)
        }
        val responseDTO = ResponseTO.responseBuilder(200, "COM01", "/master-option", "ruleMaster", ruleMasterService.addRuleMaster(ruleMasterTO))
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }

    @RequestMapping(value = ["/update"], method = [RequestMethod.POST])
    fun updateRuleMaster( @RequestBody ruleMasterTO: RuleMasterTO, errors: Errors): ResponseEntity<Any> {
        if (errors.hasErrors()) {
            val validationError: ValidationError = ValidationError.fromBindingErrors(errors)
            return ResponseEntity<Any>(validationError, HttpStatus.OK)
        }
        val responseDTO = ResponseTO.responseBuilder(200, "COM02", "/master-option", "ruleMaster",  ruleMasterService.updateRuleMaster(ruleMasterTO))
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }


    @RequestMapping(value = ["/delete"], method = [RequestMethod.DELETE])
    fun deleteRuleMasters(@RequestParam(name = "ruleMasterId") ruleMasterId: Long): ResponseEntity<*>? {
        val responseDTO = ResponseTO.responseBuilder(200, "COM05", "/master-option", "ruleMaster", ruleMasterService.deleteRuleMaster(ruleMasterId))
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }

    @RequestMapping(value = ["/{id}"], method = [RequestMethod.GET])
    fun getRuleMasterById(@PathVariable(name = "id") ruleMasterId: Long): ResponseEntity<*>? {
        val responseDTO = ResponseTO.responseBuilder(200, "COM05", "/master-option", "ruleMaster", ruleMasterService.getRuleMaster(ruleMasterId))
        return ResponseEntity<Any>(responseDTO, HttpStatus.OK)
    }

    @RequestMapping(value = ["/list"], method = [RequestMethod.POST])
    fun getRuleMasterList(@RequestBody masterSearchRequestTO: MasterSearchRequestTO): ResponseEntity<*> {
        val responseTO: SearchResponseTO<RuleMasterTO> = ruleMasterService.getRuleMasterList(masterSearchRequestTO)
        val response = ResponseTO.responseBuilder(200, "COM11", "/master-option", "ruleMaster", responseTO)
        return ResponseEntity<ResponseTO>(response, HttpStatus.OK)
    }

}