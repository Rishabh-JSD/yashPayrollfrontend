package hostbooks.payroll.ruleMaster.dto

import hostbooks.payroll.shared.utility.model.AuditTO
import jakarta.persistence.Column

class RuleMasterOptionTO:AuditTO() {
    var id: Long? = null

    var ruleMasterId: Int? = null

    var allowanceId: Int? = null

    var percentageOfSalary: Double? = null

    var amount: Double? = null
}