package hostbooks.payroll.ruleMaster.dto

import hostbooks.payroll.shared.utility.model.AuditTO

class RuleMasterTO:AuditTO() {

    var id: Long? = null

    var ruleName: String? = null

    var basicSalary: Double = 0.000000

    var type: String? = null

    var ruleMasterOptions:List<RuleMasterOptionTO>? = null
}