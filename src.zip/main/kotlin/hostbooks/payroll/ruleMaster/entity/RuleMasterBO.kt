package hostbooks.payroll.ruleMaster.entity

import hostbooks.payroll.shared.constant.Tables
import hostbooks.payroll.shared.utility.model.Audit
import jakarta.persistence.*

@Entity
@Table(name = Tables.RULE_MASTER)
class RuleMasterBO:Audit(){
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", updatable = false, nullable = false)
    var id: Long? = null

    @Column(name = "rule_name")
    var ruleName: String? = null

    @Column(name = "basic_salary")
    var basicSalary: Double?= null

    @Column(name = "type")
    var type: String? = null

    @OneToMany(cascade = [CascadeType.ALL], orphanRemoval = true)
    @JoinColumn(name = "rule_master_id", referencedColumnName = "id")
    var ruleMasterOptions:List<RuleMasterOptionBO>?= mutableListOf();
}