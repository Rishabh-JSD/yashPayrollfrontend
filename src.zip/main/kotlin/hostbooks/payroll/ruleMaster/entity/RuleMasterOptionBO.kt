package hostbooks.payroll.ruleMaster.entity

import hostbooks.payroll.shared.constant.Tables
import jakarta.persistence.*

@Entity
@Table(name = Tables.RULE_MASTER_OPTION)
class RuleMasterOptionBO {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", updatable = false, nullable = false)
    var id: Long? = null

    @Column(name = "rule_master_id")
    var ruleMasterId: Int? = null

    @Column(name = "allowance_deduction_id")
    var allowanceId: Int? = null

    @Column(name = "percentage")
    var percentageOfSalary: Double? = null

    @Column(name = "amount")
    var amount: Double? = null
}