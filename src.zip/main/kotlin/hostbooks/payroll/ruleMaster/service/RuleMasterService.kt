package hostbooks.payroll.ruleMaster.service

import hostbooks.payroll.masters.MasterSearchRequestTO
import hostbooks.payroll.ruleMaster.dto.RuleMasterTO
import hostbooks.payroll.shared.utility.model.SearchResponseTO

interface RuleMasterService {
    fun addRuleMaster(ruleMasterTO: RuleMasterTO): RuleMasterTO?

    fun updateRuleMaster(ruleMasterTO: RuleMasterTO): RuleMasterTO?

    fun deleteRuleMaster(ruleMasterId: Long):RuleMasterTO?

    fun getRuleMasterList(masterSearchRequestTO: MasterSearchRequestTO): SearchResponseTO<RuleMasterTO>;

    fun getRuleMaster(ruleMasterId: Long):RuleMasterTO?;


}