package hostbooks.payroll.ruleMaster.service

import hostbooks.payroll.core.commonDao.CommonDao
import hostbooks.payroll.core.dto.FilterInfo
import hostbooks.payroll.core.dto.HbSort
import hostbooks.payroll.masters.MasterSearchRequestTO
import hostbooks.payroll.ruleMaster.dto.RuleMasterTO
import hostbooks.payroll.ruleMaster.entity.RuleMasterBO
import hostbooks.payroll.shared.constant.AppEnum
import hostbooks.payroll.shared.utility.MapHandler
import hostbooks.payroll.shared.utility.model.SearchResponseTO
import jakarta.transaction.Transactional
import org.springframework.data.domain.Page
import org.springframework.data.domain.PageRequest
import org.springframework.data.domain.Pageable
import org.springframework.stereotype.Service
import java.util.*

@Service
@Transactional
open class RuleMasterServiceImpl(
    private val commonDao: CommonDao,
    private val mapHandler: MapHandler)
    :RuleMasterService{
    override fun addRuleMaster(ruleMasterTO: RuleMasterTO): RuleMasterTO? {
         val ruleMaster :RuleMasterBO? = commonDao.persist(mapHandler.mapObject(ruleMasterTO,RuleMasterBO::class.java))
        return mapHandler.mapObject(ruleMaster,RuleMasterTO::class.java);
    }

    override fun updateRuleMaster(ruleMasterTO: RuleMasterTO): RuleMasterTO? {
        val ruleMaster :RuleMasterBO? = commonDao.merge(mapHandler.mapObject(ruleMasterTO,RuleMasterBO::class.java))
        return mapHandler.mapObject(ruleMaster,RuleMasterTO::class.java);
    }

    override fun deleteRuleMaster(ruleMasterId: Long): RuleMasterTO? {
        val ruleMaster :RuleMasterBO? =  commonDao.selectSingleByDiscriminator(RuleMasterBO::class.java,ruleMasterId,"id");
        val ruleMaster_return :RuleMasterBO? =  commonDao.delete(ruleMaster);
        return mapHandler.mapObject(ruleMaster_return,RuleMasterTO::class.java);
    }

    override fun getRuleMasterList(masterSearchRequestTO: MasterSearchRequestTO): SearchResponseTO<RuleMasterTO> {
        val searchResponseTO = SearchResponseTO<RuleMasterTO>()
        val discriminatorMap: WeakHashMap<String, FilterInfo<*>> = WeakHashMap()
        discriminatorMap["ruleName"] = FilterInfo(AppEnum.FilterType.LIKE, masterSearchRequestTO.searchFor);
        discriminatorMap["type"] = FilterInfo(AppEnum.FilterType.EQ, masterSearchRequestTO.type);
        val sorts: List<HbSort> = listOf(HbSort("id", AppEnum.SortDirection.DESC))
        val pageable: Pageable = PageRequest.of(masterSearchRequestTO.page - 1, masterSearchRequestTO.limit)
        val data: Page<RuleMasterBO> = commonDao.listByFilterPagination(RuleMasterBO::class.java, discriminatorMap, pageable, sorts)
        val ruleMasterList = ArrayList<RuleMasterTO>()

        data.content.forEach { ruleMasterBO ->
            val ruleMaster: RuleMasterTO? = mapHandler.mapObject(ruleMasterBO, RuleMasterTO::class.java)
            if (ruleMaster != null) {
                ruleMasterList.add(ruleMaster)
            }
        }
        searchResponseTO.list = ruleMasterList
        searchResponseTO.pageCount = data.totalPages.toLong()
        searchResponseTO.totalRowCount = data.totalElements
        return searchResponseTO
    }

    override fun getRuleMaster(ruleMasterId: Long):RuleMasterTO? {
        val ruleMaster :RuleMasterBO? =  commonDao.selectSingleByDiscriminator(RuleMasterBO::class.java,ruleMasterId,"id");
        return mapHandler.mapObject(ruleMaster,RuleMasterTO::class.java)
    }
}