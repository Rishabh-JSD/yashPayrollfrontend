package hostbooks.payroll.shared.constant

object AppConst {
    const val NULL_STRING = "null"
    const val NA_STRING = "NA"

    object MasterOption {
        const val ALLOWANCE: String = "ALW"
        const val DEDUCTION: String = "DED"
        const val REIMBURSEMENT: String = "REIM"
        const val PAY_FREQUENCY: String = "PAYF"
        const val DESIGNATION: String = "DES"
        const val EMPLOYEE_STATUS: String = "EMPS"
        const val EMPLOYEE_TYPE: String = "EMPT"
        const val EMPLOYEE_LEVEL: String = "EMPL"
        const val SHIFT_TYPE: String = "SHIFTTYPE"
        const val SHIFT_TIMING: String = "SHIFTTIME"
        const val DOCUMENT_TYPE: String = "DOCTYPE"
        const val DOCUMENT_CATEGORY: String = "DOCCAT"
    }

    object AutoCompleteType {
        const val MASTER_OPTION: String = "MASTER_OPTION"
        const val PINCODE: String = "PINCODE"
        const val COUNTRY: String = "COUNTRY"
        const val CITY: String = "CITY"
        const val STATE: String = "STATE"
        const val BRANCH: String = "BRANCH"
        const val COST_CENTER: String = "COST_CENTER"
        const val DEPARTMENT: String = "DEPARTMENT"
        const val FIXED_MASTERS: String = "FIXED_MASTERS"
        const val EMPLOYEE: String = "EMPLOYEE"
        const val INDUSTRY: String = "INDUSTRY"
        const val DISPLAY_STYLE: String = "DISPLAY_STYLE"
        const val LEAVE_TYPE: String = "LEAVE_TYPE"
        const val HOLIDAY_TYPE: String = "HOLIDAY_TYPE"
    }

    object ModuleCode{
        const val Employee: String = "EMP"
        const val Reimburisement_Claim="RECLAIM"
    }

    object AttendanceStatus{
        const val DRAFT: String = "EADT"
        const val APPROVED: String = "EAAP"
        const val SUBMIT_FOR_APPROVAL: String = "EAPN"
    }
}



