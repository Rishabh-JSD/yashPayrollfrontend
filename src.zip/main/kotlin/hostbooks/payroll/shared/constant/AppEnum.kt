package hostbooks.payroll.shared.constant

class AppEnum {
    enum class FilterType {
        EQ, IN, OR, LIKE, NEQ, GT, LT, GEQ, LEQ, BW, NN, NIN ,FIS, AND, BETWEEN
    }

    enum class SortDirection {
        ASC, DESC
    }

    enum class ActionType {
        Create, Update, List, View, Delete, Other
    }

    enum class EffectType {
        Allow, Deny
    }

    enum class ApprovalType {
        All, AnyOf
    }

    enum class ApprovalAmountType {
        OverAndEqual, Under, Between, AnyAmount
    }

    enum class ApprovalRqType {
        Any, Allow, Deny
    }

    enum class LeaveAdjustmentType {
        ADJ, OPENING
    }

    enum class LeaveQuantityType {
        INC, DEC
    }

    enum class Status {
        ACTIVE, INACTIVE, SUSPENDED
    }

    enum class PayRunStatus {
        PRDT, PRSA, PRAP, PRPC, PRRP, PRVD, PRDL
    }

    enum class LeaveOrAttendanceType {
        LT, AT
    }

    enum class PayFrequencyType {
        WEEKLY, DAILY, MONTHLY
    }
}