package hostbooks.payroll.shared.constant

object AppMsg {
    const val HELP = "support@hostbooks.com"

    val RESPONSE = mapOf(
        "GL001" to "UNAUTHORIZED Request",
        /* Auth module responses */
        "AUTH01" to "Logged in successfully",
        "AUTH02" to "Password changed.",
        /* Common responses */
        "COM01" to "Created successfully",
        "COM02" to "Updated successfully",
        "COM03" to "Get successfully",
        "COM04" to "Listed successfully",
        "COM05" to "Deleted successfully",
        "COM06" to "Voided successfully",
        "COM07" to "Archived successfully",
        "COM08" to "Restored successfully",
        "COM09" to "Added successfully",
        "COM10" to "Removed successfully",
        "COM11" to "Fetched successfully",
        "COM12" to "Migrated successfully",
        "COM13" to "Processed successfully",
        "COM14" to "Validation In Progress",
        "COM15" to "In Progress",
        "COM16" to "Linked successfully",
        "COM17" to "Deactivated successfully",
        "COM18" to "Cannot delete, Already in use!",
        "COM01E" to "Invalid Request",
        "COM02E" to "Already Used",
        "COM03E" to "Not Found",
        "COM04E" to "Duplicate",
        "COM05E" to "Invalid",
        "COM06E" to "Required",
        "COM07E" to "Less or Equal than last To",
        "COM08E" to "Less than From",
        "COM09E" to "Less or Equal than last Change Date",
        "COM10E" to "Less than Applicable Date",
        "COM11E" to "Lot No Already Used",
        "COM12E" to "Import Already In process",
        "COM13E" to "Captcha Not Found",
        "COM14E" to "Captcha Not Valid",
        "COM15E" to "Verification Already In Process",
        "COM16E" to "No Contact Found For Verification",
        "COM17E" to "Already In Process",
        "COM18E" to "This API is not applicable for this business because Inventory Module is not activated.",
        "COM19E" to "No Need",
        "COM20E" to "In Use",
        "COM21E" to "Comment Required",
        "COM22E" to "Number Already Exist",
        "COM23E" to "Physical Stock verification",
        "COM24E" to "RFQ Number Already Exist",
        "COM25E" to "You are not Authorized",
        "COM26E" to "Password Mismatched"
    )
}