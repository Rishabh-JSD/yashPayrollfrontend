package hostbooks.payroll.shared.utility

import com.fasterxml.jackson.annotation.JsonInclude
import com.fasterxml.jackson.databind.ObjectMapper
import hostbooks.payroll.core.dto.ResponsePaginationTO
import hostbooks.payroll.shared.constant.AppConst
import org.springframework.data.domain.Page
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.pow
import kotlin.math.roundToInt

class CommonUtil {
    companion object {
        private const val ALPHA_STRING = "abcdefghijklmnopqrstuvwxyz123456789"

        fun getJdbcUrl(dbName: String, host: String?, port: String?): String {
            return "jdbc:mysql://" + host + ":" + port + "/" + (dbName.ifEmpty { "" }) + "?useUnicode=true&characterEncoding=UTF-8&useSSL=false&allowPublicKeyRetrieval=true  "
        }

        fun mathRound(decimal: Double): Double {
            val decimalPoint = 2
            return (decimal * 10.0.pow(decimalPoint.toDouble())).roundToInt() / 10.0.pow(decimalPoint.toDouble())
        }

        fun checkNullEmpty(resultList: List<*>?): Boolean {
            return resultList != null && resultList.isNotEmpty()
        }

        fun checkNullEmpty(value: String?): Boolean {
            return !value.isNullOrEmpty() && value != AppConst.NULL_STRING
        }

        fun checkNullEmptyAndNA(value: String?): Boolean {
            return !value.isNullOrEmpty() && value != AppConst.NULL_STRING && value != AppConst.NA_STRING
        }

        fun checkNullEmpty(obj: Any?): Boolean {
            return obj != null && obj.toString().isNotEmpty()
        }

        fun checkNullEmpty(obj: Boolean?): Boolean {
            return obj != null && obj
        }

        fun checkNullEmpty(obj: StringBuilder?): Boolean {
            return !obj.isNullOrEmpty()
        }

        fun checkNullEmpty(`val`: Int): Boolean {
            return `val` != 0
        }

        fun objectToJson(jsonObject: Any?): String? {
            val Obj = ObjectMapper()
            Obj.setSerializationInclusion(JsonInclude.Include.NON_NULL)
            Obj.setSerializationInclusion(JsonInclude.Include.NON_EMPTY)
            try {
                return Obj.writeValueAsString(jsonObject)
            } catch (ex: Exception) {
                ex.printStackTrace()
            }
            return ""
        }

        fun isValid(value: String?): Boolean {
            return !value.isNullOrEmpty() && value != AppConst.NULL_STRING
        }

        fun <T> isValid(value: List<T>?): Boolean {
            return !value.isNullOrEmpty()
        }

        fun generateRandomString(length: Int, clientName: String?): String {
            val charset = ('a'..'z') + ('A'..'Z') + ('0'..'9')
            val generatedString = (1..length).map { charset.random() }.joinToString("")
            return if (clientName != null) {
                clientName.replace(" ".toRegex(), "").substring(0, 2).lowercase(Locale.getDefault()) + generatedString
            } else generatedString
        }

        fun <T, E> mapPagination(
            response: Page<E>,
            mapHandler: MapHandler,
            objClass: Class<T>
        ): ResponsePaginationTO<T> {
            return ResponsePaginationTO(
                response.totalPages,
                response.totalElements.toInt(),
                mapHandler.mapObjectList(response.content, objClass)
            )
        }

        fun randomAlphaNumeric(count: Int): String {
            var count1 = count
            val builder = java.lang.StringBuilder()
            while (count1-- != 0) {
                val character: Int = (Math.random() * ALPHA_STRING.length).toInt()
                builder.append(ALPHA_STRING[character])
            }
            return builder.toString()
        }

        fun <T> getSingleResult(resultList: List<T>): T? {
            return if (checkNullEmpty(resultList)) {
                resultList[0]
            } else null
        }
        fun formatDateToString(date: Date): String {
            val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
            return sdf.format(date)
        }

    }
}