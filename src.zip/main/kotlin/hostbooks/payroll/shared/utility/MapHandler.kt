package hostbooks.payroll.shared.utility

import org.modelmapper.ModelMapper
import org.springframework.stereotype.Service

@Service
class MapHandler(private val modelMapper: ModelMapper) {

    fun <D, T> mapObject(entity: T, outClass: Class<D>): D? {
        return if (entity != null) {
            this.modelMapper.map(entity, outClass)
        } else null
    }

    fun <D, T> mapObjectList(entityList: List<T>?, outCLass: Class<D>): List<D>? {
        var objectTOList: MutableList<D>? = null
        if (CommonUtil.isValid(entityList)) {
            objectTOList = ArrayList()
            if (entityList != null) {
                for (entityListObject in entityList) {
                    mapObject(entityListObject, outCLass)?.let { objectTOList.add(it) }
                }
            }
        }
        return objectTOList
    }
}