package hostbooks.payroll.shared.utility

import hostbooks.payroll.core.user.dto.UserTO
import org.apache.commons.logging.LogFactory

class UserSessionContext {
    companion object {
        private val log = LogFactory.getLog(this::class.java)
        private val currentTenant: ThreadLocal<UserTO> = ThreadLocal()

        fun setCurrentTenant(userTO: UserTO) {
            log.info("Setting User session Context ************************************ ===> ${CommonUtil.objectToJson(userTO)}")
            currentTenant.set(userTO)
        }

        fun getCurrentTenant(): UserTO? {
            return currentTenant.get()
        }

        fun clear() {
            currentTenant.set(null)
        }
    }
}