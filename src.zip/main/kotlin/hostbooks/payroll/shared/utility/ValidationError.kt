package hostbooks.payroll.shared.utility

import hostbooks.payroll.shared.constant.AppMsg
import hostbooks.payroll.shared.utility.model.FieldValidError
import lombok.AllArgsConstructor
import lombok.Getter
import lombok.NoArgsConstructor
import lombok.Setter
import org.springframework.validation.Errors

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
data class ValidationError(
    var status: Int = 400,
    var code: String = "CM001E",
    var message: String? = AppMsg.RESPONSE["COM01E"],
    var totalErrorCount: Int = 0,
    var fieldErrors: MutableList<FieldValidError> = mutableListOf()
) {
    companion object {
        fun fromBindingErrors(errors: Errors): ValidationError {
            var failObj = 0
            val error = ValidationError()

            for (fieldError in errors.fieldErrors) {
                failObj++
                val fieldValidError = FieldValidError()
                fieldValidError.fieldName = fieldError.field
                fieldValidError.message = fieldError.defaultMessage
                error.fieldErrors.add(fieldValidError)
            }

            error.totalErrorCount = failObj
            return error
        }

        fun fromBindingErrorsArrayList(errors: Errors): ValidationError {
            val error = ValidationError()
            error.status= 400;
            error.code="GOL007";
            // error.setMessage(errors.getFieldError().getDefaultMessage());
            error.message=AppMsg.RESPONSE["GOL007"]
            for (filedError in errors.globalErrors) {
                val fieldError = FieldValidError()
                fieldError.fieldName =(filedError.codes!![0])
                fieldError.message=(filedError.codes!![1])
                error.fieldErrors.add(fieldError)
            }
            return error
        }
    }
}