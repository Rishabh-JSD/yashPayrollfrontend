package hostbooks.payroll.shared.utility.model

import com.fasterxml.jackson.annotation.JsonIgnoreProperties
import jakarta.persistence.*
import org.hibernate.annotations.UpdateTimestamp
import org.springframework.data.jpa.domain.support.AuditingEntityListener
import java.util.*

@MappedSuperclass
@EntityListeners(value = [AuditingEntityListener::class, AuditListenerHandler::class])
@JsonIgnoreProperties(value = ["createdAt", "updatedAt", "createdBy", "updatedBy"], allowGetters = true)
open class Audit {

    @Column(name = "version")
    open var version: String? = null

    @Column(nullable = false, updatable = false, name = "created_at")
    @Temporal(TemporalType.TIMESTAMP)
    // @get:CreationTimestamp
    open val createdAt: Date = Calendar.getInstance().time

    @Column(name = "created_by", updatable = false)
    open var createdBy: Long? = null

    @Column(nullable = false, name = "updated_at")
    @Temporal(TemporalType.TIMESTAMP)
    @get:UpdateTimestamp
    open val updatedAt: Date = Calendar.getInstance().time

    @Column(name = "updated_by")
    open var updatedBy: Long? = null
}