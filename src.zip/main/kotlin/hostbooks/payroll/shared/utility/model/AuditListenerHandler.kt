package hostbooks.payroll.shared.utility.model

import hostbooks.payroll.shared.utility.UserSessionContext
import jakarta.persistence.PrePersist
import jakarta.persistence.PreUpdate
import org.springframework.core.io.ClassPathResource
import org.springframework.core.io.support.PropertiesLoaderUtils
import java.util.*


class AuditListenerHandler {

    companion object {
        val props: Properties = PropertiesLoaderUtils.loadProperties(ClassPathResource("/application.properties"))
    }

    @PrePersist
    fun onPrePersist(audit: Audit?) {
        if (audit != null) {
            audit.version = props.getProperty("app.version")
            audit.createdBy = UserSessionContext.getCurrentTenant()?.id
            audit.updatedBy = UserSessionContext.getCurrentTenant()?.id
        }
    }

    @PreUpdate
    fun onPreUpdate(audit: Audit?) {
        if (audit != null) {
            audit.updatedBy = UserSessionContext.getCurrentTenant()?.id
        }
    }
}