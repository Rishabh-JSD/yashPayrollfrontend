package hostbooks.payroll.shared.utility.model

import java.util.*

open class AuditTO {
    var createdAt: Date? = null
    var createdBy: Long? = null
    var createdByName: String? =null
    var updatedAt: Date? = null
    var updatedBy: Long? = null
    var updatedByName: String? =null
    var version: String? = null
}