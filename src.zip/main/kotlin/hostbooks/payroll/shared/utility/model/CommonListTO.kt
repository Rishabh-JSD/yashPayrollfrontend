package hostbooks.payroll.shared.utility.model

import com.fasterxml.jackson.annotation.JsonInclude

@JsonInclude(JsonInclude.Include.NON_EMPTY)
class CommonListTO<T> {
    var totalRow: Long? = null
    var pageCount: Long? = null
    var dataList: List<T>? = null
}
