package hostbooks.payroll.shared.utility.model

data class FieldValidError(
    var fieldName: String? = null,
    var message: String? = null
)