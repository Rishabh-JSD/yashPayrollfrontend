package hostbooks.payroll.shared.utility.model

import hostbooks.payroll.shared.constant.AppMsg
import org.springframework.stereotype.Component

@Component
data class ResponseDTO(
    var status: Int = 0,
    var message: String? = null,
    var path: String? = null,
    var code: String? = null,
    val data: MutableMap<String?, Any?> = mutableMapOf()
) {
    fun putData(key: String, value: Any) {
        data[key] = value
    }

    companion object {
        fun responseBuilder(status: Int, code: String?, path: String, key: String?, data: Any?): ResponseDTO {
            return ResponseDTO(status, AppMsg.RESPONSE[code], path, code, mutableMapOf(Pair(key, data)));
        }
    }
}
