package hostbooks.payroll.shared.utility.model

import hostbooks.payroll.shared.constant.AppMsg

data class ResponseTO(
    var status: Int = 0,
    var message: String? = null,
    var path: String? = null,
    var code: String? = null,
    var data: MutableMap<String, Any> = mutableMapOf()
) {
    fun putData(key: String, value: Any) {
        data[key] = value
    }

    companion object {
        fun responseBuilder(status: Int, code: String, path: String, key: String, data: Any?): ResponseTO {
            val response = ResponseTO()
            response.status = status
            response.path = path
            response.message = AppMsg.RESPONSE[code]
            response.code = code
            if (data != null) {
                response.putData(key, data)
            }
            return response
        }
    }
}