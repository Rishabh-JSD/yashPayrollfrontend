package hostbooks.payroll.shared.utility.model

open class SearchRequestTO {
    val page = 1
    val limit = 10
    val firstLimit = 0
    val endLimit = 0
    val sortType = 0
    val sortField: String? = null
}