package hostbooks.payroll.shared.utility.model

import java.io.Serializable

open class SearchResponseTO<T>: Serializable {
    var pageCount: Long? = 0

    var totalRowCount: Long? = 0

    var list: List<T>? = null

    companion object {
        @java.io.Serial
        private const val serialVersionUID: Long=-3932831066096414182L
    }
}
