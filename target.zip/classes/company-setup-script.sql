-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Dec 20, 2023 at 12:26 PM
-- Server version: 8.2.0
-- PHP Version: 8.3.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hb_payroll_client`
--

-- --------------------------------------------------------

--
-- Table structure for table `address`
--

CREATE TABLE `address` (
  `id` bigint NOT NULL,
  `address_one` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci,
  `address_two` text,
  `city_name` varchar(250) DEFAULT NULL,
  `pincode` varchar(250) DEFAULT NULL,
  `state_name` varchar(250) DEFAULT NULL,
  `country_name` varchar(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `allowance_master`
--

CREATE TABLE `allowance_master` (
  `id` bigint NOT NULL,
  `name` varchar(45) NOT NULL,
  `delete_flag` tinyint NOT NULL DEFAULT '0',
  `version` varchar(250) NOT NULL DEFAULT '1.0.0.0',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` bigint NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` bigint NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `id` bigint NOT NULL,
  `employee_id` varchar(250) NOT NULL,
  `date` date NOT NULL,
  `leave_type_id` bigint DEFAULT NULL,
  `type` varchar(250) NOT NULL,
  `status` varchar(250) NOT NULL,
  `version` varchar(250) NOT NULL DEFAULT '1.0.0.0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` bigint NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` bigint NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `attendance_pay_frequency`
--

CREATE TABLE `attendance_pay_frequency` (
  `id` bigint NOT NULL,
  `year` bigint NOT NULL,
  `month` bigint NOT NULL,
  `frequency_id` bigint NOT NULL,
  `start_date` timestamp NOT NULL,
  `end_date` timestamp NOT NULL,
  `total_employee` bigint NOT NULL,
  `status` varchar(200) NOT NULL,
  `version` varchar(250) NOT NULL DEFAULT '1.0.0.0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` bigint NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` bigint NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `branch`
--

CREATE TABLE `branch` (
  `id` bigint NOT NULL,
  `name` varchar(255) NOT NULL,
  `code` varchar(45) NOT NULL,
  `gstin` varchar(45) DEFAULT NULL,
  `address_id` bigint DEFAULT NULL,
  `head_id` bigint DEFAULT NULL,
  `phone_no` bigint DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `shift_type_id` bigint NOT NULL,
  `shift_timing_id` bigint NOT NULL,
  `working_hours` double NOT NULL,
  `status` varchar(255) NOT NULL,
  `version` varchar(250) NOT NULL DEFAULT '1.0.0.0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` bigint NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` bigint NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `checkin_checkout`
--

CREATE TABLE `checkin_checkout` (
  `id` bigint NOT NULL,
  `attendance_id` bigint NOT NULL,
  `date_time` datetime NOT NULL,
  `type` varchar(250) NOT NULL,
  `status` varchar(250) NOT NULL,
  `version` varchar(250) NOT NULL DEFAULT '1.0.0.0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` bigint NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` bigint NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `company`
--

CREATE TABLE `company` (
  `id` int NOT NULL,
  `document_id` bigint DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `pan` varchar(45) NOT NULL,
  `tan` varchar(45) NOT NULL,
  `gstin` varchar(45) NOT NULL,
  `phone_no` bigint NOT NULL,
  `email` varchar(255) NOT NULL,
  `address_registered_id` bigint NOT NULL,
  `same_as_registered` tinyint NOT NULL DEFAULT '0',
  `address_operational_id` bigint NOT NULL,
  `working_days` varchar(255) NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `delete_flag` tinyint NOT NULL DEFAULT '0',
  `version` varchar(250) NOT NULL DEFAULT '1.0.0.0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` bigint NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` bigint NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `company_dynamic_info`
--

CREATE TABLE `company_dynamic_info` (
  `id` bigint NOT NULL,
  `name` varchar(45) NOT NULL,
  `delete_flag` tinyint DEFAULT '0',
  `version` varchar(250) NOT NULL DEFAULT '1.0.0.0',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` bigint NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` bigint NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `company_dynamic_info_option`
--

CREATE TABLE `company_dynamic_info_option` (
  `id` bigint NOT NULL,
  `company_dynamic_info_id` bigint NOT NULL,
  `department_flag` tinyint DEFAULT '1',
  `sub_department_flag` tinyint DEFAULT '0',
  `name` varchar(45) NOT NULL,
  `code` varchar(45) DEFAULT NULL,
  `gstin` varchar(45) DEFAULT NULL,
  `branch_id` bigint DEFAULT NULL,
  `cost_center_id` bigint DEFAULT NULL,
  `department_id` bigint DEFAULT NULL,
  `same_branch_flag` tinyint DEFAULT NULL,
  `address_id` bigint NOT NULL,
  `head_id` bigint DEFAULT NULL,
  `shift_type_id` bigint DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `delete_flag` tinyint NOT NULL DEFAULT '0',
  `version` varchar(250) NOT NULL DEFAULT '1.0.0.0',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` bigint NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` bigint NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `cost_center`
--

CREATE TABLE `cost_center` (
  `id` bigint NOT NULL,
  `name` varchar(255) NOT NULL,
  `branch_id` bigint NOT NULL,
  `same_as_branch_flag` tinyint NOT NULL DEFAULT '0',
  `address_id` bigint NOT NULL,
  `head_id` bigint DEFAULT NULL,
  `department_id` bigint NOT NULL,
  `phone_no` bigint DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `shift_type_id` bigint NOT NULL,
  `shift_timing_id` bigint NOT NULL,
  `working_hours` double NOT NULL,
  `status` varchar(255) NOT NULL,
  `version` varchar(250) NOT NULL DEFAULT '1.0.0.0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` bigint NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` bigint NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `deduction_master`
--

CREATE TABLE `deduction_master` (
  `id` bigint NOT NULL,
  `name` varchar(45) NOT NULL,
  `delete_flag` tinyint NOT NULL DEFAULT '0',
  `version` varchar(250) NOT NULL DEFAULT '1.0.0.0',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` bigint NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` bigint NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `id` bigint NOT NULL,
  `department_flag` tinyint NOT NULL DEFAULT '1',
  `department_id` bigint DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `branch_id` bigint NOT NULL,
  `cost_center_id` bigint NOT NULL,
  `head_id` bigint DEFAULT NULL,
  `phone_no` bigint DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `shift_type_id` bigint NOT NULL,
  `shift_timing_id` bigint NOT NULL,
  `working_hours` double NOT NULL,
  `description` text,
  `status` varchar(255) NOT NULL,
  `version` varchar(250) NOT NULL DEFAULT '1.0.0.0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` bigint NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` bigint NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `designation_master`
--

CREATE TABLE `designation_master` (
  `id` bigint NOT NULL,
  `name` varchar(45) NOT NULL,
  `code` varchar(45) NOT NULL,
  `level_id` bigint NOT NULL,
  `reporting_to_id` bigint DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `delete_flag` tinyint NOT NULL DEFAULT '0',
  `version` varchar(250) NOT NULL DEFAULT '1.0.0.0',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` bigint NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` bigint NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `display_style`
--

CREATE TABLE `display_style` (
  `id` int NOT NULL,
  `display_style` varchar(200) NOT NULL,
  `symbol` varchar(45) DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` int NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int NOT NULL,
  `version` varchar(250) NOT NULL DEFAULT '1.0.0.0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `document_category_master`
--

CREATE TABLE `document_category_master` (
  `id` bigint NOT NULL,
  `name` varchar(45) NOT NULL,
  `code` varchar(255) NOT NULL,
  `delete_flag` tinyint NOT NULL DEFAULT '0',
  `version` varchar(250) NOT NULL DEFAULT '1.0.0.0',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` bigint NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` bigint NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `document_series_settings`
--

CREATE TABLE `document_series_settings` (
  `series_id` int NOT NULL,
  `doc_type` varchar(200) NOT NULL,
  `branch_id` text,
  `prefix` varchar(200) DEFAULT NULL,
  `suffix` varchar(200) DEFAULT NULL,
  `start_number` varchar(200) DEFAULT NULL,
  `end_number` int DEFAULT NULL,
  `start_date` date NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `override_flag` tinyint(1) DEFAULT '0',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` int NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int NOT NULL,
  `version` varchar(250) NOT NULL DEFAULT '1.0.0.0',
  `display_style` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `document_type_master`
--

CREATE TABLE `document_type_master` (
  `id` bigint NOT NULL,
  `document_category_code` varchar(255) NOT NULL,
  `name` varchar(45) NOT NULL,
  `delete_flag` tinyint NOT NULL DEFAULT '0',
  `version` varchar(250) NOT NULL DEFAULT '1.0.0.0',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` bigint NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` bigint NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `id` bigint NOT NULL,
  `profile_completion` double DEFAULT NULL,
  `employment_status_id` bigint NOT NULL,
  `name` varchar(255) NOT NULL,
  `fathers_name` varchar(255) NOT NULL,
  `dob` date NOT NULL,
  `gender` varchar(255) NOT NULL,
  `personal_email` varchar(255) NOT NULL,
  `official_email` varchar(255) NOT NULL,
  `phone_no` bigint NOT NULL,
  `nationality_id` bigint NOT NULL,
  `marital_status` varchar(255) NOT NULL,
  `pan` varchar(255) NOT NULL,
  `verification_address` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `company_detail_id` bigint DEFAULT NULL,
  `salary_detail_id` bigint DEFAULT NULL,
  `address_correspondence_id` bigint DEFAULT NULL,
  `same_as_correspondence` tinyint NOT NULL DEFAULT '0',
  `address_permanent_id` bigint DEFAULT NULL,
  `status` varchar(255) NOT NULL,
  `version` varchar(250) NOT NULL DEFAULT '1.0.0.0',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` bigint NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` bigint NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `employee_account`
--

CREATE TABLE `employee_account` (
  `id` bigint NOT NULL,
  `employee_id` bigint DEFAULT NULL,
  `full_name` varchar(255) NOT NULL,
  `bank_name` varchar(255) NOT NULL,
  `account_number` varchar(255) NOT NULL,
  `branch_name` varchar(255) NOT NULL,
  `ifsc` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `employee_allowance`
--

CREATE TABLE `employee_allowance` (
  `id` bigint NOT NULL,
  `employee_salary_detail_id` bigint DEFAULT NULL,
  `allowance_master_id` bigint NOT NULL,
  `amount` decimal(10,0) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `employee_attendance_pay_frequency`
--

CREATE TABLE `employee_attendance_pay_frequency` (
  `id` bigint NOT NULL,
  `attendance_pay_frequency_id` bigint NOT NULL,
  `attendance_id` bigint NOT NULL,
  `leave_type_id` bigint NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `employee_company_detail`
--

CREATE TABLE `employee_company_detail` (
  `id` bigint NOT NULL,
  `employee_number` varchar(255) NOT NULL,
  `current_number` varchar(200) DEFAULT NULL,
  `display_style` int DEFAULT NULL,
  `joining_date` date NOT NULL,
  `employee_category_id` bigint NOT NULL,
  `attendance_type_code` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `contract_from` date NOT NULL,
  `contract_to` date NOT NULL,
  `shift_type_id` bigint NOT NULL,
  `shift_timing_id` bigint NOT NULL,
  `designation_id` bigint NOT NULL,
  `branch_id` bigint DEFAULT NULL,
  `cost_center_id` bigint DEFAULT NULL,
  `department_id` bigint DEFAULT NULL,
  `employee_level_id` bigint NOT NULL,
  `report_to_id` bigint DEFAULT NULL,
  `functional_appraiser_id` bigint DEFAULT NULL,
  `admin_appraiser_id` bigint DEFAULT NULL,
  `pay_frequency_id` bigint NOT NULL,
  `separation_date` date DEFAULT NULL,
  `overtime_flag` tinyint NOT NULL DEFAULT '0',
  `job_description` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `employee_deduction`
--

CREATE TABLE `employee_deduction` (
  `id` bigint NOT NULL,
  `employee_salary_detail_id` bigint DEFAULT NULL,
  `deduction_master_id` bigint NOT NULL,
  `amount` decimal(10,0) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `employee_experience`
--

CREATE TABLE `employee_experience` (
  `id` bigint NOT NULL,
  `employee_id` bigint DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `employment_type_code` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `company_name` varchar(255) NOT NULL,
  `country_name` varchar(250) NOT NULL,
  `state_name` varchar(250) DEFAULT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `job_title` varchar(255) NOT NULL,
  `industry_id` bigint NOT NULL,
  `job_description` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `employee_experience_attachment`
--

CREATE TABLE `employee_experience_attachment` (
  `id` bigint NOT NULL,
  `employee_experience_id` bigint DEFAULT NULL,
  `document_type_id` bigint NOT NULL,
  `remark` text,
  `document_id` bigint DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `employee_kyc`
--

CREATE TABLE `employee_kyc` (
  `id` bigint NOT NULL,
  `employee_id` bigint DEFAULT NULL,
  `document_type_id` bigint NOT NULL,
  `remark` text NOT NULL,
  `document_id` bigint DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `employee_qualification`
--

CREATE TABLE `employee_qualification` (
  `id` bigint NOT NULL,
  `employee_id` bigint DEFAULT NULL,
  `document_type_id` bigint NOT NULL,
  `remark` text,
  `institution_description` text,
  `country_name` varchar(250) NOT NULL,
  `state_name` varchar(250) NOT NULL,
  `document_id` bigint DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `employee_reference`
--

CREATE TABLE `employee_reference` (
  `id` bigint NOT NULL,
  `name` varchar(255) NOT NULL,
  `employee_id` bigint DEFAULT NULL,
  `mobile` bigint NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `employee_reimbursement`
--

CREATE TABLE `employee_reimbursement` (
  `id` bigint NOT NULL,
  `employee_salary_detail_id` bigint DEFAULT NULL,
  `reimbursement_master_id` bigint NOT NULL,
  `amount` decimal(10,0) NOT NULL,
  `delete_flag` tinyint NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `employee_salary_detail`
--

CREATE TABLE `employee_salary_detail` (
  `id` bigint NOT NULL,
  `basic_salary` decimal(10,0) NOT NULL,
  `ctc` decimal(10,0) NOT NULL,
  `net_pay_before_tds` decimal(10,0) NOT NULL,
  `tax_summary` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `fixed_masters`
--

CREATE TABLE `fixed_masters` (
  `id` bigint NOT NULL,
  `name` varchar(255) NOT NULL,
  `code` varchar(45) NOT NULL,
  `type` varchar(45) NOT NULL,
  `description` text,
  `status` varchar(250) NOT NULL,
  `version` varchar(250) NOT NULL DEFAULT '1.0.0.0',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` bigint NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` bigint NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `fixed_masters`
--

INSERT INTO `fixed_masters` (`id`, `name`, `code`, `type`, `description`, `status`, `version`, `updated_at`, `updated_by`, `created_at`, `created_by`) VALUES
(1, 'Mobile', 'ATMB', 'attendance_types', NULL, 'ACTIVE', '1.0.0.0', '2022-02-03 06:16:01', 0, '2022-02-03 06:16:01', 0),
(2, 'Punching', 'ATPC', 'attendance_types', NULL, 'ACTIVE', '1.0.0.0', '2022-02-03 06:16:01', 0, '2022-02-03 06:16:01', 0),
(3, 'Manual', 'ATMN', 'attendance_types', NULL, 'ACTIVE', '1.0.0.0', '2022-02-03 06:16:01', 0, '2022-02-03 06:16:01', 0),
(4, 'Mobile & Punching', 'ATMPC', 'attendance_types', NULL, 'ACTIVE', '1.0.0.0', '2022-02-03 06:16:01', 0, '2022-02-03 06:16:01', 0),
(5, 'Punching & Manual', 'ATPCM', 'attendance_types', NULL, 'ACTIVE', '1.0.0.0', '2022-02-03 06:16:01', 0, '2022-02-03 06:16:01', 0),
(6, 'Mobile & Manual', 'ATMNM', 'attendance_types', NULL, 'ACTIVE', '1.0.0.0', '2022-02-03 06:16:01', 0, '2022-02-03 06:16:01', 0),
(7, 'All Three(Mobile, Punching & Manual)', 'ATMPM', 'attendance_types', NULL, 'ACTIVE', '1.0.0.0', '2022-02-03 06:16:01', 0, '2022-02-03 06:16:01', 0),
(8, 'Full-Time', 'ETFLT', 'employment_type', NULL, 'ACTIVE', '1.0.0.0', '2022-02-21 14:42:51', 0, '2022-02-21 14:42:51', 0),
(9, 'Part-Time', 'ETPTT', 'employment_type', NULL, 'ACTIVE', '1.0.0.0', '2022-02-21 14:42:51', 0, '2022-02-21 14:42:51', 0),
(10, 'Self-Employed', 'ETSEMP', 'employment_type', NULL, 'ACTIVE', '1.0.0.0', '2022-02-21 14:42:51', 0, '2022-02-21 14:42:51', 0),
(11, 'Freelance', 'ETFRL', 'employment_type', NULL, 'ACTIVE', '1.0.0.0', '2022-02-21 14:42:51', 0, '2022-02-21 14:42:51', 0),
(12, 'Internship', 'ETITS', 'employment_type', NULL, 'ACTIVE', '1.0.0.0', '2022-02-21 14:42:51', 0, '2022-02-21 14:42:51', 0),
(13, 'Trainee', 'ETTRN', 'employment_type', NULL, 'ACTIVE', '1.0.0.0', '2022-02-21 14:42:51', 0, '2022-02-21 14:42:51', 0);

-- --------------------------------------------------------

--
-- Table structure for table `holiday_calendar`
--

CREATE TABLE `holiday_calendar` (
  `id` bigint NOT NULL,
  `name` varchar(255) NOT NULL,
  `master_id` bigint NOT NULL,
  `status` varchar(250) NOT NULL,
  `date` date NOT NULL,
  `version` varchar(250) NOT NULL DEFAULT '1.0.0.0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` bigint NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` bigint NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `holiday_master`
--

CREATE TABLE `holiday_master` (
  `id` bigint NOT NULL,
  `name` varchar(250) NOT NULL,
  `code` varchar(250) NOT NULL,
  `status` varchar(250) NOT NULL,
  `version` varchar(250) NOT NULL DEFAULT '1.0.0.0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` bigint NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` bigint NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `import_template_fields`
--

CREATE TABLE `import_template_fields` (
  `id` int NOT NULL,
  `field_key` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `field_display` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `import_template_setting_id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `import_template_setting`
--

CREATE TABLE `import_template_setting` (
  `id` int NOT NULL,
  `template_name` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `txn_type` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `standard_template_flag` tinyint DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `leave_adjustment`
--

CREATE TABLE `leave_adjustment` (
  `id` bigint NOT NULL,
  `employee_id` bigint NOT NULL,
  `date` date NOT NULL,
  `leave_type_id` bigint NOT NULL,
  `quantity` decimal(16,6) NOT NULL DEFAULT '0.000000',
  `quantity_type` varchar(250) NOT NULL,
  `adj_type` varchar(250) NOT NULL,
  `status` varchar(250) NOT NULL,
  `version` varchar(250) NOT NULL DEFAULT '1.0.0.0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` bigint NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` bigint NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `leave_apply`
--

CREATE TABLE `leave_apply` (
  `id` bigint NOT NULL,
  `employee_id` bigint NOT NULL,
  `start_date` date NOT NULL,
  `start_date_type` varchar(250) NOT NULL,
  `end_date` date NOT NULL,
  `end_date_type` varchar(250) NOT NULL,
  `no_of_days` decimal(16,6) NOT NULL DEFAULT '0.000000',
  `leave_type_id` bigint NOT NULL,
  `employee_cc_ids` text,
  `reason` text,
  `approver_remarks` text,
  `status` varchar(250) NOT NULL,
  `version` varchar(250) NOT NULL DEFAULT '1.0.0.0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` bigint NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` bigint NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `leave_rule_combined_restriction`
--

CREATE TABLE `leave_rule_combined_restriction` (
  `id` bigint NOT NULL,
  `leave_type_ids` varchar(255) DEFAULT NULL,
  `status` varchar(250) NOT NULL,
  `version` varchar(250) NOT NULL DEFAULT '1.0.0.0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` bigint NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` bigint NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `leave_rule_combined_restriction_options`
--

CREATE TABLE `leave_rule_combined_restriction_options` (
  `id` bigint NOT NULL,
  `combined_restriction_id` bigint DEFAULT NULL,
  `leave_type_id` bigint NOT NULL,
  `quantity` decimal(16,6) NOT NULL DEFAULT '0.000000'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `leave_rule_credit_carry`
--

CREATE TABLE `leave_rule_credit_carry` (
  `id` bigint NOT NULL,
  `leave_type_id` bigint NOT NULL,
  `credit_days` decimal(16,6) NOT NULL DEFAULT '0.000000',
  `carry_days` decimal(16,6) NOT NULL DEFAULT '0.000000',
  `status` varchar(250) NOT NULL,
  `version` varchar(250) NOT NULL DEFAULT '1.0.0.0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` bigint NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` bigint NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `leave_rule_permissible`
--

CREATE TABLE `leave_rule_permissible` (
  `id` bigint NOT NULL,
  `leave_type_id` bigint NOT NULL,
  `max_no` decimal(16,6) NOT NULL DEFAULT '0.000000',
  `status` varchar(250) NOT NULL,
  `version` varchar(250) NOT NULL DEFAULT '1.0.0.0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` bigint NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` bigint NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `leave_rule_sandwich`
--

CREATE TABLE `leave_rule_sandwich` (
  `id` bigint NOT NULL,
  `week_off_flag` tinyint NOT NULL DEFAULT '0',
  `holiday_type_ids` text,
  `day_before_flag` tinyint DEFAULT '0',
  `day_after_flag` tinyint DEFAULT '0',
  `lop_flag` tinyint DEFAULT '0',
  `status` varchar(250) NOT NULL,
  `version` varchar(255) NOT NULL DEFAULT '1.0.0.0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` bigint NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` bigint NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `leave_rule_utilisation_period`
--

CREATE TABLE `leave_rule_utilisation_period` (
  `id` bigint NOT NULL,
  `leave_type_id` bigint NOT NULL,
  `no_of_days` decimal(16,6) NOT NULL DEFAULT '0.000000',
  `status` varchar(250) NOT NULL,
  `version` varchar(250) NOT NULL DEFAULT '1.0.0.0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` bigint NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` bigint NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `leave_type`
--

CREATE TABLE `leave_type` (
  `id` bigint NOT NULL,
  `name` varchar(250) NOT NULL,
  `code` varchar(250) NOT NULL,
  `status` varchar(250) NOT NULL,
  `type` varchar(45) NOT NULL,
  `version` varchar(250) NOT NULL DEFAULT '1.0.0.0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` bigint NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` bigint NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `location`
--

CREATE TABLE `location` (
  `id` bigint NOT NULL,
  `name` varchar(255) NOT NULL,
  `cost_center_id` bigint NOT NULL,
  `address_id` bigint NOT NULL,
  `head_id` bigint NOT NULL,
  `phone_no` bigint DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `shift_type_id` bigint NOT NULL,
  `shift_timing_id` bigint NOT NULL,
  `status` varchar(255) NOT NULL,
  `version` varchar(250) NOT NULL DEFAULT '1.0.0.0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` bigint NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` bigint NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `payroll_master`
--

CREATE TABLE `payroll_master` (
  `id` int NOT NULL,
  `code` varchar(200) NOT NULL,
  `name` varchar(200) DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` bigint NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` bigint NOT NULL,
  `status` varchar(255) NOT NULL,
  `version` varchar(250) NOT NULL DEFAULT '1.0.0.0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `payroll_master_option`
--

CREATE TABLE `payroll_master_option` (
  `id` int NOT NULL,
  `name` varchar(45) DEFAULT NULL,
  `coa_id` int DEFAULT NULL,
  `cat_code` varchar(45) NOT NULL,
  `reporting_to_id` bigint DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `parent_id` bigint DEFAULT NULL,
  `parent_cat_option_id` bigint DEFAULT NULL,
  `start_time` time DEFAULT NULL,
  `end_time` time DEFAULT NULL,
  `working_hours` double DEFAULT NULL,
  `shift_start_tolerance` varchar(250) DEFAULT NULL,
  `shift_end_tolerance` varchar(250) DEFAULT NULL,
  `fixed_shift_flag` tinyint DEFAULT NULL,
  `start_day` bigint DEFAULT NULL,
  `end_day` bigint DEFAULT NULL,
  `days` bigint DEFAULT NULL,
  `pre_defined_flag` tinyint NOT NULL,
  `code` varchar(45) DEFAULT NULL,
  `level` bigint DEFAULT NULL,
  `level_ref_id` bigint DEFAULT NULL,
  `status` varchar(255) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` bigint NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` bigint NOT NULL,
  `version` varchar(250) NOT NULL DEFAULT '1.0.0.0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `payrun`
--

CREATE TABLE `payrun` (
  `id` bigint NOT NULL,
  `payrun_id` bigint NOT NULL,
  `year` int NOT NULL,
  `month` int NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `total_employee` int NOT NULL,
  `payroll_cost` decimal(16,6) NOT NULL,
  `taxes` decimal(16,6) NOT NULL,
  `net_pay` decimal(16,6) NOT NULL,
  `payrun_type` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `created_by` bigint NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` bigint NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `version` decimal(16,6) NOT NULL DEFAULT '0.000000'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `payrun_employee_line`
--

CREATE TABLE `payrun_employee_line` (
  `id` bigint NOT NULL,
  `payrun_id` bigint NOT NULL,
  `employee_id` bigint NOT NULL,
  `employee_name` varchar(255) NOT NULL,
  `paid_days` int NOT NULL,
  `lop_days` int NOT NULL,
  `gross_pay` decimal(16,6) NOT NULL,
  `deduction` decimal(16,6) NOT NULL,
  `basic` decimal(16,6) NOT NULL,
  `allowances` decimal(16,6) NOT NULL,
  `income_tax` decimal(16,6) NOT NULL,
  `taxes` decimal(16,6) NOT NULL,
  `addition` decimal(16,6) NOT NULL,
  `reimbursement` decimal(16,6) NOT NULL,
  `adjustment` decimal(16,6) NOT NULL,
  `net_payment` decimal(16,6) NOT NULL,
  `bank_transfer` decimal(16,6) NOT NULL,
  `bank_id` varchar(255) DEFAULT NULL,
  `cheque_payment` decimal(16,6) NOT NULL,
  `cheque_details` varchar(255) DEFAULT NULL,
  `cheque_bank_id` varchar(255) DEFAULT NULL,
  `payment_status` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `pay_frequency_master`
--

CREATE TABLE `pay_frequency_master` (
  `id` bigint NOT NULL,
  `name` varchar(45) NOT NULL,
  `delete_flag` tinyint NOT NULL DEFAULT '0',
  `version` varchar(250) NOT NULL DEFAULT '1.0.0.0',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` bigint NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` bigint NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `pay_run`
--

CREATE TABLE `pay_run` (
  `id` bigint NOT NULL,
  `pay_run_ref_id` bigint DEFAULT NULL,
  `year` int NOT NULL,
  `month` int NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `total_employee` int NOT NULL,
  `payroll_cost` decimal(16,6) NOT NULL,
  `taxes` decimal(16,6) NOT NULL,
  `net_pay` decimal(16,6) NOT NULL,
  `pay_run_type` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `created_by` bigint NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` bigint NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `version` varchar(250) NOT NULL DEFAULT '1.0.0.0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `pay_run_employee_line`
--

CREATE TABLE `pay_run_employee_line` (
  `id` bigint NOT NULL,
  `pay_run_id` bigint DEFAULT NULL,
  `employee_id` bigint NOT NULL,
  `employee_name` varchar(255) NOT NULL,
  `paid_days` int NOT NULL,
  `lop_days` int NOT NULL,
  `gross_pay` decimal(16,6) NOT NULL,
  `deduction` decimal(16,6) NOT NULL,
  `basic` decimal(16,6) NOT NULL,
  `allowances` decimal(16,6) NOT NULL,
  `income_tax` decimal(16,6) NOT NULL,
  `taxes` decimal(16,6) NOT NULL,
  `addition` decimal(16,6) NOT NULL,
  `reimbursement` decimal(16,6) NOT NULL,
  `adjustment` decimal(16,6) NOT NULL,
  `net_payment` decimal(16,6) NOT NULL,
  `bank_transfer` decimal(16,6) NOT NULL,
  `bank_id` varchar(255) DEFAULT NULL,
  `cheque_payment` decimal(16,6) NOT NULL,
  `cheque_details` varchar(255) DEFAULT NULL,
  `cheque_bank_id` varchar(255) DEFAULT NULL,
  `payment_status` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `profit_center`
--

CREATE TABLE `profit_center` (
  `id` int NOT NULL,
  `name` varchar(45) NOT NULL,
  `branch_id` bigint NOT NULL,
  `same_as_branch` tinyint NOT NULL,
  `address_id` bigint NOT NULL,
  `head_id` bigint NOT NULL,
  `phone_no` bigint NOT NULL,
  `email` varchar(255) NOT NULL,
  `shift_type_id` bigint NOT NULL,
  `shift_timing_id` bigint NOT NULL,
  `delete_flag` tinyint NOT NULL DEFAULT '0',
  `version` varchar(250) NOT NULL DEFAULT '1.0.0.0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` bigint NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` bigint NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `reimbursements`
--

CREATE TABLE `reimbursements` (
  `id` int NOT NULL,
  `reimbursement_claim_id` int DEFAULT NULL,
  `reimbursement_master_id` int DEFAULT NULL,
  `description` varchar(250) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `date` date DEFAULT NULL,
  `amount` decimal(16,6) DEFAULT '0.000000',
  `approved_amount` decimal(16,6) DEFAULT '0.000000',
  `rejected_amount` decimal(16,6) DEFAULT '0.000000',
  `created_at` timestamp NULL DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` int DEFAULT NULL,
  `version` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `reimbursement_claim`
--

CREATE TABLE `reimbursement_claim` (
  `id` int NOT NULL,
  `branch_id` int DEFAULT NULL,
  `claim_number` varchar(250) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `current_number` varchar(250) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `display_style` int DEFAULT NULL,
  `employee_id` int DEFAULT NULL,
  `claim_date` date DEFAULT NULL,
  `status` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` int DEFAULT NULL,
  `version` varchar(250) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `reimbursement_master`
--

CREATE TABLE `reimbursement_master` (
  `id` bigint NOT NULL,
  `name` varchar(45) NOT NULL,
  `delete_flag` tinyint NOT NULL DEFAULT '0',
  `version` varchar(250) NOT NULL DEFAULT '1.0.0.0',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` bigint NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` bigint NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `rule_master`
--

CREATE TABLE `rule_master` (
  `id` int NOT NULL,
  `rule_name` varchar(250) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `basic_salary` decimal(16,6) DEFAULT '0.000000',
  `type` varchar(250) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `version` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `rule_master_option`
--

CREATE TABLE `rule_master_option` (
  `id` int NOT NULL,
  `rule_master_id` int DEFAULT NULL,
  `allowance_deduction_id` int NOT NULL,
  `percentage` decimal(16,6) DEFAULT '0.000000',
  `amount` decimal(16,6) DEFAULT '0.000000'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `shift_timing_master`
--

CREATE TABLE `shift_timing_master` (
  `id` bigint NOT NULL,
  `shift_type_id` bigint NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `working_hours` double DEFAULT NULL,
  `delete_flag` tinyint NOT NULL DEFAULT '0',
  `version` varchar(250) NOT NULL DEFAULT '1.0.0.0',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` bigint NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` bigint NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `shift_type_master`
--

CREATE TABLE `shift_type_master` (
  `id` bigint NOT NULL,
  `name` varchar(45) NOT NULL,
  `delete_flag` tinyint NOT NULL DEFAULT '0',
  `version` varchar(250) NOT NULL DEFAULT '1.0.0.0',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` bigint NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` bigint NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `tenant`
--

CREATE TABLE `tenant` (
  `id` bigint NOT NULL,
  `tenant_detail_id` int NOT NULL,
  `owner_id` bigint NOT NULL,
  `industry_id` bigint NOT NULL,
  `name` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `db_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `db_uuid` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` bigint DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `created_by` bigint DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tenant_details`
--

CREATE TABLE `tenant_details` (
  `id` int NOT NULL,
  `address_id` int NOT NULL,
  `business_type` varchar(200) DEFAULT NULL,
  `alias` text,
  `legal_name` varchar(256) DEFAULT NULL,
  `logo` varchar(256) DEFAULT NULL,
  `phone` varchar(256) DEFAULT NULL,
  `email` varchar(256) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int NOT NULL,
  `user_detail_id` int DEFAULT NULL,
  `name` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `username` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `password` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `enabled` tinyint NOT NULL DEFAULT '1',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user_details`
--

CREATE TABLE `user_details` (
  `id` int NOT NULL,
  `tenant_creation_limit` int DEFAULT NULL,
  `address_id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `address`
--
ALTER TABLE `address`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `allowance_master`
--
ALTER TABLE `allowance_master`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `attendance`
--
ALTER TABLE `attendance`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `attendance_pay_frequency`
--
ALTER TABLE `attendance_pay_frequency`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id_UNIQUE` (`id`);

--
-- Indexes for table `branch`
--
ALTER TABLE `branch`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_branch_address1_idx` (`address_id`);

--
-- Indexes for table `checkin_checkout`
--
ALTER TABLE `checkin_checkout`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `company`
--
ALTER TABLE `company`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_company_address1_idx` (`address_registered_id`),
  ADD KEY `fk_company_address2_idx` (`address_operational_id`);

--
-- Indexes for table `company_dynamic_info`
--
ALTER TABLE `company_dynamic_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `company_dynamic_info_option`
--
ALTER TABLE `company_dynamic_info_option`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_category_option_categories1_idx` (`company_dynamic_info_id`);

--
-- Indexes for table `cost_center`
--
ALTER TABLE `cost_center`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_cost_center_address1_idx` (`address_id`);

--
-- Indexes for table `deduction_master`
--
ALTER TABLE `deduction_master`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `designation_master`
--
ALTER TABLE `designation_master`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `display_style`
--
ALTER TABLE `display_style`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `document_category_master`
--
ALTER TABLE `document_category_master`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `document_series_settings`
--
ALTER TABLE `document_series_settings`
  ADD PRIMARY KEY (`series_id`);

--
-- Indexes for table `document_type_master`
--
ALTER TABLE `document_type_master`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_employee_employee_company_details_idx` (`company_detail_id`),
  ADD KEY `fk_employee_employee_salary_details1_idx` (`salary_detail_id`),
  ADD KEY `fk_employee_address1_idx` (`address_correspondence_id`),
  ADD KEY `fk_employee_address2_idx` (`address_permanent_id`);

--
-- Indexes for table `employee_account`
--
ALTER TABLE `employee_account`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_employee_account_employee1_idx` (`employee_id`);

--
-- Indexes for table `employee_allowance`
--
ALTER TABLE `employee_allowance`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_employee_allowance_employee_salary_details1_idx` (`employee_salary_detail_id`);

--
-- Indexes for table `employee_attendance_pay_frequency`
--
ALTER TABLE `employee_attendance_pay_frequency`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `employee_company_detail`
--
ALTER TABLE `employee_company_detail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `employee_deduction`
--
ALTER TABLE `employee_deduction`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_employee_deductions_employee_salary_details1_idx` (`employee_salary_detail_id`);

--
-- Indexes for table `employee_experience`
--
ALTER TABLE `employee_experience`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_employee_experience_employee1_idx` (`employee_id`);

--
-- Indexes for table `employee_experience_attachment`
--
ALTER TABLE `employee_experience_attachment`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_employee_experience_attachment_employee_experience1_idx` (`employee_experience_id`);

--
-- Indexes for table `employee_kyc`
--
ALTER TABLE `employee_kyc`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_employee_kyc_employee1_idx` (`employee_id`);

--
-- Indexes for table `employee_qualification`
--
ALTER TABLE `employee_qualification`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_employee_qualification_employee1_idx` (`employee_id`);

--
-- Indexes for table `employee_reference`
--
ALTER TABLE `employee_reference`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_employee_reference_employee1_idx` (`employee_id`);

--
-- Indexes for table `employee_reimbursement`
--
ALTER TABLE `employee_reimbursement`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_employee_reimbursement_employee_salary_details1_idx` (`employee_salary_detail_id`);

--
-- Indexes for table `employee_salary_detail`
--
ALTER TABLE `employee_salary_detail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fixed_masters`
--
ALTER TABLE `fixed_masters`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `code` (`code`);

--
-- Indexes for table `holiday_calendar`
--
ALTER TABLE `holiday_calendar`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `holiday_master`
--
ALTER TABLE `holiday_master`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `import_template_fields`
--
ALTER TABLE `import_template_fields`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `import_template_setting`
--
ALTER TABLE `import_template_setting`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `leave_adjustment`
--
ALTER TABLE `leave_adjustment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `leave_apply`
--
ALTER TABLE `leave_apply`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `leave_rule_combined_restriction`
--
ALTER TABLE `leave_rule_combined_restriction`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `code` (`leave_type_ids`);

--
-- Indexes for table `leave_rule_combined_restriction_options`
--
ALTER TABLE `leave_rule_combined_restriction_options`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_combined_restriction_id` (`combined_restriction_id`);

--
-- Indexes for table `leave_rule_credit_carry`
--
ALTER TABLE `leave_rule_credit_carry`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `leave_rule_permissible`
--
ALTER TABLE `leave_rule_permissible`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `leave_rule_sandwich`
--
ALTER TABLE `leave_rule_sandwich`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `leave_rule_utilisation_period`
--
ALTER TABLE `leave_rule_utilisation_period`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `leave_type`
--
ALTER TABLE `leave_type`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`),
  ADD UNIQUE KEY `code` (`code`);

--
-- Indexes for table `location`
--
ALTER TABLE `location`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_location_address1_idx` (`address_id`);

--
-- Indexes for table `payroll_master`
--
ALTER TABLE `payroll_master`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `code` (`code`);

--
-- Indexes for table `payroll_master_option`
--
ALTER TABLE `payroll_master_option`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_cat_code` (`cat_code`),
  ADD KEY `fk_reporting_to_id` (`reporting_to_id`);

--
-- Indexes for table `payrun`
--
ALTER TABLE `payrun`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payrun_employee_line`
--
ALTER TABLE `payrun_employee_line`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pay_frequency_master`
--
ALTER TABLE `pay_frequency_master`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pay_run`
--
ALTER TABLE `pay_run`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pay_run_employee_line`
--
ALTER TABLE `pay_run_employee_line`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `profit_center`
--
ALTER TABLE `profit_center`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_profit_center_address1_idx` (`address_id`);

--
-- Indexes for table `reimbursements`
--
ALTER TABLE `reimbursements`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reimbursement_claim`
--
ALTER TABLE `reimbursement_claim`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reimbursement_master`
--
ALTER TABLE `reimbursement_master`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rule_master`
--
ALTER TABLE `rule_master`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rule_master_option`
--
ALTER TABLE `rule_master_option`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `shift_timing_master`
--
ALTER TABLE `shift_timing_master`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `shift_type_master`
--
ALTER TABLE `shift_type_master`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tenant`
--
ALTER TABLE `tenant`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tenant_details`
--
ALTER TABLE `tenant_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_details`
--
ALTER TABLE `user_details`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `address`
--
ALTER TABLE `address`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `allowance_master`
--
ALTER TABLE `allowance_master`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `attendance`
--
ALTER TABLE `attendance`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `attendance_pay_frequency`
--
ALTER TABLE `attendance_pay_frequency`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `branch`
--
ALTER TABLE `branch`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `checkin_checkout`
--
ALTER TABLE `checkin_checkout`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `company`
--
ALTER TABLE `company`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `company_dynamic_info`
--
ALTER TABLE `company_dynamic_info`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `company_dynamic_info_option`
--
ALTER TABLE `company_dynamic_info_option`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cost_center`
--
ALTER TABLE `cost_center`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `deduction_master`
--
ALTER TABLE `deduction_master`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `department`
--
ALTER TABLE `department`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `designation_master`
--
ALTER TABLE `designation_master`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `display_style`
--
ALTER TABLE `display_style`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `document_category_master`
--
ALTER TABLE `document_category_master`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `document_series_settings`
--
ALTER TABLE `document_series_settings`
  MODIFY `series_id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `document_type_master`
--
ALTER TABLE `document_type_master`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `employee_account`
--
ALTER TABLE `employee_account`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `employee_allowance`
--
ALTER TABLE `employee_allowance`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `employee_attendance_pay_frequency`
--
ALTER TABLE `employee_attendance_pay_frequency`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `employee_company_detail`
--
ALTER TABLE `employee_company_detail`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `employee_deduction`
--
ALTER TABLE `employee_deduction`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `employee_experience`
--
ALTER TABLE `employee_experience`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `employee_experience_attachment`
--
ALTER TABLE `employee_experience_attachment`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `employee_kyc`
--
ALTER TABLE `employee_kyc`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `employee_qualification`
--
ALTER TABLE `employee_qualification`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `employee_reference`
--
ALTER TABLE `employee_reference`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `employee_reimbursement`
--
ALTER TABLE `employee_reimbursement`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `employee_salary_detail`
--
ALTER TABLE `employee_salary_detail`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `fixed_masters`
--
ALTER TABLE `fixed_masters`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `holiday_calendar`
--
ALTER TABLE `holiday_calendar`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `holiday_master`
--
ALTER TABLE `holiday_master`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `import_template_fields`
--
ALTER TABLE `import_template_fields`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `import_template_setting`
--
ALTER TABLE `import_template_setting`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `leave_adjustment`
--
ALTER TABLE `leave_adjustment`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `leave_apply`
--
ALTER TABLE `leave_apply`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `leave_rule_combined_restriction`
--
ALTER TABLE `leave_rule_combined_restriction`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `leave_rule_combined_restriction_options`
--
ALTER TABLE `leave_rule_combined_restriction_options`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `leave_rule_credit_carry`
--
ALTER TABLE `leave_rule_credit_carry`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `leave_rule_permissible`
--
ALTER TABLE `leave_rule_permissible`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `leave_rule_sandwich`
--
ALTER TABLE `leave_rule_sandwich`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `leave_rule_utilisation_period`
--
ALTER TABLE `leave_rule_utilisation_period`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `leave_type`
--
ALTER TABLE `leave_type`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `location`
--
ALTER TABLE `location`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `payroll_master`
--
ALTER TABLE `payroll_master`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `payroll_master_option`
--
ALTER TABLE `payroll_master_option`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `payrun`
--
ALTER TABLE `payrun`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `payrun_employee_line`
--
ALTER TABLE `payrun_employee_line`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pay_frequency_master`
--
ALTER TABLE `pay_frequency_master`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pay_run`
--
ALTER TABLE `pay_run`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pay_run_employee_line`
--
ALTER TABLE `pay_run_employee_line`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `profit_center`
--
ALTER TABLE `profit_center`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `reimbursements`
--
ALTER TABLE `reimbursements`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `reimbursement_claim`
--
ALTER TABLE `reimbursement_claim`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `reimbursement_master`
--
ALTER TABLE `reimbursement_master`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `rule_master`
--
ALTER TABLE `rule_master`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `rule_master_option`
--
ALTER TABLE `rule_master_option`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `shift_timing_master`
--
ALTER TABLE `shift_timing_master`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `shift_type_master`
--
ALTER TABLE `shift_type_master`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tenant`
--
ALTER TABLE `tenant`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tenant_details`
--
ALTER TABLE `tenant_details`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_details`
--
ALTER TABLE `user_details`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `branch`
--
ALTER TABLE `branch`
  ADD CONSTRAINT `fk_branch_address1` FOREIGN KEY (`address_id`) REFERENCES `address` (`id`);

--
-- Constraints for table `company`
--
ALTER TABLE `company`
  ADD CONSTRAINT `fk_company_address1` FOREIGN KEY (`address_registered_id`) REFERENCES `address` (`id`),
  ADD CONSTRAINT `fk_company_address2` FOREIGN KEY (`address_operational_id`) REFERENCES `address` (`id`);

--
-- Constraints for table `company_dynamic_info_option`
--
ALTER TABLE `company_dynamic_info_option`
  ADD CONSTRAINT `fk_category_option_categories1` FOREIGN KEY (`company_dynamic_info_id`) REFERENCES `company_dynamic_info` (`id`);

--
-- Constraints for table `cost_center`
--
ALTER TABLE `cost_center`
  ADD CONSTRAINT `fk_cost_center_address1` FOREIGN KEY (`address_id`) REFERENCES `address` (`id`);

--
-- Constraints for table `employee`
--
ALTER TABLE `employee`
  ADD CONSTRAINT `fk_employee_address1` FOREIGN KEY (`address_correspondence_id`) REFERENCES `address` (`id`),
  ADD CONSTRAINT `fk_employee_address2` FOREIGN KEY (`address_permanent_id`) REFERENCES `address` (`id`),
  ADD CONSTRAINT `fk_employee_employee_company_details` FOREIGN KEY (`company_detail_id`) REFERENCES `employee_company_detail` (`id`),
  ADD CONSTRAINT `fk_employee_employee_salary_details1` FOREIGN KEY (`salary_detail_id`) REFERENCES `employee_salary_detail` (`id`);

--
-- Constraints for table `employee_account`
--
ALTER TABLE `employee_account`
  ADD CONSTRAINT `fk_employee_account_employee1` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`id`);

--
-- Constraints for table `employee_allowance`
--
ALTER TABLE `employee_allowance`
  ADD CONSTRAINT `fk_employee_allowance_employee_salary_details1` FOREIGN KEY (`employee_salary_detail_id`) REFERENCES `employee_salary_detail` (`id`);

--
-- Constraints for table `employee_deduction`
--
ALTER TABLE `employee_deduction`
  ADD CONSTRAINT `fk_employee_deductions_employee_salary_details1` FOREIGN KEY (`employee_salary_detail_id`) REFERENCES `employee_salary_detail` (`id`);

--
-- Constraints for table `employee_experience`
--
ALTER TABLE `employee_experience`
  ADD CONSTRAINT `fk_employee_experience_employee1` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`id`);

--
-- Constraints for table `employee_experience_attachment`
--
ALTER TABLE `employee_experience_attachment`
  ADD CONSTRAINT `fk_employee_experience_attachment_employee_experience1` FOREIGN KEY (`employee_experience_id`) REFERENCES `employee_experience` (`id`);

--
-- Constraints for table `employee_kyc`
--
ALTER TABLE `employee_kyc`
  ADD CONSTRAINT `fk_employee_kyc_employee1` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`id`);

--
-- Constraints for table `employee_qualification`
--
ALTER TABLE `employee_qualification`
  ADD CONSTRAINT `fk_employee_qualification_employee1` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`id`);

--
-- Constraints for table `employee_reference`
--
ALTER TABLE `employee_reference`
  ADD CONSTRAINT `fk_employee_reference_employee1` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`id`);

--
-- Constraints for table `employee_reimbursement`
--
ALTER TABLE `employee_reimbursement`
  ADD CONSTRAINT `fk_employee_reimbursement_employee_salary_details1` FOREIGN KEY (`employee_salary_detail_id`) REFERENCES `employee_salary_detail` (`id`);

--
-- Constraints for table `leave_rule_combined_restriction_options`
--
ALTER TABLE `leave_rule_combined_restriction_options`
  ADD CONSTRAINT `fk_combined_restriction_id` FOREIGN KEY (`combined_restriction_id`) REFERENCES `leave_rule_combined_restriction` (`id`);

--
-- Constraints for table `location`
--
ALTER TABLE `location`
  ADD CONSTRAINT `fk_location_address1` FOREIGN KEY (`address_id`) REFERENCES `address` (`id`);

--
-- Constraints for table `profit_center`
--
ALTER TABLE `profit_center`
  ADD CONSTRAINT `fk_profit_center_address1` FOREIGN KEY (`address_id`) REFERENCES `address` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
