#!/bin/bash

# MySQL connection details
 host="localhost"
 user="root"
 password="Admin@123"
#host="actmysql.hostbooks.in"
#user="sandboxinusers"
#password="9dmI0KplI&pyP0rS"

# Array of system databases to exclude
#system_databases=("hb_payroll_master" "information_schema" "mysql" "phpmyadmin" "performance_schema" "sys" "tmp")
system_databases=("information_schema" "mysql" "phpmyadmin" "performance_schema" "sys" "tmp")

# Fetch the list of client databases
databases=$(mysql -h "$host" -u "$user" -p"$password" -Bse "SHOW DATABASES")
# FIXED DB FOR LOCAL
# databases=("hb-accounts-database-v1")
# Loop through each client database
for database in $databases; do
    # Skip system databases
    skip=false
    for sys_db in "${system_databases[@]}"; do
        if [ "$sys_db" == "$database" ]; then
            skip=true
            break
        fi
    done

    if [ "$skip" = true ]; then
        continue
    fi

    echo "***********************************START FOR THIS DB($database)***************************************************"

    # Array of alter queries
    queries=(
        # your queries here
        "ALTER TABLE user_details
    ADD phone           VARCHAR(250) NULL AFTER address_id,
    ADD gender          VARCHAR(250) NULL AFTER phone,
    ADD secondary_email VARCHAR(250) NULL AFTER gender,
    ADD landline        VARCHAR(250) NULL AFTER secondary_email;"
    )

    # Connect to the database and execute the alter queries
    for query in "${queries[@]}"; do
        echo "$query"
        if mysql -h "$host" -u "$user" -p"$password" -D "$database" -e "$query"; then
            echo "DONE successfully $database"
        else
            echo "Error executing ALTER TABLE query for database $database"
            continue
        fi
    done

    echo "***********************************END FOR THIS DB($database)***************************************************"
done

